export class makepayment {
    id: number;
    paymentNumber: any;
    subsidiaryId: any;
    accountId: number;
    bankId:any;
    supplierId: any;
    paymentDate: any;
    currency: any;
    subsidiaryCurrency: string;
    exchangeRate: string;
    paymentMode: string;
    amount: number=0.00;
    bankTransactionType: string;
    bankReferenceNumber: number;
    memo: string;
    netsuiteId: number;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    subsidiaryName: string;
    supplierName: string;
    bankAccountName: string;
    advancePaymentNumber: string;
    advancePaymentType: string;
    advancePaymentAmount: string;
    paymentAmount: number=0.00;
    advancePayment: string;
    makePaymentList:makePaymentList[]=[];
    deleted: boolean;
    markall: boolean;
    voidDescription:string;
    voidDate:any;
    status:any;
    bankName:string;
    type?:string;
    approvalRoutingActive: boolean;
    FormDate:any;
    Todate:any;
    isApprovalButtonShowHide?: any;
    creator?:any;
    recent?:any;
}

export class paymentdeyailsbysupplier
{
invoiceId:number;
supplierId: number;
subsidiaryId:number;
poId:number;
locationId:number;
invoiceNo:string;
invStatus:string;
paymentTerm:string;
integratedId:string;
currency:string;
billTo:string;
shipTo:string;
invoiceDate:Date;
dueDate:Date;
fxRate:number;
amount:number;
taxAmount:number;
totalAmount:number;
paymentAmount:number;
amountDue:number;
invoiceItems:string;
createdDate?: Date;
createdBy?: string;
lastModifiedDate?: Date;
lastModifiedBy?: string;
active:boolean;
paymentamtdisable:boolean=true;
}

export class makePaymentList
{
   id?:number;
   type?:string;
   paymentNumber?:string;
   paymentId?:number;
   billNo?:string;
   invoiceId?:number;
   invoiceAmount:number;
   paidAmount:any;
   amountDue:any;
   createdDate?: Date;
   createdBy?: string;
   lastModifiedDate?: Date;
   lastModifiedBy?: string;
   paymentAmount:any;
   deleted?:boolean;
   active?:boolean=false;
   paymentamtdisable?:boolean=true;
   invoiceDate?:any;
   invoiceDateShow?:any;
   currency?:string;
   vds?:any;
   tds?:any;
   totalPaymentAmount?:any;
}
export class paymentRequestList {
    billNo: any;
    invoiceAmount: any;
    paymentAmount: any;
    amountDue: any;
    paidAmount: any;
    invoiceId: any;
    paymentamtdisable: any;
    active: any;
    type: any;
    vds: any;
    tds: any;
    totalPaymentAmount: any;
}
export class suppcurrency
{
code:string;
}

export class bank{
id:number;
name:string;
}


export class mpApproval{
id: number;
paymentNumber: any;
subsidiaryId: number;
accountId: any;
bankId: number;
supplierId: number;
paymentDate: Date;
currency: string;
subsidiaryCurrency: any;
exchangeRate: any;
paymentMode: string;
amount: any;
bankTransactionType: any;
bankReferenceNumber: any;
memo: any;
netsuiteId: any;
rejectedComments: any;
noteToApprover: any;
voidDescription: any;
voidDate: any;
type: any;
status: any;
nsMessage: any;
nsStatus: any;
integratedId: any;
paymentStatus: string;
approvedBy: any;
nextApprover: any;
nextApproverRole: any;
nextApproverLevel: any;
approverPreferenceId: any;
approverSequenceId: any;
approverMaxLevel: any;
createdDate: any;
createdBy: any;
lastModifiedDate: any;
lastModifiedBy: any;
subsidiaryName: string;
supplierName: string;
bankAccountName: any;
bankName: string;
paymentAmount: any;
approvedByName: any;
makePaymentList: any;
deleted: boolean;
approvalRoutingActive: boolean;
// for approval
selected:boolean;
NewrejectComments?: any;
isAdminRole:boolean;
advanceAmount:any;
comments:any;
}

export class SubsidiaryEntry {
id?: number;
name?: string;

}
export class supplierlist{
id?: any;
name?: string;

}      