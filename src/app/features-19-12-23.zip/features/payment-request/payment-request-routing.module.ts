import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {  PaymentRequestListComponent } from './payment-request-list/payment-request-list.component';
import {  PaymentRequestAddEditComponent } from './payment-request-add-edit/payment-request-add-edit.component';
const routes: Routes = [
  {
    path: '',
    component: PaymentRequestListComponent,
  },
  {
    path: 'list',
    component: PaymentRequestListComponent,
  },
  {
    path: 'list/:status',
    component: PaymentRequestListComponent,
  },
  {
    path: 'action/:action/:id',
    component: PaymentRequestAddEditComponent,
  },
  {
    path: 'action/:action/:id/:chkid',
    component: PaymentRequestAddEditComponent,
  },
  {
    path: 'action/:action',
    component: PaymentRequestAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PaymentRequestRoutingModule { }
