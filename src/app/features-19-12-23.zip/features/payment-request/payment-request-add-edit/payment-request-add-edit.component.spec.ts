import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentRequestAddEditComponent } from './payment-request-add-edit.component';

describe('PaymentRequestAddEditComponent', () => {
  let component: PaymentRequestAddEditComponent;
  let fixture: ComponentFixture<PaymentRequestAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentRequestAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentRequestAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
