import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { makepayment,paymentdeyailsbysupplier,makePaymentList,suppcurrency, bank, mpApproval } from '../model/payment-request-module'
import { PrimeNGConfig } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { MakePaymentComponent } from '../../reports/make-payment/make-payment.component';
@Component({
  selector: 'app-payment-request-add-edit',
  templateUrl: './payment-request-add-edit.component.html',
  styleUrls: ['./payment-request-add-edit.component.scss']
})

export class PaymentRequestAddEditComponent implements OnInit {
  makepayment: makepayment = new makepayment();
  paymentline:paymentdeyailsbysupplier[]=[];
  totalmakepayment: number = 0;
  paymentmode: any;
  Vendorlist: any[] = [];
  Subsidiarylist: any[] = [];
  BankaccountList: bank[]=[];
  lstCurrencyList: suppcurrency[] = [];
  makepaymentId: number = 0;
  private subscription: any;
  chkcurrMode:boolean=false;
  exHidden1:boolean=false;
  chkmarkall:boolean=false;
  exHidden:boolean=false;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  invoiceMode:boolean=false
  HistoryMode: boolean = false;
  displaySetupDialog:boolean=false;
  paymentamtdisenb:boolean=true;
  CrossCurrency:boolean;
  RetRoleDetails:any;
  role: any;
  loginId:any;
  SubsideryObject:any=[];
  makepaymentlist:boolean=false;
  ApprovalButtonShowHide:Number=0;
  makepaymentHistoryList: HistoryModel[] = [];
  isdisablecurr:boolean=true;
  empID: number;
  url:any;
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  isviewEditable:boolean=true;
  isloadbyId:boolean=true;
  advancedpayment:boolean=false;
  fiscalCalenderDTLS:any;
  showloader:boolean=false;
  isdisablevoid:boolean=true;
  isEditViewButton:boolean;
  ret_LoggerDtls:any
  RetloginDetails: any;
  approveMode:boolean=false;
  listURL:any;
  // For Role Base Access
  makepaymentline:makePaymentList[]=[];
  chkId:any;
  Chktooltip:boolean=false;
  display: boolean = false;
  isviewapprovereject:boolean=false;
  mpApproval: mpApproval = new mpApproval()
  appSequencelist:any[]=[];
  isAppSequenceVisivble:boolean;

  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private activatedRoute: ActivatedRoute,
    private makePaymentReport: MakePaymentComponent,
    private toastService: ToastService,) { 
      this.paymentmode = [{id:'Net Banking',value:'Net Banking'},{id:'Instrument',value:'Instrument'},{id:'NEFT',value:'NEFT'},{id:'RTGS',value:'RTGS'},{id:'PAYPAL',value:'PAYPAL'},{id:'Cheque',value:'Cheque'}];
    }
  ngOnInit(): void {
   
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);

    const LoginDetails:any=localStorage.getItem("LoggerDTLS");
    this.ret_LoggerDtls = JSON.parse(LoginDetails);
    this.loginId= this.ret_LoggerDtls.employeeId;
    this.RetRoleDetails=role_Dtls;
    
     const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
    {
      if(role_Dtls[0].rolePermissions[i].accessPoint == "Make Payment")
      {
        this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
        this.isEditable=role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable=role_Dtls[0].rolePermissions[i].view;
        if(this.isEditable==false)
        this.isviewEditable=false;
      }
    }
   
  // End For Role Base Access

    if (localStorage.getItem("Subsidiary") != null) {
      this.makepayment.subsidiaryId=Number(localStorage.getItem("Subsidiary"))
      this.CheckforCrossCurrencyadvpayment(Number(localStorage.getItem("Subsidiary")));
      //this.GetAccountType('Bank',Number(localStorage.getItem("Subsidiary")));
      this.GetAllVendorListbySubsidiaryID();
      this.HttpService.GetAll('/setup-ws/subsidiary/get?id='+this.makepayment.subsidiaryId,this.ret_LoggerDtls.token).subscribe(
        (res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        { this.makepayment.subsidiaryCurrency=res.currency.toString();}
        },
        (error) => {
         },
        () => {
       }
      );
      this.makepayment.supplierId=Number(localStorage.getItem("Supplier"));
      this.makepayment.type=localStorage.getItem("Type")?.toString();
      let currency_:any;
      currency_=localStorage.getItem("invoicecurrency")?.toString();
      this.lstCurrencyList=[];
      this.lstCurrencyList.push({code:currency_});
      this.makepayment.currency=currency_;
      this.makepayment.makePaymentList.push({
        type:localStorage.getItem("Type")?.toString(),
        billNo:localStorage.getItem("billno")?.toString(),
        invoiceAmount:Number(localStorage.getItem("invoiceamount")),
        paymentAmount:0,
        //amountDue:Number(localStorage.getItem("invoiceamount")),
         amountDue:Number(localStorage.getItem("dueamount")),
        invoiceDate:localStorage.getItem("invoiceDate"),
        paidAmount:0,
        invoiceId:Number(localStorage.getItem("invoiceId")),
        currency:currency_,
       // invoiceId:this.paymentline[i].invoiceId,
        paymentamtdisable:true,
        active:false
      });
      setTimeout(() => {
        // localStorage.clear();
        localStorage.removeItem("Subsidiary");
        localStorage.removeItem("Supplier");
        localStorage.removeItem("Type");
        localStorage.removeItem("billno");
        localStorage.removeItem("invoicecurrency");
        localStorage.removeItem("invoiceamount");
        localStorage.removeItem("dueamount");
        localStorage.removeItem("invoiceId");
        localStorage.removeItem("invoiceDate");
      if(this.makepayment.currency==this.makepayment.subsidiaryCurrency)
            {
              //this.isdisablecurr=true;
              this.chkcurrMode=false;
              this.exHidden1=true;
              this.exHidden=false;
              this.makepayment.exchangeRate="1.00";
            }
        else
            {
              
              this.chkcurrMode=true;
              this.exHidden1=false;
              this.exHidden=true;
            }
      },1000);
      this.makepayment.paymentDate=(new Date());
      this.advancedpayment=true;
      this.isdisablecurr=true;
    }
 
    this.GetAllSubsidiaryList();
    this.All_CurrencyList();
    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id'] && params['action'] != 'invoID') {
            this.makepaymentId = +params['id']; // (+) converts string 'id' to a number
            this.GetMakePaymentbyId();
          }
          else if(params['action'] == 'invoID') {
            this.getInvoiceDetails(params['id']);
          }
          
          //add by Anirban
          if (params['id']) {
            this.makepaymentId = +params['id']; // (+) converts string 'id' to a number
          }
          if (params['chkid']) {
            this.chkId = +params['chkid'];
           }
          // End add by Anirban

     
          if(params['action']== "approval")
          {
            this.listURL="/main/make-payment/MP_Approval";
          }
          else
          {
            this.listURL='/main/make-payment/list';
          }
          this.assignMode(params['action']);
         
        }else {
          this.listURL='/main/make-payment/list';
         } 
       
      },
      (error) => {
       }
    );
    if(this.addMode || this.invoiceMode)
    {
  
     this.loadrequestor();
    }
  }
   //get by Id for edit and view
     GetMakePaymentbyId() {
    this.isloadbyId=false;
    this.HttpService
      .GetById('/finance-ws/payment-request/get?id=' + this.makepaymentId, this.makepaymentId,this.ret_LoggerDtls.token)
      .subscribe((res) => {
        if(res.status == 401)
     { this.showAlert("Unauthorized Access !");
       this.router.navigate(['/login']);
     }
     else if(res.status == 404)
     { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
    }else {
          this.appSequencelist=res.approvers;
          let nextApprover=res.nextApprover;
          let isNextApproverFound:Boolean=false;
          if(this.appSequencelist != null)
         { for(let x=0;x<this.appSequencelist.length;x++)
          {
            let status='';
            if (this.appSequencelist[x].id == nextApprover)
            {
              isNextApproverFound=true;
              status='current';//this.appSequencelist[x]['status']=;
            }
            else
            {
              if(isNextApproverFound)
              {
                status='pending';
                //this.appSequencelist[x]['status']='pending';
              }else{
                status='approved';
                //this.appSequencelist[x]['status']='approved';
              }
            }
            this.appSequencelist[x]['status']=status;
          }}
      if(this.chkId==1)
        {
          this.isviewapprovereject=true;
        }
         this.isEditViewButton=(res.status =='Pending Approval' || res.status =='Partially Approved' || res.status =='Voided') ? false:true;
        if(res.status=='Pending Approval' || res.status=='Applied' || res.status=='Partially Applied' || res.status=='Approved' || res.status=='Closed' || res.status=='Voided' || res.status=='Partially Approved') //Send Approval Mode
        {
          this.ApprovalButtonShowHide=0;
        }
        else{
          this.ApprovalButtonShowHide=1;
        }
        if(res.status=="Approved")
        {
          this.isdisablevoid=false;        
        }
        else if(res.status=="Voided")
        {
          this.isdisablevoid=true;        
        }
  
       this.makepayment=res;
       this.makepayment.paymentDate=this.makepayment.paymentDate!=null?new Date(this.makepayment.paymentDate):"";
       this.GetAllVendorListbySubsidiaryID();
       this.GetAccountType('Bank',this.makepayment.subsidiaryId);
       this.makepayment.exchangeRate=parseFloat(this.makepayment.exchangeRate).toFixed(2);
        for(let i=0;i<=this.makepayment.makePaymentList.length;i++)
        {
          this.makepayment.makePaymentList[i].paymentamtdisable=true;
          this.makepayment.makePaymentList[i].paidAmount=parseFloat(this.makepayment.makePaymentList[i].paidAmount).toFixed(2)
    
        }}
      });
      setTimeout(() => {this.isloadbyId=true;},1000);
     }
     getInvoiceDetails(invoiceId:any){
      this.HttpService
        .GetById('/finance-ws/invoice/get?invoiceId=' + invoiceId, invoiceId, this.ret_LoggerDtls.token)
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res.errorMessage) {
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );
            } else {
              this.makepayment.subsidiaryId=res.subsidiaryId;
              this.makepayment.supplierId=res.supplierId;
              this.makepayment.currency=res.currency;
              //this.makepayment.subsidiaryCurrency=res.currency;
              this.makepayment.paymentDate=this.makepayment.paymentDate!=null?new Date(this.makepayment.paymentDate):"";
              this.GetAllVendorListbySubsidiaryID();
              this.loadSupplierCurrencyFromInvoice(res.supplierId)
              this.loadBankAccountFromInvoice(res.subsidiaryId);
              this.AssignCurrencyForSubsidiary(res.subsidiaryId);

              this.makepayment.makePaymentList=[];
                    this.makepayment.makePaymentList.push({
                    type:"AP Invoice",
                    billNo:res.invoiceNo,
                    invoiceAmount:res.totalAmount,
                   paymentAmount:null,
                   amountDue:res.amountDue,
                   paidAmount:null,
                    invoiceId:invoiceId,
                    currency:res.currency,
                    paymentamtdisable:true,
                    active:false,
                    invoiceDate:new Date(res.invoiceDate)
      
                  });
              

              //this.loadPaymentListFromInvoice(res.supplierId,res.currency);
              //this.GetAccountType('Bank',res.subsidiaryId);

            }
          }
  
        });
    }
    AssignCurrencyForSubsidiary(subsidiaryId: any) {
      this.HttpService.GetById('/setup-ws/subsidiary/get' + '?id=' + subsidiaryId, subsidiaryId,this.ret_LoggerDtls.token).subscribe( 
        (res) => {
          if(res.status == 401)
        { 
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { 
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {
          this.makepayment.subsidiaryCurrency=res.currency;
          //this.pr.currency = res.currency;
        }
           },
           (error) => {
            this.showAlert(error);
           }
         );
    }
  //Save Make Payent
  savemakepayment() 
  {
      if(this.makepayment.subsidiaryId==undefined)
      {
        this.showAlert("Please select Subsidiary");
        return;
      }
      if(this.makepayment.bankId==undefined)
      {
        this.showAlert("Please select Bank Account");
        return;
      }
      if(this.makepayment.supplierId==undefined)
      {
        this.showAlert("Please select Supplier");
        return;
      }
      if(this.makepayment.paymentDate==undefined)
      {
        this.showAlert("Please select Payment Date");
        return;
      }
      if(this.makepayment.currency!=this.makepayment.subsidiaryCurrency)
      {
        if(this.makepayment.exchangeRate==undefined || this.makepayment.exchangeRate=="")
        {
          this.showAlert("Please enter Exchange Rate");
          return;
        }
     }
      if(this.makepayment.paymentMode==undefined)
      {
        this.showAlert("Please select Payment Mode");
        return;
      }
      this.makepaymentline=[];
      for(let i=0;i<this.makepayment.makePaymentList.length;i++)
      {
        if(this.addMode)
        {
          if(this.makepayment.makePaymentList[i].active==true)
          {
                this.makepaymentlist=true;
                this.makepaymentline.push({
                  billNo:this.makepayment.makePaymentList[i].billNo,
                  invoiceAmount:this.makepayment.makePaymentList[i].invoiceAmount,
                  paymentAmount:this.makepayment.makePaymentList[i].paymentAmount,
                  amountDue:this.makepayment.makePaymentList[i].amountDue,
                  paidAmount:this.makepayment.makePaymentList[i].paidAmount,
                  invoiceId:this.makepayment.makePaymentList[i].invoiceId,
                  paymentamtdisable:true,
                  active:this.makepayment.makePaymentList[i].active,
                  type:this.makepayment.makePaymentList[i].type,
                  invoiceDate:Date.parse(this.makepayment.makePaymentList[i].invoiceDate),
                  vds:this.makepayment.makePaymentList[i].vds,
                  tds:this.makepayment.makePaymentList[i].tds,
                  totalPaymentAmount:this.makepayment.makePaymentList[i].totalPaymentAmount
               });
         }
        }
        else
        {
          if(this.makepayment.makePaymentList[i].active==true)
          {
                this.makepaymentlist=true;
                this.makepaymentline.push({
                  id:this.makepayment.makePaymentList[i].id,
                  billNo:this.makepayment.makePaymentList[i].billNo,
                  invoiceAmount:this.makepayment.makePaymentList[i].invoiceAmount,
                  paymentAmount:this.makepayment.makePaymentList[i].paymentAmount,
                  amountDue:this.makepayment.makePaymentList[i].amountDue,
                  paidAmount:this.makepayment.makePaymentList[i].paidAmount,
                  invoiceId:this.makepayment.makePaymentList[i].invoiceId,
                  paymentamtdisable:true,
                  active:this.makepayment.makePaymentList[i].active,
                  type:this.makepayment.makePaymentList[i].type,
                  invoiceDate:Date.parse(this.makepayment.makePaymentList[i].invoiceDate),
                  vds:this.makepayment.makePaymentList[i].vds,
                  tds:this.makepayment.makePaymentList[i].tds,
                  totalPaymentAmount:this.makepayment.makePaymentList[i].totalPaymentAmount
               });
               
         }
        }
   
      }  
 if(this.addMode)
 {
      if(this.makepaymentlist==false)
      {
        this.showErrorBillLine();
        return;
      }
 }
      this.makepaymentlist=false;
      if(this.addMode)
    {
      for(let i=0;i<this.makepayment.makePaymentList.length;i++)
      {
        if(this.makepayment.makePaymentList[i].active==true)
        {
           if(new Date(this.makepayment.paymentDate) < new Date(this.makepayment.makePaymentList[i].invoiceDate))
            {
              let pdate: any = new Date(this.makepayment.paymentDate).getDate();
              let Pmonths: any = new Date(this.makepayment.paymentDate).getMonth() + 1;
              let Pyear: any = new Date(this.makepayment.paymentDate).getFullYear();
              let idate: any = new Date(this.makepayment.makePaymentList[i].invoiceDate).getDate();
              let imonths: any = new Date(this.makepayment.makePaymentList[i].invoiceDate).getMonth() + 1;
              let iyear: any = new Date(this.makepayment.makePaymentList[i].invoiceDate).getFullYear();

              if(pdate==idate && Pmonths==imonths && Pyear==iyear)
              {

              }
              else
              {
                this.showAlert("Payment Date must be greater than and equal to Invoice Date");
                return;
  
              }
              }
             if(this.makepayment.makePaymentList[i].paymentAmount<=0)
             {
              this.showErrorchlpaymentamt();
              return;
             }
        }
      }
    }
    
    else if(this.editMode)
    {
      
      for(let i=0;i<this.makepayment.makePaymentList.length;i++)
      {

            if(new Date(this.makepayment.paymentDate) < new Date(this.makepayment.makePaymentList[i].invoiceDate))
            {
              this.showAlert("Payment Date must be greater than and equal to Invoice Date");
              return;
            }
        
      }
    }
    let mp_days:any = new Date(this.makepayment.paymentDate).getDate();
    let mp_months:any = new Date(this.makepayment.paymentDate).getMonth()+1;
    let mp_year:any = new Date(this.makepayment.paymentDate).getFullYear();
    if(mp_months<10)
    {
      mp_months="0".toString()+mp_months.toString();
    }
    if(mp_days<10)
    {
      mp_days="0".toString()+mp_days.toString();
    }
    //this.makepayment.paymentDate=mp_year+"-"+mp_months+"-"+mp_days;
    this.makepayment.makePaymentList=[];
    this.makepayment.makePaymentList=this.makepaymentline;
    if(this.addMode){ this.makepayment.createdBy=this.ret_LoggerDtls.username;this.makepayment.lastModifiedBy=this.ret_LoggerDtls.username}
    else if(!this.addMode){ this.makepayment.lastModifiedBy=this.ret_LoggerDtls.username}
   if(this.makepayment.type=="Advance Payment")
   {
    this.showloader=true;
    this.HttpService.Insert('/finance-ws/payment-request/save', this.makepayment,this.ret_LoggerDtls.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else if (res && res.id > 0) {
          this.showloader=false;
          this.showSuccess();
          this.router.navigate(['/main/make-payment/list']);
        } else {
          this.showloader=false;
          this.showError();
         }
      },
      (error) => {
        this.showloader=false;
       },
      () => {}
    );
   }
   else
   {
    this.showloader=true;
    if(this.addMode){ this.makepayment.createdBy=this.ret_LoggerDtls.username;this.makepayment.lastModifiedBy=this.ret_LoggerDtls.username}
    else if(!this.addMode){ this.makepayment.lastModifiedBy=this.ret_LoggerDtls.username}
    this.HttpService.Insert('/finance-ws/payment-request/save', this.makepayment,this.ret_LoggerDtls.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else if (res && res.id > 0) {
          this.showloader=false;
          this.showSuccess();
          this.router.navigate(['/main/make-payment/list']);
        } else {
          this.showloader=false;
          this.showError();
         }
      },
      (error) => {
        this.showloader=false;
        this.showAlert(error);
      },
      () => {}
    );
   }
  }
  savemakepaymentforvoid() 
  {
      if(this.makepayment.subsidiaryId==undefined)
      {
        this.showAlert("Please select Subsidiary");
        return;
      }
      if(this.makepayment.bankId==undefined)
      {
        this.showAlert("Please select Bank Account");
        return;
      }
      if(this.makepayment.supplierId==undefined)
      {
        this.showAlert("Please select Supplier");
        return;
      }
      if(this.makepayment.paymentDate==undefined)
      {
        this.showAlert("Please select Payment Date");
        return;
      }
      if(this.makepayment.currency!=this.makepayment.subsidiaryCurrency)
      {
        if(this.makepayment.exchangeRate==undefined || this.makepayment.exchangeRate=="")
        {
          this.showAlert("Please enter Exchange Rate");
          return;
        }
     }
      if(this.makepayment.paymentMode==undefined)
      {
        this.showAlert("Please select Payment Mode");
        return;
      }

    if(this.makepayment.makePaymentList[0].type=="Advance Payment")
    {
      this.HttpService.GetAll('/finance-ws/payment/check-payment-for-void?id='+this.makepaymentId+'&type=Advance Payment',this.ret_LoggerDtls.token)
      .subscribe((res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
       else if(res == true)
       {
        this.HttpService.GetAll('/finance-ws/advance/void-payment-for-advance?paymentId='+this.makepaymentId+'&type=Advance Payment',this.ret_LoggerDtls.token)
        .subscribe((res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
         else if(res)
          {
            this.showloader=false;
            this.showSuccessVoidPayment();
            this.displaySetupDialog=false;
            this.router.navigate(['/main/make-payment/list']);
          }
          else{
            this.showloader=false;
            this.showError();
          }
          });
       }
      });


      //////////////////////Add for advance payment void////////////////////////
      this.makepaymentline=[];
      this.makepayment.makePaymentList=[];
      this.showloader=true;
      this.HttpService.Insert('/finance-ws/payment/save', this.makepayment,this.ret_LoggerDtls.token).subscribe(
        (res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else if (res && res.id > 0) {
            this.showloader=false;
            this.voidpayment();
            this.displaySetupDialog=false;
          } else {
            this.showloader=false;
            this.showError();
           }
        },
        (error) => {
          this.showloader=false;
         },
        () => {}
      );
      //////////////////////////////////////////////////////////////////////////

    
    }
    else
    {
    this.makepaymentline=[];
    this.makepayment.makePaymentList=[];
    this.showloader=true;
    this.HttpService.Insert('/finance-ws/payment/save', this.makepayment,this.ret_LoggerDtls.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else if (res && res.id > 0) {
          this.showloader=false;
          this.voidpayment();
          this.displaySetupDialog=false;
        } else {
          this.showloader=false;
          this.showError();
         }
      },
      (error) => {
        this.showloader=false;
       },
      () => {}
    );
   }
  }
  clearmakepayment()
  {
    if (this.editMode)
      this.router.navigate(['/main/make-payment/list']);
    else
    location.reload();
   }
  //load account base of type,all vendor list,subsidiary based on id
  Loadlov()
  {
    if(this.isloadbyId==true)
    {
      
      this.Vendorlist=[];
      this.BankaccountList=[];
      this.makepayment.makePaymentList=[];
      // this.GetAllSubsidiaryList();
      //this.makepayment.currency=undefined;
      this.makepayment.exchangeRate="";
      this.makepayment.subsidiaryCurrency="";
    }  
    this.GetAllVendorListbySubsidiaryID();
    this.HttpService.GetAll('/setup-ws/subsidiary/get?id='+this.makepayment.subsidiaryId,this.ret_LoggerDtls.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       {this.makepayment.subsidiaryCurrency=res.currency.toString();}
      },
      (error) => {
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
    if(this.makepayment.type!="Advanced Payment")
    {
    this.CheckforCrossCurrency();
    }
    this.getRanges();
  }
  CheckforCrossCurrency()
  {
   
    this.HttpService.GetAll('/setup-ws/preference/get-cross-currency-active-by-subsidiary?subsidiaryId='+this.makepayment.subsidiaryId,this.ret_LoggerDtls.token).subscribe(
      (res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
         else
       { this.CrossCurrency=res;
        if(this.CrossCurrency==false)
        {
          
          //this.Loadsuppliercurrbysubsidiary();
          //this.isdisablecurr=false;
          this.chkcurrMode=false;
          this.exHidden1=true;
          this.exHidden=false;
          this.makepayment.exchangeRate="1.00";
        }
        else if(this.CrossCurrency==true)
        {
          this.GetAccountTypeMulticurrency("Bank",this.makepayment.subsidiaryId);
        }}
      },
      (error) => {
       },
      () => {
      }
    );
  }
  Loadsuppliercurr()
  {
    if(this.isloadbyId==true)
    {
      this.makepayment.makePaymentList=[];
      this.makepayment.currency="";
      this.makepayment.exchangeRate="";
      this.GetAllVendorListbySubsidiaryID();
    }
    if(localStorage.getItem("Type")?.toString()=="Advance Payment")
    {
      if(this.makepayment.currency==this.makepayment.subsidiaryCurrency)
      {
        //this.isdisablecurr=true;
        this.chkcurrMode=false;
        this.exHidden1=true;
        this.exHidden=false;
        this.makepayment.exchangeRate="1.00";
      }
      else
          {
            this.chkcurrMode=true;
            this.exHidden1=false;
            this.exHidden=true;
          }
    }
    else
    {
      this.HttpService.GetAll('/masters-ws/supplier/get-currency-by-supplier?supplierId='+this.makepayment.supplierId,this.ret_LoggerDtls.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
      {  this.lstCurrencyList=[];
        if(this.CrossCurrency)
        {
          this.isdisablecurr=false;
          this.lstCurrencyList=[];
          for(let i=0;i<res.length;i++)
          {
            this.lstCurrencyList.push({code:res[i].supplierCurrency});
            if(res[i].preferredCurrency==true)
            {
              this.makepayment.currency=res[i].supplierCurrency
            }
          }
         /* if(this.makepayment.currency==this.makepayment.subsidiaryCurrency)
          {
            //this.isdisablecurr=true;
            this.chkcurrMode=false;
            this.exHidden1=true;
            this.exHidden=false;
            this.makepayment.exchangeRate="1.00";
          }
          else
          {
            this.chkcurrMode=true;
            this.exHidden1=false;
            this.exHidden=true;
          }*/

          if(!this.CrossCurrency)
          {
            this.chkcurrMode=false;
            this.exHidden1=true;
            this.exHidden=false;
            this.makepayment.exchangeRate="1.00";
          }
          if(res.length<=1)
          {
            this.isdisablecurr=true;
          }
          else
          {
            this.isdisablecurr=false;
          }
       }
        else
        {
          for(let i=0;i<res.length;i++)
          {
            this.lstCurrencyList.push({code:res[i].supplierCurrency});
            if(res[i].preferredCurrency==true)
            {
              this.makepayment.currency=res[i].supplierCurrency
            }
          }
          if(res.length<=1)
          {
            this.isdisablecurr=true;
          }
          else
          {
            this.isdisablecurr=false;
          }
         /* if(this.makepayment.currency==this.makepayment.subsidiaryCurrency)
          {
           // this.isdisablecurr=true;
            this.chkcurrMode=false;
            this.exHidden1=true;
            this.exHidden=false;
            this.makepayment.exchangeRate="1.00";
          }
          else
          {
            this.chkcurrMode=true;
            this.exHidden1=false;
            this.exHidden=true;
          }*/

          if(!this.CrossCurrency)
          {
            this.chkcurrMode=false;
            this.exHidden1=true;
            this.exHidden=false;
            this.makepayment.exchangeRate="1.00";
          }
        }}
      },
      (error) => {
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
    }
    if (localStorage.getItem("Subsidiary") === null) {
      setTimeout(() => { this.loadLineitems();},500);
     }
  }
  Loadsuppliercurrbysubsidiary()
  {
      this.HttpService.GetAll('/masters-ws/supplier/get?id='+this.makepayment.supplierId,this.ret_LoggerDtls.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {this.makepayment.currency=res.supplierSubsidiary[0].supplierCurrency;}
        /*if(this.makepayment.currency==this.makepayment.subsidiaryCurrency)
        {
          this.chkcurrMode=false;
          this.exHidden1=true;
          this.exHidden=false;
          this.makepayment.exchangeRate="1.00";
        }
        else
        {
          this.chkcurrMode=true;
          this.exHidden1=false;
          this.exHidden=true;
          
        }*/
      },
      (error) => {
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
  }
  loadLineitems()
  {
    if(!this.CrossCurrency)
    {this.GetAccountType('Bank',this.makepayment.subsidiaryId);}
    

    if(this.makepayment.currency==this.makepayment.subsidiaryCurrency)
    {
     // this.isdisablecurr=true;
      this.chkcurrMode=false;
      this.exHidden1=true;
      this.exHidden=false;
      this.makepayment.exchangeRate="1.00";
    }
    else
    {
      this.chkcurrMode=true;
      this.exHidden1=false;
      this.exHidden=true;
    }
    this.HttpService.GetAll('/finance-ws/payment/get-payment-details-by-supplier-and-currency?supplierId='+this.makepayment.supplierId+'&currency='+this.makepayment.currency,this.ret_LoggerDtls.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
     {   this.paymentline=res;
        //this.makepayment.makePaymentList.push(res);
        this.makepayment.makePaymentList=[];
        for(let i=0;i<this.paymentline.length;i++)
        {
              this.makepayment.makePaymentList.push({
              type:"AP Invoice",
              billNo:this.paymentline[i].invoiceNo,
              invoiceAmount:this.paymentline[i].totalAmount,
              paymentAmount:this.paymentline[i].paymentAmount,
              amountDue:this.paymentline[i].amountDue,
              paidAmount:this.paymentline[i].amount,
              invoiceId:this.paymentline[i].invoiceId,
              currency:this.paymentline[i].currency,
              paymentamtdisable:true,
              active:false,
              invoiceDate:new Date(this.paymentline[i].invoiceDate)

            });
        }}
      },
      (error) => {
       },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
  }
  GetAllSubsidiaryList_old(){
    this.HttpService.GetAll("/setup-ws/subsidiary/get/all",this.ret_LoggerDtls.token)
    .subscribe(res => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
      {this.Subsidiarylist=res.list;}
      });
   }
   GetAllSubsidiaryList() {

    this.Subsidiarylist=[];
    //if(this.RetRoleDetails[0].selectedAccess == 'ADMIN')
    if(this.RetloginDetails.userType=='SUPERADMIN')
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.ret_LoggerDtls.token).subscribe(
    //this.httpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
       else {
        this.Subsidiarylist=res;
      }
        // this.GetSubsideryListLov();
      },
      (error) => {
      
      }
    );
  }else if(this.RetloginDetails.userType=='ENDUSER')
  {
    this.Subsidiarylist.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });
  }
  }
   getAllSubsidiaryReloadList()
   {
    /*this.Subsidiarylist=[];
    this.Vendorlist=[];
    this.BankaccountList=[];
    this.makepayment.makePaymentList=[];
    this.GetAllSubsidiaryList();
    this.makepayment.currency="";
    this.makepayment.exchangeRate="";
    this.makepayment.subsidiaryCurrency="";*/
    location.reload();
   }
   //Load Bank Account
   GetAccountTypeMulticurrency(type: string,id:number) {
  
    this.HttpService.GetAll('/masters-ws/bank/get-by-subsidiary-id?subsidiaryId='+id,this.ret_LoggerDtls.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        { this.BankaccountList = [];
         for(let i=0;i<res.length;i++)
         {
              if(res[i].active==true)
              {
                this.BankaccountList.push({id:res[i].id,name:res[i].name})
              }
         }
    }
      },
      (error) => {
        this.showAlert(error);
       },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
  }
  GetAccountType(type: string,id:number) {
      this.HttpService.GetAll('/masters-ws/bank/get-by-subsidiary-id?subsidiaryId='+id,this.ret_LoggerDtls.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        { this.BankaccountList = [];
         if(this.addMode)
         {
          for(let i=0;i<res.length;i++)
          {
               if(this.makepayment.currency==res[i].currency)
               {
                 this.BankaccountList.push({id:res[i].id,name:res[i].name})
               }
          }
         }
         else
         {
          for(let i=0;i<res.length;i++)
         {
              this.BankaccountList.push({id:res[i].id,name:res[i].name})
         }
         }}
      },
      (error) => {
       },
      () => {
        }
    );
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        this.invoiceMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.invoiceMode = false;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.invoiceMode = false;
        break;
        case 'invoID':
        this.invoiceMode = true;
        break;
        case 'approval':
          this.viewMode = true;
          this.addMode = false;
          this.editMode = false;
          this.approveMode=true;
    break;
      default:
        break;
    }
  }
  getAllBankaccountReload()
  {
    this.BankaccountList=[];
    this.GetAccountType('Bank',this.makepayment.subsidiaryId);
  }
  //Load all vendor respect of subsidiary id 
  GetAllVendorListbySubsidiaryID() {
    this.HttpService.GetAll('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId='+this.makepayment.subsidiaryId,this.ret_LoggerDtls.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Vendorlist=res;
        if(!this.addMode)
        {
          let _vendor = this.Vendorlist.find(
            (o) => o.id == this.makepayment.supplierId
          );
          if(!_vendor)
          {
          this.getsupplierById();
          }
        }}
      },
      (error) => {
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
  }
  getAllSupplierReloadList()
  {
    this.makepayment.makePaymentList=[];
    this.makepayment.currency="";
    this.makepayment.exchangeRate="";
    this.Vendorlist=[];
    this.lstCurrencyList=[];
    this.GetAllVendorListbySubsidiaryID();
  }
  //Load Currency ddl
  All_CurrencyList() {
    this.HttpService.GetAll("/setup-ws/currency/get/all",this.ret_LoggerDtls.token)
      .subscribe(res => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {this.lstCurrencyList = res;}
      });
  }
  //reload currency
  getAllCurrencyReloadList()
  {
    this.lstCurrencyList=[];
    this.All_CurrencyList();
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Make Payment Saved Successfully!'
    );
  }
  showSuccessVoidPayment() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Void Payment Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Make Payment!'
    );
  }
  showErrorAmount() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Payment Amount must be smaller than Due Amount!'
    );
  }
  showErrorchlpaymentamt() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Payment amount must be greater than 0!'
    );
  }
  showErrorBillLine() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select atleast one line!'
    );
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  // switch enable disable
    chkenable()
  {
    if(this.makepayment.markall)
    {
      for(let i=0;i<this.makepayment.makePaymentList.length;i++)
      {
      this.makepayment.makePaymentList[i].active=true;
      this.makepayment.makePaymentList[i].paymentamtdisable=false;
      }
    }
      else
      {
        for(let i=0;i<this.makepayment.makePaymentList.length;i++)
        {
        this.makepayment.makePaymentList[i].active=false;
        this.makepayment.makePaymentList[i].paymentamtdisable=true;
        this.makepayment.makePaymentList[i].paymentAmount=null;
        this.makepayment.makePaymentList[i].vds=null;
        this.makepayment.makePaymentList[i].tds=null;
        }
      }
    }
   // Enable disable the payment amount
    paymentamtdisable(rowindex:number)
    {
      debugger

      if(this.makepayment.makePaymentList[rowindex].active==true)
      {
              // this.paymentamtdisenb=false;
              this.makepayment.makePaymentList[rowindex].paymentamtdisable=false;
      }
      else{
               // this.paymentamtdisenb=true;
               this.makepayment.amount-=this.makepayment.makePaymentList[rowindex].paymentAmount > 0 ?parseFloat(this.makepayment.makePaymentList[rowindex].paymentAmount.toString()) :0;
               this.makepayment.makePaymentList[rowindex].paymentAmount=null;
               this.makepayment.makePaymentList[rowindex].vds=null;
               this.makepayment.makePaymentList[rowindex].tds=null;
               this.makepayment.makePaymentList[rowindex].paymentamtdisable=true;
      }
    }
    //Calculate header amount in respect of line
    getdueamt(rowindex:number)
    {
     if(this.makepayment.makePaymentList[rowindex].paymentAmount>this.makepayment.makePaymentList[rowindex].amountDue)
     {
          this.showErrorAmount();
          this.makepayment.makePaymentList[rowindex].paymentAmount=0.00;
     }
      const amt=0;
      this.makepayment.amount=0;
      for(let i=0;i<this.makepayment.makePaymentList.length;i++)
      {
        if(this.makepayment.makePaymentList[i].active)
        {
          this.makepayment.amount+=parseFloat(this.makepayment.makePaymentList[i].paymentAmount.toString());
        }
      }
      //this.makepayment.amount=amt;
      
    }
    voidpayment()
    {
      let days_void:any = new Date(this.makepayment.voidDate).getUTCDate();
      if(days_void<10)
      {
        days_void="0"+days_void;
      }
      let months_void:any = new Date(this.makepayment.voidDate).getUTCMonth()+1;
      
      if(months_void<10)
      {
        months_void="0"+months_void;
      }
      let year_void:any = new Date(this.makepayment.voidDate).getUTCFullYear();
      let date_full=days_void+"-"+months_void+"-"+year_void;

      this.HttpService.GetAll('/finance-ws/payment/delete?paymentId='+this.makepaymentId+'&type=Make Payment&voidDate='+date_full+'',this.ret_LoggerDtls.token)
      .subscribe((res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else if(res)
        {
          this.showSuccessVoidPayment();
          this.router.navigate(['/main/make-payment/list']);
        }
        });
    }
    oncancel()
    {
     this.displaySetupDialog=false;
    }
    onsavedialog()
    {
        if(this.makepayment.voidDescription==undefined || this.makepayment.voidDescription=="")
        {
        
         this.showAlert("Please input Void Description !");
         return;
        }
        if(this.makepayment.voidDate==undefined)
        {
         this.showAlert("Please input Void Date !");
         return;
        }
        this.savemakepaymentforvoid();
    }
    opendialog()
    {
      this.displaySetupDialog=true;
    }
    getsupplierById()
    {
      this.HttpService.GetAll('/masters-ws/supplier/get?id='+this.makepayment.supplierId,this.ret_LoggerDtls.token).subscribe(
        (res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
          else
         { this.Vendorlist.push({name:res.name,id:res.id})
          this.makepayment.supplierId=res.id;}
        },
        (error) => {
          this.showAlert(error)
         },
        () => {
         }
      );
    }
    decimalFilter(event: any) {
      const reg = /^-?\d*(\.\d{0,2})?$/;
      let input = event.target.value + String.fromCharCode(event.charCode);
     if (!reg.test(input)) {
          event.preventDefault();
      }
    }
    decimalfrectionQuntity(event: any,index:any,fieldType:any=null) {
      
      let VDS=fieldType == 'vds' ?  event.value > 0 ?parseFloat(event.value):0:(this.makepayment.makePaymentList[index].vds > 0 ? parseFloat(this.makepayment.makePaymentList[index].vds):0 );
      let TDS=fieldType == 'tds' ?  event.value > 0 ?parseFloat(event.value):0:(this.makepayment.makePaymentList[index].tds > 0 ? parseFloat(this.makepayment.makePaymentList[index].tds):0 );
      let PayAmount=fieldType == 'payble' ? event.value > 0 ?parseFloat(event.value):0:(this.makepayment.makePaymentList[index].paymentAmount > 0 ?parseFloat(this.makepayment.makePaymentList[index].paymentAmount):0);
      let TotalPayAmount=VDS + TDS + PayAmount ;

      this.makepayment.makePaymentList[index].vds=VDS;
      this.makepayment.makePaymentList[index].tds=TDS;
      this.makepayment.makePaymentList[index].totalPaymentAmount=TotalPayAmount;
      //(fieldType == 'vds' ? parseFloat(event.value):(this.makepayment.makePaymentList[index].vds > 0 ? parseFloat(this.makepayment.makePaymentList[index].vds):0 )) +
      //(fieldType == 'tds' ? parseFloat(event.value):(this.makepayment.makePaymentList[index].tds > 0 ? parseFloat(this.makepayment.makePaymentList[index].tds):0 ))+ 

      let amount_due=parseFloat(this.makepayment.makePaymentList[index].amountDue.toFixed(2));
      let pay_amt=parseFloat(this.makepayment.makePaymentList[index].paymentAmount);
      //if(pay_amt>amount_due)
      if(TotalPayAmount>amount_due)
      //this.makepayment.makePaymentList[index].amountDue)
      {
          this.showErrorAmount();
          this.makepayment.makePaymentList[index].paymentAmount=0.00;
          if(this.invoiceMode)
          {
            this.makepayment.amount=0
          }
          return; 
      }
      else
      {
        this.makepayment.makePaymentList[index].paymentAmount=PayAmount;
        // if(event.target.value !="")
        // this.makepayment.makePaymentList[index].paymentAmount=parseFloat(event.target.value).toFixed(2)
      }
      const amt=0;
      this.makepayment.amount=0;
       for(let i=0;i<this.makepayment.makePaymentList.length;i++)
       {
         if(this.makepayment.makePaymentList[i].active)
         {
           this.makepayment.amount+=parseFloat(this.makepayment.makePaymentList[i].paymentAmount.toString());
         }
       }
    }
    decimalfrectionQuntityExchangeR(event: any) {
          if(event.target.value !="")
          this.makepayment.exchangeRate=parseFloat(event.target.value).toFixed(2)
    }
    GetOptionLabel(Name:any)
    {
      this.makepayment.bankAccountName=Name.originalEvent.currentTarget.ariaLabel;
      this.HttpService
      .GetAll('/masters-ws/bank/get?id='+ this.makepayment.bankId,this.ret_LoggerDtls.token)
      .subscribe((res) => {
        
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
     else  if(res)
        {
          if(this.CrossCurrency)
          {
               if(res.currency==this.makepayment.currency)
               {
                this.chkcurrMode=false;
                this.exHidden1=true;
                this.exHidden=false;
                this.makepayment.exchangeRate="1.00";
               }
               else
               {
                this.chkcurrMode=true;
                this.exHidden1=false;
                this.exHidden=true;
               }
          }
          else
          {
            this.chkcurrMode=false;
            this.exHidden1=true;
            this.exHidden=false;
            this.makepayment.exchangeRate="1.00";
          }
        }
      });
     
    }
    handleTabChange(event: any) {
      //Fetch History if the selected tab index is History Tab index
      if (event.index == 1) {
        this.LoadHistory();
       // this.displayAddressDialog = false;
      }
    }
    LoadHistory() {
      if (this.makepaymentHistoryList.length == 0)
        this.HttpService
          .GetAll('/finance-ws/payment-request/get-history?id='+ this.makepaymentId +'&pageSize=100',this.ret_LoggerDtls.token)
          .subscribe((res) => {
            if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
           {  this.makepaymentHistoryList = res;}
          });
    }
    CheckVoidDate()
    {
      if(new Date(this.makepayment.voidDate) < new Date(this.makepayment.paymentDate))
         {

          let mpvdays:any = new Date(this.makepayment.voidDate).getDate();
          let mpvmonths:any = new Date(this.makepayment.voidDate).getMonth()+1;
          let mpvyear:any = new Date(this.makepayment.voidDate).getFullYear();
          let mpdays:any = new Date(this.makepayment.paymentDate).getDate();
          let mpmonths:any = new Date(this.makepayment.paymentDate).getMonth()+1;
          let mpyear:any = new Date(this.makepayment.paymentDate).getFullYear();

          if(mpvdays==mpdays && mpvmonths==mpmonths && mpvyear==mpyear)
          {

          }
          else
          {
            this.showAlert("Void Date should be equal or greater than Payment Date");
            this.makepayment.voidDate={};
            return;
          }

     
        }
    }
    getRanges() {
      if(this.makepayment.subsidiaryId != undefined && this.makepayment.paymentDate !=undefined){
        this.HttpService
        .GetById('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId=' + this.makepayment.subsidiaryId, this.makepayment.subsidiaryId,this.ret_LoggerDtls.token)
        .subscribe((res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else  if (res) {
            this.fiscalCalenderDTLS=res;
            if(this.fiscalCalenderDTLS != null && this.fiscalCalenderDTLS.fiscalCalanderAccounting.length >0)
            {
            let AllowMonths: any = "Allow Months: ";
            let IsDateAvailable:boolean = false;
        
            var Dummymonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        
            let PRdays: any = new Date(this.makepayment.paymentDate).getDate();
            let PRmonths: any = new Date(this.makepayment.paymentDate).getMonth() + 1;
            let PRyear: any = new Date(this.makepayment.paymentDate).getFullYear();
            let PRDate: any = this.makepayment.paymentDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""
        
            for (let x = 0; x < this.fiscalCalenderDTLS.fiscalCalanderAccounting.length; x++) {
              AllowMonths += this.fiscalCalenderDTLS.fiscalCalanderAccounting.length == (x + 1) ? this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month : this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month + " , "
        
              if (PRDate >= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].fromDate && PRDate <= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].toDate && this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month == Dummymonths[PRmonths - 1] + "-" + PRyear) {
                IsDateAvailable = true;
              }
            }
        
            if (IsDateAvailable == false) {
              this.showAlert("Selected Date is Not available in Fiscal Calendar ! " + AllowMonths);
              this.makepayment.paymentDate = {};
            }
          }
          else{
            this.showAlert("Selected Date is Not available in Fiscal Calendar ! ");
            this.makepayment.paymentDate = {};
          }
          } else {
            this.showAlert("No Data Found");
          }
        },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Error',
               error
            );
          }
    
        );

    }
    }
    sendmakepayForApproval() {
      this.showloader=true;
      this.HttpService
        .GetById('/finance-ws/payment/send-for-approval?id=' +  this.makepaymentId ,  this.makepaymentId ,this.ret_LoggerDtls.token)
        .subscribe((res) => {
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
             this.router.navigate(['/login']);
           }
         else if (res == true) {
          this.toastService.addSingle(
            'success',
            'Success',
            'Make Payment Sent for Approval Successfully!'
          );
          window.location.reload();
          this.showloader=false;
         } else {
          this.showAlert(res.errorMessage);
          this.showloader=false;
        }
        },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Error',
              'Error occured while sending Make Payment for Approval!'
            );
            this.showloader=false;
          }
  
        );
    }
    selfmakeApproval() {
      this.showloader=true;
      this.HttpService
        .GetById('/finance-ws/payment/self-approve?id=' +  this.makepaymentId ,  this.makepaymentId ,this.ret_LoggerDtls.token)
        .subscribe((res) => {
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
             this.router.navigate(['/login']);
           }
         else if (res == true) {
          this.toastService.addSingle(
            'success',
            'Success',
            'Make Payment Approved Successfully!'
          );
          window.location.reload();
          this.showloader=false;
         } else {
          this.showAlert(res.errorMessage);
          this.showloader=false;
        }
        },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Error',
              'Error occured while sending Make Payment for Approval!'
            );
            this.showloader=false;
          }
  
        );
    }
    CheckforCrossCurrencyadvpayment(id:number)
    {
     
      this.HttpService.GetAll('/setup-ws/preference/get-cross-currency-active-by-subsidiary?subsidiaryId='+id,this.ret_LoggerDtls.token).subscribe(
        (res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
       else {   //res=true;
          this.CrossCurrency=res;
          if(this.CrossCurrency==false)
          {
            
            this.GetAccountType('Bank',Number(localStorage.getItem("Subsidiary")));
          }
          else if(this.CrossCurrency==true)
          {
            this.GetAccountTypeMulticurrency("Bank",Number(localStorage.getItem("Subsidiary")));
          }}
        },
        (error) => {
         },
        () => {
        }
      );
    }
    loadSupplierCurrencyFromInvoice(supplierID:any)
    {
      this.HttpService.GetAll('/masters-ws/supplier/get-currency-by-supplier?supplierId='+supplierID,this.ret_LoggerDtls.token).subscribe(
        (res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
        {  this.lstCurrencyList=[];
          if(this.CrossCurrency)
          {
            this.isdisablecurr=false;
            this.lstCurrencyList=[];
            for(let i=0;i<res.length;i++)
            {
              this.lstCurrencyList.push({code:res[i].supplierCurrency});
              if(res[i].preferredCurrency==true)
              {
                this.makepayment.currency=res[i].supplierCurrency
              }
            }
           /* if(this.makepayment.currency==this.makepayment.subsidiaryCurrency)
            {
              //this.isdisablecurr=true;
              this.chkcurrMode=false;
              this.exHidden1=true;
              this.exHidden=false;
              this.makepayment.exchangeRate="1.00";
            }
            else
            {
              this.chkcurrMode=true;
              this.exHidden1=false;
              this.exHidden=true;
            }*/
  
            if(!this.CrossCurrency)
            {
              this.chkcurrMode=false;
              this.exHidden1=true;
              this.exHidden=false;
              this.makepayment.exchangeRate="1.00";
            }
            if(res.length<=1)
            {
              this.isdisablecurr=true;
            }
            else
            {
              this.isdisablecurr=false;
            }
         }
          else
          {
            for(let i=0;i<res.length;i++)
            {
              this.lstCurrencyList.push({code:res[i].supplierCurrency});
              if(res[i].preferredCurrency==true)
              {
                this.makepayment.currency=res[i].supplierCurrency
              }
            }
            if(res.length<=1)
            {
              this.isdisablecurr=true;
            }
            else
            {
              this.isdisablecurr=false;
            }
           /* if(this.makepayment.currency==this.makepayment.subsidiaryCurrency)
            {
             // this.isdisablecurr=true;
              this.chkcurrMode=false;
              this.exHidden1=true;
              this.exHidden=false;
              this.makepayment.exchangeRate="1.00";
            }
            else
            {
              this.chkcurrMode=true;
              this.exHidden1=false;
              this.exHidden=true;
            }*/
  
            if(!this.CrossCurrency)
            {
              this.chkcurrMode=false;
              this.exHidden1=true;
              this.exHidden=false;
              this.makepayment.exchangeRate="1.00";
            }
          }}
        },
        (error) => {
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        }
      );
    }
    loadBankAccountFromInvoice(subsidiaryId:any)
    {
      this.HttpService.GetAll('/masters-ws/bank/get-by-subsidiary-id?subsidiaryId='+subsidiaryId,this.ret_LoggerDtls.token).subscribe(
        (res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
          { this.BankaccountList = [];
           for(let i=0;i<res.length;i++)
           {
                if(res[i].active==true)
                {
                  this.BankaccountList.push({id:res[i].id,name:res[i].name})
                }
           }
      }
        },
        (error) => {
          this.showAlert(error);
         },
        () => {
        }
      );
    }
    loadPaymentListFromInvoice(supplierID:any,currency:any)
    {
      this.HttpService.GetAll('/finance-ws/payment/get-payment-details-by-supplier-and-currency?supplierId='+supplierID+'&currency='+currency,this.ret_LoggerDtls.token).subscribe(
        (res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
       {   this.paymentline=res;
          //this.makepayment.makePaymentList.push(res);
          this.makepayment.makePaymentList=[];
          for(let i=0;i<this.paymentline.length;i++)
          {
                this.makepayment.makePaymentList.push({
                type:"AP Invoice",
                billNo:this.paymentline[i].invoiceNo,
                invoiceAmount:this.paymentline[i].totalAmount,
                paymentAmount:this.paymentline[i].paymentAmount,
                amountDue:this.paymentline[i].amountDue,
                paidAmount:this.paymentline[i].amount,
                invoiceId:this.paymentline[i].invoiceId,
                currency:this.paymentline[i].currency,
                paymentamtdisable:true,
                active:false,
                invoiceDate:new Date(this.paymentline[i].invoiceDate)
  
              });
          }}
        },
        (error) => {
         },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        }
      );
    }
    loadPaymentListFromSelectedInvoice(supplierID:any,currency:any)
    {
      this.HttpService.GetAll('/finance-ws/payment/get-payment-details-by-supplier-and-currency?supplierId='+supplierID+'&currency='+currency,this.ret_LoggerDtls.token).subscribe(
        (res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
       {   this.paymentline=res;
          //this.makepayment.makePaymentList.push(res);
          this.makepayment.makePaymentList=[];
          for(let i=0;i<this.paymentline.length;i++)
          {
                this.makepayment.makePaymentList.push({
                type:"AP Invoice",
                billNo:this.paymentline[i].invoiceNo,
                invoiceAmount:this.paymentline[i].totalAmount,
                paymentAmount:this.paymentline[i].paymentAmount,
                amountDue:this.paymentline[i].amountDue,
                paidAmount:this.paymentline[i].amount,
                invoiceId:this.paymentline[i].invoiceId,
                currency:this.paymentline[i].currency,
                paymentamtdisable:true,
                active:false,
                invoiceDate:new Date(this.paymentline[i].invoiceDate)
  
              });
          }}
        },
        (error) => {
         },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        }
      );
    }
    DownloadReport(makePmtNo:any){
      this.showloader=true;
      //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
    this.makePaymentReport.exportPdf(makePmtNo);  
    this.showloader=false;
    }
    approveIndividual(mainId:any)
    {
      try {
        var approveList: any = [];
        approveList.push(mainId);
  
        if (approveList.length > 0) {
          this.showloader = true;

          if(this.RetloginDetails.userType=='SUPERADMIN'){
            this.url='/finance-ws/payment/approve-all-payments?currentApproverId=' + this.loginId;
    
           }
           else if(this.RetloginDetails.userType=='ENDUSER')
           {
                if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
                {
                  this.url='/finance-ws/payment/approve-all-payments?currentApproverId=' + this.loginId;
                }
                else
                {
                  this.url='/finance-ws/payment/approve-all-payments'
                }
          
           }
            this.HttpService.Insert(this.url,approveList,this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else if (res.messageCode) {
                this.showloader = false;
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );
              } else {
                this.showloader = false;
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Payment approved successfully !'
                );
                this.router.navigate([this.listURL]);
              }
            },
            (error) => {
              this.showAlert(error);
            }
          );
        }
      } catch (err:any) {
        this.showAlert(err)
      }
    }
    rejectIndividual(mainId:any,rejectComments:any)
    {
      try {
        if( rejectComments==undefined)
        {
          this.showAlert("Please enter Reject Comments");
          return true;
        }
          var rejectList: any = [];
          var isrejectComments: boolean = false;
          rejectList.push({id:mainId,rejectedComments:rejectComments})
                isrejectComments = true;
                //this.isRejectPressed = true  
          if (isrejectComments) {
            this.showloader = true;
            this.HttpService.Insert('/finance-ws/payment/reject-all-payments',rejectList,this.RetloginDetails.token).subscribe(
              //this.HttpService.Insert('/finance-ws/advance/reject-all-advance-payments',rejectList ,this.RetloginDetails.token).subscribe(
              (res) => {
                if (res.status == 401) {
                  this.showAlert("Unauthorized Access !");
                  this.router.navigate(['/login']);
                }
                else if (res.status == 404) {
                  this.showAlert("Wrong/Invalid Token!");
                  this.router.navigate(['/login']);
                }
                else if (res.messageCode) {
                  this.showloader = false;
                  this.toastService.addSingle(
                    'error',
                    'Error',
                    res.errorMessage
                  );

                  isrejectComments=false;
                }
                else {
                  this.showloader = false;
                  this.toastService.addSingle(
                    'success',
                    'Success',
                    'Reject selected Make Payment!'
                  );
                }
                // this.loading = false;
              },
              (error) => {
                this.showAlert(error);
              }
            );
          }
      } catch (err:any) {
        this.showAlert(err);
      }
    }
    gotopage()
{
  if(this.chkId)
  {
    this.router.navigate(['/main/payment-request/MP_Approval']);
  }
  else
  {
    this.router.navigate(['/main/payment-request/list']);
  }
 
    }
   hidepopup()
{
  this.display=false;
    }
   Opendialog()
{
  this.display=true;
    }
   funreject()
{
 
  try { 
    if(this.mpApproval.comments=="" || this.mpApproval.comments==undefined)
    {
         this.showAlert("Please enter Comments !");
         return;

    }
    else
    {
      var rejectList:any=[];
      var isrejectComments:boolean=false   
      rejectList.push({id:this.makepaymentId,rejectedComments:this.mpApproval.comments})
     
        this.showloader = true;
      this.HttpService.Insert('/finance-ws/payment/reject-all-payments',rejectList,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
  
          if (res.messageCode) {
           this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
            this.showloader = false;
            this.display=false;
          } else {
            this.toastService.addSingle(
              'success',
              'Success',
              'Reject selected Make Payment!'
            );
            this.display=false;
            this.showloader = false;
            this.router.navigate(['/main/make-payment/MP_Approval']);
          }
          
         // this.loading = false;
        }
        },
        (error:any) => {
          this.display=false;
          this.showAlert(error);
          this.showloader = false;
         // this.loading = false;
        }
      );
    }
   
    
    
 
  } catch (err:any) {
    this.showAlert(err);
    this.showloader = false;
  }
    }
   loadrequestor()
{
  this.HttpService.GetAll('/masters-ws/employee/get?id='+this.loginId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {

   
      this.makepayment.creator=res.fullName
     
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

    }
   OpenAppSequence()
{
  this.isAppSequenceVisivble=true;
    }
    sendmail()
    {
     //{{financeGateway}}/payment/send-mail-to-payment-supplier?paymentId=80
     this.showloader=true;
     this.HttpService.GetAll('/finance-ws/payment/send-mail-to-payment-supplier?paymentId='+this.makepaymentId+'&empId='+ this.loginId,this.ret_LoggerDtls.token)
     .subscribe((res) => {
       if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
     else 
       {
        
         if(res.status == 500)
         {
 
           this.showloader=false;
           this.showAlert("Error occured while sending mail!")
         }
         else{
           this.showloader=false;
           this.showSuccessMail();
           this.router.navigate(['/main/make-payment/list']);
         }
         
        
       }
 
       },
       (error) => {
         this.showloader=false;
         this.showAlert(error);
       
        },
       () => {}
       );
 
 
 
    }
    recallStatus(mainId:any)
{
  this.showloader = true;
  this.HttpService
    .GetAllResponseText('/finance-ws/payment/recall?id=' +mainId, this.RetloginDetails.token)
    .subscribe((res) => {
      //For Auth
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else if (res.status == 200) {
          this.toastService.addSingle(
            'success',
            'Success',
            res.error.text
          );
          this.showloader = false;
          window.location.reload();
      }
      else
      {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      }
    },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      });
}
    showSuccessMail() {
      this.toastService.addSingle(
        'success',
        'Success',
        'Mail Sent Successfully!'
      );
    }
}
