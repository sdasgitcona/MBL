import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ActivatedRoute, Params } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import { saveAs } from 'file-saver';
import { jsPDF } from 'jspdf';
import * as XLSX  from 'xlsx';
//import * as XLSX from 'xlsx-js-style'
import {banDetailsList } from '../bank-statement/model/bank-statement.model';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-bank-statement',
  templateUrl: './bank-statement.component.html',
  styleUrls: ['./bank-statement.component.scss']
})
export class BankStatementComponent implements OnInit {

  bankDetailsList: banDetailsList[];
  SubsideryObject = [];
  exportColumns: any[];
  columns: any[] = [];
  totalRecords: number = 0;
  loading: boolean = false;
  lastPTableSearchEvent: any;
  departmentOptions: any;
  RetloginDetails: any;
  subscription: any;
  subsidiaryName:string;
  suppplierName:string;
  bankName:string;
  subsidiaryId:number;
  supplierId:number;
  bankId:any;
  fromDate:any;
  toDate:any;
  currency:string;
  asOfDate:string;
  status: any;
  file: File;
  displayModal: boolean;
  fileName = 'ExcelSheet.xlsx';
  isParams: boolean = true;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  // For Role Base Access
  runBy:any
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService,
    

  ) {
    
  }

  ngOnInit(): void {

       this.subscription = this.activatedRoute.params.subscribe((params) => {

      if (params) {
      
        this.subsidiaryName = params['subName'];
        this.subsidiaryId = params['subId'];
        this.bankId = params['bankId'];
        this.fromDate = params['fromDate'];
        this.toDate = params['toDate'];
        //alert(this.bankId);
      }


    });

    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    let role_Dtls = JSON.parse(retDetails);

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    console.log( this.RetloginDetails.username);

    



    this.primengConfig.ripple = true;
    this.columns = [
      { field: 'sl', header: 'Sl' },
      { field: 'bank', header: 'Bank' },
      { field: 'date', header: 'Date' },
      { field: 'Supplier', header: 'Supplier' },
      { field: 'TransactionCurrency', header: 'Transaction Currency' },
      { field: 'FunctionalCurrency', header: 'Functional Currency' },
      { field: 'VoucherNumber', header: 'Voucher Number' },
      { field: 'AccountNumber', header: 'Account Number' },
      { field: 'PaymentMode', header: 'Payment Mode' },
      { field: 'InstrumentNo', header: 'Instrument No' },
      { field: 'Amount', header: 'Amount' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    this.getAPIData();
  }
 
  public getAPIData() {
    
    this.HttpService
      .GetAll(`/finance-ws/payment/get-bank-statement?subsidiaryId=`+this.subsidiaryId+`&bankId=`+this.bankId+`&fromDate=`+this.fromDate+`&toDate=`+this.toDate
        , this.RetloginDetails.token)
      .subscribe((res) => { console.log(res)
        if (res?.status == 401) {
          alert("Unauthorized Access !");
        }
        else if (res?.status == 404) {
          alert("Wrong/Invalid Token!");
        }
        else {

          this.bankDetailsList = res;
          
          if (res) {

            this.totalRecords = res.totalRecords
            
          } else {
          
            this.totalRecords = 0;

          }
          this.loading = false;
          


        }
      });

  }


  loadPrs(event: any) {

  }




  public exportPdf() {

    // create a new jsPDF instance
    const doc = new jsPDF('l', 'mm', 'a4');



    // generate table content
    let subsidiaryName = this.subsidiaryName;



    
    let fromDate = this.fromDate;
    let toDate = this.toDate;
    let x = 45; // X coordinate
    let y = 54; // Y coordinate
    let y2 = 54;
    // define the header and footer
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text('Bank Statement', doc.internal.pageSize.width/2-(13), 24);
      doc.text(subsidiaryName || '', doc.internal.pageSize.width/2-(subsidiaryName.length), 36);
      doc.setFontSize(12)
      doc.text('From '+fromDate+' To '+toDate||'', doc.internal.pageSize.width/2-(fromDate.length+toDate.length+2), 46);
  
    };
    

    
    const headerAfer = function () {

      doc.setFillColor(156, 178, 221); // set fill color to yellow
      doc.rect(204, 58, 84,  16, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color

      doc.setFont("Arial", "bold");
      doc.text('Bank Balance As on', 206, 64);
      doc.setFont("Arial", "normal");
      doc.text(": ", 244, 64);
      
      doc.setFont("Arial", "bold");
      doc.text('Total Receipt', 206, 68);
      doc.setFont("Arial", "normal");
      doc.text(": ", 244, 68);
      
      
      doc.setFont("Arial", "bold");
      doc.text('Total Payment', 206, 72);
      doc.setFont("Arial", "normal");
      doc.text(": ", 244, 72);



    };


   
    let runBy=this.RetloginDetails.username;
    const footer = function () {
      
      let currentDate: Date;
      currentDate = new Date()
      doc.setFontSize(12);
      doc.text("Run Date & Time: "+currentDate.toLocaleString(), 8, doc.internal.pageSize.height - 10);  //doc.internal.pageSize.width/2-currentDate.toLocaleString().length
      doc.setFontSize(12);
      doc.text("Run By: "+runBy, 200, doc.internal.pageSize.height - 10);
    };


    let bankBody:any[]=[];
    let sl =0;
    this.bankDetailsList?.forEach((bankList)=>{
      let paymentDate:any = new Date(bankList?.paymentDate??'').toLocaleDateString('en-GB');
      

      bankBody.push([++sl,bankList.bankName,paymentDate,bankList.supplierName
    ,bankList.currency,bankList.subsidiaryCurrency,bankList.paymentNumber,bankList.bankAccountName,bankList.paymentMode
  ,bankList.bankReferenceNumber,bankList?.amount?.toFixed(2)])
    })
   
    let startY=85;

    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: bankBody,
      margin: { left: 8, bottom: 70, top: startY, right: 8 },
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [255, 255, 255],

      },

      headStyles: {
        fillColor: [53, 67, 110], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles: {
        9: { halign: 'right' },
        10: { halign: 'right' },

        //7: { columnWidth: 22 }

      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;


        }




      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();
        headerAfer();

        doc.setPage(data.pageNumber);
        
        y = 54;
        y2 = 54;
        startY = (doc as any).autoTable.previous.finalY + 10;
        //(doc as any).setY(startY)
      },

    });
    footer();
    
   // this.addWaterMark(doc); 
    

    // save the pdf file
    doc.save('report.pdf');
  }
  //----Suman Addition


  // Download Report 
  DownloadReport(prNumber: any) {
      }

 
 exportexcel() {
    const wsBody: any = [];
    
    // Heading of the invoice list
   
    wsBody.push([]);
    wsBody.push(['','Bank Statement']);

    wsBody.push(['',this.subsidiaryName]);
    wsBody.push(['','From '+this.fromDate +' To '+this.toDate]);
    wsBody.push([]);
    wsBody.push(['','','','','','','','','','','Bank Balance As on','']);
    wsBody.push(['','','','','','','','','','','Total Receipt','']);
    wsBody.push(['','','','','','','','','','','Total Payment','']);
   
    wsBody.push([]);
    const headerRow =  ['', ...this.columns.map(col => col.header)];
    wsBody.push(headerRow);
    
    let sl = 0;
    this.bankDetailsList?.forEach((bankList)=>{
      let paymentDate:any = new Date(bankList?.paymentDate??'').toLocaleDateString('en-GB');
      wsBody.push(['',++sl,bankList.bankName,paymentDate,bankList.supplierName
    ,bankList.currency,bankList.subsidiaryCurrency,bankList.paymentNumber,bankList.bankAccountName,bankList.paymentMode
  ,bankList.bankReferenceNumber,bankList?.amount?.toFixed(2)])
    })

    let runBy=this.RetloginDetails.username;
    let currentDate: Date;
    currentDate = new Date()  
    wsBody.push([]);
    wsBody.push([]);
    wsBody.push(['','','','','','','Run By: '+runBy+', '+currentDate.toLocaleString()]);
    // wsBody.push(['   Authorized Signature']);
    // wsBody.push([]);

    const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(wsBody);

    // Merge and center 
    const reportHeadMerge = { s: { r: 1, c: 1 }, e: { r: 1, c: this.columns.length  } };
    const reportNameMerge = { s: { r: 2, c: 1 }, e: { r: 2, c: this.columns.length  } };
    const reportDateMerge = { s: { r: 3, c: 1 }, e: { r: 3, c: this.columns.length } };
  
    
    ws['!merges'] = [reportHeadMerge, reportNameMerge, reportDateMerge];
   
    let headerStyle = {
      // styling for all cells
      font: {
        name: 'arial',
        bold:true,
        sz:14
      },
      alignment: {
        vertical: 'center',
        horizontal: 'center',
        //wrapText: '1', // any truthy value here
      },
      
    };

    let tableStyle = {
      // styling for all cells
      alignment: {
        vertical: 'center',
        horizontal: 'center',
        //wrapText: '1', // any truthy value here
      },
      width: 20,
    };
    
    ws['B2'].s = headerStyle,
    ws['B3'].s = headerStyle,
    ws['B4'].s = headerStyle,
    
    ws['B4'].s = headerStyle; 
   
    
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);

  }








  fileList: File[] = [];
  listOfFiles: any[] = [];
  isLoading = false;











  // DownloadPdf() {
  //   window.open(this.HttpService.baseUrl + "/pr/download-template")
  // }

  showAlert(AlertMSG: any) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }


}
