

export class banDetailsList {
    id?: 2;
    paymentNumber?: string;
    subsidiaryId?: Number;
    accountId?: Number;
    bankId?: Number;
    supplierId?: Number;
    paymentDate?: Date;
    currency?: string;
    subsidiaryCurrency?: string;
    exchangeRate?: Number;
    paymentMode?: string;
    amount?: Number;
    bankTransactionType?: string;
    bankReferenceNumber?: Number;
    memo?: any;
    netsuiteId?: any;
    rejectedComments?: any;
    noteToApprover?: any;
    voidDescription?: string;
    voidDate?: any;
    type?: string;
    status?: string;
    nsMessage?:string;
    nsStatus?: string;
    integratedId?: any;
    approvedBy?: string;
    nextApprover?: any;
    nextApproverUid?: null;
    nextApproverRole?: null;
    nextApproverLevel?: null;
    approverPreferenceId?: null;
    approverSequenceId?: null;
    approverMaxLevel?: null;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    subsidiaryName?: string;
    supplierName?: string;
    bankAccountName?:any;
    bankName?: string;
    paymentAmount?: Number;
    approvedByName?: string;
    makePaymentList?: any;
    bank?: string;
    subsidiary?: string;
    supplier?: string;
    amountWithSign?: Number;
    approvalRoutingActive?: boolean;
    deleted?: boolean;

}

