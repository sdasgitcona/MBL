export class agingSummary {
        supplierName?: string;
        currency?: string;
        unPaidBillCount?:any
        unPaidBillAmount?: any;
        dueDatesInfo?: dueDatesInfo[];

}

export class dueDatesInfo {
  category?: string; 
  value?: any;
}

