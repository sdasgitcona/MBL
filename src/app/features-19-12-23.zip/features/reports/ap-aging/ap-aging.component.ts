import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ActivatedRoute, Params } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import { saveAs } from 'file-saver';
import { jsPDF } from 'jspdf';
import * as XLSX  from 'xlsx';
// import * as XLSX from 'xlsx-js-style'
// import { PrReportComponent } from '../../report/pr-report/pr-report.component';
import { agingSummary, dueDatesInfo } from './model/ap-aging/ap-aging.model';

@Component({
  selector: 'app-ap-aging',
  templateUrl: './ap-aging.component.html',
  styleUrls: ['./ap-aging.component.scss']
})
export class ApAgingComponent implements OnInit {

  agingList: agingSummary[];
  dueDatesInfo: dueDatesInfo[];
  agingListData:any[];
  dueDatesCategory:any[];
  SubsideryObject = [];
  exportColumns: any[];
  columns: any[] = [];
  totalRecords: number = 0;
  loading: boolean = false;
  lastPTableSearchEvent: any;
  departmentOptions: any;
  EmployeeList: any[];
  RetloginDetails: any;
  subscription: any;
  subsidiaryName:string;
  subsidiaryId:any;
  asOfDate:string;
  status: any;
  file: File;
  displayModal: boolean;
  fileName = 'ExcelSheet.xlsx';
  isParams: boolean = true;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  // For Role Base Access

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService,
    //private prReport: PrReportComponent

  ) {
    this.departmentOptions = ["Admin", "HR", "Finance", "Purchase", "Production",]
  }

  ngOnInit(): void {

       this.subscription = this.activatedRoute.params.subscribe((params) => {

      if (params) {
      
        this.subsidiaryName = params['subName'];
        this.subsidiaryId = params['subId']
        this.asOfDate = params['date']
        
      }


    });

    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Purchase Requisition") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
      }
    }
    // End For Role Base Access



    this.primengConfig.ripple = true;
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },

      //{ field: 'id', header: 'Internal ID' },
      { field: 'SupplierName', header: 'Supplier Name' },
      { field: 'Currency', header: 'Currency' },
      { field: 'TotalUnpaidBillCount', header: 'Total Unpaid Bill Count' },
      { field: 'TotalUnpaidAmount', header: 'Total Unpaid Amount' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    this.getAPIData();
  }

  public getAPIData() {
    
    this.HttpService
      .GetAll(`/finance-ws/invoice/get-invoice-aging-summary?subsidiaryId=`+this.subsidiaryId+`&date=`+this.asOfDate
        , this.RetloginDetails.token)
      .subscribe((res) => { 
        if (res.status == 401) {
          alert("Unauthorized Access !");
        }
        else if (res.status == 404) {
          alert("Wrong/Invalid Token!");
        }
        else {

          this.agingList = res;
          this.dueDatesInfo = res.dueDatesInfo;
          this.dueDatesCategory = [];
          
          for(let i = 0; i<res.length;i++){
            this.agingListData?.push(res[i]?.SuplierName??'',
            res[i]?.currency??'',res[i]?.TotalUnpaidBillCount??''
            ,res[i]?.TotalUnpaidAmount??''
            ,res[i]?.dueDatesInfo[0]?.amount??''
            ,res[i]?.dueDatesInfo[1]?.amount??''
            ,res[i]?.dueDatesInfo[2]?.amount??''
            ,res[i]?.dueDatesInfo[3]?.amount??''
            ,res[i]?.dueDatesInfo[4]?.amount??'')
          }

          console.log("aging List"+this.agingListData);

          for(let i = 0; i<res[0].dueDatesInfo.length;i++){
            this.dueDatesCategory?.push(res[0].dueDatesInfo[i]?.category)
          }
          console.log("due dates list"+this.dueDatesCategory);
          
          if (res) {

            this.totalRecords = res.totalRecords
            
          } else {
          
            this.totalRecords = 0;

          }
          this.loading = false;
          


        }
      });

  }


  loadPrs(event: any) {

  }


  public exportPdf() {

    // create a new jsPDF instance
    const doc = new jsPDF('p', 'mm', 'a4');



    // generate table content
    let subsidiaryName = this.subsidiaryName || '';
    const asOfdate = new Date(this.asOfDate).toLocaleDateString('en-GB');
    
    let x = 45; // X coordinate
    let y = 54; // Y coordinate
    let y2 = 54;
    // define the header and footer
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName || '', 8, 12);
      doc.text('Invoice Aging Summary', 75, 24);
      doc.setFontSize(12)
      doc.text("As Of "+asOfdate||'', 95, 36);
    };
    ;


    const pdfHeader:any[]=[];
    pdfHeader.push('Sl','Supplier Name','Currency','Total Unpaid Bill Count'
    ,'Total Unpaid Amount',this.dueDatesCategory[0] ??''
    ,this.dueDatesCategory[1] ??'',this.dueDatesCategory[2] ??''
    ,this.dueDatesCategory[3] ??'')
    let startY=65;
    
    const pdfBody:any[]=[]; 
    let sl=0;
    this.agingList?.forEach((agingList: any) => {
    
      pdfBody.push([++sl,
        agingList.supplierName??'',
        agingList.currency??'',
        agingList.unPaidBillCount?.toFixed(2)??'',
        agingList.unPaidBillAmount?.toFixed(2)??'',
        agingList.dueDatesInfo[0]?.amount?.toFixed(2)??'',
        agingList.dueDatesInfo[1]?.amount?.toFixed(2)??'',
        agingList.dueDatesInfo[2]?.amount?.toFixed(2)??'',
        agingList.dueDatesInfo[3]?.amount?.toFixed(2)??''
      ]);
    });

    let runBy=this.RetloginDetails.username;
    const footer = function () {
      
      let currentDate: Date;
      currentDate = new Date()
      doc.setFontSize(8);
      doc.text("Run Date & Time: "+currentDate.toLocaleString(), 8, doc.internal.pageSize.height - 10);  //doc.internal.pageSize.width/2-currentDate.toLocaleString().length
      
      doc.text("Run By: "+runBy, 135, doc.internal.pageSize.height - 10);
    };

    (doc as any).autoTable({

      startY: startY,
      head: [pdfHeader],
      body:  pdfBody,
      //foot: [['', '', '', '', '', 'Estimated Total:', this.estimatedAmount]],
      margin: { left: 8, bottom: 70, top: startY, right: 8 },
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [255, 255, 255],

      },

      headStyles: {
        fillColor: [53, 67, 110], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles: {
        2: { halign: 'right' },
        3: { halign: 'right' },
        4: { halign: 'right' },
        5: { halign: 'right' },
        6: { halign: 'right' },
        7: { halign: 'right' },
       
        //7: { columnWidth: 22 }

      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;


        }




      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();
      
        doc.setPage(data.pageNumber);
        //(doc as any).setY(doc.internal.pageSize.height - 50);
        // set the startY option for the autoTable on this page
        y = 54;
        y2 = 54;
        startY = (doc as any).autoTable.previous.finalY + 10;
        //(doc as any).setY(startY)
      },

    });
    footer();
   // this.addWaterMark(doc); 
    

    // save the pdf file
    doc.save('report.pdf');
  }
  //----Suman Addition


  // Download Report 
  DownloadReport(prNumber: any) {
   // this.prReport.exportPdf(prNumber)

    //window.open(this.HttpService.ReportUrl + "/run?__report=report/Purchase_Requisition.rptdesign&__format=pdf&pr_number=" + prNumber, '_blank')
  }

 
 exportexcel() {
    const wsBody: any = [];
    
    // Heading of the invoice list
   
    wsBody.push([]);
    wsBody.push(['',,this.subsidiaryName]);

    wsBody.push(['','Invoice Aging Summary']);
    wsBody.push(['','As of '+this.asOfDate]);
    wsBody.push(['','Summary','','','','Due Date']);
    const headerRow =  ['','Supplier Name','Currency','Total Unpaid Bill Count','Total Unpaid Amount',this.dueDatesCategory[0] ||''
    ,this.dueDatesCategory[1] ??'',this.dueDatesCategory[2] ??'',this.dueDatesCategory[3] ??'',this.dueDatesCategory[4] ??''];
    wsBody.push(headerRow);
    

    this.agingList?.forEach((agingList: any) => {
      wsBody.push(['',
        agingList.supplierName??'',
        agingList.currency??'',
        agingList.unPaidBillCount?.toFixed(2)??'',
        agingList.unPaidBillAmount?.toFixed(2)??'',
        agingList.dueDatesInfo[0]?.amount?.toFixed(2)??'',
        agingList.dueDatesInfo[1]?.amount?.toFixed(2)??'',
        agingList.dueDatesInfo[2]?.amount?.toFixed(2)??'',
        agingList.dueDatesInfo[3]?.amount?.toFixed(2)??''
      ]);
    });

    wsBody.push([]);

    let runBy=this.RetloginDetails.username;
    let currentDate: Date;
    currentDate = new Date()  
    wsBody.push([]);
    wsBody.push([]);
     wsBody.push(['','','','','','','Run By: '+runBy+', '+currentDate.toLocaleString()]);

    const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(wsBody);

    // Merge and center 
    const reportHeadMerge = { s: { r: 1, c: 1 }, e: { r: 1, c: this.columns.length  } };
    const reportNameMerge = { s: { r: 2, c: 1 }, e: { r: 2, c: this.columns.length  } };
    const reportDateMerge = { s: { r: 3, c: 1 }, e: { r: 3, c: this.columns.length } };
    const reportSummaryMerge = { s: { r: 4, c: 1 }, e: { r: 4, c: this.columns.length -7} };
    const reportDueDateMerge = { s: { r: 4, c: 5 }, e: { r: 4, c: this.columns.length } };
    
    
    ws['!merges'] = [reportHeadMerge, reportNameMerge, reportDateMerge,reportSummaryMerge,reportDueDateMerge];

    
    const mergeCellStyles = {
      font: { bold: true },
      alignment: { horizontal: 'center', vertical: 'center' },
      border: {
        top: { style: 'thick', color: { rgb: '000000' } },
        bottom: { style: 'thick', color: { rgb: '000000' } },
        left: { style: 'thick', color: { rgb: '000000' } },
        right: { style: 'thick', color: { rgb: '000000' } }
      },
      fill: { fgColor: { rgb: '#ff0' } } 
    };
   
    let headerStyle = {
      // styling for all cells
      font: {
        name: 'arial',
        bold:true,
        sz:14
      },
      alignment: {
        vertical: 'center',
        horizontal: 'center',
        //wrapText: '1', // any truthy value here
      },
      width: 160,
      // border: {
      //   right: {
      //     style: 'thin',
      //     color: '000000',
      //   },
      //   left: {
      //     style: 'thin',
      //     color: '000000',
      //   },
      // },
    };

    let tableStyle = {
      // styling for all cells
      alignment: {
        vertical: 'center',
        horizontal: 'center',
        //wrapText: '1', // any truthy value here
      },
      width: 160,
    };
    
    ws['B2'].s = headerStyle,
    ws['B3'].s = headerStyle,
    ws['B4'].s = headerStyle,
    ws['B5'].s = headerStyle;
    ws['F5'].s = headerStyle;
//    ws['B6'].s = tableStyle; 
  //  ws['C6'].s = tableStyle; 
    //ws['D6'].s = tableStyle; 
    //ws['E6'].s = tableStyle; 
    //ws['F6'].s = tableStyle; 
    //ws['G6'].s = tableStyle; 
    //ws['H6'].s = tableStyle; 
    //ws['I6'].s = tableStyle; 
    //ws['J6'].s = tableStyle; 
    //ws['B2'].l = { Target:"https://conacent.com", Tooltip:"Find us @ Conacent.com!" };
    
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);

  }








  fileList: File[] = [];
  listOfFiles: any[] = [];
  isLoading = false;











  DownloadPdf() {
    window.open(this.HttpService.baseUrl + "/pr/download-template")
  }

  showAlert(AlertMSG: any) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }


}
