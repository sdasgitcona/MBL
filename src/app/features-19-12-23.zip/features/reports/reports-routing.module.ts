import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PoReportComponent } from './po-report/po-report.component';

import { AccountStatementComponent } from './account-statement/account-statement.component';
import { ApAgingComponent } from './ap-aging/ap-aging.component';
import { ApAgingDetailsComponent } from './ap-aging-details/ap-aging-details.component';
import { BankStatementComponent } from './bank-statement/bank-statement.component';


const routes: Routes = [
  {
    path: 'po_report',
    component: PoReportComponent,
  },
  {
    path: 'account_statement',
    component: AccountStatementComponent,
  },
  {
    path:'account_statement/action/:subName',
    component:AccountStatementComponent
  },
  {
    path:'account_statement/action/:subName/:subId/:fromDate/:fDate/:toDate/:tDate/:supName/:supId/:currency',
    component:AccountStatementComponent
  },
  {
    path:'agingSummary',
    component:ApAgingComponent
  },
  {
    path:'agingSummary/action/:subId/:subName/:date',
    component:ApAgingComponent
  },
  {
    path:'agingDetails',
    component:ApAgingDetailsComponent
  },
  {
    path:'agingDetails/action/:subName',
    component:ApAgingDetailsComponent
  },
  {
    path:'agingDetails/action/:subId/:subName/:supId/:supName/:date/:currency',
    component:ApAgingDetailsComponent
  },
  {
    path:'bankStatementDtl',
    component:BankStatementComponent
  },
  {
    path:'bankStatementDtl/action/:subId/:subName/:bankId/:fromDate/:toDate',
    component:BankStatementComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
