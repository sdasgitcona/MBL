import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class RfqReportModule { 
  id?: number;
  /* rfqNumber?: any;
   bidOpenDate?: any;
   bidCloseDate?: any;
   bidType?: string;
   currency?:string;
   quotationPrs?: number;
   subsidiaryId?: number;
   rfqDate?: any;*/
   rfqNumber?:string;
   subsidiaryId?:number;
   rfqDate?:any;
   memoNotes?:string;
   bidType?:string;
   bidOpenDate?:any;
   bidCloseDate?:any;
   locationId?:number;
   status?:string;
   netSuiteId?:string;
   createdDate?: Date;
   createdBy?: string;
   creator?: any;
   lastModifiedDate?: Date;
   lastModifiedBy?: string;
   currency?:string;
   quotationPrs:quotationPrs[]=[];
   subsidiary:subsidiary[]=[];
   exchangeRate?:string;
   department?:string;
   subsidiaryAddress?:string;
   bidRecieveEmail?:string;
   subsidiaryName?:string;
   quotationVendors:quotationVendors[]=[];
   quotationItems:quotationItems[]=[];
   quotationInfos:quotationInfos[]=[];
   deleted?:boolean;
   submitted:boolean;
   createQa:boolean=false;
   prNumberafterSubmit:string;
   projectName:string;
   departmentName:string;
   
}
export class BaseSearch {
   filters?: Filter | {} = {};
   pageNumber?: number = 0;
   pageSize?: number = 0;
   sortColumn?: string = '';
   sortOrder?: string = '';
 }
 
 //this class holds the custom filter values at component level.
 export class Filter {
   subsidiary?: string = '';
   vendorname?: string = '';
   vendornumber?: string = '';
   vendortype?: string = '';
   pan?: string = '';
   active?: string = '';
 }

 export class itemVendors{

   id?: number;
   quotationId?: number;
   rfqNumber?: string;
   itemId?:number;
   vendorId?:any;
   createdDate?: Date;
   createdBy?: string;
   lastModifiedDate?: Date;
   lastModifiedBy?: string;
   vendorName?: string;
   deleted?: boolean;


 }

 export class quotationItems{
   id?:number;
   itemId:number;
   quantity:number;
   remainedQuantity?:number;
   receivedDate:any;
   remarks:string;
   prNumber?:any;
   prLocation?:number;
   prLocationName?:string;
   itemVendors:itemVendors[] = [];
   itemName?: string;
   itemDescription?:string;
   itemUom?:string;
   deleted?:boolean=false;
   quotationId?:number;
   rfqNumber?:string;
   currency?:string;
   itemNameToDisplay?:string;
   createdDate?: Date;
   createdBy?: string;
   lastModifiedDate?: Date;
   lastModifiedBy?: string;
   prId?:any; // add by Aftab
 }
 export class itemline{
   id?:number;
   prId?:number;
   prNumber:string;
   itemId:number;
   itemDescription?:string;
   quantity:number;
   remainedQuantity?:number;
   rate?:number;
   memo?:string;
   integratedId?:number;
   estimatedAmount?:number;
   receivedDate?:any;
   poNumber?:number;
   createdDate?: Date;
   createdBy?: string;
   lastModifiedDate?: Date;
   lastModifiedBy?: string;
   itemName?:string;
   itemUom?:string;
   department?:string;
   accountId?:number;
   deleted?:boolean;
   supplier:itemVendors[]=[];
   Suppliers:any[]=[];
   prLocationName?:string;
   Remarks:string;
   prLocationId?:number;
 
 }


 export class quotationVendors{
       id?:number;
       quotationId?:number;
       rfqNumber?:string;
       vendorId?:number;
       contactName?:string;
       email?:string;
       memo?:string;
       createdDate?: Date;
       createdBy?: string;
       lastModifiedDate?: Date;
       lastModifiedBy?: string;
       vendorName?:string;
       deleted?:boolean;
 }
 export class subsidiary{
         id?: number;
        name?: string;
        legalName?:string;
        parentCompany?:string;
        country?: string;
        email?: string;
        website?: string;
        language?: string;
        currency?: any;
        fiscalCalender?:string;
        pan?: any;
        cin?: any;
        tan?: string;
        bidMail?: any;
        invoiceMail?: any;
        invoicePasswd?:any;
        adminMail?: any;
        activeDate?: any;
        subsidiaryAddresses:subsidiaryAddress[]=[];
        integrated_id?: null;
        logoMetadata?: null;
        logo?: string;
        
}

export class subsidiaryAddress{

id?:any; 
subsidiaryId?: any;
country?: string;
attention?: any;
address?: string;
phone?: number;
address1?: string;
address2?: string;
city?: string;
state?: string;
zipcode?: any;
registrationCode?: any;
registrationType?: any;
}
 export class quotationPrs{
           id?: number;            
           quotationId?:number;
           quotationNumber?:string;
           prNumber?:any;
           prLocationId?:number;
           createdDate?: Date;
           createdBy?: string;
           lastModifiedDate?: Date;
           lastModifiedBy?: string;
           deleted?:boolean;
           name?:any;
           prId?:any;
           //isDisabled?: boolean;

 }


 export class suppliers{
   id?: number;            
   supplier?:string;
   createdDate?: Date;
   createdBy?: string;
   lastModifiedDate?: Date;
   lastModifiedBy?: string;
   deleted?:boolean;
}
export class generalinfo{
 remarks:string;
 deleted:boolean;
}

export class quotationInfos{
 id?:number;
 remarks:string;
 deleted=false;
}