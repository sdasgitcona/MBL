import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { jsPDF } from 'jspdf';
import * as XLSX from 'xlsx';
import html2canvas from 'html2canvas';
import 'jspdf-autotable';
import { Injectable } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ActivatedRoute, Route } from '@angular/router';
import { RfqReportModule, quotationItems, subsidiary, subsidiaryAddress } from './model/rfq-report/rfq-report.module';

@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-rfq-report',
  templateUrl: './rfq-report.component.html',
  styleUrls: ['./rfq-report.component.scss']
})
export class RfqReportComponent implements OnInit {

  rfqList: RfqReportModule = new RfqReportModule();
  rfQData: any = [];
  rfqItem: quotationItems[] = [];
  rfqSubsidiary: subsidiary = new subsidiary();
  rfqSubsidiaryAddress: any = [];
  quotationInfos:any =[];
  //address: subsidiaryAddress[] = [];
  exportColumns: any[];
  prReportData: any[];
  SubsidiaryId: any;
  rfqNumber: any;
  RetloginDetails: any;
  selectedSubsidiaryId: any;
  title = 'angular-app';
  fileName = 'ExcelSheet.xlsx';
  columns: any[] = [];
  //selectedPr: PrReportModule = new PrReportModule();
  totalRecords: number = 0;
  loading: boolean = false;
  //totalPages :number = 0;

  estimatedAmount: any;

  constructor(private httpService: CommonHttpService, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {

    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.columns = [
      { field: 'Sl No', header: '#' },
      { field: 'itemName', header: 'Item' },
      { field: 'itemDescription', header: 'Description' },
      { field: 'itemUom', header: 'UOM' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'rate', header: 'Estimated Rate' },
      { field: 'estimatedAmount', header: 'Estimated Amount' },
      { field: 'receivedDate', header: 'Received By Date' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    //this.getAPIData();


  }

  exportPdf(rfqNumber: any) {

    this.rfqNumber = rfqNumber;
    this.rfQData = [];;
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.columns = [
      { field: 'Sl No', header: '#' },
      { field: 'itemName', header: 'Item' },
      { field: 'itemDescription', header: 'Description' },
      { field: 'itemUom', header: 'UOM' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'receivedDate', header: 'Received By Date' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    this.getAPIData();

  }

  public getAPIData() {

    this.httpService
      .GetAll(`/procure-ws/quotation/get-by-rfq-number?rfqNumber=` + this.rfqNumber, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          alert("Unauthorized Access !");
        }
        else if (res.status == 404) {
          alert("Wrong/Invalid Token!");
        }
        else {

          if (res && res.quotationItems.length > 0) {

            this.rfqList = res;
            // this.estimatedAmount = res.estimatedAmount.toFixed(2);
            this.rfqSubsidiary = res.subsidiary;
            this.rfqItem = res.quotationItems;

            // if (res.subsidiary && Array.isArray(res.subsidiary.subsidiaryAddresses && res.subsidiary.subsidiaryAddresses.active)) {
            //   this.rfqSubsidiaryAddress = res.subsidiary.subsidiaryAddresses;
            //   this.rfqSubsidiaryAddress.forEach((address: any) => {
            //     this.rfqSubsidiaryAddress = address;
            //   });
            // } else {
            //   console.log("Error: invalid response");
            // }

            if (
              res.subsidiary &&
              Array.isArray(res.subsidiary.subsidiaryAddresses)
            ) {
              const filteredData = res.subsidiary.subsidiaryAddresses.filter(
                (address: any) => address.active === true
              );

              
              filteredData.forEach((rfqSubsidiaryAddress: any) => {
                this.rfqSubsidiaryAddress = rfqSubsidiaryAddress;
              });

              
            } else {
              console.log("Error: invalid response");
            }

            //start of quotation info
            this.quotationInfos=[];
            let Infos:any =[];
            Infos =res?.quotationInfos;
            
            for (let i = 0; i < Infos?.length; i++) {
                  this.quotationInfos.push([ Infos[i].remarks ])
                }
                //alert(this.quotationInfos)
                //end of quotation info
            this.totalRecords = res.totalRecords;


            for (let i = 0; i < this.rfqItem.length; i++) {
              const receivedDate = new Date(this.rfqItem[i].receivedDate);
              this.rfQData.push([i + 1, this.rfqItem[i].itemName, this.rfqItem[i].itemDescription, this.rfqItem[i].itemUom,
              this.rfqItem[i].quantity?.toFixed(2), receivedDate.toLocaleDateString('en-GB')]);
            }
            this.exportPdfAPI();

          } else {
            // this.rfqList = [];
            this.totalRecords = 0;

          }
          this.loading = false;
          //this.rfqItem= res.rfqItems;
          // console.log(this.rfqList);


        }
      });

  }


  public exportPdfAPI() {

    // create a new jsPDF instance
    const doc = new jsPDF('p', 'mm', 'a4');


    // generate table content

    let subsidiaryName = this.rfqSubsidiary.legalName;
    if (subsidiaryName) {
      subsidiaryName = this.rfqSubsidiary?.legalName || '';
    } else {

      subsidiaryName = this.rfqSubsidiary?.name || '';

    }

    // define the header and footer
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName || '', 8, 12);
      doc.text('Request For Quotation', 75, 24);
    };

    let rfqNumber: any = this.rfqList?.rfqNumber || '';
    const timestamp = this.rfqList?.rfqDate || '';
    const date = new Date(timestamp);
    const rfqDate = date.toLocaleDateString('en-GB');

    // let projectNameLine = doc.splitTextToSize(projectName || '', 70);
    //let attention: any = doc.splitTextToSize(this.rfqSubsidiaryAddress?.attention || '', 72);
    let address: any = doc.splitTextToSize((this.rfqSubsidiaryAddress?.address1 ?? '') +
      (this.rfqSubsidiaryAddress?.address2 ? (this.rfqSubsidiaryAddress.address1 ? ', ' : '') + this.rfqSubsidiaryAddress.address2 : ''),
      72);
    let city: any = doc.splitTextToSize(this.rfqSubsidiaryAddress?.city || '', 72);
    let state: any = doc.splitTextToSize(this.rfqSubsidiaryAddress?.state || '', 72);
    let zipcode: any = this.rfqSubsidiaryAddress?.zipcode || '';
    let country: any = doc.splitTextToSize(this.rfqSubsidiaryAddress?.country || '', 72);
    let email: any = doc.splitTextToSize(this.rfqSubsidiary?.email || '', 58);
    let mergedEmail: string[] = [];


    email.forEach((part: string) => {
      if (part.endsWith('@') || part.includes('.')) {
        const lastMergedPart = mergedEmail[mergedEmail.length - 1];
        if (lastMergedPart && lastMergedPart.includes('@') && !lastMergedPart.endsWith('@')) {
          mergedEmail[mergedEmail.length - 1] += part;
        } else {
          mergedEmail.push(part);
        }
      } else {
        const lastMergedPart = mergedEmail[mergedEmail.length - 1];
        if (lastMergedPart && lastMergedPart.endsWith('.') && part.startsWith('com')) {
          mergedEmail[mergedEmail.length - 1] += part;
        } else {
          mergedEmail.push(part);
        }
      }
    });


    let website: any = doc.splitTextToSize(this.rfqSubsidiary?.website || '', 72);
    let registrationCode: any = doc.splitTextToSize(this.rfqSubsidiaryAddress?.registrationCode || '', 72);
    let vatRegistration: any = doc.splitTextToSize(this.rfqSubsidiary?.tan || '', 72);
    let bidType: any = doc.splitTextToSize(this.rfqList?.bidType || '', 72);
    let openDate: any = new Date(this.rfqList?.bidOpenDate || '')
    let bidOpenDate: any = openDate.toLocaleDateString('en-GB');
    let closeDate: any = new Date(this.rfqList?.bidCloseDate || '');
    let bidCurrency: any = doc.splitTextToSize(this.rfqList?.currency || '', 72);
    let bidCloseDate: any = closeDate.toLocaleDateString('en-GB');
    let status: any = doc.splitTextToSize(this.rfqList?.status || '', 72);
    let memoNotes: any = doc.splitTextToSize(this.rfqList?.memoNotes || '', 226);
    let projectNamelabel: any = doc.splitTextToSize(subsidiaryName || '', 72);

    let projectName:any=this.rfqList?.projectName;
    let departmentName:any=this.rfqList?.departmentName;
    
    let LeftLengthCount = address.length + projectNamelabel.length + city.length + state.length + country.length
      + email.length + website.length + registrationCode.length + vatRegistration.length;

    let x = 8; // X coordinate
    let y = 64; // y coordinate
    let x1 = 120; // x cordinate of second rectangel
    let y2 = 64; // y cordinate of second rectangel
    let startY = 104 + LeftLengthCount * 4;




    const headerAfer = function () {



      let rectHeight = 38;
      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);

      doc.text('RFQ Number :', x, 36);

      doc.setFont("Arial", "normal");
      doc.text(rfqNumber || "", 38, 36);
      doc.setFont("Arial", "bold");
      doc.text('RFQ Date :', 118, 36);
      doc.setFont("Arial", "normal");
      doc.text(rfqDate || "", 142, 36);
      doc.rect(6, 48, 86, 10, 'F');

      doc.setTextColor(255, 255, 255);
      doc.text('SUBSIDIARY INFORMATION', 20, 54);

      doc.setFillColor(156, 178, 221); // set fill color to yellow
      doc.rect(6, 58, 86, rectHeight + (LeftLengthCount * 4), 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(10);

      doc.setFont("Arial", "bold");
      doc.text('Name ', x, y);
      doc.setFont("Arial", "normal");
      doc.text(': ', 46, y);
      projectNamelabel.forEach((proName: any) => {
        doc.text(proName || "", 48, y);
        y += 4; // Move down to the next line (adjust as needed)
      })

      doc.setFont("Arial", "bold");
      doc.text('Address', x, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(": ", 46, y);
      address.forEach((address: any) => {
        doc.text(address || "", 48, y);
        y += 4; // Move down to the next line (adjust as needed)

      });



      doc.setFont("Arial", "bold");
      doc.text('City', x, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(': ', 46, y);
      city.forEach((city: any) => {
        doc.text(city || '', 48, y);
        y += 4;
      })

      doc.setFont("Arial", "bold");
      doc.text('State', x, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(': ', 46, y);
      state.forEach((state: any) => {
        doc.text(state || '', 48, y);
        y += 4;
      })

      doc.setFont("Arial", "bold");
      doc.text('Pin/Zip ', x, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(': ', 46, y);
      doc.text(zipcode || '', 48, y);

      doc.setFont("Arial", "bold");
      doc.text('Country', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ', 46, y);
      country.forEach((country: any) => {
        doc.text(country || '', 48, y);
        y += 4;
      })

      doc.setFont("Arial", "bold");
      doc.text('Email', x, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(': ', 46, y);

      mergedEmail.forEach((part: string, index: number) => {
        doc.text(part, 48, y + index * 4);
      });

      y += mergedEmail.length * 4;






      doc.setFont("Arial", "bold");
      doc.text('Website', x, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(': ', 46, y);
      website.forEach((website: any) => {
        doc.text(website || '', 48, y);
        y += 4;
      })

      doc.setFont("Arial", "bold");
      doc.text('Vat Registraion Number', x, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(': ', 46, y);
      vatRegistration.forEach((vatRegistration: any) => {
        doc.text(vatRegistration || "", 48, y);
        y += 4;
      })

      doc.setFont("Arial", "bold");
      doc.text('Registraion Number', x, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(": ", 46, y);
      registrationCode.forEach((registrationCode: any) => {
        doc.text(registrationCode || "", 48, y);
        y += 4;
      })
      doc.setFont("Arial", "bold");
      doc.text('Project Name ', x, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(': ', 46, y);
      doc.text(projectName || '', 48, y);

      doc.setFont("Arial", "bold");
      doc.text('Department Name ', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ', 46, y);
      doc.text(departmentName  || '', 48, y);


      doc.rect(118, 48, 86, 10, 'F'); // draw a rectangle as background
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.text('BIDDING INFORMATION', 136, 54);
      doc.setFillColor(156, 178, 221); // set fill color to blue
      doc.rect(118, 58, 86, 34, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(10);


      doc.setFont("Arial", "bold");
      doc.text('Bid Type', x1, y2);
      doc.setFont("Arial", "normal");
      doc.text(": " + bidType || "", 142, y2);

      doc.setFont("Arial", "bold");
      doc.text('Bid Open ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + bidOpenDate || "", 142, y2);

      doc.setFont("Arial", "bold");
      doc.text('Bid Close', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + bidCloseDate || "", 142, y2);


      doc.setFont("Arial", "bold");
      doc.text('Bid Currency ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + bidCurrency || "", 142, y2);


      doc.setFont("Arial", "bold");
      doc.text('Status ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + status || "", 142, y2);



      doc.setTextColor(0);
      margin: { top: 30 }

    };





    const footer = function () {
      doc.setFontSize(12);
      doc.setTextColor(0);
      //doc.text('Remarks     :', 14, doc.internal.pageSize.height - 36);
      doc.text('Declaration :', 14, doc.internal.pageSize.height - 36);
      let line = 36;
      memoNotes.forEach((memoNotes: any) => {
        doc.text(memoNotes, 39, doc.internal.pageSize.height - line);
        line -= 4;
      })
      doc.text('____________________', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 66);
      doc.text('  Authorized Signature', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 60);

    };





    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: this.rfQData,
      //foot: [['', '', '', '', '', 'Estimated Total:', this.estimatedAmount]],
      margin: { left: 6, bottom: 70, top: startY, right: 6 },
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [255, 255, 255],

      },


      headStyles: {
        fillColor: [53, 67, 110], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles: {
        4: { halign: 'right' }
      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;
        }



      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();
        headerAfer();


        doc.setPage(data.pageNumber);

        //(doc as any).setY(doc.internal.pageSize.height - 50);
        // set the startY option for the autoTable on this page
        y = 64; // y coordinate
        y2 = 64;
        startY = (doc as any).autoTable.previous.finalY + 10;
        //(doc as any).setY(startY)
      },

    });

    doc.addPage();
    header();

    //let quotationInfos:any = doc.splitTextToSize(this.quotationInfos || '', 226);
        
    // Set the font size and color for the annexure text
    doc.setFont('Arial', 'bold');
    doc.setTextColor(0);
    doc.setFontSize(10);
    let lineAnex:any=40;
    (doc as any).text('Annexure :', 14, lineAnex, {
      lineHeightFactor: 1.5,
      baseline: 'top',
      textColor: [0, 0, 0],
      startY: 40
    });
    
    lineAnex = lineAnex + 8;
    let sl: any = 1;
    this.quotationInfos.forEach((anexure: any) => {
      const lines = doc.splitTextToSize(sl + ". " + anexure, 180);
      lines.forEach((line: any, index: number) => {
        const xOffset = index === 0 ? 16 : 20; // Adjust the xOffset for the first line of each serial number
        (doc as any).text(line, xOffset, lineAnex);
        lineAnex += 4;
      });
      sl += 1;
    });

    footer();
    doc.save('report.pdf');
  }







  ngAfterViewInit() { }








  exportexcel() {
    /* pass here the table id */
    let element = document.getElementById('content');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    /* save to file */
    XLSX.writeFile(wb, this.fileName);

  }
}



