import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ActivatedRoute, Params } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import { saveAs } from 'file-saver';
import { jsPDF } from 'jspdf';
import * as XLSX  from 'xlsx';
//import * as XLSX from 'xlsx-js-style'
import { INRDetails, agingDetailsSummary } from '../ap-aging-details/model/ap-aging-details.model';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-ap-aging-details',
  templateUrl: './ap-aging-details.component.html',
  styleUrls: ['./ap-aging-details.component.scss']
})
export class ApAgingDetailsComponent implements OnInit {

  // agingDetailsList: agingDetailsSummary=new agingDetailsSummary();
  agingDetailsList: any[];
  keyVal: any;
  agingDetailsData: any[]
  SubsideryObject = [];
  exportColumns: any[];
  columns: any[] = [];
  totalRecords: number = 0;
  loading: boolean = false;
  lastPTableSearchEvent: any;
  departmentOptions: any;
  EmployeeList: any[];
  RetloginDetails: any;
  subscription: any;
  subsidiaryName: string;
  suppplierName: string;
  subsidiaryId: number;
  supplierId: number;
  currency: string;
  asOfDate: string;
  status: any;
  file: File;
  displayModal: boolean;
  fileName = 'ExcelSheet.xlsx';
  isParams: boolean = true;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  // For Role Base Access

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService,


  ) {

  }

  ngOnInit(): void {

    this.subscription = this.activatedRoute.params.subscribe((params) => {

      if (params) {

        this.subsidiaryName = params['subName'];
        this.subsidiaryId = params['subId'];
        this.asOfDate = params['date']
        //var datePipe = new DatePipe(this.asOfDate).transform('dd/MM/yyyy');

        this.suppplierName = params['supName'];
        this.supplierId = params['supId']
        this.currency = params['currency'];

      }


    });

    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    // for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
    //   if (role_Dtls[0].rolePermissions[i].accessPoint == "Purchase Requisition") {
    //     this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
    //     this.isEditable = role_Dtls[0].rolePermissions[i].edit;
    //     this.isViewtable = role_Dtls[0].rolePermissions[i].view;
    //   }
    // }
    // // End For Role Base Access



    this.primengConfig.ripple = true;
    this.columns = [
      { field: 'Sl', header: 'Sl' },
      { field: 'InvoiceNumber', header: 'Invoice Number' },
      { field: 'VoucherNumber', header: 'Voucher Number' },
      { field: 'InvoiceDate', header: 'Invoice Date' },
      { field: 'PaymentTerm', header: 'Payment Term' },
      { field: 'DueDate', header: 'Due Date' },
      { field: 'Aged', header: 'Aged' },
      { field: 'Currency', header: 'Currency' },
      { field: 'ActualAmount', header: 'Actual Amount' },
      { field: 'UnpaidAmount', header: 'Unpaid Amount' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    this.getAPIData();
  }

  public getAPIData() {

    this.agingDetailsList = []
    if (this.currency == '' || this.currency == 'NULL' || this.currency == 'undefined') {

      this.HttpService
        .GetAll(`/finance-ws/invoice/get-invoice-aging-details?date=` + this.asOfDate + `&subsidiaryId=` + this.subsidiaryId + `&supplierId=` + this.supplierId
          , this.RetloginDetails.token)
        .subscribe((res) => {
          if (res?.status == 401) {
            alert("Unauthorized Access !");
          }
          else if (res?.status == 404) {
            alert("Wrong/Invalid Token!");
          }
          else {


            // var keys=Object.keys(res);
            //  for(let x=0;x<keys.length;x++)
            //  { alert("xcount"+x+1)
            //   for(let i=0;i<keys[x].length;i++)
            //   {alert("icount"+i+1)
            //     this.agingDetailsList.push(res[keys[x]][i]);
            //   }
            //  // this.accountStatement.(res[keys[x]]);
            //  }

            var keys = Object.keys(res);
            for (let x = 0; x < keys.length; x++) {
              let currentKey = keys[x];
              let data = res[currentKey];
              let obj: any = {};
              for (let i = 0; i < data.length; i++) {
                obj[i] = data[i];
              }
              this.agingDetailsList.push(obj);
            }



            console.log(this.agingDetailsList);
            //this.keyVal = Object.keys(this.agingDetailsList);
           


            // for(let i=0;i<this.agingDetailsList.INR.le;i++){

            //     this.agingDetailsData.push()
            // }

            if (res) {

              this.totalRecords = res.totalRecords

            } else {

              this.totalRecords = 0;

            }
            this.loading = false;



          }
        });
    }

    else {
      this.HttpService
        .GetAll(`/finance-ws/invoice/get-invoice-aging-details?date=` + this.asOfDate + `&subsidiaryId=` + this.subsidiaryId + `&supplierId=` + this.supplierId + `&currency=` + this.currency
          , this.RetloginDetails.token)
        .subscribe((res) => {
          if (res?.status == 401) {
            alert("Unauthorized Access !");
          }
          else if (res?.status == 404) {
            alert("Wrong/Invalid Token!");
          }
          else { 
            var keys = Object.keys(res);
            for (let x = 0; x < keys.length; x++) {
              this.agingDetailsList = res[keys[x]];
              //this.accountStatement?.push(res[keys[x]]);
            }

            this.agingDetailsData=[];
            
              this.agingDetailsData.push(this.agingDetailsList[0]?.paidAndUnpaidAmount[0],this.agingDetailsList[0]?.paidAndUnpaidAmount[1]);


            // for(let i=0;i<this.agingDetailsList.INR.le;i++){

            //     this.agingDetailsData.push()
            // }

            if (res) {

              this.totalRecords = res.totalRecords

            } else {

              this.totalRecords = 0;

            }
            this.loading = false;



          }
        });




    }



  }

  getObjectKeys(obj: any): string[] {
    return Object.keys(obj);
  }
  
  public exportPdf() {

    // create a new jsPDF instance
    const doc = new jsPDF('p', 'mm', 'a4');
    const pdfBody: any = [];



    // generate table content
    let subsidiaryName = this.subsidiaryName;
    let asOfdate = this.asOfDate;
    let supplierName = this.suppplierName;
    let x = 45; // X coordinate
    let y = 54; // Y coordinate
    let y2 = 54;
    // define the header and footer
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text("As of " + subsidiaryName || '', 8, 12);
      doc.text('Invoice Aging Summary', 75, 24);
      doc.setFontSize(12)
      doc.text("As Of " + asOfdate || '', 95, 36);
      //doc.setFontSize(14)
      const pageWidth = doc.internal.pageSize.getWidth(); // Get the width of the PDF page
      const text = supplierName || '';
      
      // Calculate the width of the text in the given font size
      const textWidth = doc.getStringUnitWidth(text) * 14 / doc.internal.scaleFactor;

      // Calculate the X-coordinate to center the text
      const x = (pageWidth - textWidth) / 2;

      doc.text(text, x, 48, {align: 'center' });
    };
   
    let startY = 75;
    const headerRow = [...this.columns.map((col) => {
      return { content: col.header, styles: { fillColor: [53, 67, 110], textColor: [255, 255, 255] } };
    })];

    if (this.currency == '' || this.currency == 'NULL' || this.currency == 'undefined') {
      for (let i = 0; i < this.agingDetailsList.length; i++) {
        // pdfBody.push([]);
        pdfBody.push(headerRow);
        let obj = this.agingDetailsList[i];
        let keys = Object.keys(obj);
        for (let j = 0; j < keys.length; j++) {
          let currentKey = keys[j];
          let data = obj[currentKey];
          // Access and use the data as needed
          let invoiceNo = data?.invoiceNo ?? '';
          let invoiceCode = data?.invoiceCode ?? '';
          let invoiceDate = new Date(data?.invoiceDate).toLocaleDateString('en-GB') ?? '';
          let paymentTerm = data?.paymentTerm ?? '';
          let dueDate = new Date(data?.dueDate).toLocaleDateString('en-GB') ?? '';
          let agedDays = data?.agedDays ?? '';
          let currency = data?.currency ?? '';
          let totalPaidAmount = data?.totalAmount?.toFixed(2) ?? '';
          let amountDue = data?.amountDue?.toFixed(2) ?? '';
          var paidAmount = obj[0]?.paidAndUnpaidAmount[0]?.toFixed(2) ?? '';
          var UnpaidAmount = obj[0]?.paidAndUnpaidAmount[1]?.toFixed(2) ?? '';
          pdfBody.push([j+1,invoiceNo, invoiceCode, invoiceDate, paymentTerm, dueDate, agedDays, currency, totalPaidAmount, amountDue]);
        }
        pdfBody.push(['Total', '', '', '', '', '', '', paidAmount, UnpaidAmount]);
        pdfBody.push(['Blank', '', '', '', '', '', '', '', ''])
      }
    } else {
      //pdfBody.push([]);
      pdfBody.push(headerRow);
      for (let i = 0; i < this.agingDetailsList.length; i++) {


        let data = this.agingDetailsList[i];

        // Access and use the data as needed
        let invoiceNo = data?.invoiceNo ?? '';
        let invoiceCode = data?.invoiceCode ?? '';
        let invoiceDate = new Date(data?.invoiceDate).toLocaleDateString('en-GB') ?? '';
        let paymentTerm = data?.paymentTerm ?? '';
        let dueDate = new Date(data?.dueDate).toLocaleDateString('en-GB') ?? '';
        let agedDays = data?.agedDays ?? '';
        let currency = data?.currency ?? '';
        let totalPaidAmount = data?.totalAmount?.toFixed(2) ?? '';
        let amountDue = data?.amountDue?.toFixed(2) ?? '';
        var paidAmount = this.agingDetailsList[0]?.paidAndUnpaidAmount[0]?.toFixed(2) ?? '';
        var UnpaidAmount = this.agingDetailsList[0]?.paidAndUnpaidAmount[1]?.toFixed(2) ?? '';
        pdfBody.push([i+1,invoiceNo, invoiceCode, invoiceDate, paymentTerm, dueDate, agedDays, currency, totalPaidAmount, amountDue]);


      }
      pdfBody.push(['Total', '', '', '', '', '', '', paidAmount, UnpaidAmount]);
    }

    let runBy=this.RetloginDetails.username;
    const footer = function () {
      
      let currentDate: Date;
      currentDate = new Date()
      doc.setFontSize(12);
      doc.text("Run Date & Time: "+currentDate.toLocaleString(), 8, doc.internal.pageSize.height - 10);  //doc.internal.pageSize.width/2-currentDate.toLocaleString().length
      doc.setFontSize(12);
      doc.text("Run By: "+runBy, 200, doc.internal.pageSize.height - 10);
    };


    (doc as any).autoTable({

      startY: startY,
      body: pdfBody,
      margin: { left: 8, bottom: 60, top: startY, right: 8 },
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [255, 255, 255],

      },

      headStyles: {
        fillColor: [53, 67, 110], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles: {
        4: { halign: 'right' },
        5: { halign: 'right' },
        6: { halign: 'right' },

        //7: { columnWidth: 22 }

      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;


        }

        if (data.section === 'body' && data.row.raw[0] === 'Blank') {
          data.cell.styles.fillColor = [255, 255, 255];
          data.cell.styles.lineWidth = 0;
          data.cell.styles.textColor = [255, 255, 255];

        }
      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();

        doc.setPage(data.pageNumber);
        //(doc as any).setY(doc.internal.pageSize.height - 50);
        // set the startY option for the autoTable on this page
        y = 54;
        y2 = 54;
        startY = (doc as any).autoTable.previous.finalY + 10;
      },
      
    });
    footer();
    

    // save the pdf file
    doc.save('report.pdf');
  }
  //----Suman Addition


  // Download Report 
  DownloadReport(prNumber: any) {
    //this.prReport.exportPdf(prNumber)

    //window.open(this.HttpService.ReportUrl + "/run?__report=report/Purchase_Requisition.rptdesign&__format=pdf&pr_number=" + prNumber, '_blank')
  }


  exportexcel() {
    const wsBody: any = [];

    // Heading of the invoice list

    wsBody.push([]);
    wsBody.push(['', this.subsidiaryName]);

    wsBody.push(['', 'Invoice Aging Summary']);
    wsBody.push(['', 'As of ' + this.asOfDate]);
    wsBody.push([]);
    wsBody.push(['', this.suppplierName]);
    if (this.currency == '' || this.currency == 'NULL' || this.currency == 'undefined') {
      for (let i = 0; i < this.agingDetailsList.length; i++) {

        wsBody.push([]);
        const headerRow = ['', ...this.columns.map(col => col.header)];
        wsBody.push(headerRow);
        let obj = this.agingDetailsList[i];
        let keys = Object.keys(obj);
        for (let j = 0; j < keys.length; j++) {
          let currentKey = keys[j];
          let data = obj[currentKey];
          // Access and use the data as needed
          let invoiceNo = data?.invoiceNo ?? '';
          let invoiceCode = data?.invoiceCode ?? '';
          let invoiceDate = new Date(data?.invoiceDate).toLocaleDateString('en-GB') ?? '';
          let paymentTerm = data?.paymentTerm ?? '';
          let dueDate = new Date(data?.dueDate).toLocaleDateString('en-GB') ?? '';
          let agedDays = data?.agedDays ?? '';
          let currency = data?.currency ?? '';
          let totalPaidAmount = data?.totalAmount?.toFixed(2) ?? '';
          let amountDue = data?.amountDue?.toFixed(2) ?? '';
          var paidAmount = obj[0]?.paidAndUnpaidAmount[0]?.toFixed(2) ?? '';
          var UnpaidAmount = obj[0]?.paidAndUnpaidAmount[1]?.toFixed(2) ?? '';
          wsBody.push(['',j+1,invoiceNo, invoiceCode, invoiceDate, paymentTerm, dueDate, agedDays, currency, totalPaidAmount, amountDue]);
        }
        wsBody.push(['', 'Total', '', '', '', '', '', '', paidAmount, UnpaidAmount]);

      }
    } else {
      const headerRow = ['', ...this.columns.map(col => col.header)];
      wsBody.push(headerRow);
      for (let i = 0; i < this.agingDetailsList.length; i++) {
        let data = this.agingDetailsList[i];
        let invoiceNo = data?.invoiceNo ?? '';
        let invoiceCode = data?.invoiceCode ?? '';
        let invoiceDate = new Date(data?.invoiceDate).toLocaleDateString('en-GB') ?? '';
        let paymentTerm = data?.paymentTerm ?? '';
        let dueDate = new Date(data?.dueDate).toLocaleDateString('en-GB') ?? '';
        let agedDays = data?.agedDays ?? '';
        let currency = data?.currency ?? '';
        let totalPaidAmount = data?.totalAmount?.toFixed(2) ?? '';
        let amountDue = data?.amountDue?.toFixed(2) ?? '';
        var paidAmount = this.agingDetailsList[0]?.paidAndUnpaidAmount[0]?.toFixed(2) ?? '';
        var UnpaidAmount = this.agingDetailsList[0]?.paidAndUnpaidAmount[1]?.toFixed(2) ?? '';
        wsBody.push(['',i+1, invoiceNo, invoiceCode, invoiceDate, paymentTerm, dueDate, agedDays, currency, totalPaidAmount, amountDue]);
      }
      wsBody.push(['', 'Total', '', '', '', '', '', '', paidAmount, UnpaidAmount]);



    }

    let runBy=this.RetloginDetails.username;
    let currentDate: Date;
    currentDate = new Date()  
    wsBody.push([]);
    wsBody.push([]);
    wsBody.push(['','','','','','','Run By: '+runBy+', '+currentDate.toLocaleString()]);

    const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(wsBody);

    // Merge and center 
    const reportHeadMerge = { s: { r: 1, c: 1 }, e: { r: 1, c: this.columns.length } };
    const reportNameMerge = { s: { r: 2, c: 1 }, e: { r: 2, c: this.columns.length } };
    const reportDateMerge = { s: { r: 3, c: 1 }, e: { r: 3, c: this.columns.length } };
    const reportSummaryMerge = { s: { r: 5, c: 1 }, e: { r: 5, c: this.columns.length } };


    ws['!merges'] = [reportHeadMerge, reportNameMerge, reportDateMerge, reportSummaryMerge];

    let headerStyle = {
      // styling for all cells
      font: {
        name: 'arial',
        bold: true,
        sz: 14
      },
      alignment: {
        vertical: 'center',
        horizontal: 'center',
        //wrapText: '1', // any truthy value here
      },
      // border: {
      //   right: {
      //     style: 'thin',
      //     color: '000000',
      //   },
      //   left: {
      //     style: 'thin',
      //     color: '000000',
      //   },
      // },
    };

    let tableStyle = {
      // styling for all cells
      alignment: {
        vertical: 'center',
        horizontal: 'center',
        //wrapText: '1', // any truthy value here
      },
      width: 20,
    };

    ws['B2'].s = headerStyle,
      ws['B3'].s = headerStyle,
      ws['B4'].s = headerStyle,
      //ws['B5'].s = headerStyle;
      // ws['F5'].s = headerStyle;
      ws['B6'].s = headerStyle;
    // ws['C6'].s = tableStyle; 
    // ws['D6'].s = tableStyle; 
    //ws['E6'].s = tableStyle; 
    //ws['F6'].s = tableStyle; 
    // ws['G6'].s = tableStyle; 
    //ws['H6'].s = tableStyle; 
    //ws['I6'].s = tableStyle; 
    // ws['J6'].s = tableStyle; 
    //ws['B2'].l = { Target:"https://conacent.com", Tooltip:"Find us @ Conacent.com!" };

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);

  }








  fileList: File[] = [];
  listOfFiles: any[] = [];
  isLoading = false;











  DownloadPdf() {
    window.open(this.HttpService.baseUrl + "/pr/download-template")
  }

  showAlert(AlertMSG: any) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }


}
