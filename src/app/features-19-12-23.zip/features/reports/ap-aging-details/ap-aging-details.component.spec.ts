import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApAgingDetailsComponent } from './ap-aging-details.component';

describe('ApAgingDetailsComponent', () => {
  let component: ApAgingDetailsComponent;
  let fixture: ComponentFixture<ApAgingDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApAgingDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApAgingDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
