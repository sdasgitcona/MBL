

export class agingDetailsSummary {
 INR:INRDetails[]// = new INRDetails();

}

export class INRDetails {
    unPaidBillCount?:any
    unPaidBillAmount?: any;
    invoiceId?: number;
    supplierId?: number;
    subsidiaryId?: number;
    poId?: number;
    locationId?: number;
    billToId?: any;
    shipToId?: any;
    invoiceNo?: any;
    invStatus?: string;
    paymentTerm?: string;
    integratedId?: any;
    currency?: string;
    billTo?: any;
    shipTo?: any;
    invoiceCode?: any;
    invoiceSupplyNumber?: any;
    taxRegNumber?: string;
    invoiceDate?: Date;
    dueDate?: Date;
    fxRate?: number;
    amount?: number;
    taxAmount?: number;
    totalAmount?: number;
    rejectedComments?: any;
    amountDue?: number;
    temp_xyz?: any;
    externalId?: any;
    hasError?: boolean;
    approvedBy?: string;
    nextApprover?: string;
    nextApproverUid?: any;
    nextApproverRole?: string;
    nextApproverLevel?: any;
    approverPreferenceId?: any;
    approverSequenceId?: any;
    approverMaxLevel?: any;
    noteToApprover?: string;
    nsMessage?: string;
    nsStatus?: string;
    subsidiaryName?: string;
    supplierName?: string;
    poNumber?: any;
    invoiceItems?: string;
    totalPaidAmount?: number;
    invoicePayments?: any;
    approvedByName?: string;
    locationName?: string;
    createdBy?: string;
    lastModifiedBy?: string;
    createdDate?: Date;
    lastModifiedDate?: Date;
    agedDays?: any;
    paidAndUnpaidAmount?:any=[]

}



