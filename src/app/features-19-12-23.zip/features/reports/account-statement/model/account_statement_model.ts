export class accountStatement {
    type?: string;
    refNo?: string;
    voucherNo?:any;
    date?:any;
    currency?:any;
    bankName?: any;
    paymentMode?:any;
    amount?: any;
    currentBalance?:any;
    amountWithSign:any;
}

export class dueDatesInfo {
category?: string; 
value?: any;
}

