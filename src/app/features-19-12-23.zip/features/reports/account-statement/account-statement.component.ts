import { Component, OnInit ,ViewChild,ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { ActivatedRoute, Params } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import { HttpHeaderResponse, HttpHeaders } from '@angular/common/http';
import { saveAs } from 'file-saver';
import { jsPDF } from 'jspdf';
import * as XLSX from 'xlsx';
import { accountStatement, dueDatesInfo } from './model/account_statement_model';




@Component({
  selector: 'app-account-statement',
  templateUrl: './account-statement.component.html',
  styleUrls: ['./account-statement.component.scss']
})
export class AccountStatementComponent implements OnInit {

 // accountStatement: accountStatement[];
  accountStatement: any[]=[];
  dueDatesInfo: dueDatesInfo[];
  SubsideryObject = [];

  //accStmt: accountStatement = new accountStatement();
  
  columns: any[] = [];
  totalRecords: number = 0;
  loading: boolean = false;
  lastPTableSearchEvent: any;
  departmentOptions: any;
  EmployeeList: any[];
  RetloginDetails: any;
  subscription: any;
  subsidiaryName:string;

  acctStmt:any=[];
  
  status: any;
  file: File;
  displayModal: boolean;
  //file_upliad: file_upliad = new file_upliad();
  fileName = 'ExcelSheet.xlsx';
  isParams: boolean = true;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  // For Role Base Access
  subsidiaryId:number;

  fromDate:any;
  toDate:any;
  fDate:any;
  tDate:any;
  
  supplier:any;
  currency:any;
  supId:any;

  frmDate:any;
  toooDate:any;

  cols: any[];
  @ViewChild('header')header!: ElementRef;
  @ViewChild('footer')footer!: ElementRef;
  @ViewChild('estimatedTotal') estimatedTotal!: ElementRef;


  exportColumns: any[];

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService,
    
    //private prReport: PrReportComponent

  ) {
    this.departmentOptions = ["Admin", "HR", "Finance", "Purchase", "Production",]
  }

  ngOnInit(): void {

       this.subscription = this.activatedRoute.params.subscribe((params) => {

       
      if (params) {
      
        this.subsidiaryName = params['subName'];
        this.subsidiaryId = params['subId'];
        this.fromDate = params['fromDate'];
        this.toDate = params['toDate'];
        this.supplier = params['supName'];
        this.supId=params['supId'];
        this.currency = params['currency'];
        this.fDate=params['fDate'];
        this.tDate=params['tDate'];

      }


    });

    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Account Statement") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
      }
    }
    // End For Role Base Access



    this.primengConfig.ripple = true;
    this.columns = [
      { field: 'Sl No', header: '#'},
      { field: 'Transaction Type', header: 'Transaction Type' },
      { field: 'Transaction Reference', header: 'Transaction Reference' },
      { field: 'Voucher No', header: 'Voucher No' },
      { field: 'Date', header: 'Date' },
      { field: 'Currency', header: 'Currency' },
      { field: 'Bank Name', header: 'Bank Name' },
      { field: 'Payment Mode', header: 'Payment Mode' },
      { field: 'Amount', header: 'Amount' },
      { field: 'Balance', header: 'Balance' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

   

    this.getAPIData();
    

  }

  


  public getAPIData() {
     
    //http://43.205.33.156:8082/finance-ws/invoice/get-account-statement?fromDate=01/04/2023&toDate=30/04/2023&currency=INR&supplierName=Cloud India Pvt Ltd&subsidiaryId=24
    
    
    
    this.accountStatement=[]
    if(this.currency =='' || this.currency =='NULL' || this.currency =='undefined'){
    //alert(this.subsidiaryId+''+this.supId);
    this.HttpService
      .GetAll(`/finance-ws/invoice/get-supplier-statement?fromDate=`+this.fromDate+`&toDate=`+this.toDate+`&supplierId=`+this.supId+`&subsidiaryId=`+this.subsidiaryId, this.RetloginDetails.token)
      //.GetAll(`/finance-ws/invoice/get-account-statement?fromDate=2023-05-01&toDate=2023-06-01&supplierId=4&subsidiaryId=12`, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          alert("Unauthorized Access !");
        }
        else if (res.status == 404) {
          alert("Wrong/Invalid Token!");
        }
        else {
          var keys = Object.keys(res);
            for (let x = 0; x < keys.length; x++) {
              let currentKey = keys[x];
              let data = res[currentKey];
              let obj: any = {};
              for (let i = 0; i < data.length; i++) {
                obj[i] = data[i];
              }
              this.accountStatement.push(obj);
            }
          this.dueDatesInfo = res.dueDatesInfo;
          if (res) {
 
            this.totalRecords = res.totalRecords;

          } else {
            
            this.totalRecords = 0;

          }
          this.loading = false;

        }
      });
    }
    else{
      //alert('second');
      this.HttpService
      
      .GetAll(`/finance-ws/invoice/get-supplier-statement?fromDate=`+this.fromDate+`&toDate=`+this.toDate+`&currency=`+this.currency+`&supplierId=`+this.supId+`&subsidiaryId=`+this.subsidiaryId
        , this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          alert("Unauthorized Access !");
        }
        else if (res.status == 404) {
          alert("Wrong/Invalid Token!");
        }
        else {
          // console.log(JSON.stringify(res));
           var keys=Object.keys(res);
           for(let x=0;x<keys.length;x++)
           {
           this.accountStatement =res[keys[x]];
           //this.accountStatement?.push(res[keys[x]]);
           }
          // 
          //this.accountStatement = res.INR;
          this.dueDatesInfo = res.dueDatesInfo;
          if (res) {
 
            this.totalRecords = res.totalRecords;

          } else {
            
            this.totalRecords = 0;

          }
          this.loading = false;
         

        }
      });
    }
  }


 exportexcel() {

  
    const wsBody: any = [];

    // Heading of the invoice list
    const subsidaryName = ['','','','','Subsidiary Name',this.subsidiaryName];
    wsBody.push([]);
    wsBody.push(subsidaryName);

    wsBody.push(['','','','','Supplier Statement']);
    wsBody.push(['','','','','Supplier Name',this.supplier]);
    wsBody.push(['','','','','From', this.fromDate, 'To',this.toDate]);

    
    wsBody.push(['','','','','','','Account Summary']);
    wsBody.push(['','','','','','','Opening Amount as on',this.fromDate,'']);
    wsBody.push(['','','','','','','Invoice Amount','']);
    wsBody.push(['','','','','','','Amount Paid','']);
    wsBody.push(['','','','','','','Amount Due','']);

    if (this.currency == '' || this.currency == 'NULL' || this.currency == 'undefined') {
      for (let i = 0; i < this.accountStatement.length; i++) {

    wsBody.push([]);
    const headerRow =  ['', ...this.columns.map(col => col.header)];
    wsBody.push(headerRow);
    let obj = this.accountStatement[i];
    let keys = Object.keys(obj);//15
    for (let j = 0; j <  keys.length; j++) {//13
      let currentKey = keys[j];
      let data = obj[currentKey];

      //console.log("data: "+data);
    // Add payment data body
      let type=data?.type ?? '';
      let refNo=data?.refNo ?? '';
      let vouchNo=data?.voucherNo ?? '';
      let stDate = new Date(data?.date).toLocaleDateString('en-GB')??'';
      let bankName=data?.bankName ?? '';
      let paymentMode=data?.paymentMode ?? '';
      let amountWithSign=Number(data?.amountWithSign??'').toFixed(2);
      let curr=data?.currency ?? '';
      let curblnc=data?.currentBalance?.toFixed(2)??''  
      wsBody.push([
     '', 
      j+1,
      type,
      refNo,
      vouchNo,
      stDate,
      curr,
      bankName,
      paymentMode,
      amountWithSign,
      curblnc
      ]);
    
  }
 }
}
  else{
    const headerRow =  ['', ...this.columns.map(col => col.header)];
    wsBody.push(headerRow);
    let i=0;
    // Add payment data body
    this.accountStatement.forEach((accountStatement: any) => {
      const stDate = new Date(accountStatement?.date??'');
      wsBody.push([
        '',
        i+1,
        accountStatement.type,
        accountStatement.refNo,
        accountStatement.voucherNo,
        stDate?.toLocaleDateString('en-GB')??'',
        accountStatement.currency,
        accountStatement.bankName,
        accountStatement.paymentMode,
        Number(accountStatement?.amountWithSign??'').toFixed(2),
        accountStatement?.currentBalance?.toFixed(2)??''
      ]);
    });
  }


  let runBy=this.RetloginDetails.username;
    let currentDate: Date;
    currentDate = new Date()  
    wsBody.push([]);
    wsBody.push([]);
     wsBody.push(['','','','Run By- '+runBy+', '+currentDate.toLocaleString()]);
    const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(wsBody);

    // Merge and center 
    const reportHeadMerge = { s: { r: 1, c: 1 }, e: { r: 1, c: this.columns.length - 1 } };
    const reportNameMerge = { s: { r: 2, c: 1 }, e: { r: 2, c: this.columns.length - 1 } };
    const reportDateMerge = { s: { r: 3, c: 1 }, e: { r: 3, c: this.columns.length - 1 } };
    const outline = {s: { r: 5, c: 1 }, e: { r: 5, c: this.columns.length - 1 }};
    // const authorizedSignatureMerge = { s: { r: wsBody.length - 3, c: 0 }, e: { r: wsBody.length - 2, c: this.columns.length - 1 } };

    //ws['!merges'] = [reportHeadMerge, reportNameMerge, reportDateMerge, authorizedSignatureMerge];

    ws['!outline']= [outline];
    const mergeCellStyles = {
      font: { bold: true },
      alignment: { horizontal: 'center', vertical: 'center' },
      border: {
        top: { style: 'thick', color: { rgb: '000000' } },
        bottom: { style: 'thick', color: { rgb: '000000' } },
        left: { style: 'thick', color: { rgb: '000000' } },
        right: { style: 'thick', color: { rgb: '000000' } }
      },
      fill: { fgColor: { rgb: '#ff0' } } 
    };
    let row = [
      { v: "Courier: 24", t: "s", s: { font: { name: "Courier", sz: 24 } } },
      { v: "bold & color", t: "s", s: { font: { bold: true, color: { rgb: "FF0000" } } } },
      { v: "fill: color", t: "s", s: { fill: { fgColor: { rgb: "E9E9E9" } } } },
      { v: "line\nbreak", t: "s", s: { alignment: { wrapText: true } } },
    ];
    
   
    ws['B5'].cellStyles = mergeCellStyles;

    
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);
  }

  fileList: File[] = [];
  listOfFiles: any[] = [];
  isLoading = false;

  exportPdf(){
    //alert("PDF"); 
  this.getApisall();
  
  }

  getApisall(){
   //alert("api data");

   this.accountStatement=[];
   //api related

   if(this.currency == '' || this.currency =='NULL' || this.currency =='undefined'){
   this.HttpService
     .GetAll(`/finance-ws/invoice/get-supplier-statement?fromDate=`+this.fromDate+`&toDate=`+this.toDate+`&supplierId=`+this.supId+`&subsidiaryId=`+this.subsidiaryId
     , this.RetloginDetails.token)
     .subscribe((res) => {
       if (res.status == 401) {
         alert("Unauthorized Access !");
       }
       else if (res.status == 404) {
         alert("Wrong/Invalid Token!");
       }
       else {
        
       
        var keys = Object.keys(res);
            for (let x = 0; x < keys.length; x++) {
              let currentKey = keys[x];
              let data = res[currentKey];
              let obj: any = {};
              for (let i = 0; i < data.length; i++) {
                obj[i] = data[i];
              }
              this.accountStatement.push(obj);
            }
         if (res) {

           this.totalRecords = res.totalRecords;

            this.DownloadPdf(); 

         } else {
           
           this.totalRecords = 0;

         }
         this.loading = false;
        

       }
     });
   }
   else{
     
     this.HttpService
     .GetAll(`/finance-ws/invoice/get-supplier-statement?fromDate=`+this.fromDate+`&toDate=`+this.toDate+`&currency=`+this.currency+`&supplierId=`+this.supId+`&subsidiaryId=`+this.subsidiaryId
       , this.RetloginDetails.token)
     .subscribe((res) => {
       if (res.status == 401) {
         alert("Unauthorized Access !");
       }
       else if (res.status == 404) {
         alert("Wrong/Invalid Token!");
       }
       else {
        var keys=Object.keys(res);
        for(let x=0;x<keys.length;x++)
        {
        this.accountStatement =res[keys[x]];
        //this.accountStatement?.push(res[keys[x]]);
        }
      
         if (res) {

           this.totalRecords = res.totalRecords;

           
             this.DownloadPdf(); 

         } else {
           
           this.totalRecords = 0;

         }
         this.loading = false;
        

       }
     });
   }
   
  }

  DownloadPdf() {
   // alert("Download Pdf");

    // create a new jsPDF instance
    const doc = new jsPDF('p', 'mm', 'a4');
    const pdfBody: any = [];

    // generate table content
    let subName=this.subsidiaryName;
    let supName=this.supplier
    let fDate=this.fDate
    let tDate=this.tDate
    //end table content

    // define the header and footer
    this.subsidiaryName
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subName, 8, 12);
      doc.text('Supplier Statement', 82, 24);
      doc.setFontSize(12);
      doc.text('Supplier Name:', 80, 30);
      doc.text(supName,110, 30);
      doc.text('From Date:', 70, 36);
      doc.text(fDate, 92, 36);
      doc.text('To Date:', 115, 36);
      doc.text(tDate, 132, 36);
      //header data
      //end header data

      //right block data
      let x1 = 120;
      let y2 = 64;


      doc.rect(115, 48, 90, 10, 'F'); // draw a rectangle as background
      doc.setTextColor(255, 255, 255);
      doc.setFont("Arial", "bold")
      doc.setFontSize(12);
      doc.text('Account Summary', 134, 54);
      doc.setFillColor(156, 178, 221); // set fill color to blue
      doc.rect(115, 58, 90, 30, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(10);

      doc.setFont("Arial", "bold");
      doc.text('Opening Amount as on '+fDate, x1, y2);
      doc.setFont("Arial", "normal");
      doc.text(": "|| "", 175, y2);
      

      doc.setFont("Arial", "bold");
      doc.text('Invoice Amount ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "|| "", 175, y2);
      

      doc.setFont("Arial", "bold");
      doc.text('Ammount paid', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "  || "", 175, y2);

      doc.setFont("Arial", "bold");
      doc.text('Amount Due', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "  || "", 175, y2);

    };


    let runBy=this.RetloginDetails.username;
    const footer = function () {

      let currentDate: Date;
      currentDate = new Date()

      let y=doc.internal.pageSize.height - 36;
      doc.setFontSize(9);
      doc.setTextColor(0);
      doc.text('Remarks', 14, y);
      doc.text(': ', 32, y);
      
      doc.text('Current Date', 14, doc.internal.pageSize.height - 10);
      doc.text(': ' + currentDate.toLocaleString(), 37, doc.internal.pageSize.height - 10);

      doc.text('____________________', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 40);
      doc.text('  Authorized Signature', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 30);

      
      doc.text('Run By: '+runBy, doc.internal.pageSize.width -80, doc.internal.pageSize.height - 10);

    };

    

    let startY = 90;

    const headerRow = [...this.columns.map((col) => {
      return { content: col.header, styles: { fillColor: [53, 67, 110], textColor: [255, 255, 255] } };
    })];

    if (this.currency == '' || this.currency == 'NULL' || this.currency == 'undefined') {
      for (let i = 0; i < this.accountStatement.length; i++) {
      
        // pdfBody.push([]);
        pdfBody.push(headerRow);
        let obj = this.accountStatement[i];
        let keys = Object.keys(obj);
        for (let j = 0; j < keys.length; j++) {
          let currentKey = keys[j];
          let data = obj[currentKey];
          // Access and use the data as needed
        let type=data?.type ?? '';
      let refNo=data?.refNo ?? '';
      let vouchNo=data?.voucherNo ?? '';
      let stDate = new Date(data?.date).toLocaleDateString('en-GB')??'';
      let bankName=data?.bankName ?? '';
      let paymentMode=data?.paymentMode ?? '';
      let amountWithSign=Number(data?.amountWithSign??'').toFixed(2);
      let curr=data?.currency ?? '';
      let curblnc=data?.currentBalance?.toFixed(2)??''  
          pdfBody.push([j+1,
          type,
          refNo,
          vouchNo,
          stDate,
          curr,
          bankName,
          paymentMode,
          amountWithSign,
          curblnc]);
        }
       
      }
    } else {
      //pdfBody.push([]);
      //pdfBody.push(headerRow);
      for (let i = 0; i < this.accountStatement.length; i++) {


        let data = this.accountStatement[i];

        // Access and use the data as needed
      let type=data?.type ?? '';
      let refNo=data?.refNo ?? '';
      let vouchNo=data?.voucherNo ?? '';
      let stDate = new Date(data?.date).toLocaleDateString('en-GB')??'';
      let bankName=data?.bankName ?? '';
      let paymentMode=data?.paymentMode ?? '';
      let amountWithSign=Number(data?.amountWithSign??'').toFixed(2);
      let curr=data?.currency ?? '';
      let curblnc=data?.currentBalance?.toFixed(2)??''  
        pdfBody.push([i+1,
        type,
        refNo,
        vouchNo,
        stDate,
        curr,
        bankName,
        paymentMode,
        amountWithSign,
        curblnc]);



      }
      
    }


    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: pdfBody,
      margin: { left: 6, bottom: 40, top: startY, right: 5 },
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [255, 255, 255],

      },

      headerStyles: {
        fillColor: [53, 67, 110], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles:{
        4:{halign:'right'}
      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;
          if (data.pageCount === (doc as any).internal.getNumberOfPages()) {
            // add the footer section to the last page
            (doc as any).autoTable({
              head: false,
              body: false,
              //foot: [['', '', '', '', '', 'Estimated Total:']],
              startY: doc.internal.pageSize.height - 90,
              tableWidth: 'wrap',
              styles: {
                cellPadding: 1,
                fontSize: 10,
                valign: 'middle',
                halign: 'center',
                fillColor: [53, 67, 110],
              },
            });
          }

        }




      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();
        
        doc.setPage(data.pageNumber);
        
        startY = (doc as any).autoTable.previous.finalY + 10;
        
      },

    });

    footer();

    doc.save('Supplier_Statement.pdf');


  }

  showAlert(AlertMSG: any) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }

  getObjectKeys(obj: any): string[] {
    return Object.keys(obj);
  }

}

