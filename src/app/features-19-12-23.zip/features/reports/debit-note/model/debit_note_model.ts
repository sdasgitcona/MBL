export class debitNote{
  id:any;
  debitNoteNumber:any;
  subsidiaryId:any;
  supplierId:any;
  debitNoteDate:any;
  department:any;
  rtvNumber:any;
  grnNumber:any;
  invoiceNumber:any;
  amount:any;
  taxAmount:any;
  totalAmount:any;
  currency:any;
  exchangeRate:any;
  memo:any;
  returnType:any;
  approvalStatus:any;
  createdDate:any;
  createdBy:any;
  lastModifiedDate:any;
  lastModifiedBy:any;
  departmentId:any;
  projectId:any;
  nsMessage:any;
  nsStatus:any;
  integratedId:any;
  nextApprover:any;
  nextApproverRole:any;
  rejectedComments:any;
  approvedBy:any;
  approvedByName:any;

  debitNoteItem:debitNoteItem[]=[];
  debitNoteApply:any;
  approverPreferenceId:any;
  approverSequenceId:any;
  approverMaxLevel:any;
  noteToApprover:any;
  nextApproverUid:any;
  nextApproverLevel:any;
  approvalDate:any;
  subsidiaryName:any;
  supplierName:any;

  suppliers:supplier;
  subsidiarys:subsidiary;

  deleted: boolean;
  approvalRoutingActive: boolean;
}
export class debitNoteItem{
            id:any;
            debitNoteId:any;
            debitNoteNumber:any;
            itemId:any;
            itemName:any;
            department:any;
            projectId:any;
            itemDescription:any;
            glCode:any;
            quantity:any;
            rate:any;
            basicAmount:any;
            taxGroupId:any;
            taxAmount:any;
            totalAmount:any;
            createdDate:any;
            createdBy:any;
            lastModifiedDate:any;
            lastModifiedBy:any;
            departmentId:any;
            taxName:any;
            deleted:any;
}
export class supplier{
        id:any;
        externalId:any;
        name:any;
        legalName:any;
        paymentTerm:any;
        vendorNumber:any;
        vendorType:any;
        uin:any;
        approvalStatus:any;
        rejectComments:any;
        natureOfSupply:any;
        uniqueNumber:any;
        invoiceMail:any;
        tdsWitholding:any;
        approvedBy:any;
        nextApprover:any;
        nextApproverRole:any;
        nextApproverLevel:any;
        approverPreferenceId:any;
        approverSequenceId:any;
        approverMaxLevel:any;
        noteToApprover:any;
        nsMessage:any;
        nsStatus:any;
        integratedId:any;
        activeDate:any;
        createdDate:any;
        createdBy:any;
        lastModifiedDate:any;
        lastModifiedBy:any;
        //supplierAddresses:any;
        supplierAddresses:supAddrs[]=[];
        supplierContacts:supContact[]=[];
        active:any;
        deleted:any;
        approvalRoutingActive:any;
}
export class supAddrs{
  id:any;
  supplierId:any;
  address1: any;
  address2: any;
  city: any;
  state: any;
  country: any;
  pin: any;
  taxRegistrationNumber: any;
  registrationType: any;             
}  
export class supContact{
  id:any;
  supplierId:any;
  name: any;
  contactNumber: any;
  altContactNumber: any;
  email: any;
  web: any;
  fax: any;
}

export class subsidiary{
        id:any;
        name:any;
        accountId:any;
        legalName:any;
        parentCompany:any;
        country:any;
        email:any;
        website:any;
        language:any;
        currency: any;
        fiscalCalender:any;
        pan:any;
        cin:any;
        tan:any;
        bidMail:any;
        invoiceMail:any;
        invoicePasswd:any;
        adminMail:any;
        activeDate:any;
        integratedId:any;
        logoMetadata:any;
        logo:any;
        createdDate:any;
        createdBy:any;
        lastModifiedDate:any;
        lastModifiedBy:any;
        inactiveDate:any;
        parent:any;
        active:any;
        deleted:any;     
        subsidiaryAddresses: subAddrs[]=[];
        subsidiaryGeneralInfo:subGenInfos[]=[]
}

export class subAddrs{
  subsidiaryId:any;
  country:any;
  attention: any;
  address: any;
  phone: any;
  address1: any;
  address2: any;
  city: any;
  state: any;
  zipcode: any;
  registrationCode: any;
  registrationType: any  
     
}
export class subGenInfos{
id:number;
serialNumber:number;
remarks:any;
subsidiaryId:number;
}


