import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { Router } from '@angular/router';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { debitNote,debitNoteItem,supplier,supAddrs,supContact,subsidiary,subAddrs} from './model/debit_note_model';
import * as FileSaver from 'file-saver';
import {jsPDF} from 'jspdf';
import * as XLSX from 'xlsx';
import jsPDFWithPlugin from 'jspdf';
import html2canvas from 'html2canvas';

//import 'jspdf-autotable';
import autoTable from 'jspdf-autotable';
import { Header } from 'primeng/api';
import { TableBody } from 'primeng/table';
import 'jspdf-autotable';

@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-debit-note',
  templateUrl: './debit-note.component.html',
  styleUrls: ['./debit-note.component.scss']
})
export class DebitNoteComponent implements OnInit {

  dnList:debitNote=new debitNote();
  debitNoteItem:any[]=[];
  
  subsidiarys:subsidiary=new subsidiary();
  subAddrs:subAddrs[]=[];

  subAddress:subAddrs=new subAddrs();
  //subGenInfo:subGenInfo=new subGenInfo();
  //subGen:any =[];
  
  suppliers:supplier=new supplier();
  supAddrs:supAddrs[]=[];
  supContact:supContact[]=[];

  supplierAddress:any=[];
  subsidiaryAddress:any=[];


  //supplierContacts:supContacts=new supContacts();
  supplierContacts:any=[];
  
  dnNumber:any;
  dnItem:any[]=[];
  dnData: any = [];

  totalRecords:number=0;
  loading: boolean = false;
  RetloginDetails:any;
  pdfSrc:any;
  convertedSignature:any;
  finalAppDate:any;
  cols: any[];
  file: File ;
  //file_upload:file_upload=new file_upload();
  type:any;




  
  


  @ViewChild('header')header!: ElementRef;
  @ViewChild('footer')footer!: ElementRef;
  @ViewChild('estimatedTotal') estimatedTotal!: ElementRef;


  exportColumns: any[];


  constructor(private httpService: CommonHttpService,
    private routeStateService: RouteStateService,
    private router: Router,
    private toastService: ToastService) { 

  }

  ngOnInit(){
    
    
      
  //   this.productService.getProductsMini().then((data) => {
  //     this.products = data;
  // });

  this.cols = [
    { field: 'id', header: '#'},
    { field: 'name', header: 'Item Name' },
    { field: 'description', header: 'Description' },
    { field: 'uom', header: 'Uom' },
    { field: 'quantity', header: 'Quantity' },
    { field: 'rate', header: 'Rate'},
    { field: 'taxableamount', header:'Taxable Amount'},
    { field: 'taxamount', header:'Tax Code'},
    { field: 'taxamount', header:'Tax Amount'},
    { field: 'amount', header:'Amount'}
];

this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
//call api
this.getApiall(this.dnNumber,this.type);
    
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  exportPdf(dnNumber:any,type:any){
  
    this.cols = [
      { field: 'id', header: '#'},
      { field: 'name', header: 'Item Name' },
      { field: 'description', header: 'Description' },
      { field: 'uom', header: 'Uom' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'rate', header: 'Rate'},
      { field: 'taxableamount', header:'Taxable Amount'},
      { field: 'taxcode', header:'Tax Code'},
      { field: 'taxamount', header:'Tax Amount'},
      { field: 'amount', header:'Total Amount'}
  ];
  
  this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
  
  this.getApiall(dnNumber,type);

  }
  getApiall(dnNumber:any,type:any){
    //api call with token
    //alert('api call');
      const retDetails: any = localStorage.getItem("RoleDTLS");
      var role_Dtls = JSON.parse(retDetails);
  
  
      const LDetails: any = localStorage.getItem("LoggerDTLS");
      this.RetloginDetails = JSON.parse(LDetails);
  
      this.httpService
       .GetAll(`/finance-ws/debitNote/report?debitNoteNumber=`+dnNumber, this.RetloginDetails.token)
      //.GetAll(`/procure-ws/po/get/by-po-number?poNumber=HPL/10004/PO`, this.RetloginDetails.token)
       .subscribe((res) => {
          if (res.status == 401) {
            alert("Unauthorized Access !");
          }
          else if (res.status == 404) {
            alert("Wrong/Invalid Token!");
          }
          else{
            if (res && res?.debitNoteItem?.length > 0) 
          {
            console.log('Rsultant Value= '+JSON.stringify(res));
            this.dnList=res;

            if (res.supplier && Array.isArray(res?.supplier?.supplierAddresses)) {
             
                  this.supplierAddress = res.supplier?.supplierAddresses;
                  this.supplierAddress.forEach((address: any) => {
                    this.supplierAddress = address;
                  });
                } else {
                  console.log("Error: invalid response");
                }

                if (res.supplier && Array.isArray(res.supplier.supplierContacts)) {
             
                  this.supplierContacts = res.supplier.supplierContacts;
                  this.supplierContacts.forEach((contacts: any) => {
                    this.supplierContacts = contacts;
                  });
                } else {
                  console.log("Error: invalid response");
                }
    
                if (res.subsidiary && Array.isArray(res.subsidiary.subsidiaryAddresses)) {
             
                  this.subsidiaryAddress = res.subsidiary.subsidiaryAddresses;
                  this.subsidiaryAddress.forEach((subAdrs: any) => {
                    this.subsidiaryAddress = subAdrs;
                   
                  });
                } else {
                  console.log("Error: invalid response");
                }

                console.log('Subsidiary Address-----'+JSON.stringify(this.subsidiaryAddress));

              this.subsidiarys =res.subsidiary;
              //console.log('Subsidiary-----'+JSON.stringify(this.subsidiarys));

              this.subAddrs=res.subsidiary.subsidiaryAddresses;
              //console.log('Subsidiary Address-----'+JSON.stringify(this.subAddr));

              this.suppliers =res.supplier;
              //console.log('Supplier Details-----'+JSON.stringify(this.suppliers));

              this.supAddrs=this.suppliers.supplierAddresses;
              //console.log('Supplier Address-----'+JSON.stringify(this.supAddr));

              this.supContact=this.suppliers.supplierContacts;
              //console.log('Supplier Contacts-----'+JSON.stringify(this.supContacts));

              this.dnItem = res.debitNoteItem;

              this.totalRecords = res.totalRecords;
              //Push data
              this.dnData=[];
              for (let i = 0; i < this.dnItem.length; i++) {
                
                this.dnData.push([i + 1, 
                  this.dnItem[i].itemName, 
                  this.dnItem[i].itemDescription, 
                  this.dnItem[i].itemUom,
                  this.dnItem[i].quantity, 
                  this.dnItem[i].rate?.toFixed(2), 
                  this.dnItem[i].basicAmount?.toFixed(2), 
                  this.dnItem[i].taxName, 
                  this.dnItem[i].taxAmount?.toFixed(2), 
                  this.dnItem[i].totalAmount?.toFixed(2)]);
                }
           }
           else {
             
                this.totalRecords = 0;
    
              }
              this.loading = false;
          }
          this.exportPdfAPI(type);
        });
        
    }
  //water Mark
  public addWaterMark(doc:any) {
    let totalPages:any = doc.internal.getNumberOfPages();
    let status: any = this.dnList?.nsStatus;
    //alert (totalPages);
  
    for (let i = 1; i <= totalPages; i++) {

      doc.setPage(i);
      //doc.addImage(imgData, 'PNG', 40, 40, 75, 75);
      doc.setTextColor(150);
      doc.setFontSize(300);
    
      //for text transparency
      doc.saveGraphicsState();
      doc.setGState(new doc.GState({opacity: 0.2}));

      
      //if(status=='Draft' || status=='draft'){
     if(status=='Open' || status=='open' || status=='Rejected' || status=='rejected'|| status=='Partially Approved' || status=='partially approved'|| status=='Pending Approval'|| status=='pending approval'){
     
      
      doc.text(60, doc.internal.pageSize.height - 35, 'Draft',{angle: 50,});
      }
      else{
       
        doc.text(8, doc.internal.pageSize.height - 135,'',{angle: 45,});
        
      }
      doc.restoreGraphicsState(); 
    }
    return doc;
    
  }

  //exportPdf(poNumber:any) {
    exportPdfAPI(type:any){

  // create a new jsPDF instance
    const doc = new jsPDF('p', 'mm', 'a4');
  
    // generate table content
    
    let subsidiaryName = (this.subsidiarys ?.legalName)|| '';

    console.log('Subsidiary Name - '+subsidiaryName);

      if(subsidiaryName!=''){
       subsidiaryName = (this.subsidiarys ?.legalName)|| '';
      }
      else{
        subsidiaryName = (this.subsidiarys ?.name)|| '';
      }



    let subName = doc.splitTextToSize(this.subsidiarys ?.legalName || '',75);

   if(subName!=''){
    subName=doc.splitTextToSize(this.subsidiarys ?.legalName || '',85);
   }
   else{
    subName = doc.splitTextToSize(this.subsidiarys ?.name || '',75);
   }

    let supplierName = doc.splitTextToSize(this.suppliers ?.legalName || '',75);

    if(supplierName==''){
      supplierName = doc.splitTextToSize(this.suppliers ?.name || '',75); 
    }
    else{
      supplierName = doc.splitTextToSize(this.suppliers ?.legalName || '',75);
    }

    // define the header and footer
    
    //header data
    let dnNumber: any = this.dnList?.debitNoteNumber || '';

    let memo: any=doc.splitTextToSize(this.dnList?.memo || '',180);

    //let sign:any=this.dnList?.convertedSignature||'';

    const appDate:any=this.dnList?.approvalDate||'';
    const date2 = new Date(appDate);
    const appsDate = date2.toLocaleDateString('en-GB');

    

     if(appsDate=='Invalid Date'){
      this.finalAppDate='';
     }
     else{
      this.finalAppDate=appsDate;
     }
    

    const timestamp = this.dnList?.debitNoteDate || '';
    const date = new Date(timestamp);
    const dnData = date.toLocaleDateString('en-GB');

    const returnType=this.dnList?.returnType || '';

     const rtvNumber=this.dnList?.rtvNumber || '';
     const grnNumber=this.dnList?.grnNumber || '';
    

    //const approvalstat= this.dnList?.poStatus || '';

    //ship to location
    //let location: any = this.dnList?.locationName || '';

  //subsidiary

  
    let address: any = doc.splitTextToSize((this.subsidiaryAddress?.address1 ?? '') +
    (this.subsidiaryAddress?.address2 ? (this.subsidiaryAddress.address1 ? ', ' : '') + this.subsidiaryAddress.address2 : ''),
    80);
    
    let city: any = this.subsidiaryAddress?.city || '';
    let email:any=this.subsidiaryAddress?.email || '';
    let invMail:any=this.subsidiarys?.invoiceMail || '';
     let state: any = this.subsidiaryAddress?.state || '';
    let zipcode: any = this.subsidiaryAddress?.zipcode || '';
    let country: any = this.subsidiaryAddress?.country|| '';
     let website: any = this.subsidiaryAddress?.website || '';
     let vatCode: any = this.subsidiarys?.pan || '';
     let regCode: any = this.subsidiarys?.tan || '';
    let currency:any=this.subsidiarys?.currency||'';
    //let term:any=this.dnList?.paymentTerm||'';
   // let subGenInfo=this.subGenInfo||'';
    
    
   //supplier 
     let saddress: any = doc.splitTextToSize((this.supplierAddress?.address1 ?? '') +
    (this.supplierAddress?.address2 ? (this.supplierAddress.address1 ? ', ' : '') + this.supplierAddress.address2 : ''),
    80);
    //alert(saddress);
    let scity: any = this.supplierAddress?.city || '';
     let sstate: any = this.supplierAddress?.state || '';
    let szipcode: any = this.supplierAddress?.pin || '';
    let scountry: any = this.supplierAddress?.country|| '';
    let sregtype: any = this.supplierAddress?.registrationType|| '';
    let sregno:any=this.supplierAddress?.taxRegistrationNumber|| '';
    //let staxid: any = this.supplierContacts?.name|| '';
    // let scontactperson: any = this.supplierContacts?.name|| '';
     let sphone: any = this.supplierContacts?.contactNumber|| '';
     let semail: any = this.supplierContacts?.email|| '';
    let staxRegNo:any=this.supplierAddress?.taxRegistrationNumber|| '';


    
    const header = function () {

      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName, 8, 12);
      doc.setFontSize(10);
      doc.setFont("Arial", "bold");
      doc.text(address, 10, 16);
      doc.text(city, 10, 24);
      doc.text(state, 10, 28);
      doc.text(zipcode, 10, 32);
      doc.text(country, 10, 36);
      doc.text(vatCode, 10,40);
      doc.text(regCode, 10,44);
      doc.text(website, 10, 48);
      doc.text(invMail, 10, 52)
    
    };
    
    
    let leftLengthCount=address.length;
    let rightLengthCount=saddress.length



    let x = 8; // X coordinate
    let y = 74;
    const headerAfer = function () {

      // Y coordinate
      let rectHeight = 45;
     
      


      doc.setFillColor(234, 242, 248)
      doc.rect(6, 54, 200, 10, 'F');
      doc.setTextColor(53, 67, 112);
      doc.setFontSize(14);
      doc.text('Debit Note', 8, 60);


      //supplier details
      
      doc.setFillColor(253, 254, 254); // set fill color to yellow
      doc.rect(6, 64, 60, 60, 'F'); //  draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(12);
      doc.text('Supplier', 8, 68);
      doc.setFontSize(10);

      doc.setFont("Arial", "normal");
      supplierName.forEach((supplierName: any) => {
        doc.text(supplierName  || "", 8, y);
        y += 4; // Move down to the next line (adjust as needed)
    });

    
      doc.setFont("Arial", "normal");
      saddress.forEach((saddress: any) => {
        doc.text(saddress  || "", 8, y);
        y += 4; // Move down to the next line (adjust as needed)
    });

     
      doc.setFont("Arial", "normal");
      doc.text(scity || '',8, y);

     
      
      doc.setFont("Arial", "normal");
      doc.text( sstate || '',8, y+=4);

     
      doc.setFont("Arial", "normal");
      doc.text( szipcode,8 || '',y+=4);

      
      doc.setFont("Arial", "normal");
      doc.text( scountry || '', 8, y+=4);

      doc.setFont("Arial", "normal");
      doc.text(''||'', 80, y+=4);

      doc.setFont("Arial", "normal");
      doc.text( "Registration Type" || '', 8, y+=4);
      doc.setFont("Arial", "normal");
      doc.text( ": " + sregtype || '',37, y);

      doc.setFont("Arial", "normal");
      doc.text( "Registration No" || '', 8, y+=4);
      doc.setFont("Arial", "normal");
      doc.text( ": " + staxRegNo || '',37, y);

      doc.setFont("Arial", "normal");
      doc.text( "Phone" || '', 8, y+=8);
      doc.setFont("Arial", "normal");
      doc.text( ": " + sphone || '',18, y);

      doc.setFont("Arial", "normal");
      doc.text( "Email" || '', 8, y+=4);
      doc.setFont("Arial", "normal");
      doc.text( ": " + semail || '', 18, y);

      
     

      doc.setFont("Arial", "normal");
      doc.text(''||'', 8, y);


    
      let y2 = 74;
     

      
      doc.setFont("Arial", "normal");
      doc.text(''||'', 80, y2);
    
     //po related details
      let y3=68
      let x3=135

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Debit Memo No ', x3, y3);
      doc.setFont("Arial", "normal");
      doc.text(": "+dnNumber || "", 170, y3);

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Debit Memo Date ', x3, y3+=6);
      doc.setFont("Arial", "normal");
      doc.text(": "+dnData || "", 170, y3);

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Debit MemoType ', x3, y3+=6);
      doc.setFont("Arial", "normal");
      doc.text(": "+returnType|| "", 170, y3);

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('RTV Ref No ', x3, y3+=6);
      doc.setFont("Arial", "normal");
      doc.text(": "+rtvNumber|| "", 170, y3);

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('GRN Ref No ', x3, y3+=6);
      doc.setFont("Arial", "normal");
      doc.text(": "+grnNumber|| "", 170, y3);

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Currency ', x3, y3+=6);
      doc.setFont("Arial", "normal");
      doc.text(": "+currency|| "", 170, y3);


      // doc.setFont("Arial", "bold");
      // doc.setTextColor(53, 67, 112);
      // doc.text('Memo ', x3, y3+=6);
      // doc.setFont("Arial", "normal");
      // //doc.text(": "|| "", 170, y3);
      // doc.setFillColor(234, 242, 248);
      // doc.rect(x3, y3+3, 70, 20, 'F'); // draw a rectangle as background

      


      //doc.setFontSize(10);
      doc.setTextColor(0);
      margin: { top: 30 }
    };

  

    
    let startY =y + 64;

    if(leftLengthCount>rightLengthCount){

      startY += leftLengthCount*4;
    }else{

      startY += rightLengthCount*4;
    }
    
    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: this.dnData,
      //foot: [['', '', '', '', '', 'Estimated Total:', this.estimatedAmount]],
      margin: { left: 6, bottom: 40, top: 60, right: 5 },
     
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [253, 254, 254],
        textColor: [44, 62, 80]
      },

      headerStyles: {
        fillColor: [234, 242, 248], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles:{
        4:{halign:'right'},
        5:{halign:'right'},
        6:{halign:'right'},
        7:{halign:'right'},
        8:{halign:'right'},

      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [253, 254, 254];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;
          if (data.pageCount === (doc as any).internal.getNumberOfPages()) {
            // add the footer section to the last page
            (doc as any).autoTable({
              head: false,
              body: false,
              //foot: [['', '', '', '', '', 'Estimated Total:']],
              startY: doc.internal.pageSize.height - 90,
              tableWidth: 'wrap',
              styles: {
                cellPadding: 1,
                fontSize: 10,
                valign: 'middle',
                halign: 'center',
                fillColor: [53, 67, 110],
              },
            });
          }

        }




      },
      
      didDrawPage: function (data: any) {

        // add the header and footer to each page
       
        //y =72;
        doc.setPage(data.pageNumber);
        //startY = (doc as any).autoTable.previous.finalY + 2;

        if(data.pageNumber<=1){
          header();
          headerAfer();
        }
        else{
          header();
        }
      
       
      },
     
    });
   
    const estimatedTotalText = `: ${this.dnList?.currency} ${this.dnList.amount?.toFixed(2) || ''}`;
    const taxTotalText = `: ${this.dnList?.currency} ${this.dnList.taxAmount?.toFixed(2) || ''}`;
    const totalText = `: ${this.dnList?.currency} ${this.dnList.totalAmount?.toFixed(2) || ''}`;
    
    doc.setFillColor(234, 242, 248);
    (doc as any).rect(120, (doc as any).autoTable.previous.finalY +3, 85, 20, 'F');
    (doc as any).setFontSize(10);
    doc.setTextColor(44, 62, 80);


    (doc as any).text(
      122,
      (doc as any).autoTable.previous.finalY + 8,
      'Sub Total', { bold: true, font: 'Arial' }
    );
    (doc as any).text(
      172,
      (doc as any).autoTable.previous.finalY + 8,
      estimatedTotalText, { bold: true, font: 'Arial' }
    );

    (doc as any).text(
      122,
      (doc as any).autoTable.previous.finalY + 14,
      'Tax Total', { bold: true, font: 'Arial' }
    );
    (doc as any).text(
      172,
      (doc as any).autoTable.previous.finalY + 14,
      taxTotalText, { bold: true, font: 'Arial' }
    );

    // (doc as any).text(
    //   122,
    //   (doc as any).autoTable.previous.finalY + 20,
    //   'Discount', { bold: true, font: 'Arial' }
    // );
    // (doc as any).text(
    //   172,
    //   (doc as any).autoTable.previous.finalY + 20,
    //   taxTotalText, { bold: true, font: 'Arial' }
    // );


    (doc as any).text(
      122,
      (doc as any).autoTable.previous.finalY + 20,
      'Total Amount', { bold: true, font: 'Arial' }
    );
    (doc as any).text(
      172,
      (doc as any).autoTable.previous.finalY + 20,
      totalText, { bold: true, font: 'Arial' }
    );

    doc.setFillColor(255, 255, 255);
    (doc as any).rect(8, (doc as any).autoTable.previous.finalY + 36, 198, 23, 'F');
    (doc as any).setFontSize(12);
    doc.setTextColor(0);

    (doc as any).setFontSize(9);
    (doc as any).text(
      8,
      (doc as any).autoTable.previous.finalY +=33,
      'Remarks: ', { bold: true, font: 'Arial' }
    );

    (doc as any).text(
      8,
      (doc as any).autoTable.previous.finalY +=4,
      memo, { bold: true, font: 'Arial' }
    );

let y4=72;
//alert((doc as any).autoTable.previous.finalY)
if((doc as any).autoTable.previous.finalY<250){

    (doc as any).setFontSize(9);
    (doc as any).text(
      128,
      y4+=200,
      'Authorized Signature', { bold: true, font: 'Arial' }
    );

    //doc.addImage(sign, 'JPEG',153, y4-=20, 60, 30);

    (doc as any).text(
      163,
     y4+=2,
      '--------------------------------------', { bold: true, font: 'Arial' }
    );


    (doc as any).text(
      150,
      y4+=6,
      'Date', { bold: true, font: 'Arial' }
    );

   //alert(JSON.stringify(appsDate));

    
      (doc as any).text(
        176,
         y4+=2,
         this.finalAppDate || "", { bold: true, font: 'Arial' }
       );
    
    
     (doc as any).text(
       163,
        y4+=3,
        '--------------------------------------', { bold: true, font: 'Arial' }
      );

    

    // (doc as any).setFontSize(8);

    // let dataSet=doc.splitTextToSize(this.subGen || '',180);

    
   
  //   dataSet.forEach((data:any)=>{
  //     (doc as any).text(
  //       8,
  //       y4-40,
  //       data, { bold: true, font: 'Arial' }
  //     )
  //     y4+=4;
  //   })
   }
  
  if((doc as any).autoTable.previous.finalY>250){
    doc.addPage();
    let rectHeight = 45;
     
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName, 8, 12);
      doc.setFontSize(10);
      doc.setFont("Arial", "bold");
      doc.text(address, 10, 18);
      doc.text(city, 10, 26);
      doc.text(state, 10, 30);
      doc.text(zipcode, 10, 34);
      doc.text(country, 10, 38);

      doc.text(website, 10, 46);
      doc.text(invMail, 10, 50);
    


    
    // (doc as any).setFontSize(8);

    // let dataSet=doc.splitTextToSize(this.subGen || '',180);

    // (doc as any).text(
    //   8,
    //   y4+=2,
    //   'N.B: Please specify the following details in your Invoice if applicable. ', { bold: true, font: 'Arial' }
    // )
    
    // dataSet.forEach((data:any)=>{
    //   (doc as any).text(
    //     8,
    //     y4+=4,
    //     data, { bold: true, font: 'Arial' }
    //   )
    //   y4+4;
    // });


    (doc as any).setFontSize(9);
    (doc as any).text(
      128,
      y4+=8,
      'Authorized Signature', { bold: true, font: 'Arial' }
    );

    doc.addImage('', 'JPEG',153, y4-18, 60, 30);      //sign

    (doc as any).text(
      163,
     y4+=4,
      '--------------------------------------', { bold: true, font: 'Arial' }
    );


    (doc as any).text(
      150,
      y4+=4,
      'Date', { bold: true, font: 'Arial' }
    );
  
      (doc as any).text(
        176,
         y4+=2,
         this.finalAppDate || "", { bold: true, font: 'Arial' }
       );
   
    (doc as any).text(
      163,
       y4+=4,
       '--------------------------------------', { bold: true, font: 'Arial' }
     );

  }
    //alert(y);
    
    this.addWaterMark(doc); 
   // footer();

   

    //let blob = doc.output('datauristring');
    //this.sendFile(blob);
    

    //alert(type)

    
      doc.save('report.pdf');
  
   

  }
  
  }
 


