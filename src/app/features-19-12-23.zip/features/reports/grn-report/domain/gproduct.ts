export class grn{
    id: number;
    grnNumber:number;
    subsidiaryId: number;
    locationId:number;
    poNumber:string;
    grnDate:any;
    supplierId:number;
    currency:string;
    memo:string;
    purchaseDate:Date;
    poDate:Date;
    exchangeRate:string;
    modeOfTransport:string;
    vehicleNumber:string;
    awNumber:string;
    reciver:string;
    netsuiteId:string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    poId:number;
    locationName: string;
    subsidiaryName: string;
    supplierName: string;
    grnItem: grnItem[]=[];
    supplier: supplier;
    location: location;
    deleted:boolean;
    ewayBillNumber: string;
    markall:boolean;
    subCurrency:string;
    PODate:any;
    status:any;
    rtvStatus:any;
    billStatus:any;
}
export class BaseSearch {
filters?: Filter | {} = {};
pageNumber?: number = 0;
pageSize?: number = 0;
sortColumn?: string = '';
sortOrder?: string = '';
}

export class supplier{
    id?:any;
    name?:any;
    legalName?:any;
    supplierAddresses:supAddr[]=[];
    supplierContacts:supCont[]=[];

}
export class supAddr{
    supplierId: any;
    addressCode: any;
    address1: any;
    address2: any;
    city: any;
    state: any;
    country: any;
    pin: any;
    taxRegistrationNumber: any;
    registrationType: any         
}
export class supCont{
    supplierId:any;
    name: any;
    contactNumber: any;
    altContactNumber: any;
    email: any;
    web: any;                       
}

//this class holds the custom filter values at component level.
export class Filter {
subsidiary?: string = '';
vendorname?: string = '';
vendornumber?: string = '';
vendortype?: string = '';
pan?: string = '';
active?: string = '';
}

export class grnItem{
        id:any;
        grnId:number;
        itemId:number;
        poNumber:string;
        grnNumber:string;
        itemName:string;
        itemDescription:string;
        itemUom:string;
        taxGroupId:number;
        quantity:number;
        reciveQuantity:number;
        remainQuantity:any;
        lotNumber:string;
        rate:number;
        rtvQuantity:number;
        invoiceNumber:string;
        createdDate?: Date;
        createdBy?: string;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        deleted:boolean;
        poId?:number;
        poiId?:number;
        amount?:number;
        taxAmount?:number;
        totalTaxAmount?:number;
        totalAmount?:number;
        receivedByDate?:Date;
        prNumber?:string;
        shipToLocationId?:number;
        shipToLocation?:string;
        department?:string;
        memo?:string;
        accountId?:string;
        accountCode?:string;
        itemIntegratedId?:string;
        qaNumber?:string;
        active:boolean;
        receiveqtydisable:boolean;
        lotnodisable:boolean;
        disabledIfInvoice:boolean;
        unbilledQuantity:number;
        status:string;
        rtvStatus:any;
        billStatus:any;
}
export class location
{
id:number;
locationName:any;
locationAddress:locationAddress;
}
export class locationAddress{
    locationId:any;
    country: any;
    phone: any;
    address1: any;
    address2: any;
    city: any;
    state: any;
    pin: any;
}

export class POList{
id:number;
poNumber:string;
poStatus:string;
}


