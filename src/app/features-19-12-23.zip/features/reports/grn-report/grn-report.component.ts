import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { Injectable } from '@angular/core';


import { grn,supplier,supAddr,supCont,location,locationAddress } from './domain/gproduct'; 
import * as FileSaver from 'file-saver';
import {jsPDF} from 'jspdf';
import * as XLSX from 'xlsx';
import jsPDFWithPlugin from 'jspdf';
import html2canvas from 'html2canvas';

//import 'jspdf-autotable';
import autoTable from 'jspdf-autotable';
import { Header } from 'primeng/api';
import { TableBody } from 'primeng/table';
import 'jspdf-autotable';

@Injectable({
  providedIn: 'root'
})
@Component({
  selector: 'app-grn-report',
  templateUrl: './grn-report.component.html',
  styleUrls: ['./grn-report.component.scss']
})
export class GrnReportComponent implements OnInit {

  grnList: grn = new grn();
  List: any[] = [];
  grnItem:any[]=[];

  // subsidiary:subsidiary=new subsidiary();
  // subAddr:subAddr[]=[];

  //subAddress:subAddr=new subAddr();

  supplier:supplier=new supplier();
  supAddr:supAddr[]=[];
  supContacts:supCont[]=[];

  location:location=new location();

  grnNumber:any;
  grnData: any = [];
  poNumber:any;
  //grnData: any = [];

  totalRecords:number=0;
  loading: boolean = false;

  RetloginDetails:any;

 
  //supplierAddress:supAddr=new supAddr();
  supplierAddress:any=[];
  //supplierContacts:supContacts=new supContacts();
  supplierContacts:any=[];
  locationAddress:any=[];
  

  


  cols: any[];
  @ViewChild('header')header!: ElementRef;
  @ViewChild('footer')footer!: ElementRef;
  @ViewChild('estimatedTotal') estimatedTotal!: ElementRef;


  exportColumns: any[];


  constructor(private httpService: CommonHttpService) { }

  ngOnInit(){
      
  //   this.productService.getProductsMini().then((data) => {
  //     this.products = data;
  // });

  this.cols = [
    { field: 'id', header: '#'},
    { field: 'name', header: 'Item' },
    { field: 'description', header: 'Description' },
    { field: 'uom', header: 'Uom' },
    { field: 'quantity', header: 'Quantity' }
];

this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
//call api
this.getApiall();
    
  }


  exportPdf(grnNumber: any){
    this.grnNumber=grnNumber;
    this.cols = [
      { field: 'id', header: '#'},
      { field: 'name', header: 'Item' },
      { field: 'description', header: 'Description' },
      { field: 'uom', header: 'Uom' },
      { field: 'quantity', header: 'Quantity' },
     
  ];
  
  this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
  
  this.getApiall();
  
  }
  getApiall(){
    //api call with token
    //alert('api call');
      const retDetails: any = localStorage.getItem("RoleDTLS");
      var role_Dtls = JSON.parse(retDetails);
  
  
      const LDetails: any = localStorage.getItem("LoggerDTLS");
      this.RetloginDetails = JSON.parse(LDetails);
  
      this.httpService
        .GetAll(`/procure-ws/grn/get-grn-report-data?grnNumber=`+this.grnNumber, this.RetloginDetails.token)
        .subscribe((res) => {
          if (res.status == 401) {
            alert("Unauthorized Access !");
          }
          else if (res.status == 404) {
            alert("Wrong/Invalid Token!");
          }
          else {
          
            if (res && res.grnItem?.length > 0) {
              this.grnList = res;

            if (res.supplier && Array.isArray(res.supplier.supplierAddresses)) {
             
              this.supplierAddress = res.supplier.supplierAddresses;
              this.supplierAddress.forEach((address: any) => {
                this.supplierAddress = address;
              });
            } else {
              console.log("Error: invalid response");
            }

            
            this.location=res.location;
            
            
              this.locationAddress=res.location?.locationAddress;
            

           
              
              this.supplier =res.supplier;
             // console.log('Supplier Details-----'+JSON.stringify(this.supplier));

              this.supAddr=this.supplier?.supplierAddresses;
              //console.log('Supplier Address-----'+JSON.stringify(this.supAddr));

              this.supContacts=this.supplier?.supplierContacts;
              //console.log('Supplier Contacts-----'+JSON.stringify(this.supContacts));

              
                
             

              // this.locationAddress=this.location.locationAddress;
               
              this.grnItem = res.grnItem;
              //console.log('Po Item-----'+JSON.stringify(this.poItem));
  
              this.totalRecords = res.totalRecords;
              
            // Push data
            this.grnData=[];
              for (let i = 0; i < this.grnItem.length; i++) {
                
                this.grnData.push([i + 1, 
                  this.grnItem[i].itemName, 
                  this.grnItem[i].itemDescription, 
                  this.grnItem[i].itemUom,
                  this.grnItem[i].reciveQuantity, 
                 ]);
            
              }
             
  
              this.exportPdfAPI();
  
            } else {
             
              this.totalRecords = 0;
  
            }
            this.loading = false;
            
  
  
          }
        });
  
    }

  //exportPdf(poNumber:any) {
    exportPdfAPI(){

  // create a new jsPDF instance
    const doc = new jsPDF('p', 'mm', 'a4');


    // generate table content
    let subsidiaryName = this.grnList ?.subsidiaryName || '';


    let supplierName = doc.splitTextToSize(this.supplier ?.legalName || '',75);

    if(supplierName==''){
      supplierName = doc.splitTextToSize(this.supplier ?.name || '',75);
    }
    else{
      supplierName = doc.splitTextToSize(this.supplier ?.legalName || '',75);
    }

    // define the header and footer
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName, 8, 12);
      doc.text('Goods Receipt Note', 82, 24);
    };
    //header data
     let grnNumber: any = this.grnList?.grnNumber|| '';
     let poNumber: any = this.grnList?.poNumber|| '';
    
    const timestamp1 = this.grnList?.grnDate || '';
    const date1 = new Date(timestamp1);
    const grnData = date1.toLocaleDateString('en-GB');

    const timestamp2 = this.grnList?.poDate || '';
    const date2= new Date(timestamp2);
    const poDate = date2.toLocaleDateString('en-GB');
    

    //ship to location
    let location: any = doc.splitTextToSize(this.location?.locationName || '',75);

  //location
     let address: any =doc.splitTextToSize((this.locationAddress?.address1 ?? '') +
    (this.locationAddress?.address2 ? (this.locationAddress.address1 ? ', ' : '') + this.locationAddress.address2 : ''),
    72);
    
    let city: any = this.locationAddress?.city || '';
    let email:any=this.locationAddress?.email || '';
    let state: any = this.locationAddress?.state || '';
    let zipcode: any = this.locationAddress?.pin || '';
    let country: any = this.locationAddress?.country|| '';
     
    
   //supplier  
     let saddress: any =doc.splitTextToSize((this.supplierAddress?.address1 ?? '') +
    (this.supplierAddress?.address2 ? (this.supplierAddress.address1 ? ', ' : '') + this.supplierAddress.address2 : ''),
    72);
    //alert(saddress);
    let scity: any = this.supplierAddress?.city || '';
     let sstate: any = this.supplierAddress?.state || '';
    let szipcode: any = this.supplierAddress?.pin || '';
    let scountry: any = this.supplierAddress?.country|| '';
    let sregtype: any = this.supplierAddress?.registrationType|| '';
    let sregno:any=this.supplierAddress?.taxRegistrationNumber|| '';
    let staxid: any = this.supplierContacts?.name|| '';
    let scontactperson: any = this.supplierContacts?.name|| '';
    let sphone: any = this.supplierContacts?.contactNumber|| '';
    let semail: any = this.supplierContacts?.email|| '';
    let staxRegNo:any=this.supplierAddress?.taxRegistrationNumber|| '';

    //subtable data
    let receiver:any=this.grnList?.reciver|| '';
    let memo=doc.splitTextToSize(this.grnList?.memo|| '',110);
    let modeOfTrans:any=this.grnList?.modeOfTransport|| '';;
    let vNumber:any=this.grnList?.vehicleNumber|| '';;
    let awNumber:any=this.grnList?.awNumber|| '';;
    let ewBill:any=this.grnList?.ewayBillNumber|| '';;

    let leftLengthCount=address.length+location.length;
    let rightLengthCount=saddress.length+supplierName.length;

    let x = 8; // X coordinate
    let y = 64;
    const headerAfer = function () {

      // Y coordinate
      let rectHeight = 42;
      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);

      doc.text('GRN Number ', x, 36);
      doc.text(": "+grnNumber || "", 42, 36);
      doc.text('PO Number ', x, 45);
      doc.text(": "+poNumber || "", 42, 45);

      doc.text('GRN Date ', 118, 36);
      doc.text(": " +grnData || "", 152, 36);
      doc.text('PO Date ', 118, 45);
      doc.text(": " +poDate || "", 152, 45);


      doc.rect(6, 48, 96, 10, 'F');
      doc.setTextColor(255, 255, 255);
      doc.text('LOCATION INFORMATION', 20, 54);

      doc.setFillColor(156, 178, 221); // set fill color to yellow
      doc.rect(6, 58, 96, rectHeight+(leftLengthCount*4), 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(10);

      doc.setFont("Arial", "bold");
      doc.text('Location name', x, y );
      doc.setFont("Arial", "normal");
     doc.text(": "|| '', 50, y);
     location.forEach((location:any)=>{
      doc.text(location || "", 52, y);
        y += 4; // Move down to the next line (adjust as needed)
      })

      let strLength = 0;
      doc.setFont("Arial", "bold");
      doc.text('Address', x, y += 4);
      doc.setFont("Arial", "normal");
      doc.text(': '|| '',50,y);
      address.forEach((address:any)=>{
      doc.text(address || "", 52, y);
        y += 4; // Move down to the next line (adjust as needed)
      })
    
      //alert(address.length);

      doc.setFont("Arial", "bold");
      doc.text('City', x, y += 4);
      doc.setFont("Arial", "normal");
      doc.text(": " + city|| '', 50, y);

      doc.setFont("Arial", "bold");
      doc.text('State', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + state || '', 50, y);

      doc.setFont("Arial", "bold");
      doc.text('Pin/Zip ', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + zipcode || '' , 50 || '', y);

      doc.setFont("Arial", "bold");
      doc.text('Country', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + country || '', 50, y);


   

      let addressCount=1;

     

      let x1 = 120;
      let y2 = 64;


      doc.rect(115, 48, 91, 10, 'F'); // draw a rectangle as background
      doc.setTextColor(255, 255, 255);
      doc.setFont("Arial", "bold")
      doc.setFontSize(12);
      doc.text('SUPPLIER INFORMATION', 134, 54);
      doc.setFillColor(156, 178, 221); // set fill color to blue
      doc.rect(115, 58, 91, rectHeight+(rightLengthCount*4), 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(10);

      doc.setFont("Arial", "bold");
      doc.text('Name', x1, y2);
      doc.setFont("Arial", "normal");
      doc.text(": "|| "", 148, y2);
      supplierName.forEach((supplierName:any)=>{
        doc.text(supplierName || "", 150, y2);
          y2 += 4; // Move down to the next line (adjust as needed)
        })

      doc.setFont("Arial", "bold");
      doc.text('Address ', x1, y2 += 4);
      doc.setFont("Arial", "normal");
      doc.text(": "|| "", 148, y2);
      saddress.forEach((saddress:any)=>{
        doc.text(saddress || "", 150, y2);
          y2 += 4; // Move down to the next line (adjust as needed)
        })

      doc.setFont("Arial", "bold");
      doc.text('City', x1, y2 += 4);
      doc.setFont("Arial", "normal");
      doc.text(": " +scity || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('State', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +sstate || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('Pin', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +szipcode || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('Country', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +scountry || "", 148, y2);

      doc.rect(6, y2+=20, 200, 10, 'F'); // draw a rectangle as background
      doc.setTextColor(255, 255, 255);
      doc.setFont("Arial", "bold")
      doc.setFontSize(10);

      doc.text('Receiver', 12, y2+=6);
      doc.setFontSize(10);
      doc.text('Mode Of Transport', 52,y2);
      doc.setFontSize(10);
      doc.text('Vehicle Number', 92, y2);
      doc.setFontSize(10);
      doc.text('AW Number', 132, y2);
      doc.setFontSize(10);
      doc.text('E_WAY Bill', 172,y2);

      doc.setFillColor(255, 255, 255);
      doc.rect(6, y2+=4, 200, 8, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112);
      doc.setFont("Arial")
      doc.setFontSize(10);
      doc.text(receiver || "", 12, y2+=6);
      // doc.setFontSize(10);
      // doc.text(memo || "", 42, y2);
      doc.setFontSize(10);
      doc.text(modeOfTrans || "", 52,y2);
      doc.setFontSize(10);
      doc.text(vNumber || "", 92, y2);
      doc.setFontSize(10);
      doc.text(awNumber || "", 132, y2);
      doc.setFontSize(10);
      doc.text(ewBill || "", 172,y2);


      //doc.setFontSize(10);
      doc.setTextColor(0);
      margin: { top: 30 }
    };



    const footer = function () {

      y=doc.internal.pageSize.height - 36;
      doc.setFontSize(12);
      doc.setTextColor(0);
      doc.text('Memo', 14, y);
      doc.text(': ', 26, y);
      memo.forEach((memo:any)=>{
        doc.text(memo || "", 28, y);
        y+= 4; // Move down to the next line (adjust as needed)
      })

      doc.text('____________________', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 40);
      doc.text('  Authorized Signature', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 30);

    };

    // generate the invoice
    
    let startY = y + 85;

    if(leftLengthCount>rightLengthCount){

      startY += leftLengthCount*2;
    }else{

      startY += rightLengthCount*2;
    }

    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: this.grnData,
      //foot: [['', '', '', '', '', 'Estimated Total:', this.estimatedAmount]],
      margin: { left: 6, bottom: 40, top: startY, right: 5 },
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [255, 255, 255],

      },

      headerStyles: {
        fillColor: [53, 67, 110], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles:{
        4:{halign:'right'}
      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;
          if (data.pageCount === (doc as any).internal.getNumberOfPages()) {
            // add the footer section to the last page
            (doc as any).autoTable({
              head: false,
              body: false,
              //foot: [['', '', '', '', '', 'Estimated Total:']],
              startY: doc.internal.pageSize.height - 90,
              tableWidth: 'wrap',
              styles: {
                cellPadding: 1,
                fontSize: 10,
                valign: 'middle',
                halign: 'center',
                fillColor: [53, 67, 110],
              },
            });
          }

        }




      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();
        headerAfer();
        

        y=64;
        doc.setPage(data.pageNumber);
        
        startY = (doc as any).autoTable.previous.finalY + 10;
        
      },

    });

    footer();

    doc.save('report.pdf');
  }
  

    

// exportExcel() {
//     // import('xlsx').then((xlsx) => {
//     //     const worksheet = xlsx.utils.json_to_sheet();
//     //     const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
//     //     const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
//     //     this.saveAsExcelFile(excelBuffer, 'po_report');
//     // });
// }

// saveAsExcelFile(buffer: any, fileName: string): void {
//     let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
//     let EXCEL_EXTENSION = '.xlsx';
//     const data: Blob = new Blob([buffer], {
//         type: EXCEL_TYPE
//     });
//     FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
// }
  

 
}
