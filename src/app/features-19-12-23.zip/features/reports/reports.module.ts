import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportsRoutingModule } from './reports-routing.module';
import { PoReportComponent } from './po-report/po-report.component';


import { AccountStatementComponent } from './account-statement/account-statement.component';

import { ApAgingComponent } from './ap-aging/ap-aging.component';
import { ApAgingDetailsComponent } from './ap-aging-details/ap-aging-details.component';

import { ButtonModule } from 'primeng/button';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { TableModule } from 'primeng/table';
import { PanelModule } from 'primeng/panel';

import { CardModule } from 'primeng/card';
import { FieldsetModule } from 'primeng/fieldset';
import { DropdownModule } from 'primeng/dropdown';
import { DialogModule } from 'primeng/dialog';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { BankStatementComponent } from './bank-statement/bank-statement.component';


@NgModule({
  declarations: [
    PoReportComponent,
    AccountStatementComponent,
    ApAgingComponent,
    ApAgingDetailsComponent,
    BankStatementComponent,
  ],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    TableModule,
    ButtonModule,
    InputTextareaModule,
    PanelModule,

    //CardModule,
    FieldsetModule,
    DropdownModule,
    DialogModule,
    ScrollPanelModule
    
  ],
  providers:[
  
    
    
  ]
})
export class ReportsModule { }
