export class MakePaymentModule {
        id?: number;
        paymentNumber?: String;
        subsidiaryId?: number;
        accountId?: number;
        bankId?:number;
        supplierId?: number;
        paymentDate?: any;
        currency?: string;
        subsidiaryCurrency?: string;
        exchangeRate?: string;
        paymentMode?: string;
        amount?: number=0.00;
        bankTransactionType?: string;
        bankReferenceNumber?: number;
        memo?: string;
        netsuiteId?: number;
        createdDate?: Date;
        createdBy?: string;
        creator?:string;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        subsidiaryName?: string;
        supplierName?: string;
        bankAccountName?: string;
        advancePaymentNumber?: string;
        advancePaymentType?: string;
        advancePaymentAmount?: string;
        paymentAmount?: number=0.00;
        advancePayment?: string;
        deleted?: boolean;
        markall?: boolean;
        voidDescription?:string;
        voidDate?:any;
        status:string;
        bankName:string;
        type?:string;
        approvalRoutingActive: boolean;
        makePaymentList?:makePaymentList=new makePaymentList();
        bank?:bank[]=[];
 }



 export class paymentdetailsbysupplier
 {
         invoiceId:number;
         supplierId: number;
         subsidiaryId:number;
         poId:number;
         locationId:number;
         invoiceNo:string;
         invStatus:string;
         paymentTerm:string;
         integratedId:string;
         currency:string;
         billTo:string;
         shipTo:string;
         invoiceDate:Date;
         dueDate:Date;
         fxRate:number;
         amount:number;
         taxAmount:number;
         totalAmount:number;
         paymentAmount:number;
         amountDue:number;
         invoiceItems:string;
         createdDate?: Date;
         createdBy?: string;
         lastModifiedDate?: Date;
         lastModifiedBy?: string;
         active:boolean;
         paymentamtdisable:boolean=true;
 }
 
 export class makePaymentList
 {
            type?:string;
            paymentNumber?:any;
            paymentId?:number;
            billNo?:string;
            invoiceId?:number;
            invoiceAmount:number;
            paidAmount:any;
            amountDue:number;
            createdDate?: Date;
            createdBy?: string;
            lastModifiedDate?: Date;
            lastModifiedBy?: string;
            paymentAmount:any;
            totalPaymentAmount:any;
            deleted?:boolean;
            active?:boolean=false;
            paymentamtdisable?:boolean=true;
            invoiceDate?:any;
            invoiceDateShow?:any;
            currency?:string;
            invoice:invoice=new invoice();
 }
 export class invoice 
 {
        invoiceId?: Number;
        supplierId?: Number;
        subsidiaryId?: Number
        poId?: any;
        locationId?: any;
        billToId?: any;  
        shipToId?: any;
        invoiceNo?: string;
        invStatus?:string;
        paymentTerm?: string;
        integratedId?: any;
        currency?: string;
        billTo?: string;
        shipTo?: string;
        invoiceCode?: string;
        invoiceSupplyNumber?:any;
        taxRegNumber?: any;
        invoiceDate?:Date;
        dueDate?:Date;
        fxRate?: any;
        amount?: any;
        taxAmount?: any;
        totalAmount?: any;
        rejectedComments?: any;
        amountDue?: any;
        temp_xyz?: any
        externalId?: any;
        hasError?: boolean;
        approvedBy?: string;
        extApprover?: string;
        nextApproverUid?: any;
        nextApproverRole?: any;
        nextApproverLevel?: any;
        approverPreferenceId?: any;
        approverSequenceId?: any;
        approverMaxLevel?:any;
        noteToApprover?: any;
        nsMessage?: string;
        nsStatus?: string;
        subsidiaryName?: string;
        supplierName?: string;
        poNumber?: string;
        invoiceItems?: string;
        totalPaidAmount?: any;
        invoicePayments?: any;
        approvedByName?: string;
        locationName?: string;
        createdBy: string;
        lastModifiedBy?: string;
        createdDate?: Date;
        lastModifiedDate?: Date;
        approvalRoutingActive?: boolean;
        deleted?: boolean;
}

export class suppplier
{
     id?: Number
     externalId?: any;
     name: string;
     legalName?:string;
     paymentTerm?:string;
     vendorNumber?: string;
     vendorType?: string;
     uin?: any;
     approvalStatus?: string;
     rejectComments: string;
     natureOfSupply?: string;
     uniqueNumber?: any;
     invoiceMail?: any;
     tdsWitholding?:any;
     approvedBy?: string;
     nextApprover?: string;
     nextApproverRole?: any;
     nextApproverLevel?: any;;
     approverPreferenceId?: any;
     approverSequenceId?: any;
     approverMaxLevel?: any;
     noteToApprover?: any;
     nsMessage?: string;
     nsStatus?:string; 
     integratedId?: any;
     activeDate?:Date; 
     createdDate?: Date;
     createdBy?: string;
     lastModifiedDate?: Date;
     lastModifiedBy?:string;
     supplierAddresses?: supplierAddresses[]=[];
     active?: boolean;
     approvalRoutingActive?: boolean;
     deleted?: boolean;
}

export class supplierAddresses
{
        
        id?: Number;
        supplierId?:any;
        addressCode?: string;
        address1?: string;
        address2?:string;
        city?: string;
        state?: string;
        country?: string;
        pin?: string;
        taxRegistrationNumber?: string;
        registrationType?: string;
        defaultBilling?: boolean;
        defaultShipping?:boolean;
        createdDate?: Date;
        createdBy?: string;
        lastModifiedDate?: Date;
        lastModifiedBy?:string;
        deleted?: boolean
            
}
 export class suppcurrency
 {
         code:string;
 }
 
 export class bank
 {
         id?: number
         subsidiaryId?: number;
         name?: string;
         branch?: string;
         address?: string;
         accountNumber?: string;
         accountType?: string;
         currency?: string;
         branchCode?: any;
         ifscCode?: any;
         iban?: any;
         swiftCode?: any;
         sortCode?: any;
         micrCode?: any;
         glBank?: string;
         glBankCode?: any;
         glExchange?: any;
         effectiveFrom?:string;
         effectiveTo?: any;
         status?: string;
         activeDate?: Date;
         createdDate?: Date;
         createdBy?: string;
         lastModifiedDate?: Date;
         lastModifiedBy?: string;
         subsidiaryName?:string ;
         active?: boolean
         deleted?: false
 }
 
 export class subsidiary
 {

        id?: Number;
        name?: string;
        legalName?: string;
        parentCompany?: string;
        country?: string;
        email?: string;
        website?: string;
        language?: string;
        currency?: string;
        fiscalCalender?:string;
        pan?: any;
        cin?: any;
        tan?: any;
        bidMail?: string;
        invoiceMail?: string;
        invoicePasswd?: string;
        adminMail?: string;
        activeDate?: Date;
        integrated_id?: any;
        logoMetadata?: any;
        logo?: any;

 }
 export class mpApproval{
         id: number;
         paymentNumber: any;
         subsidiaryId: number;
         accountId: any;
         bankId: number;
         supplierId: number;
         paymentDate: Date;
         currency: string;
         subsidiaryCurrency: any;
         exchangeRate: any;
         paymentMode: string;
         amount: any;
         bankTransactionType: any;
         bankReferenceNumber: any;
         memo: any;
         netsuiteId: any;
         rejectedComments: any;
         noteToApprover: any;
         voidDescription: any;
         voidDate: any;
         type: any;
         status: any;
         nsMessage: any;
         nsStatus: any;
         integratedId: any;
         paymentStatus: string;
         approvedBy: any;
         nextApprover: string;
         nextApproverRole: any;
         nextApproverLevel: any;
         approverPreferenceId: any;
         approverSequenceId: any;
         approverMaxLevel: any;
         createdDate: any;
         createdBy: any;
         lastModifiedDate: any;
         lastModifiedBy: any;
         subsidiaryName: string;
         supplierName: string;
         bankAccountName: any;
         bankName: string;
         paymentAmount: any;
         approvedByName: any;
         makePaymentList: any;
         deleted: boolean;
         approvalRoutingActive: boolean;
         // for approval
        selected:boolean;
        NewrejectComments?: any;
        isAdminRole:boolean;
 }
 