import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { jsPDF } from 'jspdf';
import * as XLSX from 'xlsx';

import 'jspdf-autotable';
import { Injectable } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ActivatedRoute, Route } from '@angular/router';
import { makePaymentList, MakePaymentModule, bank, suppplier } from './model/make-payment.module';
import { subsidiary } from '../rfq-report/model/rfq-report/rfq-report.module';


@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-make-payment',
  templateUrl: './make-payment.component.html',
  styleUrls: ['./make-payment.component.scss']
})
export class MakePaymentComponent implements OnInit {

  resList: MakePaymentModule = new MakePaymentModule();
  amountInWords: string;
  paymentData: any = [];
  makePaymentList: makePaymentList = new makePaymentList();
  suppplier: suppplier = new suppplier();
  makePaymentSubsidiary: subsidiary = new subsidiary();
  makePaymentSubsidiaryAddress: any = [];
  bank: bank = new bank();
  invoice: any = [];
  makePaymentData: any = [];
  supAddress: any = [];
  exportColumns: any[];
  ReExportColumns: any[];
  prReportData: any[];
  SubsidiaryId: any;
  makePaymentNumber: any;
  RetloginDetails: any;
  selectedSubsidiaryId: any;
  title = 'angular-app';
  fileName = 'ExcelSheet.xlsx';
  columns: any[] = [];
  ReColumns: any[] = [];
  totalRecords: number = 0;
  loading: boolean = false;
  file: any;
  estimatedAmount: any;





  constructor(private httpService: CommonHttpService, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {

    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.columns = [
      { field: 'Sl No', header: '#' },
      { field: 'itemName', header: 'Item Name' },
      { field: 'itemDescription', header: 'Description' },
      { field: 'itemUom', header: 'UOM' },
      { field: 'quantity', header: 'Quantity' },
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

  }


  

 // exportPdf(makePaymentNumber: any, file: any) {
  exportPdf(makePaymentNumber: any) {


    this.makePaymentNumber = makePaymentNumber;
//    this.file = file;
    this.paymentData = [];
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);


    this.columns = [
      { field: 'Sl No', header: 'Sl.' },
      { field: 'bill', header: 'Bill/PI Number' },
      { field: 'BillDate', header: 'Bill Date' },
      { field: 'BillAmount', header: 'Bill Amount' },
      { field: 'tds', header: 'TDS' },
      { field: 'vds', header: 'VDS ' },
      { field: 'payment', header: 'Payment Amount' },
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
    this.getAPIData();
  }

  public getAPIData() {

    this.httpService
      .GetAll(`/finance-ws/payment/get-payment-report?paymentNumber=` + this.makePaymentNumber
        , this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          alert("Unauthorized Access !");
        }
        else if (res.status == 404) {
          alert("Wrong/Invalid Token!");
        }
        else {

          if (res && res.makePaymentList?.length > 0) {
            this.resList = res;
            this.suppplier = res.supplier
            this.bank = res.bank;
            this.makePaymentSubsidiary = res.subsidiary;
            this.makePaymentList = res.makePaymentList;
            this.totalRecords = res.totalRecords;

            for (let i = 0; i < res.makePaymentList.length; i++) {
              const invoiceDateString = res.makePaymentList[i].invoiceDate;
              const dueDateString = res.makePaymentList[i].invoice?.dueDate;

              const invoiceDate = invoiceDateString ? new Date(invoiceDateString) : null;
              const dueDate = dueDateString ? new Date(dueDateString) : null;

              this.paymentData.push([
                i + 1,
                res.makePaymentList[i].billNo,
                invoiceDate ? invoiceDate.toLocaleDateString('en-GB') : '',
                //dueDate ? dueDate.toLocaleDateString('en-GB') : '',
                res.makePaymentList[i].invoiceAmount?.toFixed(2) ?? '',
                res.makePaymentList[i].tds?.toFixed(2) ?? '',
                res.makePaymentList[i].vds?.toFixed(2) ?? '',
                res.makePaymentList[i].paidAmount?.toFixed(2) ?? ''
              ]);
            }


            if (res.supplier && Array.isArray(res.supplier.supplierAddresses)) {
              this.supAddress = res.supplier.supplierAddresses;
              this.supAddress.forEach((address: any) => {
                this.supAddress = address;
              });
            } else {
              console.log("Error: invalid response");
            }

            this.makePaymentData = [];
            this.invoice = [];
            if (res.makePaymentList && Array.isArray(res.makePaymentList)) {

              this.makePaymentData = res.makePaymentList
              this.makePaymentData.forEach((makePaymentData: any) => {
                this.makePaymentData = makePaymentData;
                this.invoice = makePaymentData.invoice
              })

            } else {
              console.log("Error: invalid response");
            }

            // if (this.file == 1) {
            //   this.exportexcel();
            // } else {
              this.exportPdfAPI();
            //}
          } else {
            // this.resList = [];
            this.totalRecords = 0;

          }
          this.loading = false;
          //this.makePaymentList= res.makePaymentLists;
        }
      });

  }


  convertAmountToWords(currency: string) {
    const singleDigits = [
      'Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
      'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
      'Seventeen', 'Eighteen', 'Nineteen'
    ];

    const tensMultiples = [
      '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
    ];

    let scales = ['', 'Thousand', 'Million', 'Billion', 'Trillion', 'Quadrillion'];

    if (currency === 'INR') {
      scales = ['', 'Thousand', 'Lakh', 'Crore', 'Arab', 'Kharab', 'Neel', 'Padma', 'Shankh'];
    }

    const convertThreeDigitNumber = (num: number) => {
      let words = '';
      if (num >= 100) {
        words += singleDigits[Math.floor(num / 100)] + ' Hundred ';
        num %= 100;
      }
      if (num >= 20) {
        words += tensMultiples[Math.floor(num / 10)] + ' ';
        num %= 10;
      }
      if (num > 0) {
        words += singleDigits[num] + ' ';
      }
      return words.trim();
    };

    let amount: any = this.resList?.amount;

    let words = '';

    if (amount === 0) {
      words = 'Zero';
    } else {
      let remainingAmount = Math.floor(amount);
      let scaleIndex = 0;

      while (remainingAmount > 0) {
        const threeDigits = remainingAmount % 1000;
        if (threeDigits !== 0) {
          const scale = scales[scaleIndex];
          const threeDigitWords = convertThreeDigitNumber(threeDigits);
          words = threeDigitWords + ' ' + scale + ' ' + words;
        }
        remainingAmount = Math.floor(remainingAmount / 1000);
        scaleIndex++;
      }
    }

    let currencyName = '';

    if (currency === 'INR') {
      currencyName = 'Rupees';
    } else if (currency === 'USD') {
      currencyName = 'Dollars';
    }

    this.amountInWords = words.trim() + ' ' + currencyName;
  }


  public exportPdfAPI() {

    let currency: any = this.resList.currency;
    this.convertAmountToWords(currency);
    // create a new jsPDF instance
    const doc = new jsPDF('p', 'mm', 'a4');


    // generate table content
    let subsidiaryName = this.makePaymentSubsidiary.legalName || '';

    if (subsidiaryName) {
      subsidiaryName = this.makePaymentSubsidiary?.legalName || '';
    }

    else {

      subsidiaryName = this.makePaymentSubsidiary?.name || '';

    }

    // define the header and footer
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName, 8, 12);
      doc.text('Payment Voucher', 75, 24);
    };


    let makePaymentNumber: any = this.resList.paymentNumber || '';

    const timestamp = this.resList?.paymentDate || '';
    const date = new Date(timestamp);
    const paymentDate = date.toLocaleDateString('en-GB');

    // let projectNameLine = doc.splitTextToSize(projectName || '', 70);
    let supName: any = doc.splitTextToSize(this.suppplier?.legalName || '', 66);

    if (supName==undefined || supName=='' || supName==null) {            //changes done in 160823
      supName = doc.splitTextToSize(this.suppplier?.name || '', 66);
    } else {
      supName = doc.splitTextToSize(this.suppplier?.legalName || '', 66);
    }

    let bankName: any = doc.splitTextToSize(this.bank?.name || '', 66);
    let branchName: any = doc.splitTextToSize(this.bank?.branch || '', 66);
    let bankAccountNum: any = doc.splitTextToSize(this.bank?.accountNumber || '', 66);
    let paymentMode: any = doc.splitTextToSize(this.resList?.paymentMode || '', 66);

    let address: any = doc.splitTextToSize((this.supAddress.address1 ?? '') +
      (this.supAddress?.address2 ? (this.supAddress.address1 ? ', ' : '') + this.supAddress.address2 : ''),
      66);
    let city: any = doc.splitTextToSize(this.supAddress.city || '', 66)
    let state: any = doc.splitTextToSize(this.supAddress.state || '', 66)
    let pin: any = doc.splitTextToSize(this.supAddress.pin || '', 66)
    let country: any = doc.splitTextToSize(this.supAddress.country || '', 66)

    let bankReferenceNumber: any = this.resList?.bankReferenceNumber || "";
    let paymentVouchar: any = doc.splitTextToSize(bankReferenceNumber, 66);
    let ExchangeRate: any = doc.splitTextToSize(this.resList?.exchangeRate || '', 66);
    let status: any = doc.splitTextToSize(this.resList?.status || '', 66);
    let functionalCurrency: any = doc.splitTextToSize(this.resList?.subsidiaryCurrency || '', 66);
    let TransanctionCurrency: any = doc.splitTextToSize(this.resList?.currency || '', 66);
    let CreateBy: any = doc.splitTextToSize(this.resList?.creator || '', 66);

    let remarks: any = doc.splitTextToSize(this.resList?.memo || '', 130);
    let projectNamelabel: any = doc.splitTextToSize(subsidiaryName || '', 66);
    let totalCount = paymentVouchar.length + ExchangeRate.length + status.length + functionalCurrency.length +
      TransanctionCurrency.length + CreateBy.length + supName.length + bankName.length + branchName.length + bankAccountNum.length + paymentMode.length + address.length + projectNamelabel.length;

    let x = 6; // X coordinate  
    let y = 42; // y coordinate
    let x1 = 120; // x cordinate of second rectangel
    let y2 = 42; // y cordinate of second rectangel
    let startY = 80 + totalCount * 4;

    const headerAfer = function () {
      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Payment Voucher No', x + 2, y);
      doc.setFont("Arial", "normal");
      doc.text(': ' + makePaymentNumber || "", x + 42, y);

      doc.setFont("Arial", "bold");
      doc.text('Payment No', x + 2, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(':', x + 42, y);
      paymentVouchar.forEach((paymentVouchar: any) => {
        doc.text(paymentVouchar || "", x + 44, y);
        y += 4;
      });
      let y2rect = y;
      doc.rect(6, y += 8, 84, 10, 'F');

      doc.setTextColor(255, 255, 255);
      doc.text('SUPPLIER INFORMATION', 22, y + 6);

      doc.setFillColor(156, 178, 221); // set fill color to yellow
      doc.rect(6, y += 10, 84, (totalCount * 4) - 6, 'F'); // draw a rectangle as background

      doc.setFontSize(10);
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Supplier Name', x + 2, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(":", x + 40, y);
      supName.forEach((supName: any) => {
        doc.text(supName || "", x + 42, y);
        y += 4;
      });

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Supplier Address', x + 2, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', x + 40, y);
      address.forEach((address: any) => {
        doc.text(address || "", x + 42, y);
        y += 4;
      });

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('City', x + 2, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', x + 40, y);
      city.forEach((city: any) => {
        doc.text(city || "", x + 42, y);
        y += 4;
      });

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('State', x + 2, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', x + 40, y);
      state.forEach((state: any) => {
        doc.text(state || "", x + 42, y);
        y += 4;
      });

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Pin/Zip', x + 2, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', x + 40, y);
      pin.forEach((pin: any) => {
        doc.text(pin || "", x + 42, y);
        y += 4;
      });

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Country', x + 2, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', x + 40, y);
      country.forEach((country: any) => {
        doc.text(country || "", x + 42, y);
        y += 4;
      });




      //end of supplier details----------------------------------------------
      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.text('Payment Date ', x1 + 2, y2);
      doc.setFont("Arial", "normal");
      doc.text(': ' + paymentDate || "", x1 + 40, y2);

      doc.setFont("Arial", "bold");
      doc.text('Payment Status ', x1 + 2, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(':', x1 + 40, y2);
      status.forEach((status: any) => {
        doc.text(status || "", x1 + 42, y2);
        y2 += 4;
      });
      if (y2rect > y2) {
        y2 = y2rect;
      } else {
        y2 = y2;
      }


      //start of payment details--------------------------------------------
      doc.setFillColor(53, 67, 112);
      doc.rect(x1, y2 += 8, 84, 10, 'F');

      doc.setTextColor(255, 255, 255);
      doc.text('PAYMENT INFORMATION', x1 + 16, y2 + 6);

      doc.setFillColor(156, 178, 221); // set fill color to yellow
      doc.rect(x1, y2 += 10, 84, (totalCount * 4) - 6, 'F'); // draw a rectangle as background

      doc.setTextColor(53, 67, 112);
      doc.setFontSize(10);
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Bank Name: ', x1 + 2, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(':', x1 + 40, y2);
      bankName.forEach((bankName: any) => {
        doc.text(bankName || "", x1 + 42, y2);
        y2 += 4;
      });


      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Branch', x1 + 2, y2 += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', x1 + 40, y2);
      branchName.forEach((branchName: any) => {
        doc.text(branchName || "", x1 + 42, y2);
        y2 += 4;
      });


      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Bank Acc No.', x1 + 2, y2 += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', x1 + 40, y2);
      bankAccountNum.forEach((bankAccountNum: any) => {
        doc.text(bankAccountNum || "", x1 + 42, y2);
        y2 += 4;
      });


      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Payment Mode ', x1 + 2, y2 += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', x1 + 40, y2);
      paymentMode.forEach((paymentMode: any) => {
        doc.text(paymentMode || "", x1 + 42, y2);
        y2 += 4;
      });


      doc.setFont("Arial", "bold");
      doc.text('Functional Currency', x1 + 2, y2 += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', x1 + 40, y2);
      functionalCurrency.forEach((functionalCurrency: any) => {
        doc.text(functionalCurrency || "", x1 + 42, y2);
        y2 += 4;
      });

      doc.setFont("Arial", "bold");
      doc.text('Transaction Currency', x1 + 2, y2 += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', x1 + 40, y2);
      TransanctionCurrency.forEach((TransanctionCurrency: any) => {
        doc.text(TransanctionCurrency || "", x1 + 42, y2);
        y2 += 4;
      });

      doc.setFont("Arial", "bold");
      doc.text('Exchange Rate', x1 + 2, y2 += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', x1 + 40, y2);
      ExchangeRate.forEach((ExchangeRate: any) => {
        doc.text(ExchangeRate || "", x1 + 42, y2);
        y2 += 4;
      });

      // doc.setFont("Arial", "bold");
      // doc.text('Create By', x1 + 2, y2 += 2);
      // doc.setFont("Arial", "normal");
      // doc.text(':', x1 + 40, y2);
      // CreateBy.forEach((CreateBy: any) => {
      //   doc.text(CreateBy || "", x1 + 42, y2);
      //   y2 += 4;
      // });
      //end of payment details
      doc.setTextColor(0);
      margin: { top: 30 }

    };





    const footer = function () {
      doc.setFontSize(12);
      doc.setTextColor(0);
      doc.text('Remarks :', 6, doc.internal.pageSize.height - 36);
      doc.setFontSize(10);
      let line = 36;
      remarks.forEach((remarks: any) => {
        doc.text(remarks, 24, doc.internal.pageSize.height - line);
        line -= 4;
      })


      // (doc as any).setDrawColor(53, 67, 110);
      // (doc as any).setLineWidth(0.1);
      doc.setFillColor(255, 255, 255);
      doc.setFontSize(12)
      doc.setFont("Arial", "bold")
      doc.text('________________________', doc.internal.pageSize.width - 58, doc.internal.pageSize.height - 46)
      doc.text('      Authorized Signature', doc.internal.pageSize.width - 58, doc.internal.pageSize.height - 40);

    };



    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: this.paymentData,
      //foot: [['', '', '', '', '', 'Estimated Total:', this.estimatedAmount]],
      margin: { left: 6, bottom: 50, top: startY, right: 6 },
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [255, 255, 255],

      },


      headStyles: {
        fillColor: [53, 67, 110], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles: {
        3: { halign: 'right' },
        4: { halign: 'right' },
        5: { halign: 'right' },
        6: { halign: 'right' }
      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;

        }



      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();
        headerAfer();


        doc.setPage(data.pageNumber);


        //(doc as any).setY(doc.internal.pageSize.height - 50);
        // set the startY option for the autoTable on this page
        x = 8; // X coordinate  
        y = 42; // y coordinate
        x1 = 120; // x cordinate of second rectangel
        y2 = 42;
        startY = (doc as any).autoTable.previous.finalY + 10;
        //(doc as any).setY(startY)
      },

    });
    //total amount paid
    doc.setFontSize(8);
    doc.setFillColor(53, 67, 110);
    (doc as any).rect(122, (doc as any).autoTable.previous.finalY + 10, 82, 10, 'F');
    (doc as any).setFontSize(12)
    doc.setTextColor(255, 255, 255);
    let totalPayed: any = this.resList?.amount?.toFixed(2) ?? "";
    let paymentInword: string[] = doc.splitTextToSize(this.amountInWords, 120);

    (doc as any).text(
      doc.internal.pageSize.width - 85,
      (doc as any).autoTable.previous.finalY + 16,
      'Total Amount Paid :', { bold: true, font: 'Arial' }
    );


    totalPayed = totalPayed.toString();



    (doc as any).text(
      188 - totalPayed.length * 2,
      (doc as any).autoTable.previous.finalY + 16,
      this.resList.currency + ' ' + totalPayed ?? "", { bold: true, font: 'Arial' }
    );

    (doc as any).setDrawColor(53, 67, 110);
    (doc as any).setLineWidth(0.1);
    doc.setFillColor(255, 255, 255);

    // (doc as any).rect(6, (doc as any).autoTable.previous.finalY + 10, 84, 6+(paymentInword.length)*4);
    (doc as any).setFontSize(10)
    doc.setFont("Arial", "bold");
    doc.setTextColor(0);
    (doc as any).text(
      8,
      (doc as any).autoTable.previous.finalY + 16,
      'Amount In words : ', { bold: true, font: 'Arial' }
    );
    doc.setFont("Arial", "normal");
    let pyIterator: any = (doc as any).autoTable.previous.finalY + 20;
    paymentInword.forEach((paymentText: string,) => {
      (doc as any).text(paymentText, 8, pyIterator);
      pyIterator += 4;
    });
    footer();

    doc.save('report.pdf');
  }


  exportexcel() {
    const wsBody: any = [];

    let subsidiaryName = this.makePaymentSubsidiary.legalName || '';

    if (subsidiaryName) {
      subsidiaryName = this.makePaymentSubsidiary?.legalName || '';
    }

    else {

      subsidiaryName = this.makePaymentSubsidiary?.name || '';

    }
    wsBody.push([subsidiaryName]);
    wsBody.push([]);
    // Heading of the payment list
    const separateHeadingRow = ['Make Payment'];
    wsBody.push(separateHeadingRow);

    // Add an empty row for spacing
    wsBody.push([]);
    wsBody.push([]);
    // Add table header
    const headerRow = this.columns.map(col => col.header);
    wsBody.push(headerRow);

    // Add payment data body
    this.paymentData.forEach((paymentData: any) => {
      wsBody.push(paymentData);
    });

    wsBody.push([]);
    wsBody.push([]);
    wsBody.push([]);
    wsBody.push([]);
    wsBody.push([]);
    wsBody.push([]);
    wsBody.push([]);
    wsBody.push(['_________________________']);
    wsBody.push(['   Authorized Signature']);

    const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(wsBody);

    // Merge and center the separate heading
    const subHeadMerge = { s: { r: 0, c: 0 }, e: { r: 0, c: this.columns.length - 1 } };
    const  reportNameMerge = { s: { r: 0, c: 0 }, e: { r: 0, c: this.columns.length - 5 } };

    ws['!merges'] = [subHeadMerge],[reportNameMerge];
    ws['A1'].s = {
      font: { bold: true },
      alignment: { horizontal: 'center', vertical: 'center' },
      fill: { fgColor: { rgb: 'FF0000' } } // Set the background color, e.g., red
    };

    ws['A3'].s = {
      font: { bold: true },
      alignment: { horizontal: 'center', vertical: 'center' },
      text: { fgColor: { rgb: '#35436E' } } 
    };

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);
  }

}




