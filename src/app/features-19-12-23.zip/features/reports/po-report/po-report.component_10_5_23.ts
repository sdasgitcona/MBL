import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { Injectable } from '@angular/core';


import { Item,PurchaseOrder,subsidiary,subAddr,supplier,supAddr,supContacts} from './domain/product';
import * as FileSaver from 'file-saver';
import {jsPDF} from 'jspdf';
import * as XLSX from 'xlsx';
import jsPDFWithPlugin from 'jspdf';
import html2canvas from 'html2canvas';

//import 'jspdf-autotable';
import autoTable from 'jspdf-autotable';
import { Header } from 'primeng/api';
import { TableBody } from 'primeng/table';
import 'jspdf-autotable';

@Injectable({
  providedIn: 'root'
})


@Component({
  selector: 'app-po-report',
  templateUrl: './po-report.component.html',
  styleUrls: ['./po-report.component.scss']
})
export class PoReportComponent implements OnInit {

  PoList: PurchaseOrder = new PurchaseOrder();
  List: any[] = [];
  poItem:any[]=[];

  subsidiary:subsidiary=new subsidiary();
  subAddr:subAddr[]=[];

  supplier:supplier=new supplier();
  supAddr:supAddr[]=[];
  supContacts:supContacts[]=[];

  poNumber:any;
  poData: any = [];
  totalRecords:number=0;
  loading: boolean = false;

  RetloginDetails:any;
  //supplierAddress:supAddr=new supAddr();
  supplierAddress:any=[];
  //supplierContacts:supContacts=new supContacts();
  supplierContacts:any=[];
  

  subAddress:subAddr=new subAddr();


  cols: any[];
  @ViewChild('header')header!: ElementRef;
  @ViewChild('footer')footer!: ElementRef;
  @ViewChild('estimatedTotal') estimatedTotal!: ElementRef;


  exportColumns: any[];


  constructor(private httpService: CommonHttpService) { }

  ngOnInit(){
      
  //   this.productService.getProductsMini().then((data) => {
  //     this.products = data;
  // });

  this.cols = [
    { field: 'id', header: '#'},
    { field: 'name', header: 'Item' },
    { field: 'description', header: 'Description' },
    { field: 'uom', header: 'Uom' },
    { field: 'quantity', header: 'Quantity' },
    { field: 'rate', header: 'Rate'},
    { field: 'taxableamount', header:'Taxable Amount'},
    { field: 'taxamount', header:'Tax Amount'},
    { field: 'amount', header:'Amount'}
];

this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
//call api
this.getApiall();
    
  }


  exportPdf(poNumber:any){
    this.cols = [
      { field: 'id', header: '#'},
      { field: 'name', header: 'Item' },
      { field: 'description', header: 'Description' },
      { field: 'uom', header: 'Uom' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'rate', header: 'Rate'},
      { field: 'taxableamount', header:'Taxable Amount'},
      { field: 'taxamount', header:'Tax Amount'},
      { field: 'amount', header:'Amount'}
  ];
  this.poNumber=poNumber;
  this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
  
  this.getApiall();
    this.poNumber=poNumber;
  }
  getApiall(){
    //api call with token
    //alert('api call');
      const retDetails: any = localStorage.getItem("RoleDTLS");
      var role_Dtls = JSON.parse(retDetails);
  
  
      const LDetails: any = localStorage.getItem("LoggerDTLS");
      this.RetloginDetails = JSON.parse(LDetails);
  
      this.httpService
        .GetAll(`/procure-ws/po/get/by-po-number?poNumber=`+this.poNumber, this.RetloginDetails.token)
        .subscribe((res) => {
          if (res.status == 401) {
            alert("Unauthorized Access !");
          }
          else if (res.status == 404) {
            alert("Wrong/Invalid Token!");
          }
          else {
          
            if (res && res.purchaseOrderItems?.length > 0) {
              this.PoList = res;
              
              // this.poSupplier=res.supplier;
              // console.log('Po Supplier-----'+this.poSupplier);
            
              for(let x=0; x < this.PoList.supplier.supplierAddresses?.length;x++)
             {
                if(this.PoList.supplier.supplierAddresses[x].supplierId == this.PoList.billTo){
                  this.supplierAddress=this.PoList.supplier.supplierAddresses[x];
                }
          }

            for(let x=0; x < this.PoList.supplier.supplierContacts?.length;x++)
              {
                if(this.PoList.supplier.supplierContacts[x].supplierId == this.PoList.billTo){
                  this.supplierContacts=this.PoList.supplier.supplierContacts[x];
                }
            }

            // if (res.supplier && Array.isArray(res.supplier.supplierAddresses)) {
            //   this.supplierAddress = res.subsidiary.subsidiaryAddresses;
            //   this.supplierAddress.forEach((address: any) => {
            //     this.supplierAddress = address;
            //   });
            // } else {
            //   console.log("Error: invalid response");
            // }

            // let suplierContactArr:any =[];
            // if (res.supplier && Array.isArray(res.supplier?.supplierContacts)) {
            //   suplierContactArr = res.subsidiary?.supplierContacts;
            //   suplierContactArr.forEach((contacts?: any) => {
            //    this.supplierContacts = contacts;
            //   });
            // } else {
            //   console.log("Error: invalid response");
            // }

            //this.supplierContacts =  res.subsidiary?.supplierContacts;

            for(let x=0; x < this.PoList.subsidiary.subsidiaryAddresses?.length;x++)
              {
                if(this.PoList.subsidiary.subsidiaryAddresses[x].subsidiaryId == this.PoList.subsidiaryId){
                  this.subAddress=this.PoList.subsidiary.subsidiaryAddresses[x];
                }
            }


              this.subsidiary =res.subsidiary;
              //console.log('Subsidiary-----'+JSON.stringify(this.subsidiary));

              this.subAddr=res.subsidiary.subsidiaryAddresses;
              //console.log('Subsidiary Address-----'+JSON.stringify(this.subAddr));



              this.supplier =res.supplier;
             // console.log('Supplier Details-----'+JSON.stringify(this.supplier));

              this.supAddr=this.supplier.supplierAddresses;
              //console.log('Supplier Address-----'+JSON.stringify(this.supAddr));

              this.supContacts=this.supplier.supplierContacts;
              //console.log('Supplier Contacts-----'+JSON.stringify(this.supContacts));


               
              this.poItem = res.purchaseOrderItems;
              //console.log('Po Item-----'+JSON.stringify(this.poItem));
  
              this.totalRecords = res.totalRecords;
              
            // Push data
              
              for (let i = 0; i < this.poItem.length; i++) {
                
                this.poData.push([i + 1, 
                  this.poItem[i].itemName, 
                  this.poItem[i].itemDescription, 
                  this.poItem[i].itemUom,
                  this.poItem[i].quantity, 
                  this.poItem[i].rate?.toFixed(2), 
                  this.poItem[i].amount?.toFixed(2), 
                  this.poItem[i].taxAmount?.toFixed(2), 
                  this.poItem[i].totalAmount?.toFixed(2)]);
            
              }
             
  
              this.exportPdfAPI();
  
            } else {
             
              this.totalRecords = 0;
  
            }
            this.loading = false;
            
  
  
          }
        });
  
    }

  //exportPdf(poNumber:any) {
    exportPdfAPI(){

  // create a new jsPDF instance
    const doc = new jsPDF('p', 'mm', 'a4');


    // generate table content
    let subsidiaryName = this.subsidiary ?.name || '';

    let supplierName = this.supplier ?.name || '';

    // define the header and footer
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName, 8, 12);
      doc.text('Purchase Order', 82, 24);
    };
    //header data
    let poNumber: any = this.PoList?.poNumber || '';
    let memo: any=this.PoList?.memo || '';
    const timestamp = this.PoList?.poDate || '';
    const date = new Date(timestamp);
    const poData = date.toLocaleDateString('en-GB');
    const approvalstat= this.PoList?.poStatus || '';

    //ship to location
    let location: any = this.PoList?.locationName || '';

  //subsidiary
    let address: any = doc.splitTextToSize( this.subAddress?.address1 || '' + this.subAddress?.address2 || '', 46);
    let city: any = this.subAddress?.city || '';
    let email:any=this.subsidiary?.email || '';
     let state: any = this.subAddress?.state || '';
    let zipcode: any = this.subAddress?.zipcode || '';
    let country: any = this.subAddress?.country|| '';
     let website: any = this.subsidiary?.website || '';
     let vatCode: any = this.subsidiary?.pan || '';
     let regCode: any = this.subsidiary?.tan || '';
    let currency:any=this.PoList?.currency||'';
    let term:any=this.PoList?.paymentTerm||'';
    
   //supplier 
    let saddress: any = doc.splitTextToSize( this.supplierAddress?.address1 || '' + this.supplierAddress?.address2 || '', 46);
    //alert(saddress);
    let scity: any = this.supplierAddress?.city || '';
     let sstate: any = this.supplierAddress?.state || '';
    let szipcode: any = this.supplierAddress?.pin || '';
    let scountry: any = this.supplierAddress?.country|| '';
    let sregtype: any = this.supplierAddress?.registrationType|| '';
    let sregno:any=this.supplierAddress?.taxRegistrationNumber|| '';
    let staxid: any = this.supplierContacts?.name|| '';
    let scontactperson: any = this.supplierContacts?.name|| '';
    let sphone: any = this.supplierContacts?.contactNumber|| '';
    let semail: any = this.supplierContacts?.email|| '';
    let staxRegNo:any=this.supplierAddress?.taxRegistrationNumber|| '';


    let x = 8; // X coordinate
    let y = 64;
    const headerAfer = function () {

      // Y coordinate
      let rectHeight = 72;
      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);

      doc.text('PO Number ', x, 36);
      doc.text(":"+poNumber || "", 42, 36);

      doc.text('PO Date ', 118, 36);
      doc.text(": " +poData || "", 152, 36);
      doc.text('Approval Status ', 118, 45);
      doc.text(": " +approvalstat || "", 152, 45);


      doc.rect(6, 48, 96, 10, 'F');
      doc.setTextColor(255, 255, 255);
      doc.text('SUBSIDIARY INFORMATION', 20, 54);

      doc.setFillColor(156, 178, 221); // set fill color to yellow
      doc.rect(6, 58, 96, rectHeight, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(10);

      doc.setFont("Arial", "bold");
      doc.text('Name ', x, y);
      doc.setFont("Arial", "normal");
      doc.text(": " + subsidiaryName || "", 48, y);

      // doc.setFont("Arial", "bold");
      // doc.text('Attention Company Person', x, y += 6);
      // doc.setFont("Arial", "normal");
     // doc.text(": " + attention || '', 50, y);

      let strLength = 0;
      doc.setFont("Arial", "bold");
      doc.text('Address', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(':' + address|| '',48,y);

    //  address.forEach((address: any) => {
    //  //doc.text(address  || "", 52, y);
    //     y += 4; // Move down to the next line (adjust as needed)
    //     strLength += address.length;
    // });

      //alert(address.length);

      doc.setFont("Arial", "bold");
      doc.text('City', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + city || '', 48, y);

      doc.setFont("Arial", "bold");
      doc.text('State', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + state || '', 48, y);

      doc.setFont("Arial", "bold");
      doc.text('Pin/Zip ', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + zipcode, 48 || '', y);

      doc.setFont("Arial", "bold");
      doc.text('Country', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + country || '', 48, y);


      doc.setFont("Arial", "bold");
      doc.text('Email', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + email || '', 48, y);

      doc.setFont("Arial", "bold");
      doc.text('Website', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + website || '', 48, y);

      doc.setFont("Arial", "bold");
      doc.text('Vat Registraion Number', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(': '+ vatCode ||'', 48, y);

        doc.setFont("Arial", "bold");
        doc.text('Registraion No', x, y += 6);
        doc.setFont("Arial", "normal");
        doc.text(": " + regCode || "", 48, y);

      let addressCount=1;

      // if (address.length > 1) {
      //  doc.setFillColor(156, 178, 221);
      //  doc.rect(6, y , 91, 18, 'F');
      //  doc.setFont("Arial", "bold");
      //  doc.text('Registraion No', x, y + 12);
      //  doc.setFont("Arial", "normal");
      //  doc.text(": " + regCode || "", 48, y + 12);
       
      // }
      // else {
      //   doc.setFont("Arial", "bold");
      //   doc.text('Registraion No', x, y += 6);
      //   doc.setFont("Arial", "normal");
      //   doc.text(": " + regCode || "", 48, y);
      // }



      let x1 = 120;
      let y2 = 66;


      doc.rect(115, 48, 91, 10, 'F'); // draw a rectangle as background
      doc.setTextColor(255, 255, 255);
      doc.setFont("Arial", "bold")
      doc.setFontSize(12);
      doc.text('SUPPLIER INFORMATION', 134, 54);
      doc.setFillColor(156, 178, 221); // set fill color to blue
      doc.rect(115, 58, 91, rectHeight, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(10);

      doc.setFont("Arial", "bold");
      doc.text('Name', x1, y2);
      doc.setFont("Arial", "normal");
      doc.text(": " +supplierName || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('Address ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +saddress || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('City', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +scity || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('State', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +sstate || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('Pin', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +szipcode || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('Country', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +scountry || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('Registration Type', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +sregtype || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('Tax Id', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +staxRegNo || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('Contact Person', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +scontactperson || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('Phone', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +sphone || "", 148, y2);

      doc.setFont("Arial", "bold");
      doc.text('Email', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " +semail || "", 148, y2);

      

      doc.rect(6, y2+=15, 200, 10, 'F'); // draw a rectangle as background
      doc.setTextColor(255, 255, 255);
      doc.setFont("Arial", "bold")
      doc.setFontSize(12);
      doc.text('Currency', 12, y2+=6);
      doc.setFontSize(12);
      doc.text('Terms', 92, y2);
      doc.setFontSize(12);
      doc.text('Ship To Location', 172,y2);

      doc.setFillColor(255, 255, 255);
      doc.rect(6, y2+=5, 200, 8, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112);
      doc.setFont("Arial")
      doc.setFontSize(12);
      doc.text(currency || "", 12, y2+=6);
      doc.setFontSize(12);
      doc.text(term || "", 92, y2);
      doc.setFontSize(12);
      doc.text(location || "", 172,y2);


      //doc.setFontSize(10);
      doc.setTextColor(0);
      margin: { top: 30 }
    };



    const footer = function () {
      doc.setFontSize(12);
      doc.setTextColor(0);
      doc.text('Remarks', 14, doc.internal.pageSize.height - 36);
      doc.text(':' || memo, 34, doc.internal.pageSize.height - 36);
      doc.text('Declaration:', 14, doc.internal.pageSize.height - 26);
      doc.text('____________________', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 40);
      doc.text('  Authorized Signature', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 30);

    };

    // generate the invoice
    
    let startY = y + 100;
    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: this.poData,
      //foot: [['', '', '', '', '', 'Estimated Total:', this.estimatedAmount]],
      margin: { left: 6, bottom: 70, top: startY, right: 5 },
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [255, 255, 255],

      },

      headerStyles: {
        fillColor: [53, 67, 110], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;
          if (data.pageCount === (doc as any).internal.getNumberOfPages()) {
            // add the footer section to the last page
            (doc as any).autoTable({
              head: false,
              body: false,
              //foot: [['', '', '', '', '', 'Estimated Total:']],
              startY: doc.internal.pageSize.height - 90,
              tableWidth: 'wrap',
              styles: {
                cellPadding: 1,
                fontSize: 10,
                valign: 'middle',
                halign: 'center',
                fillColor: [53, 67, 110],
              },
            });
          }

        }




      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();
        headerAfer();
        footer();

        doc.setPage(data.pageNumber);
        //(doc as any).setY(doc.internal.pageSize.height - 50);
        // set the startY option for the autoTable on this page
        startY = (doc as any).autoTable.previous.finalY + 10;
        //(doc as any).setY(startY)
      },

    });

    const estimatedTotalText = `Estimated Amount    :  ${this.PoList.amount?.toFixed(2) || ''}`;
    const taxTotalText = `Tax Total                  :    ${this.PoList.taxAmount?.toFixed(2) || ''}`;
    const totalText = `Total Amount            :  ${this.PoList.totalAmount?.toFixed(2) || ''}`;
    doc.setFillColor(53, 67, 110);
    (doc as any).rect(120, (doc as any).autoTable.previous.finalY + 10, 85, 23, 'F');
    (doc as any).setFontSize(12)
    doc.setTextColor(255, 255, 255);

    (doc as any).text(
      122,
      (doc as any).autoTable.previous.finalY + 16,
      estimatedTotalText, { bold: true, font: 'Arial' }
    );
    (doc as any).text(
      122,
      (doc as any).autoTable.previous.finalY + 22,
      taxTotalText, { bold: true, font: 'Arial' }
    );
    (doc as any).text(
      122,
      (doc as any).autoTable.previous.finalY + 28,
      totalText, { bold: true, font: 'Arial' }
    );


    doc.save('report.pdf');
  }
  

    

// exportExcel() {
//     // import('xlsx').then((xlsx) => {
//     //     const worksheet = xlsx.utils.json_to_sheet();
//     //     const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
//     //     const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
//     //     this.saveAsExcelFile(excelBuffer, 'po_report');
//     // });
// }

// saveAsExcelFile(buffer: any, fileName: string): void {
//     let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
//     let EXCEL_EXTENSION = '.xlsx';
//     const data: Blob = new Blob([buffer], {
//         type: EXCEL_TYPE
//     });
//     FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
// }
  

 
}
