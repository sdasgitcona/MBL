export class PurchaseOrder1 {
    id: number;
    subsidiaryId: number;
    itemline: Item1[] = [];
  }
  
  export class Item1 {
    id: number;
    itemId?: number;
    poNumber:any;
    itemName:string;
    itemdescription:string;
    nsinternalid:string;
    accountcode:string
    uom:string;
    quantity:string;
    rate:string;
    amount:string;
    taxgroup:string;
    taxAmount:string;
    totalAmount:string;
    receivebydate:string;
    prnumber:string;
    shiptolocation:string;
    department:string;
    memo:string;
    
  
  }
  
  
  
  export class Item {
    id?: any;
    poNumber?: string;
    poId?: number;
    itemId?: number;
    quantity?: any;
    rate?: any;
    amount?: any;
    taxGroupId?: any;
    taxAmount?: any;
    totalTaxAmount?:any;
    receivedByDate?: any;
    prNumber?: string;
    prId?:any;
    shipToLocationId?: number;
    shipToLocation?: string;
    department: string;
    memo?: string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    itemName?: any;
    itemDescription?: any;
    accountCode?: number;
    itemUom?: any;
    itemIntegratedId?: any;
    deleted?: boolean;
    totalAmount?: any;
    unbilledQuantity?:any;
    remainQuantity?:any;
    status?:string;
  
  }
  export class PrItems {
    id?: any;
    prId?: any;
    prNumber: string;
    itemId: number;
    itemDescription: string;
    quantity: number;
    rate: number;
    memo?: any;
    integratedId?: any;
    estimatedAmount?: any;
    receivedDate: Date;
    poNumber?: any;
    createdDate?: any;
    createdBy?: any;
    lastModifiedDate?: any;
    lastModifiedBy?: any;
    itemName: string;
    itemUom: string;
    department: string;
    accountId: number;
    deleted: boolean;
    prLocationName:any
  }
  export class QAItems {
    id: number;
    qaId?: any;
    qaNumber: string;
    clientQaNumber?: any;
    recievedDate: Date;
    generalSupplier?: any;
    approvedSupplier?: any;
    itemId: number;
    currency?: any;
    quantity: number;
    uom: string;
    exchangeRate?: any;
    ratePerUnit: number;
    actualRate: number;
    expectedDate?: any;
    leadTime?: any;
    prNumber?: any;
    prLocationId?: any;
    poRef?: any;
    createdDate?: any;
    createdBy?: any;
    lastModifiedDate?: any;
    lastModifiedBy?: any;
    prLocation?: any;
    itemName: string;
    itemDescription: string;
    integratedId?: any;
    accountCode?: number;
    deleted: boolean;
    processedPo: boolean;
    awarded: boolean;
  }
  export class supplierCurrency {
    id: number;
    supplierId: number;
    subsidiaryId: number;
    currency: string;
    supplierCurrency: string;
    createdDate?: any;
    createdBy?: any;
    lastModifiedDate?: any;
    lastModifiedBy?: any;
    subsidiaryName: string;
    deleted: boolean;
    preferredCurrency: boolean;
  }
  export class PurchaseOrder {
    id?: number;
    poNumber?: string;
    subsidiaryId?: number;
    poType?: string;
    locationId?: any;
    location?: string;
   // prNumber: any;
    prId?:any;
    qaNumber?: any;
    qaId?:any;
    supplierId?: number;
    originalSupplierId?: number;
    poDate?: any;
    rejectedComments?: any;
    paymentTerm?: string;
    matchType?: string;
    currency?: string;
    exchangeRate?: any;
    poStatus?: string;
    memo?: string;
    netsuiteId?: string;
    approvedBy?: any;
    approvalDate?:any;
    nextApprover?: any;
    nextApproverRole?: any;
    nextApproverLevel?: any;
    approverPreferenceId?: any;
    approverSequenceId?: any;
    approverMaxLevel?: any;
    noteToApprover?: any;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    subsidiaryName?: any;
    subsidiaryCountry: any;
    subAddress1:any;
    supAddress1: any;
    subCity: any;
    subState: any;
    subZipcode: any;
    subEmail: any;
    subWebsite: any;
    supWebsite: any;
    supPhone:any;
    subRegistrationCode:any;
    supWeb: any;
    subAddress2: any;
    supplierName?: any;
    locationName?: any;
    totalValue?: any;
    purchaseOrderItems: Item[] = [];
    subsidiary:subsidiary;
    supplier:supplier;
    revision?: number;
    deleted?: boolean;
    approvalRoutingActive?: boolean;
    supplierUpdatable?: boolean;
    isSupplierAll?: boolean;
    billTo?:any;
    shipTo?:any;
    trn?:any;
    amount?:any;
    taxAmount?:any;
    totalAmount?:any;
     // for approval
     selected?:boolean;
     NewrejectComments?: any;
     prNumbers?:any;
     supTaxRegistrationNumber:any;
     signature:any;
     convertedSignature:any;
  }
  
  
  export class subsidiary{
    id:any;
    subsidiaryId:any
    name:any;
    legalName:any;
    logo:any;
    email:any;
    website:any;
    pan:any;
    tan:any;
    cin:any;
    invoiceMail:any;
    subsidiaryAddresses: subAddr[]=[];
    subsidiaryGeneralInfo:subGenInfo[]=[]
  }
  
  export class subAddr{
      subsidiaryId:any;
      country:any;
      attention: any;
      address: any;
      phone: any;
      address1: any;
      address2: any;
      city: any;
      state: any;
      zipcode: any;
      registrationCode: any;
      registrationType: any  
         
  }
  export class subGenInfo{
    id:number;
    serialNumber:number;
    remarks:any;
    subsidiaryId:number;
  }
  export class supplier{
    id: any;
    name:any;
    legalName:any;
    vendorNumber:any;
    vendorType:any;
    uin:any;
    supplierAddresses:supAddr[]=[];
    supplierContacts:supContacts[]=[];
  }
  
  export class supAddr{
    id:any;
    supplierId:any;
    address1: any;
    address2: any;
    city: any;
    state: any;
    country: any;
    pin: any;
    taxRegistrationNumber: any;
    registrationType: any;             
  }  
  
  export class supContacts{
    id:any;
    supplierId:any;
    name: any;
    contactNumber: any;
    altContactNumber: any;
    email: any;
    web: any;
    fax: any;
  }
  
  export class POPrs{
    id?: number;            
    quotationId?:number;
    quotationNumber?:string;
    prNumber?:any;
    prLocationId?:number;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted?:boolean;
    name?:any;
    prId?:any;
  }
  
  // For CSV
  export class file_upload
    {
      file:File;
    }
  