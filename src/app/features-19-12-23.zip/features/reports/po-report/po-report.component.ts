import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { Router } from '@angular/router';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';

import { Item,PurchaseOrder,subsidiary,subAddr,supplier,supAddr,supContacts,subGenInfo,file_upload} from './model/po-report-model';
import * as FileSaver from 'file-saver';
import {jsPDF} from 'jspdf';
import * as XLSX from 'xlsx';
import jsPDFWithPlugin from 'jspdf';
import html2canvas from 'html2canvas';

//import 'jspdf-autotable';
import autoTable from 'jspdf-autotable';
import { Header } from 'primeng/api';
import { TableBody } from 'primeng/table';
import 'jspdf-autotable';

@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-po-report',
  templateUrl: './po-report.component.html',
  styleUrls: ['./po-report.component.scss']
})
export class PoReportComponent implements OnInit {

  PoList: PurchaseOrder = new PurchaseOrder();
  List: any[] = [];
  poItem:any[]=[];

  subsidiary:subsidiary=new subsidiary();
  subAddr:subAddr[]=[];
  

  supplier:supplier=new supplier();
  supAddr:supAddr[]=[];
  supContacts:supContacts[]=[];

  poNumber:any;
  poData: any = [];
  totalRecords:number=0;
  loading: boolean = false;

  RetloginDetails:any;
  //supplierAddress:supAddr=new supAddr();
  supplierAddress:any=[];
  //supplierContacts:supContacts=new supContacts();
  supplierContacts:any=[];
  
  pdfSrc:any;

  subAddress:subAddr=new subAddr();
  subGenInfo:subGenInfo=new subGenInfo();
  subGen:any =[];
  convertedSignature:any;
  finalAppDate:any;
  cols: any[];
  file: File ;
  file_upload:file_upload=new file_upload();
  type:any;

  base64:string;


  @ViewChild('header')header!: ElementRef;
  @ViewChild('footer')footer!: ElementRef;
  @ViewChild('estimatedTotal') estimatedTotal!: ElementRef;


  exportColumns: any[];


  constructor(private httpService: CommonHttpService,
    private routeStateService: RouteStateService,
    private router: Router,
    private toastService: ToastService) { 

  }

  ngOnInit(){
    
    
      
  //   this.productService.getProductsMini().then((data) => {
  //     this.products = data;
  // });

  this.cols = [
    { field: 'id', header: '#'},
    { field: 'name', header: 'Item' },
    { field: 'description', header: 'Description' },
    { field: 'uom', header: 'Uom' },
    { field: 'quantity', header: 'Quantity' },
    { field: 'rate', header: 'Rate'},
    { field: 'taxableamount', header:'Taxable Amount'},
    { field: 'taxamount', header:'Tax Amount'},
    { field: 'amount', header:'Amount'}
];

this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
//call api
this.getApiall(this.type);
    
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  exportPdf(poNumber:any,type:any){

    this.type=type;

    this.poNumber=poNumber;
    this.cols = [
      { field: 'id', header: '#'},
      { field: 'name', header: 'Item' },
      { field: 'description', header: 'Description' },
      { field: 'uom', header: 'Uom' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'rate', header: 'Rate'},
      { field: 'taxableamount', header:'Taxable Amount'},
      { field: 'taxamount', header:'Tax Amount'},
      { field: 'amount', header:'Amount'}
  ];
  
  this.exportColumns = this.cols.map((col) => ({ title: col.header, dataKey: col.field }));
  
  this.getApiall(this.type);

  }
  getApiall(type:any){
    //api call with token
    //alert('api call');
      const retDetails: any = localStorage.getItem("RoleDTLS");
      var role_Dtls = JSON.parse(retDetails);
  
  
      const LDetails: any = localStorage.getItem("LoggerDTLS");
      this.RetloginDetails = JSON.parse(LDetails);
  
      this.httpService
       .GetAll(`/procure-ws/po/get/by-po-number?poNumber=`+this.poNumber, this.RetloginDetails.token)
      //.GetAll(`/procure-ws/po/get/by-po-number?poNumber=HPL/10004/PO`, this.RetloginDetails.token)
       .subscribe((res) => {
          if (res.status == 401) {
            alert("Unauthorized Access !");
          }
          else if (res.status == 404) {
            alert("Wrong/Invalid Token!");
          }
          else {
          
            if (res && res?.purchaseOrderItems?.length > 0) {
              this.PoList = res;

            if (res.supplier && Array.isArray(res?.supplier?.supplierAddresses)) {
             
              this.supplierAddress = res.supplier?.supplierAddresses;
              this.supplierAddress.forEach((address: any) => {
                this.supplierAddress = address;
              });
            } else {
              console.log("Error: invalid response");
            }

            if (res.supplier && Array.isArray(res.supplier.supplierContacts)) {
             
              this.supplierContacts = res.supplier.supplierContacts;
              this.supplierContacts.forEach((contacts: any) => {
                this.supplierContacts = contacts;
              });
            } else {
              console.log("Error: invalid response");
            }

            
            for(let x=0; x < this.PoList.subsidiary.subsidiaryAddresses?.length;x++)
              {
                if(this.PoList.subsidiary.subsidiaryAddresses[x].subsidiaryId == this.PoList.subsidiaryId){
                  this.subAddress=this.PoList.subsidiary.subsidiaryAddresses[x];
                }
            }
            this.subGen=[];
            for(let x=0; x < this.PoList.subsidiary.subsidiaryGeneralInfo?.length;x++)
              {
                  this.subGen.push(this.PoList.subsidiary.subsidiaryGeneralInfo[x].serialNumber+'. '+this.PoList.subsidiary.subsidiaryGeneralInfo[x].remarks);
                
               }
               //console.log(this.subGen);

              this.subsidiary =res.subsidiary;
              //console.log('Subsidiary-----'+JSON.stringify(this.subsidiary));

              this.subAddr=res.subsidiary.subsidiaryAddresses;
              //console.log('Subsidiary Address-----'+JSON.stringify(this.subAddr));
             

              this.supplier =res.supplier;
             // console.log('Supplier Details-----'+JSON.stringify(this.supplier));

              this.supAddr=this.supplier.supplierAddresses;
              //console.log('Supplier Address-----'+JSON.stringify(this.supAddr));

              this.supContacts=this.supplier.supplierContacts;
              //console.log('Supplier Contacts-----'+JSON.stringify(this.supContacts));


               
              this.poItem = res.purchaseOrderItems;
              //console.log('Po Item-----'+JSON.stringify(this.poItem));
  
              this.totalRecords = res.totalRecords;
              
            // Push data
              this.poData=[];
              for (let i = 0; i < this.poItem.length; i++) {
                
                this.poData.push([i + 1, 
                  this.poItem[i].itemName, 
                  this.poItem[i].itemDescription, 
                  this.poItem[i].itemUom,
                  this.poItem[i].quantity, 
                  this.poItem[i].rate?.toFixed(2), 
                  this.poItem[i].amount?.toFixed(2), 
                  this.poItem[i].taxAmount?.toFixed(2), 
                  this.poItem[i].totalAmount?.toFixed(2)]);
            
              }
             
              // console.log("PO DATA ALL "+this.poData);
              // console.log("SUBSIDIARY DATA ALL "+JSON.stringify(this.subsidiary));
              // console.log("SUPPLIER DATA ALL "+JSON.stringify(this.supplier));
  
            this.exportPdfAPI(type);
  
            } else {
             
              this.totalRecords = 0;
  
            }
            this.loading = false;
            
  
  
          }
        });
  
    }
  //amount in words

  public addWaterMark(doc:any) {
    let totalPages:any = doc.internal.getNumberOfPages();
    let status: any = this.PoList?.poStatus;
    //alert (totalPages);
  
    for (let i = 1; i <= totalPages; i++) {

      doc.setPage(i);
      //doc.addImage(imgData, 'PNG', 40, 40, 75, 75);
      doc.setTextColor(150);
      doc.setFontSize(300);
    
      //for text transparency
      doc.saveGraphicsState();
      doc.setGState(new doc.GState({opacity: 0.2}));

      
      //if(status=='Draft' || status=='draft'){
     if(status=='Open' || status=='open' || status=='Rejected' || status=='rejected'|| status=='Partially Approved' || status=='partially approved'|| status=='Pending Approval'|| status=='pending approval'){
     
      
      doc.text(60, doc.internal.pageSize.height - 35, 'Draft',{angle: 50,});
      }
      else{
       
        doc.text(8, doc.internal.pageSize.height - 135,'',{angle: 45,});
        
      }
      doc.restoreGraphicsState(); 
    }
    return doc;
    
  }

  //exportPdf(poNumber:any) {
    exportPdfAPI(type:any){

  // create a new jsPDF instance
    const doc = new jsPDF('p', 'mm', 'a4');
    //doc.output('arraybuffer');

  
    // generate table content
    
    let subsidiaryName = (this.subsidiary ?.legalName)|| '';

      if(subsidiaryName!=''){
       subsidiaryName = (this.subsidiary ?.legalName)|| '';
      }
      else{
        subsidiaryName = (this.subsidiary ?.name)|| '';
      }



    let subName = doc.splitTextToSize(this.subsidiary ?.legalName || '',75);

   if(subName!=''){
    subName=doc.splitTextToSize(this.subsidiary ?.legalName || '',85);
   }
   else{
    subName = doc.splitTextToSize(this.subsidiary ?.name || '',75);
   }

    let supplierName = doc.splitTextToSize(this.supplier ?.legalName || '',75);

    if(supplierName==''){
      supplierName = doc.splitTextToSize(this.supplier ?.name || '',75); 
    }
    else{
      supplierName = doc.splitTextToSize(this.supplier ?.legalName || '',75);
    }

    // define the header and footer
    
    //header data
    let poNumber: any = this.PoList?.poNumber || '';

    let memo: any=doc.splitTextToSize(this.PoList?.memo || '',180);

    let sign:any=this.PoList?.convertedSignature||'';

    const appDate:any=this.PoList?.approvalDate||'';
    const date2 = new Date(appDate);
    const appsDate = date2.toLocaleDateString('en-GB');

    

     if(appsDate=='Invalid Date'){
      this.finalAppDate='';
     }
     else{
      this.finalAppDate=appsDate;
     }
    

    const timestamp = this.PoList?.poDate || '';
    const date = new Date(timestamp);
    const poData = date.toLocaleDateString('en-GB');


    const approvalstat= this.PoList?.poStatus || '';

    //ship to location
    let location: any = this.PoList?.locationName || '';

  //subsidiary
    let address: any = doc.splitTextToSize((this.subAddress?.address1 ?? '') +
    (this.subAddress?.address2 ? (this.subAddress.address1 ? ', ' : '') + this.subAddress.address2 : ''),
    80);
    
    let city: any = this.subAddress?.city || '';
    let email:any=this.subsidiary?.email || '';
    let invMail:any=this.subsidiary?.invoiceMail || '';
     let state: any = this.subAddress?.state || '';
    let zipcode: any = this.subAddress?.zipcode || '';
    let country: any = this.subAddress?.country|| '';
     let website: any = this.subsidiary?.website || '';
     let vatCode: any = this.subsidiary?.pan || '';
     let regCode: any = this.subsidiary?.tan || '';
    let currency:any=this.PoList?.currency||'';
    let term:any=this.PoList?.paymentTerm||'';
    let subGenInfo=this.subGenInfo||'';
    
    
   //supplier 
     let saddress: any = doc.splitTextToSize((this.supplierAddress?.address1 ?? '') +
    (this.supplierAddress?.address2 ? (this.supplierAddress.address1 ? ', ' : '') + this.supplierAddress.address2 : ''),
    80);
    //alert(saddress);
    let scity: any = this.supplierAddress?.city || '';
     let sstate: any = this.supplierAddress?.state || '';
    let szipcode: any = this.supplierAddress?.pin || '';
    let scountry: any = this.supplierAddress?.country|| '';
    let sregtype: any = this.supplierAddress?.registrationType|| '';
    let sregno:any=this.supplierAddress?.taxRegistrationNumber|| '';
    let staxid: any = this.supplierContacts?.name|| '';
    let scontactperson: any = this.supplierContacts?.name|| '';
    let sphone: any = this.supplierContacts?.contactNumber|| '';
    let semail: any = this.supplierContacts?.email|| '';
    let staxRegNo:any=this.supplierAddress?.taxRegistrationNumber|| '';


    
    const header = function () {

      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName, 8, 12);
      doc.setFontSize(10);
      doc.setFont("Arial", "bold");
      doc.text(address, 10, 18);
      doc.text(city, 10, 26);
      doc.text(state, 10, 30);
      doc.text(zipcode, 10, 34);
      doc.text(country, 10, 38);

      doc.text(website, 10, 46);
      doc.text(invMail, 10, 50)
    
    };
    
    
    let leftLengthCount=address.length;
    let rightLengthCount=saddress.length



    let x = 8; // X coordinate
    let y = 72;
    const headerAfer = function () {

      // Y coordinate
      let rectHeight = 45;
     
      


      doc.setFillColor(234, 242, 248)
      doc.rect(6, 52, 200, 10, 'F');
      doc.setTextColor(53, 67, 112);
      doc.setFontSize(14);
      doc.text('Purchase Order', 8, 58);


      //supplier details
      
      doc.setFillColor(253, 254, 254); // set fill color to yellow
      doc.rect(6, 62, 60, 60, 'F'); //  draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(12);
      doc.text('Supplier', 8, 66);
      doc.setFontSize(10);

      doc.setFont("Arial", "normal");
      supplierName.forEach((supplierName: any) => {
        doc.text(supplierName  || "", 8, y);
        y += 4; // Move down to the next line (adjust as needed)
    });

    
      doc.setFont("Arial", "normal");
      saddress.forEach((saddress: any) => {
        doc.text(saddress  || "", 8, y);
        y += 4; // Move down to the next line (adjust as needed)
    });

     
      doc.setFont("Arial", "normal");
      doc.text(scity || '',8, y);

     
      
      doc.setFont("Arial", "normal");
      doc.text( sstate || '',8, y+=4);

     
      doc.setFont("Arial", "normal");
      doc.text( szipcode,8 || '',y+=4);

      
      doc.setFont("Arial", "normal");
      doc.text( scountry || '', 8, y+=4);

      doc.setFont("Arial", "normal");
      doc.text(''||'', 80, y+=4);

      doc.setFont("Arial", "normal");
      doc.text( "Phone" || '', 8, y+=4);
      doc.setFont("Arial", "normal");
      doc.text( ": " + sphone || '',18, y);

      doc.setFont("Arial", "normal");
      doc.text( "Email" || '', 8, y+=4);
      doc.setFont("Arial", "normal");
      doc.text( ": " + semail || '', 18, y);

      
     

      doc.setFont("Arial", "normal");
      doc.text(''||'', 8, y);


      //ship to details
      let y2 = 72;
      doc.setFillColor(253, 254, 254); // set fill color to yellow
      doc.rect(90, 62, 60, 60, 'F'); //  draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.text('Ship To', 80, 66);

      doc.setFontSize(10);

      doc.setFont("Arial", "normal");
      subName.forEach((subName: any) => {
        doc.text(subName  || "", 80, y2);
        y2 += 4; // Move down to the next line (adjust as needed)
    });

      
      doc.setFont("Arial", "normal");
     address.forEach((address: any) => {
        doc.text(address  || "", 80, y2);
        y2 += 4; // Move down to the next line (adjust as needed)
    });

      //alert(address.length);

     
      doc.setFont("Arial", "normal");
      doc.text(city || '', 80, y2);

     
      doc.setFont("Arial", "normal");
      doc.text( state || '', 80, y2+=4);

     
      doc.setFont("Arial", "normal");
      doc.text( zipcode, 80 || '',y2+=4);

      
      doc.setFont("Arial", "normal");
      doc.text( country || '', 80, y2+=4);

      doc.setFont("Arial", "normal");
      doc.text(''||'', 80, y2+=4);

      doc.setFont("Arial", "normal");
      doc.text(''||'', 80, y2+=4);
    
      
      doc.setFont("Arial", "normal");
      doc.text( invMail || '',80, y2+=4);

      
      

      
      // doc.setFont("Arial", "normal");
      // doc.text( vatCode ||'',80, y2+=4);

      
      // doc.setFont("Arial", "normal");
      // doc.text( regCode ||'', 80, y2+=4);

      
      doc.setFont("Arial", "normal");
      doc.text(''||'', 80, y2);
    
     //po related details
      let y3=66

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('PO Number ', 147, y3);
      doc.setFont("Arial", "normal");
      doc.text(":"+poNumber || "", 173, y3);

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('PO Date ', 147, y3+=6);
      doc.setFont("Arial", "normal");
      doc.text(":"+poData || "", 173, y3);

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Supplier Qutation Ref. ', 147, y3+=6);
      doc.setFont("Arial", "normal");
      doc.text(":"|| "", 182, y3);

      doc.setFillColor(234, 242, 248);
      doc.rect(6, y+=10, 200, 8, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112);
      doc.setFont("Arial", "bold")
      doc.setFontSize(10);
      doc.text('Currency', 12, y+=6);
      doc.setFontSize(10);
      doc.text('Terms', 92, y);
      doc.setFontSize(10);
      doc.text('Ship To Location', 172,y);

      doc.setFillColor(255, 255, 255);
      doc.rect(6, y+=2, 200, 8, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112);
      doc.setFont("Arial")
      doc.setFontSize(10);
      doc.text(currency || "", 12, y+=6);
      doc.setFontSize(10);
      doc.text(term || "", 92, y);
      doc.setFontSize(10);
      doc.text(location || "", 172,y);


      //doc.setFontSize(10);
      doc.setTextColor(0);
      margin: { top: 30 }
    };

  

    
    let startY =y + 64;

    if(leftLengthCount>rightLengthCount){

      startY += leftLengthCount*4;
    }else{

      startY += rightLengthCount*4;
    }
    
    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: this.poData,
      //foot: [['', '', '', '', '', 'Estimated Total:', this.estimatedAmount]],
      margin: { left: 6, bottom: 40, top: 60, right: 5 },
     
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [253, 254, 254],
        textColor: [44, 62, 80]
      },

      headerStyles: {
        fillColor: [234, 242, 248], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles:{
        4:{halign:'right'},
        5:{halign:'right'},
        6:{halign:'right'},
        7:{halign:'right'},
        8:{halign:'right'},

      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [253, 254, 254];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;
          if (data.pageCount === (doc as any).internal.getNumberOfPages()) {
            // add the footer section to the last page
            (doc as any).autoTable({
              head: false,
              body: false,
              //foot: [['', '', '', '', '', 'Estimated Total:']],
              startY: doc.internal.pageSize.height - 90,
              tableWidth: 'wrap',
              styles: {
                cellPadding: 1,
                fontSize: 10,
                valign: 'middle',
                halign: 'center',
                fillColor: [53, 67, 110],
              },
            });
          }

        }




      },
      
      didDrawPage: function (data: any) {

        // add the header and footer to each page
       
        //y =72;
        doc.setPage(data.pageNumber);
        //startY = (doc as any).autoTable.previous.finalY + 2;

        if(data.pageNumber<=1){
          header();
          headerAfer();
        }
        else{
          header();
        }
      
       
      },
     
    });
   
    const estimatedTotalText = `: ${this.PoList?.currency} ${this.PoList.amount?.toFixed(2) || ''}`;
    const taxTotalText = `: ${this.PoList?.currency} ${this.PoList.taxAmount?.toFixed(2) || ''}`;
    const totalText = `: ${this.PoList?.currency} ${this.PoList.totalAmount?.toFixed(2) || ''}`;
    
    doc.setFillColor(234, 242, 248);
    (doc as any).rect(120, (doc as any).autoTable.previous.finalY +3, 85, 20, 'F');
    (doc as any).setFontSize(10);
    doc.setTextColor(44, 62, 80);


    (doc as any).text(
      122,
      (doc as any).autoTable.previous.finalY + 8,
      'Sub Total', { bold: true, font: 'Arial' }
    );
    (doc as any).text(
      172,
      (doc as any).autoTable.previous.finalY + 8,
      estimatedTotalText, { bold: true, font: 'Arial' }
    );

    (doc as any).text(
      122,
      (doc as any).autoTable.previous.finalY + 14,
      'Tax Total', { bold: true, font: 'Arial' }
    );
    (doc as any).text(
      172,
      (doc as any).autoTable.previous.finalY + 14,
      taxTotalText, { bold: true, font: 'Arial' }
    );

    (doc as any).text(
      122,
      (doc as any).autoTable.previous.finalY + 20,
      'Total Amount', { bold: true, font: 'Arial' }
    );
    (doc as any).text(
      172,
      (doc as any).autoTable.previous.finalY + 20,
      totalText, { bold: true, font: 'Arial' }
    );

    doc.setFillColor(255, 255, 255);
    (doc as any).rect(8, (doc as any).autoTable.previous.finalY + 26, 198, 23, 'F');
    (doc as any).setFontSize(12);
    doc.setTextColor(0);

    (doc as any).setFontSize(9);
    (doc as any).text(
      8,
      (doc as any).autoTable.previous.finalY +=30,
      'Remarks: ', { bold: true, font: 'Arial' }
    );

    (doc as any).text(
      8,
      (doc as any).autoTable.previous.finalY +=4,
      memo, { bold: true, font: 'Arial' }
    );

let y4=72;
//alert((doc as any).autoTable.previous.finalY)
if((doc as any).autoTable.previous.finalY<250){

    (doc as any).setFontSize(9);
    (doc as any).text(
      128,
      y4+=210,
      'Authorized Signature', { bold: true, font: 'Arial' }
    );

    doc.addImage(sign, 'JPEG',153, y4-=20, 60, 30);

    (doc as any).text(
      163,
     y4+=22,
      '--------------------------------------', { bold: true, font: 'Arial' }
    );


    (doc as any).text(
      150,
      y4+=6,
      'Date', { bold: true, font: 'Arial' }
    );

   //alert(JSON.stringify(appsDate));

    
      (doc as any).text(
        176,
         y4+=2,
         this.finalAppDate || "", { bold: true, font: 'Arial' }
       );
    
    
     (doc as any).text(
       163,
        y4+=3,
        '--------------------------------------', { bold: true, font: 'Arial' }
      );

    

    (doc as any).setFontSize(8);

    let dataSet=doc.splitTextToSize(this.subGen || '',180);

    
    (doc as any).text(
      8,
      y4-45,
      'N.B: Please specify the following details in your Invoice if applicable. ', { bold: true, font: 'Arial' }
    )
    
    dataSet.forEach((data:any)=>{
      (doc as any).text(
        8,
        y4-40,
        data, { bold: true, font: 'Arial' }
      )
      y4+=4;
    })
  }
  
  if((doc as any).autoTable.previous.finalY>250){
    doc.addPage();
    let rectHeight = 45;
     
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName, 8, 12);
      doc.setFontSize(10);
      doc.setFont("Arial", "bold");
      doc.text(address, 10, 18);
      doc.text(city, 10, 26);
      doc.text(state, 10, 30);
      doc.text(zipcode, 10, 34);
      doc.text(country, 10, 38);

      doc.text(website, 10, 46);
      doc.text(invMail, 10, 50);
    


    
    (doc as any).setFontSize(8);

    let dataSet=doc.splitTextToSize(this.subGen || '',180);

    (doc as any).text(
      8,
      y4+=2,
      'N.B: Please specify the following details in your Invoice if applicable. ', { bold: true, font: 'Arial' }
    )
    
    dataSet.forEach((data:any)=>{
      (doc as any).text(
        8,
        y4+=4,
        data, { bold: true, font: 'Arial' }
      )
      y4+4;
    });


    (doc as any).setFontSize(9);
    (doc as any).text(
      128,
      y4+=8,
      'Authorized Signature', { bold: true, font: 'Arial' }
    );

    doc.addImage(sign, 'JPEG',153, y4-18, 60, 30);

    (doc as any).text(
      163,
     y4+=4,
      '--------------------------------------', { bold: true, font: 'Arial' }
    );


    (doc as any).text(
      150,
      y4+=4,
      'Date', { bold: true, font: 'Arial' }
    );
  
      (doc as any).text(
        176,
         y4+=2,
         this.finalAppDate || "", { bold: true, font: 'Arial' }
       );
   
    (doc as any).text(
      163,
       y4+=4,
       '--------------------------------------', { bold: true, font: 'Arial' }
     );

  }
    //alert(y);
    
    this.addWaterMark(doc); 
    //footer();

   
    //debugger
    let blob = doc.output('datauristring');
     
    //this.base64=doc.output('datauristring');

    this.base64 = blob.replace('data:application/pdf;filename=generated.pdf;base64,','');
    
    console.log('base64 data: '+ this.base64);

    //let conv_files = blob.replace('data:application/pdf;filename=generated.pdf;base64,','');
   // this.sendFile(blob);
    

    //alert(type)

    if(type=='p_button'){
      doc.save('report.pdf');
    }
    
   

  }
  
  sendFile(conv_file:any)
  {
    //console.log(conv_file);
    let conv_files = conv_file.replace('data:application/pdf;filename=generated.pdf;base64,','');
    
    this.httpService.uploadFile_("/masters-ws/supplier/convert-file-to-pdf", conv_files,'',this.RetloginDetails.token)
    .subscribe(res => 
      {
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
      {  

       //alert('string:- '+res); 
       if (res.error){
        
         this.toastService.addSingle(
           'error',
           'Error',
           res.error.errorMessage
         );
         }
         else{
          
           this.toastService.addSingle(
             'success',
             'Success',
             'File uploaded Successfully!'
           );
           window.location.reload();
         }
        }
      });
    //}   
    
  }
    

// exportExcel() {
//     // import('xlsx').then((xlsx) => {
//     //     const worksheet = xlsx.utils.json_to_sheet();
//     //     const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
//     //     const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
//     //     this.saveAsExcelFile(excelBuffer, 'po_report');
//     // });
// }

// saveAsExcelFile(buffer: any, fileName: string): void {
//     let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
//     let EXCEL_EXTENSION = '.xlsx';
//     const data: Blob = new Blob([buffer], {
//         type: EXCEL_TYPE
//     });
//      

//      **doc.output('datauristring');

//     FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
// }

 
}
 

