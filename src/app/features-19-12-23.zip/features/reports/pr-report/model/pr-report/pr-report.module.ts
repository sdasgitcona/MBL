import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class PrReportModule { 
    id?: number;
    prDate?: any;
    prType?:string;
    prNumber?: string;
    department?: string;
    prStatus?: string;
    subsidiaryId?: number;
    type?: string;
    locationId?: number;
    projectName?: string;
    currency?: string;
    requestor?: any;
    exchangeRate?: number;
    netSuiteId?: number;
    rejectedComments?: string;
    approvedBy?: string;
    approvedByName?: string;
    nextApprover?: any;
    nextApproverRole?: string;
    nextApproverLevel?: string;
    approverPreferenceId?: number;
    approvalDate: any;
    approverSequenceId?: number;
    approverMaxLevel?: string;
    prItems: PrItem[] = [];
    subsidiaryName?: string;
    locationName?: string;
    totalValue?: string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted?: boolean;
    rfqEnabled?: boolean;
    priority?: string;
    memo?: string;
     // for approval
     approvalRoutingActive?:any;
     selected:boolean;
     NewrejectComments?: any;
     isAdminRole:boolean;
     estimatedAmount:any;
     convertedSignature:any;

}

export class PrItem {
    id?:any;
    itemId?: number;
    itemName?: string;
    itemDescription?: any;
    itemUom?: any;
    itemUomName?: string;
    quantity?: number;
    rate?: number;
    estimatedAmount?: any;
    receivedDate?: any;
    memo?: string;
    deleted?: boolean;
    integratedId?: number | null = null;
    poId?: number | null = null;
    isRowDeleted:boolean;
    disabledItem?:boolean=false;
    prNumber?:any;
}

export class PrBaseSearch {
    filters: PurchasesRequisitionFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
}

export class PurchasesRequisitionFilter {
    subsidiaryId?: number;
    prDate?: any;
    department?: string;
    prStatus?:string;
    requester?: string;
    subsidiaryName?: string;
}
export class RequesterList {
    id?: number;
    fullName?: any;
}