import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Injectable } from '@angular/core';
//import { jsPDF } from 'jspdf';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import jsPDFWithPlugin from 'jspdf';
import html2canvas from 'html2canvas';
import autoTable from 'jspdf-autotable';
import { Header } from 'primeng/api';
import { TableBody } from 'primeng/table';
import 'jspdf-autotable';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { PrItem, PrReportModule } from './model/pr-report/pr-report.module';
import { ActivatedRoute, Route } from '@angular/router';


@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-pr-report',
  templateUrl: './pr-report.component.html',
  styleUrls: ['./pr-report.component.scss']
})
export class PrReportComponent implements OnInit {

  prList: PrReportModule = new PrReportModule();
  List: any[] = [];
  prData: any = [];
  PrItem: PrItem[] = [];
  exportColumns: any[];
  prReportData: any[];
  SubsidiaryId: any;
  prNumber: any;
  RetloginDetails: any;
  selectedSubsidiaryId: any;
  title = 'angular-app';
  fileName = 'ExcelSheet.xlsx';
  columns: any[] = [];
  selectedPr: PrReportModule = new PrReportModule();
  totalRecords: number = 0;
  loading: boolean = false;
  //totalPages :number = 0;

  estimatedAmount: any;

  base64:any;                               //pr pdf changes 140823
  type:any;

  cols: any[];

  convertedSignature:any;
  finalAppDate:any;

  @ViewChild('header') content!: ElementRef;
  @ViewChild('header') header!: ElementRef;
  @ViewChild('footer') footer!: ElementRef;


  constructor(private httpService: CommonHttpService, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {

    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.columns = [
      { field: 'Sl No', header: '#' },
      { field: 'itemName', header: 'Item' },
      { field: 'itemDescription', header: 'Description' },
      { field: 'itemUom', header: 'UOM' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'rate', header: 'Estimated Rate' },
      { field: 'estimatedAmount', header: 'Estimated Amount' },
      { field: 'receivedDate', header: 'Received By Date' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    //this.getAPIData();


  }

  exportPdf(prNumber: any, type:any) {                  //pr pdf changes 140823

    this.type=type;
    
    this.prNumber = prNumber;
    this.prData = [];;
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.columns = [
      { field: 'Sl No', header: '#' },
      { field: 'itemName', header: 'Item' },
      { field: 'itemDescription', header: 'Description' },
      { field: 'itemUom', header: 'UOM' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'rate', header: 'Estimated Rate' },
      { field: 'estimatedAmount', header: 'Estimated Amount' },
      { field: 'receivedDate', header: 'Received By Date' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    this.getAPIData(this.type);
    //this.ngOnInit();
    // alert(this.prList.subsidiaryName)
    //
  }

  getAPIData(type:any) {

    // alert('api'+this.prNumber)

    //alert(this.RetloginDetails.token)   


    this.httpService
      .GetAll(`/procure-ws/pr/get-pr-report-data?prNumber=` + this.prNumber, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          alert("Unauthorized Access !");
        }
        else if (res.status == 404) {
          alert("Wrong/Invalid Token!");
        }
        else {

          if (res && res.prItems?.length > 0) {
            this.prList = res;
            this.estimatedAmount = res.estimatedAmount.toFixed(2);

            this.PrItem = res.prItems;

            this.totalRecords = res.totalRecords;
            // this.prData = {this.PrItem.itemName,this.PrItem.itemName}


            for (let i = 0; i < this.PrItem.length; i++) {
              const receivedDate = new Date(this.PrItem[i].receivedDate);
              this.prData.push([i + 1, this.PrItem[i].itemName, this.PrItem[i].itemDescription, this.PrItem[i].itemUom,
              this.PrItem[i].quantity?.toFixed(2), this.PrItem[i].rate?.toFixed(2), this.PrItem[i].estimatedAmount?.toFixed(2), receivedDate.toLocaleDateString('en-GB')]);

            }
            this.exportPdfAPI(type);

          } else {
            // this.prList = [];
            this.totalRecords = 0;

          }
          this.loading = false;
          //this.PrItem= res.prItems;
          // console.log(this.prList);


        }
      });

  }


  public addWaterMark(doc:any) {
    let totalPages:any = doc.internal.getNumberOfPages();
    let status: any = this.prList?.prStatus;
    //alert (totalPages);
  
    for (let i = 1; i <= totalPages; i++) {

      doc.setPage(i);
      //doc.addImage(imgData, 'PNG', 40, 40, 75, 75);
      doc.setTextColor(150);
      doc.setFontSize(300);
    
      //for text transparency
      doc.saveGraphicsState();
      doc.setGState(new doc.GState({opacity: 0.2}));

      
      //if(status=='Draft' || status=='draft'){
     if(status=='Open' || status=='open' || status=='Rejected' || status=='rejected'|| status=='Partially Approved' || status=='partially approved'|| status=='Pending Approval'|| status=='pending approval'){
     
      
      doc.text(60, doc.internal.pageSize.height - 35, 'Draft',{angle: 50,});
      }
      else{
       
        doc.text(8, doc.internal.pageSize.height - 135,'',{angle: 45,});
        
      }
      doc.restoreGraphicsState(); 
    }
    return doc;
    
  }




  public exportPdfAPI(type:any) {

    // create a new jsPDF instance
    const doc = new jsPDF('p', 'mm', 'a4');

    let sign:any=this.prList?.convertedSignature||'';

    // generate table content
    let subsidiaryName = this.prList.subsidiaryName || '';
    let x = 45; // X coordinate
    let y = 54; // Y coordinate
    let y2 = 54;
    // define the header and footer
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName || '', 8, 12);
      doc.text('Purchase Requisition', 75, 24);
    };
    let prNumber: any = doc.splitTextToSize(this.prList?.prNumber || '', 100);
    let prType: any = doc.splitTextToSize(this.prList?.type || '', 100);
    let prLoction: any = doc.splitTextToSize(this.prList?.locationName || '', 100);
    let department: any = doc.splitTextToSize(this.prList?.department || '', 100);
    let projectName: any = doc.splitTextToSize(this.prList?.projectName || '', 70);
    let memo: any = doc.splitTextToSize(this.prList?.memo || '', 120);
    let currency: any = doc.splitTextToSize(this.prList?.currency || '', 110);
    let requester: any = doc.splitTextToSize(this.prList?.requestor || '', 110);
    let prStatus: any = doc.splitTextToSize(this.prList?.prStatus || '', 110);
    const timestamp = this.prList?.prDate || '';
    const date = new Date(timestamp);
    const prDate = doc.splitTextToSize(date.toLocaleDateString('en-GB'), 40);


    const appDate:any=this.prList?.approvalDate||'';
    const date2 = new Date(appDate);
    const appsDate = date2.toLocaleDateString('en-GB');

    

     if(appsDate=='Invalid Date'){
      this.finalAppDate='';
     }
     else{
      this.finalAppDate=appsDate;
     }





    let LeftLengthCount = prNumber.length + prType.length + prLoction.length + department.length
      + projectName.length;

    let rightLengthCount = currency.length + requester.length + prStatus.length;

    let startY = 70;

    if (LeftLengthCount > rightLengthCount) {

      startY += LeftLengthCount * 4;
    } else {

      startY += rightLengthCount * 4;
    }

    const headerAfer = function () {
      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);

      doc.text('PR Number :', 8, 36);
      doc.text(prNumber || "", 34, 36);
      doc.text('Purchase Requisition Date :', 120, 36);
      doc.text(prDate || "", 172, 36);



      doc.setFontSize(10);
      doc.setFillColor(234, 242, 248); // set fill color to yellow
      doc.rect(8, 48, 84, 8 + (LeftLengthCount * 4), 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFont("Arial", "bold");
      doc.text('PR Type', 10, y);
      doc.setFont("Arial", "normal");
      doc.text(":", 32, y);
      prType.forEach((prType: any) => {
        doc.text(prType || "", 34, y);
        y += 4;
      });

      doc.setFont("Arial", "bold");
      doc.text('Project Name', 10, y += 2);

      doc.setFont("Arial", "normal");
      doc.text(':', 32, y);
      projectName.forEach((projectName: any) => {
        doc.text(projectName || "", 34, y);
        y += 4; // Move down to the next line (adjust as needed)
      });

      doc.setFont("Arial", "bold");
      doc.text('Location', 10, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', 32, y);
      prLoction.forEach((prLoction: any) => {
        doc.text(prLoction || "", 34, y);
        y += 4; // Move down to the next line (adjust as needed)
      })

      doc.setFont("Arial", "bold");
      doc.text('Department', 10, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(':', 32, y);
      department.forEach((department: any) => {
        doc.text(department || "", 34, y);
        y += 4;
      })




      doc.setFillColor(234, 242, 248); // set fill color to yellow
      doc.rect(118, 48, 84, 16 + rightLengthCount * 4, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color

      doc.setFont("Arial", "bold");
      doc.text('Currency', 120, y2);
      doc.setFont("Arial", "normal");
      doc.text(": ", 136, y2);
      currency.forEach((currency: any) => {
        doc.text(currency || "", 138, y2);
        y2 += 4;
      })
      doc.setFont("Arial", "bold");
      doc.text('Requestor', 120, y2 += 2);
      doc.setFont("Arial", "normal");
      doc.text(": ", 136, y2);
      requester.forEach((requester: any) => {
        doc.text(requester || "", 138, y2);
        y2 += 4;
      })

      doc.setFont("Arial", "bold");
      doc.text('Status', 120, y2 += 2);
      doc.setFont("Arial", "normal");
      doc.text(": ", 136, y2);

      prStatus.forEach((prStatus: any) => {
        doc.text(prStatus || "", 138, y2);
        y2 += 4;
      })



      //doc.setFontSize(10);
      doc.setTextColor(0);
      margin: { top: 30 }

    };



    const footer = function () {
      doc.setFontSize(12);
      doc.setTextColor(0);

      let i = 250;
      doc.text('Note:', 14, i);

      memo.forEach((memo: any) => {
        doc.text(memo || '', 25, i)
        i = i + 4;
      })
      // doc.text('____________________', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 40);
      // doc.text('  Authorized Signature', doc.internal.pageSize.width - 52, doc.internal.pageSize.height - 32);

    };



    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: this.prData,
      //foot: [['', '', '', '', '', 'Estimated Total:', this.estimatedAmount]],
      margin: { left: 8, bottom: 70, top: startY, right: 8 },
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [255, 255, 255],
        textColor: [44, 62, 80]
      },

      headStyles: {
        fillColor: [234, 242, 248], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles: {
        4: { halign: 'right' },
        5: { halign: 'right' },
        6: { halign: 'right' },

        7: { columnWidth: 22 }

      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;


        }




      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();
        headerAfer();

        doc.setPage(data.pageNumber);
        //(doc as any).setY(doc.internal.pageSize.height - 50);
        // set the startY option for the autoTable on this page
        y = 54;
        y2 = 54;
        startY = (doc as any).autoTable.previous.finalY + 10;
        //(doc as any).setY(startY)
      },

    });
    footer();
    let i = (doc as any).autoTable.previous.finalY + 16;
    let estimatedTotalText: any = this.estimatedAmount || '';
    let docXval:any = ( this.prList.currency + ' ' + estimatedTotalText).length*2;
    let estCost:any=120;
    
    if(docXval>34){
      estCost-=(docXval-36);
    }
    else{
      estCost=122;
        }
 
    doc.setFillColor(234, 242, 248);
    (doc as any).rect( 120, (doc as any).autoTable.previous.finalY + 10,82, 10, 'F');
    (doc as any).rect( estCost, (doc as any).autoTable.previous.finalY + 10,82, 10, 'F');
    (doc as any).setFontSize(12);
    doc.setTextColor( 44, 62, 80);

    (doc as any).text(
      estCost+2,
      (doc as any).autoTable.previous.finalY + 16,
      'Estimated Cost :',
      { bold: true, font: 'Arial' }
    );

    (doc as any).text(
      190-docXval,
      (doc as any).autoTable.previous.finalY + 16,
      this.prList.currency + ' ' + estimatedTotalText,
      { font: 'Arial' }
    );

    let y4=240;
    (doc as any).setFontSize(9);
    (doc as any).text(
      128,
      y4+=8,
      'Authorized Signature', { bold: true, font: 'Arial' }
    );

    doc.addImage(sign, 'JPEG',160, y4-18, 40, 20);

    (doc as any).text(
      163,
     y4+=4,
      '--------------------------------------', { bold: true, font: 'Arial' }
    );


    (doc as any).text(
      150,
      y4+=4,
      'Date', { bold: true, font: 'Arial' }
    );
  
      (doc as any).text(
        176,
         y4+=2,
         this.finalAppDate || "", { bold: true, font: 'Arial' }
       );
   
    (doc as any).text(
      163,
       y4+=4,
       '--------------------------------------', { bold: true, font: 'Arial' }
     );

    this.addWaterMark(doc); 
    // doc.setFontSize(12);
    // doc.setTextColor(0);
    // (doc as any).text( 14, (doc as any).autoTable.previous.finalY +26,'Note:');

    // doc.text('____________________', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 40);
    // doc.text('  Authorized Signature', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 30);


      //base64 data 140823

       //debugger
    let blob = doc.output('datauristring');
    
    //this.base64=doc.output('datauristring');
    this.base64 = blob.replace('data:application/pdf;filename=generated.pdf;base64,','');
    
    //console.log('base64 data: '+ this.base64);


    // save the pdf file

    if(type=='PR_BUTTON'){
      doc.save('report.pdf');
    }
    
  }


  //   exportPdf() {
  //     /*import('jspdf').then((jsPDF) => {

  //         import('jspdf-autotable').then((x) => {
  //             const doc = new jsPDF.default('p', 'px', 'a4');

  //            // (doc as any).autoTable(this.exportColumns, this.products);

  //             doc.save('po_report.pdf');
  //         });
  //     });*/
  //     const doc = new jsPDF({
  //       orientation: 'portrait',
  //       unit: 'mm',
  //       format: 'a4',
  //     });

  //   const header = this.header.nativeElement;

  //   const footer = this.footer.nativeElement;

  //   const headerWidth = header.offsetWidth;
  //   const headerHeight = header.offsetHeight;
  //   const pageHeight = doc.internal.pageSize.height - 10; // 10mm margin
  //   const totalPages = Math.ceil(headerHeight / pageHeight);

  //   html2canvas(header).then(headerCanvas => {
  //     html2canvas(footer).then(footerCanvas => {
  //       const headerImgData = headerCanvas.toDataURL('image/png');
  //       const footerImgData = footerCanvas.toDataURL('image/png');
  //       const headerImgHeight = headerCanvas.height * 210 / headerCanvas.width;
  //       const footerImgHeight = footerCanvas.height * 210 / footerCanvas.width;

  //       for (let i = 0; i < totalPages; i++) {
  //         if (i > 0) {
  //           doc.addPage();
  //         }
  //         doc.setPage(i + 1);

  //         if (i === 0) {
  //           const headerImgData = headerCanvas.toDataURL('image/png');
  //           //const headerImgHeight:any = headerImgHeight;
  //           doc.addImage(headerImgData, 'PNG', 5, 5, 200, headerImgHeight);
  //         } else {
  //           doc.addImage(headerImgData, 'PNG', 5, 5, 200, headerImgHeight);
  //         }

  //         //Add autotable to header section
  //         if (i == 0) {

  //           const startY = headerImgHeight + 10; // 10mm margin
  //           (doc as any).autoTable({
  //             head: [this.exportColumns],
  //             body: this.prData,
  //             startY: startY,
  //             style:{
  //               width:'100%'

  //             }
  //           });
  //         }

  //         doc.addImage(footerImgData, 'PNG', 5, doc.internal.pageSize.height - footerImgHeight - 10, 200, footerImgHeight);
  //       }

  //       doc.save('document.pdf');
  //     });
  //   });
  // }




  ngAfterViewInit() { }



  exportexcel() {
    /* pass here the table id */
    let element = document.getElementById('content');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    /* save to file */
    XLSX.writeFile(wb, this.fileName);

  }
}
