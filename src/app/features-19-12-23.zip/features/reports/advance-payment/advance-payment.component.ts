import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { jsPDF } from 'jspdf';
import * as XLSX from 'xlsx';
import html2canvas from 'html2canvas';
import 'jspdf-autotable';
import { Injectable } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ActivatedRoute, Route } from '@angular/router';
import { advancedPayemnt,location,subsidiary,purchaseOrder,supplier,supplierAddresses} from './model/advance_payment'

@Injectable({
  providedIn: 'root'
})


@Component({
  selector: 'app-advance-payment',
  templateUrl: './advance-payment.component.html',
  styleUrls: ['./advance-payment.component.scss']
})
export class AdvancePaymentComponent implements OnInit {

  advPmtList: advancedPayemnt=new advancedPayemnt();
  advPmtData: any = [];
  advPmtItem: any= [];

  advPmtSubsidiary: subsidiary=new subsidiary();

  advPmtLocation: location = new location();

  advPmtSupplier: supplier = new supplier();
  //advPmtSupAdd:supplierAddresses[]=[];
  advPmtSupAdd:any=[];

  advnPmtPo: purchaseOrder = new purchaseOrder();



  address: any= [];
  exportColumns: any[];
  ReExportColumns: any[];
  advPmtReportData: any[];
  SubsidiaryId: any;

  advPmtNo: any;

  RetloginDetails: any;
  selectedSubsidiaryId: any;
  title = 'angular-app';
  fileName = 'ExcelSheet.xlsx';
  columns: any[] = [];
  ReColumns: any[] = [];
  //selectedPr: PrReportModule = new PrReportModule();
  totalRecords: number = 0;
  loading: boolean = false;
  //totalPages :number = 0;
  remarks:any;
  amountInWords:any;
  estimatedAmount: any;


  constructor(private httpService: CommonHttpService, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {

    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.columns = [
      
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    //this.getAPIData();


  }

  exportPdf(advPmtNo: any) {
    
    this.advPmtNo = advPmtNo;
    this.advPmtData = [];;
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);


    this.columns = [
    
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

   

    this.getAPIData();

  }

  public getAPIData() {
    //alert(this.advPmtNo)
    this.httpService
      .GetAll(`/finance-ws/advance/get-advance-payment-report?prePaymentNo=`+ this.advPmtNo
        , this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          alert("Unauthorized Access !");
        }
        else if (res.status == 404) {
          alert("Wrong/Invalid Token!");
        }
        else {

          if (res !='') {
            //alert(res);
            this.advPmtList = res;

            this.advPmtSubsidiary = res.subsidiary;

            this.advPmtSupplier = res.supplier;


            if (res.supplier && Array.isArray(res.supplier.supplierAddresses)) {
             
              this.advPmtSupAdd = res.supplier.supplierAddresses;
              this.advPmtSupAdd.forEach((address: any) => {
                this.advPmtSupAdd = address;
              });
            } else {
              console.log("Error: invalid response");
            }
            //this.advPmtSupAdd = res.supplier.supplierAddress;

            this.advPmtLocation=res.location

            this.advnPmtPo = res.purchaseOrder




            this.totalRecords = res.totalRecords;




            this.exportPdfAPI();



          } else {
            this.totalRecords = 0;

          }
          this.loading = false;

        }
      });

  }

  //Amount in Words
  public convertAmountToWords() {
    // Single-digit and teen numbers
    const singleDigits = [
      'Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
      'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
      'Seventeen', 'Eighteen', 'Nineteen'
    ];

    // Tens multiples
    const tensMultiples = [
      '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
    ];

    // Scale names
    const scales = ['', 'Thousand', 'Million', 'Billion', 'Trillion', 'Quadrillion'];

    // Function to convert three-digit number to words
    const convertThreeDigitNumber = (num: number) => {
      let words = '';
      if (num >= 100) {
        words += singleDigits[Math.floor(num / 100)] + ' Hundred ';
        num %= 100;
      }
      if (num >= 20) {
        words += tensMultiples[Math.floor(num / 10)] + ' ';
        num %= 10;
      }
      if (num > 0) {
        words += singleDigits[num] + ' ';
      }
      return words.trim();
    };

    // Assign amount value here
    let amount = this.advPmtList?.advanceAmount?? "";
   
    // Handling special cases
    if (amount === 0) {
      this.amountInWords = 'Zero';
    } else if (amount < 0) {
      this.amountInWords = 'minus ' + this.convertAmountToWords();
      //this.amountInWords = 'minus ' + this.convertAmountToWords(Math.abs(amount));
    } else {
      const integerPart = Math.floor(amount);
      const decimalPart = Math.round((amount - integerPart) * 100);

      let words = '';
      let scaleIndex = 0;

      // Convert integer part to words in groups of three digits
      let remainingAmount = integerPart;
      while (remainingAmount > 0) {
        const threeDigits = remainingAmount % 1000;
        if (threeDigits !== 0) {
          const scale = scales[scaleIndex];
          const threeDigitWords = convertThreeDigitNumber(threeDigits);
          if (scaleIndex === 1 && threeDigitWords !== '') {
            words = threeDigitWords + ' ' + scale + ' ' + words;
          } else {
            words = threeDigitWords + ' ' + words;
          }
        }
        remainingAmount = Math.floor(remainingAmount / 1000);
        scaleIndex++;
      }

      let decimalWords = '';
      if (decimalPart > 0) {
        decimalWords = 'and ' + convertThreeDigitNumber(decimalPart) + ' Only';
      }
      else{
        decimalWords = 'Only';
      }

      this.amountInWords =  words.trim() + ' ' + decimalWords;
    }

    //console.log(this.amountInWords);
  }

  //watermark

  public addWaterMark(doc:any) {
  var totalPages = doc.internal.getNumberOfPages();

  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    //doc.addImage(imgData, 'PNG', 40, 40, 75, 75);
    doc.setTextColor(150);

    doc.setFontSize(68);
    let status: any = this.advPmtList?.status;

    //for text transparency
    doc.saveGraphicsState();
    doc.setGState(new doc.GState({opacity: 0.2}));

    //if(status=='Draft' || status=='draft'){
      if(status!='Paid' || status!='paid'){
    doc.text(85, doc.internal.pageSize.height - 165, status,{angle: 45,});
    }
    else{
      doc.text(85, doc.internal.pageSize.height - 165,'',{angle: 45,});
    }
  }

  return doc;
}

  public exportPdfAPI() {

    this.convertAmountToWords();
    // create a new jsPDF instance
    const doc = new jsPDF('p', 'mm', 'a4');
    

    // generate Subsidiary content
    let subsidiaryName = this.advPmtSubsidiary?.legalName || '';

    if(subsidiaryName ==''){
      subsidiaryName = this.advPmtSubsidiary?.name || '';
    }
    else{
      subsidiaryName = this.advPmtSubsidiary?.legalName || '';
    }


    // define the header and footer
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName, 8, 12);
      doc.text('Advance Voucher', 75, 25);
    };

    //header data
    let advPmtNumber: any= this.advPmtList?.proformaInvoice || '';
    const timestamp = this.advPmtList?.prePaymentDate || '';
    const date = new Date(timestamp);
    const advPmtDate = date.toLocaleDateString('en-GB');

    //left div details
    let suppliername: any = doc.splitTextToSize(this.advPmtSupplier?.legalName || '', 75);
    if(suppliername==''){
      suppliername= doc.splitTextToSize(this.advPmtSupplier?.name || '', 75);
    }
    else{
      suppliername= doc.splitTextToSize(this.advPmtSupplier?.legalName || '', 75);
    }

     
     let supAddress: any =doc.splitTextToSize((this.advPmtSupAdd?.address1 ?? '') +
    (this.advPmtSupAdd?.address2 ? (this.advPmtSupAdd.address1 ? ', ' : '') + this.advPmtSupAdd.address2 : ''),
    72);
    let city: any = doc.splitTextToSize(this.advPmtSupAdd?.city || '', 46);
    let state: any = doc.splitTextToSize(this.advPmtSupAdd?.state || '', 46);
    let zipcode: any = this.advPmtSupAdd?.pin || '';
    let country: any = doc.splitTextToSize(this.advPmtSupAdd?.country || '', 46);

    let location: any = doc.splitTextToSize(this.advPmtLocation?.locationName || '', 46);
    let department: any = this.advPmtList?.departmentName ;


    //right div details
    let voucherNo: any = this.advPmtList?.prePaymentNumber;
    let poNumber: any=this.advnPmtPo?.poNumber;
    let funcCurrency: any=this.advPmtList?.subsidiaryCurrency;
    let transCurrency: any=this.advPmtList?.currency;
    let exchRate: any =this.advPmtList?.exchangeRate;
    let status: any = this.advPmtList?.status;
    let pmtTerm:any = this.advnPmtPo?.paymentTerm;
    let creatorDtls:any = doc.splitTextToSize(this.advPmtList?.creator|| '', 56);
    let project:any = this.advPmtList?.projectName;

   this.remarks=doc.splitTextToSize(this.advPmtList?.memo || '',110);
    
    
    let advncAmount:any=this.advPmtList?.advanceAmount;

    //var numberToWords = require('number-to-words');

    //this.amountInWords();

    let advncAmtInWords:any=this.amountInWords||"";

    let x = 10; // X coordinate  
    let y = 54; // y coordinate
    let x1 = 120; // x cordinate of second rectangel
    let y2 = 54; // y cordinate of second rectangel
    let startY = 70;

    const headerAfer = function () {

      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);

      doc.text('PI Number ', x, 35);
      doc.text(": " + advPmtNumber || "", 45, 35);

      doc.text('Voucher Number ', x, 42);
      doc.text(": " + voucherNo || "", 45, 42);

      doc.text('PI Date ', 118, 35);
      doc.text(": " + advPmtDate || "", 149, 35);

      doc.text('Voucher Status ', 118, 42);
      doc.text(": " + status || "", 149, 42);

     doc.setFillColor(156, 178, 221); // set fill color to blue
     doc.rect(8, 48, 91, 75, 'F'); // draw a rectangle as background


      doc.setFontSize(10);
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Supplier Name  ', x, y);
      doc.setFont("Arial", "normal");
      doc.text(': '|| "",50, y);
      suppliername.forEach((suppliername: any) => {
        doc.text(suppliername  || "", 52, y);
        y += 4; // Move down to the next line (adjust as needed)
    });


      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Supplier Address ', x, y += 3);
      doc.setFont("Arial", "normal");
      doc.text(': '|| "", 50, y);
      supAddress.forEach((supAddress: any) => {
        doc.text(supAddress || "", 52, y);
        y += 4; // Move down to the next line (adjust as needed)
      });

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('City', x, y += 3);
      doc.setFont("Arial", "normal");
      doc.text(': ' + city|| "", 50, y);

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('State', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ' + state|| "", 50, y);


      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Pin', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ' + zipcode|| "", 50, y);

      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Country', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ' + country|| "", 50, y);
      
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Location', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ' + location|| "", 50, y);

      
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);
      doc.text('Department ', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ' + department || "", 50, y);

      
      //end of supplier details

     //start of payment details
     doc.setFillColor(156, 178, 221); // set fill color to blue
     doc.rect(115, 48, 91, 50, 'F'); // draw a rectangle as background

      doc.setFont("Arial", "bold");
      doc.text('PO Number ', x1, y2);
      doc.setFont("Arial", "normal");
      doc.text(': ' + poNumber|| "", x1 + 40, y2);

      doc.setFont("Arial", "bold");
      doc.text('Project ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(': '+ project|| "", x1 + 40, y2);

      doc.setFont("Arial", "bold");
      doc.text('Functional Currency      ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ' + funcCurrency|| "", x1 + 40, y2);

      doc.setFont("Arial", "bold");
      doc.text('Transaction Currency', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ' + transCurrency|| "", x1 + 40, y2);

      doc.setFont("Arial", "bold");
      doc.text('Exchange Rate      ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ' + exchRate.toFixed(2)|| "", x1 + 40, y2);

      doc.setFont("Arial", "bold");
      doc.text('Payment Term', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ' + pmtTerm|| "", x1 + 40, y2);

      doc.setFont("Arial", "bold");
      doc.text('Creator', x1, y2 += 6);

      doc.setFont("Arial", "normal");
      doc.text(': ' || "", x1 + 40, y2);
      creatorDtls.forEach((CreateBy: any) => {
         doc.text(CreateBy || "", x1 + 42, y2);
        y2 += 4;
        });

      //end of payment details
      doc.setTextColor(0);
      margin: { top: 30 }

    };




    let sMemo:any=doc.splitTextToSize(this.remarks ||'', 110);
    const footer = function () {
      
      y=doc.internal.pageSize.height - 36;
      doc.setFontSize(10);
      doc.setTextColor(0);
      doc.text('Remarks', 14, y);
      doc.text(': ', 36, y);

      sMemo.forEach((sMemo:any)=>{
        doc.text(sMemo || "", 39,y);
        y+= 4; // Move down to the next line (adjust as needed)
      });

      doc.text('____________________', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 40);
      doc.text('  Authorized Signature', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 30);

    };


    if (y > y2) {
      startY = startY + y;
    } else {
      startY = startY + y2;
    }



    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: this.advPmtData,
      //foot: [['', '', '', '', '', 'Estimated Total:', this.estimatedAmount]],
      margin: { left: 50, bottom: 70, top: startY, right: 6 },
      styles: {
        // lineWidth: 0.1,
        // lineColor: [37, 37, 37],
        // fillColor: [255, 255, 255],

      },


      headStyles: {
        fillColor: [53, 67, 110], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles: {
        4: { halign: 'right' },
        //5:{columnWidth:50}
      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;

        }



      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();
        headerAfer();
        footer();

        doc.setPage(data.pageNumber);
        

        //(doc as any).setY(doc.internal.pageSize.height - 50);
        // set the startY option for the autoTable on this page
        startY = (doc as any).autoTable.previous.finalY + 10;
        //(doc as any).setY(startY)
      },

    });
    //total amount paid
    doc.setFontSize(8);
    doc.setFillColor(53, 67, 110);
    (doc as any).rect(130, (doc as any).autoTable.previous.finalY + 10, 75, 10, 'F');
    (doc as any).setFontSize(10)
    doc.setTextColor(255, 255, 255);

    (doc as any).text(
      132,
      (doc as any).autoTable.previous.finalY + 16,
      'PI Amount  : ' +"                           "+this.advPmtList.currency+'  '+advncAmount?.toFixed(2) , { bold: true, font: 'Arial' }
    );

    //amount in words
    doc.setFillColor(53, 67, 110);
    (doc as any).rect(8, (doc as any).autoTable.previous.finalY + 10, 40, 10, 'F');
    (doc as any).setFontSize(10)
    doc.setTextColor(255, 255, 255);

    (doc as any).text(
      10,
      (doc as any).autoTable.previous.finalY + 16,
      'Amount In words: ', { bold: true, font: 'Arial' }
    );

    (doc as any).setDrawColor(53, 67, 110);
    //(doc as any).setLineWidth(1);
    doc.setFillColor(255, 255, 255);
    (doc as any).rect(48, (doc as any).autoTable.previous.finalY + 10, 70, 10);
    (doc as any).setFontSize(10)
    doc.setTextColor(0);

    (doc as any).text(
      50,
      (doc as any).autoTable.previous.finalY + 16,
     advncAmtInWords , { bold: true, font: 'Arial' }
    );

    //this.addWaterMark(doc);
    
    doc.save('report.pdf');
  }







  ngAfterViewInit() { }








  exportexcel() {
    /* pass here the table id */
    let element = document.getElementById('content');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    /* save to file */
    XLSX.writeFile(wb, this.fileName);

  }

}
