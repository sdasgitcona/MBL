
export class  advancedPayemnt {
    id: number;
    prePaymentNumber: string;
    subsidiaryId?: any;
    supplierId?: any;
    locationId?: any;
    prePaymentDate: any;
    currency: string;
    subsidiaryCurrency: string;
    proformaInvoice: string;
    exchangeRate: any;
    type: string;
    advanceAmount: any;
    paymentAmount: any;
    paymentMode: string;
    memo: string;
    status: string;
    netsuiteId?: any;
    rejectedComments?: any;
    approvedBy: string;
    nextApprover: string;
    nextApproverRole?: any;
    nextApproverLevel: string;
    approverPreferenceId?: any;
    approverSequenceId?: any;
    approverMaxLevel?: any;
    noteToApprover?: any;
    createdDate: Date;
    createdBy: string;
    creator: string;
    lastModifiedDate: Date;
    lastModifiedBy: string;
    subsidiaryName?: any;
    supplierName?: any;
    amountDue?: any;
    partPaymentAmount?: any;
    //advancePaymentApply?: any;
    deleted: boolean;
    approvalRoutingActive: boolean;
    unappliedAmount:any;
    advancePaymentApply :AdvancePaymentApply[]=[];
    supplier?:supplier;
    location?:location;
    subsidiary?:subsidiary;
    purchaseOrder?:purchaseOrder;
    department?:any;
    departmentName:any;
    projectName:any;
}
export class supplier{
    id: any;
    name: any;
    legalName: any;
    paymentTerm: any;
    supplierAddresses:supplierAddresses[]=[];
}
export class supplierAddresses{
    id: any;
    supplierId: any;
    addressCode: any;
    address1: any;
    address2: any;
    city: any;
    state: any;
    country: any;
    pin : any;
    taxRegistrationNumber: any;
    registrationType: any;        
}
export class location{
    id: any;
    locationName: any;
}
export class subsidiary{
    id: any;
    name: any;
    legalName: any;
}
export class purchaseOrder{
    id: any;
    poNumber: any;
    paymentTerm:any;
}
export class ApplyModel {
    invoiceId: number;
    supplierId: number;
    subsidiaryId: number;
    poId?: number;
    locationId?: number;
    invoiceNo?: any;
    invStatus: string;
    paymentTerm: string;
    integratedId?: any;
    currency: string;
    billTo: string;
    shipTo: string;
    invoiceCode: string;
    invoiceDate: Date;
    dueDate?: any;
    fxRate: number;
    amount: number;
    taxAmount: any;
    totalAmount: any;
    paymentAmount: number;
    amountDue: any;
    approvedBy: string;
    nextApprover?: any;
    nextApproverRole?: any;
    nextApproverLevel?: any;
    approverPreferenceId?: number;
    approverSequenceId?: number;
    approverMaxLevel: string;
    noteToApprover?: any;
    subsidiaryName?: any;
    supplierName?: any;
    invoiceItems?: any;
    totalPaidAmount: number;
    invoicePayments?: any;
    createdBy: string;
    lastModifiedBy: string;
    createdDate: Date;
    lastModifiedDate: Date;
    approvalRoutingActive: boolean;
    selected:boolean;
    applyDate:any;
    applyAmount:any;

}
export class AdvancePaymentApply{
    invoiceId?: number;
    prePaymentNumber?: string;
    applyDate?: Date;
    curency?: string;
    invoiceNumber?: string;
    invoiceAmount?: number;
    applyAmount?: number;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    amountDue?: number;
    deleted?: boolean;
}
export class filterGrid{
    subsidiaryId?:number;
    supplierId?:number;
    status?:string;
}

//--Amar Addition

export class makepayment {
    id: number;
    paymentNumber: number;
    subsidiaryId: number;
    accountId: number;
    supplierId: number;
    paymentDate: any;
    currency: string;
    subsidiaryCurrency: string;
    exchangeRate: string;
    paymentMode: string;
    amount: number;
    bankTransactionType: string;
    bankReferenceNumber: number;
    memo: string;
    netsuiteId: number;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    subsidiaryName: string;
    supplierName: string;
    bankAccountName: string;
    advancePaymentNumber: string;
    advancePaymentType: string;
    advancePaymentAmount: string;
    paymentAmount: string;
    advancePayment: string;
    makePaymentList:makePaymentList[]=[];
    deleted: boolean;
    markall: boolean;
}

export class makePaymentList
{
           paymentNumber?:string;
           paymentId?:number;
           billNo?:string;
           invoiceId?:number;
           invoiceAmount:number;
           paidAmount:number;
           amountDue:number;
           createdDate?: Date;
           createdBy?: string;
           lastModifiedDate?: Date;
           lastModifiedBy?: string;
           paymentAmount:number;
           deleted?:boolean;
           active?:boolean=false;
           paymentamtdisable?:boolean=true;

}

export class apApproval{
        id: number;
        prePaymentNumber: string;
        subsidiaryId: number;
        supplierId: number;
        locationId: null;
        prePaymentDate: Date;
        currency: string;
        subsidiaryCurrency: any;
        proformaInvoice: any;
        exchangeRate: null;
        type: null;
        advanceAmount: any;
        paymentAmount: any;
        dueAmount: any;
        unappliedAmount: any;
        paymentMode: any;
        memo: string;
        status: string;
        netsuiteId: string;
        rejectedComments: any;
        approvedBy: any;
        nextApprover: any;
        nextApproverRole: any;
        nextApproverLevel: any;
        approverPreferenceId: any;
        approverSequenceId: any;
        approverMaxLevel: any;
        noteToApprover: any;
        nsMessage: any;
        nsStatus: any;
        integratedId: any;
        department: any;
        createdDate: any;
        createdBy: any;
        lastModifiedDate: any;
        lastModifiedBy: any;
        subsidiaryName: string;
        supplierName: string;
        partPaymentAmount: any;
        advancePaymentApply: any;
        deleted: boolean;
        approvalRoutingActive: boolean;
        // for approval
       selected:boolean;
       NewrejectComments?: any;
       isAdminRole:boolean;

}

    