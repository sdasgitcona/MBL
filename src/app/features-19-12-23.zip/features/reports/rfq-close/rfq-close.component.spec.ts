import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RfqCloseComponent } from './rfq-close.component';

describe('RfqCloseComponent', () => {
  let component: RfqCloseComponent;
  let fixture: ComponentFixture<RfqCloseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RfqCloseComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RfqCloseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
