import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ActivatedRoute, Route } from '@angular/router';
import { Injectable } from '@angular/core';

import { RfqReportModule, quotationItems, subsidiary, subsidiaryAddress, suppliers, supAddr, supCont,quotationInfos,quotationVendors } from './model/rfq-close-model';

import * as FileSaver from 'file-saver';
import {jsPDF} from 'jspdf';
import * as XLSX from 'xlsx';
import jsPDFWithPlugin from 'jspdf';
import html2canvas from 'html2canvas';

//import 'jspdf-autotable';
import autoTable from 'jspdf-autotable';
import { Header } from 'primeng/api';
import { TableBody } from 'primeng/table';
import 'jspdf-autotable';
//import { supplier } from '../po-report/model/po-report-model';

@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-rfq-close',
  templateUrl: './rfq-close.component.html',
  styleUrls: ['./rfq-close.component.scss']
})
export class RfqCloseComponent implements OnInit {
 
  rfqList: RfqReportModule = new RfqReportModule();
  rfQData: any = [];
  rfqItem: quotationItems[] = [];

  quotationInfo:quotationInfos[] =[];
  quotationVendors:quotationVendors[]=[];

  rfqSubsidiary: subsidiary = new subsidiary();
  rfqSubsidiaryAddress: any = [];

  rfqSupplier:suppliers=new suppliers();
  rfqSupplierAddress:any = [];
  rfqSupplierContact:any = [];

  address: subsidiaryAddress[] = [];
  sadd:supAddr[]=[];
  contact:supCont[]=[];
  remarks:any=[];

  exportColumns: any[];
  prReportData: any[];
  SubsidiaryId: any;
  rfqNumber: any;
  supId:any;
  RetloginDetails: any;
  selectedSubsidiaryId: any;
  title = 'angular-app';
  fileName = 'ExcelSheet.xlsx';
  columns: any[] = [];
  //selectedPr: PrReportModule = new PrReportModule();
  totalRecords: number = 0;
  loading: boolean = false;
  //totalPages :number = 0;

  estimatedAmount: any;
  supplierMemo:any;




  constructor(private httpService: CommonHttpService, private activatedRoute: ActivatedRoute) { }

  ngOnInit(){
      
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    
       this.columns = [
      { field: 'Sl No', header: '#' },
      { field: 'itemName', header: 'Item' },
      { field: 'itemDescription', header: 'Description' },
      { field: 'itemUom', header: 'UOM' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'rate', header: 'Estimated Rate' },
      { field: 'estimatedAmount', header: 'Estimated Amount' },
      { field: 'receivedDate', header: 'Received By Date' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    //this.getApiall();
  }

  
  exportPdf(rfqNumber: any,supId: any) {

    this.rfqNumber = rfqNumber;   //'HPL/10004/RFQ';
    this.supId = supId;           //'154';

    this.rfQData = [];
    this.remarks=[];
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.columns = [
      { field: 'Sl No', header: '#' },
      { field: 'itemName', header: 'Item' },
      { field: 'itemDescription', header: 'Description' },
      { field: 'itemUom', header: 'UOM' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'receivedDate', header: 'Received By Date' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    this.getAPIData();

  }
   

public getAPIData() {

  this.httpService.
    GetAll(`/procure-ws/quotation/get-by-filter?rfqNumber=${this.rfqNumber}&supplierId=${this.supId}`,this.RetloginDetails.token)
    // .GetAll('/procure-ws/quotation/get-by-filter?rfqNumber='+ this.rfqNumber + '&supplierId=7', this.RetloginDetails.token)
    .subscribe((res) => {
      if (res.status == 401) {
        alert("Unauthorized Access !");
      }
      else if (res.status == 404) {
        alert("Wrong/Invalid Token!");
      }
      else {

        if (res ) {

          this.rfqList = res;
          // this.estimatedAmount = res.estimatedAmount.toFixed(2);
          this.rfqSubsidiary = res.subsidiary;
          this.rfqItem = res.quotationItems;
          this.rfqSupplier=res.supplier;
          
          this.quotationInfo=res?.quotationInfos;
          this.quotationVendors=res?.quotationVendors;

          for (let a = 0; a < this.quotationVendors.length; a++) {
          if(res.supplier?.id== res?.quotationVendors[a].vendorId){

            this.supplierMemo=this?.quotationVendors[a].memo;

            //alert(this.quotationVendors[a].memo);
            
          }
        }

         
          //alert(JSON.stringify(this.quotationInfo.remarks));
        
          
          for (let i = 0; i < this.quotationInfo.length; i++) {


            this.remarks.push([(i + 1) + '. ' + this.quotationInfo[i].remarks]);
         
          }

          
          

          // console.log("rfq main----"+JSON.stringify(this.rfqList));

          // console.log("Supplier----"+JSON.stringify(this.rfqSupplier));
//subsidiary addreess
          if (res.subsidiary && Array.isArray(res.subsidiary.subsidiaryAddresses)) {
            this.rfqSubsidiaryAddress = res.subsidiary?.subsidiaryAddresses;
            this.rfqSubsidiaryAddress.forEach((address: any) => {
              this.rfqSubsidiaryAddress = address;
            });
          } else {
            console.log("Error: invalid response");
          }
          // console.log("Subsidiary----"+JSON.stringify(this.rfqSubsidiaryAddress));

//supplier address
          
            if (res.supplier && Array.isArray(res.supplier.supplierAddresses)) {
              this.rfqSupplierAddress = res.supplier?.supplierAddresses;
              this.rfqSupplierAddress.forEach((saddr: any) => {
                this.rfqSupplierAddress = saddr;
              });
            } else {
              console.log("Error: invalid response");
              
            }
            // console.log("Sup addr----"+JSON.stringify(this.rfqSupplierAddress));

//supplier contacts
          if (res.supplier && Array.isArray(res.supplier.supplierContacts)) {
            this.rfqSupplierContact = res.supplier?.supplierContacts;
            this.rfqSupplierContact.forEach((scontact: any) => {
              this.rfqSupplierContact = scontact;
            });
          } else {
            console.log("Error: invalid response");
          }
          // console.log("Sup contact----"+JSON.stringify(this.rfqSupplierContact));

          this.totalRecords = res.totalRecords;

//tab data push
          this.rfQData=[];
          for (let i = 0; i < this.rfqItem.length; i++) {
            const receivedDate = new Date(this.rfqItem[i].receivedDate);
            this.rfQData.push([i + 1, 
              this.rfqItem[i].itemName, 
              this.rfqItem[i].itemDescription, 
              this.rfqItem[i].itemUom,
              this.rfqItem[i].quantity?.toFixed(2), 
              receivedDate.toLocaleDateString('en-GB')]);
          }
          this.exportPdfAPI();

        } else {
          // this.rfqList = [];
          this.totalRecords = 0;

        }
        this.loading = false;
       


      }
    });

}
exportPdfAPI(){

  const doc = new jsPDF('p', 'mm', 'a4');


    // generate table content

    let subsidiaryName = this.rfqSubsidiary?.legalName || '';

    if(subsidiaryName==''){
      subsidiaryName = this.rfqSubsidiary?.legalName || '';
    }

    // define the header and footer
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName, 8, 12);
      doc.text('Request For Quotation', 75, 24);
    };

    //left header
    let rfqNumber: any = this.rfqList?.rfqNumber || '';

    const timestamp = this.rfqList?.rfqDate || '';
    const date = new Date(timestamp);
    const rfqDate = date.toLocaleDateString('en-GB');

    let rfqStat:any = this.rfqList?.status || '';

    //right header
    let openDate: any = new Date(this.rfqList?.bidOpenDate || '')
    let bidOpenDate: any = openDate.toLocaleDateString('en-GB');

    let closeDate: any = new Date(this.rfqList?.bidCloseDate || '');
    let bidCloseDate: any = closeDate.toLocaleDateString('en-GB');

    let bidStat:any = this.rfqList?.bidType || '';
    


    //subsidiary
    let address: any = doc.splitTextToSize((this.rfqSubsidiaryAddress?.address1 ?? '') +
    (this.rfqSubsidiaryAddress?.address2 ? (this.rfqSubsidiaryAddress.address1 ? ', ' : '') + this.rfqSubsidiaryAddress.address2 : ''),
    72);
   
    let city: any = this.rfqSubsidiaryAddress?.city || '';
    let state: any = this.rfqSubsidiaryAddress?.state || '';
    let zipcode: any = this.rfqSubsidiaryAddress?.zipcode || '';
    let country: any = this.rfqSubsidiaryAddress?.country;
    let email: any = this.rfqSubsidiary?.email || '';
    let website: any = this.rfqSubsidiary?.website || '';
    let VatReg: any = this.rfqSubsidiary?.tan || '';
    let registrationCode: any = this.rfqSubsidiaryAddress?.registrationCode || '';
    let memoNotes: any = doc.splitTextToSize(this.rfqList?.memoNotes || '', 110);
    let projectNamelabel: any = doc.splitTextToSize(subsidiaryName, 75);

    let projectName:any=this.rfqList?.projectName;
    let departmentName:any=this.rfqList?.departmentName;

    //Supplier 
    let sName:any=doc.splitTextToSize(this.rfqSupplier?.legalName|| '',75);

    if(sName==''){
      sName=doc.splitTextToSize(this.rfqSupplier?.name|| '',75);
    }
    else{
      sName=doc.splitTextToSize(this.rfqSupplier?.legalName|| '',75);
    }

    let saddress:any=doc.splitTextToSize((this.rfqSupplierAddress?.address1?? '')+(this.rfqSupplierAddress?.address2 ? (this.rfqSupplierAddress.address1 ? ', ' : '')+ this.rfqSupplierAddress?.address2 :''),75);
    
    let sCountry:any=this.rfqSupplierAddress?.country|| '';
    let sCity:any=this.rfqSupplierAddress?.city|| '';
    let sState:any=this.rfqSupplierAddress?.state|| '';
    let sPin:any=this.rfqSupplierAddress?.pin|| '';
    let sRegType:any=this.rfqSupplierAddress?.registrationType|| '';
    let sRegCode:any=this.rfqSupplierAddress?.taxRegistrationNumber|| '';
    let sContactPerson:any=this.rfqSupplierContact?.name|| '';
    let sContactPerPhone:any=this.rfqSupplierContact?.contactNumber|| '';
    let sContactEmail:any=this.rfqSupplierContact?.email|| '';


    let leftLengthCount=address.length+projectNamelabel.length;
    let rightLengthCount=saddress.length+sName.length;

    let x = 8; // X coordinate
    let y = 70;
    const headerAfer = function () {

      // Y coordinate
     
      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);

      doc.text('RFQ Number :', x, 36);
      doc.text(rfqNumber || "", 42, 36);

      doc.text('RFQ Date :', x, 43);
      doc.text(rfqDate || "", 42, 43);

      doc.text('RFQ Status :', x, 50);
      doc.text(rfqStat || "", 42, 50);

      doc.text('Bid Open Date :', 118, 36);
      doc.text(bidOpenDate || "", 150, 36);

      doc.text('Bid Close Date :', 118, 43);
      doc.text(bidCloseDate || "", 150, 43);

      doc.text('Bid Status:', 118, 50);
      doc.text(bidStat || "", 150, 50);


      //subsidiary div
      let rectHeight = 70;

      doc.rect(6, 54, 91, 10, 'F');
      doc.setTextColor(255, 255, 255);
      doc.text('SUBSIDIARY INFORMATION', 25, 60);

      doc.setFillColor(156, 178, 221); // set fill color to yellow
      doc.rect(6, 64, 91, rectHeight+(leftLengthCount*4), 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(10);

      doc.setFont("Arial", "bold");
      doc.text('Name ', x, y);
      doc.setFont("Arial", "normal");
      //doc.text(": " + subsidiaryName || "", 50, y);
      doc.text(': '|| "", 50, y);
      projectNamelabel.forEach((proName:any)=>{
        doc.text(proName || "", 52, y);
        y += 4; // Move down to the next line (adjust as needed)
      })

      let strLength = 0;
      doc.setFont("Arial", "bold");
      doc.text('Address', x, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(": " || '', 50, y);
      address.forEach((address:any)=>{
        doc.text(address || "", 52, y);
        y += 4; // Move down to the next line (adjust as needed)
      })
      


      doc.setFont("Arial", "bold");
      doc.text('City', x, y += 2);
      doc.setFont("Arial", "normal");
      doc.text(": " + city || '', 50, y);

      doc.setFont("Arial", "bold");
      doc.text('State', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + state || '', 50, y);

      doc.setFont("Arial", "bold");
      doc.text('Pin/Zip ', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + zipcode, 50 || '', y);

      doc.setFont("Arial", "bold");
      doc.text('Country', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + country || '', 50, y);


      doc.setFont("Arial", "bold");
      doc.text('Email', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + email || '', 50, y);

      doc.setFont("Arial", "bold");
      doc.text('Website', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + website || '', 50, y);

      doc.setFont("Arial", "bold");
      doc.text('Vat Registraion Number', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(': '+VatReg, 50, y);

      doc.setFont("Arial", "bold");
      doc.text('Registraion NO', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + registrationCode || "", 50, y);    

      doc.setFont("Arial", "bold");
      doc.text('Project Name', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + projectName || "", 50, y);
      
      doc.setFont("Arial", "bold");
      doc.text('Department Name', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + departmentName || "", 50, y);   
     

      let x1 = 115;
      let y2=70;
      let rectheight2 = 72;


      doc.rect(113, 54, 91, 10, 'F'); // draw a rectangle as background
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.text('SUPPLIER INFORMATION', 136, 60);
      doc.setFillColor(156, 178, 221); // set fill color to blue
      doc.rect(113, 64, 91, rectheight2+(rightLengthCount*4), 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(10);

      doc.setFont("Arial", "bold");
      doc.text('Name', x1, y2);
      doc.setFont("Arial", "normal");
      doc.text(": "|| "", 147, y2);
      sName.forEach((sName:any)=>{
        doc.text(sName || "", 149, y2);
        y2 += 4; // Move down to the next line (adjust as needed)
      })

      doc.setFont("Arial", "bold");
      doc.text('Address', x1, y2 += 2);
      doc.setFont("Arial", "normal");
      doc.text(": " || "", 147, y2);
      saddress.forEach((saddress:any)=>{
        doc.text(saddress || "", 149, y2);
        y2 += 4; // Move down to the next line (adjust as needed)
      })

      doc.setFont("Arial", "bold");
      doc.text('City', x1, y2 += 2);
      doc.setFont("Arial", "normal");
      doc.text(": "+sCity || "", 147, y2);

      doc.setFont("Arial", "bold");
      doc.text('State', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sState || "", 147, y2);

      doc.setFont("Arial", "bold");
      doc.text('Pin', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sPin || "", 147, y2);

      doc.setFont("Arial", "bold");
      doc.text('Country', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sCountry || "", 147, y2);

      doc.setFont("Arial", "bold");
      doc.text('Registration Type', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sRegType || "", 147, y2);

      doc.setFont("Arial", "bold");
      doc.text('Tax Id ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sRegCode || "", 147, y2);

      doc.setFont("Arial", "bold");
      doc.text('Contact Person', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sContactPerson || "", 147, y2);

      doc.setFont("Arial", "bold");
      doc.text('Email Id ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sContactEmail || "", 147, y2);

      doc.setFont("Arial", "bold");
      doc.text('Phone', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sContactPerPhone || "", 147, y2);
      

      //doc.setFontSize(10);
      doc.setTextColor(0);
      margin: { top: 30 }
    };

    let sMemo:any=doc.splitTextToSize(this.supplierMemo||'', 110);
    let declarations=this.rfqList?.memoNotes || '';
    const footer = function () {
      
      let y1:any=doc.internal.pageSize.height - 56;
      let y2:any=doc.internal.pageSize.height - 36;
      doc.setFontSize(12);
      doc.setTextColor(0);
      doc.text('Remarks ', 14, y1);
      doc.text(': ', 37, y1);
      sMemo.forEach((sMemo:any)=>{
        doc.text(sMemo || "", 39, y1);
        y1+= 4; // Move down to the next line (adjust as needed)
      });
      doc.text('Declaration', 14, y2);
      doc.text(': ', 37, y2);
      //doc.text(declarations, 40, doc.internal.pageSize.height - 26);
      memoNotes.forEach((memoNotes:any)=>{
        doc.text(memoNotes || "", 39, y2);
        y2+= 4; // Move down to the next line (adjust as needed)
      });



      doc.text('____________________', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 40);
      doc.text('  Authorized Signature', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 30);

    };

    // generate the invoice
    (doc as any).autoTable({

    });

    let startY = y + 78;

    if(leftLengthCount>rightLengthCount){

      startY += leftLengthCount*4;
    }else{

      startY += rightLengthCount*4;
    }

    //let startY = y + 78;
    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: this.rfQData,
      //foot: [['', '', '', '', '', 'Estimated Total:', this.estimatedAmount]],
      margin: { left: 6, bottom: 70, top: startY, right: 6 },
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [255, 255, 255],
        
      },
  

      headerStyles: {
        fillColor: [53, 67, 110], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles:{
        4:{halign:'right'}
      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;

        }



      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();
        headerAfer();
        

        y=72;
        doc.setPage(data.pageNumber);
        startY = (doc as any).autoTable.previous.finalY + 10;
        //(doc as any).setY(startY)
      },

    });

    footer();

    doc.addPage();
    header();
    let y2:any=47;
    // Set the font size and color for the annexure text
    doc.setFont('Arial', 'bold');
    doc.setTextColor(0);
    doc.setFontSize(11);
    (doc as any).text('Annexure: '
      , 14, 40, {
      lineHeightFactor: 1.5,
      baseline: 'top',
      font: { size: 10 },
      textColor: [0, 0, 0],
      startY: 40
    });

    
    this.remarks?.forEach((remarks?: any) => {
      //alert(remarks);
      doc.text(doc.splitTextToSize(remarks,200), 8, y2);
      y2 += 4; 
       });
    
    doc.save('report.pdf');
  }







  ngAfterViewInit() { }








  exportexcel() {
    /* pass here the table id */
    let element = document.getElementById('content');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    /* save to file */
    XLSX.writeFile(wb, this.fileName);

  }
}




