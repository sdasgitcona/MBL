import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ActivatedRoute, Route } from '@angular/router';
import { Injectable } from '@angular/core';

import { RfqReportModule, quotationItems, subsidiary, subsidiaryAddress, suppliers, supAddr, supCont } from './domain/product';

import * as FileSaver from 'file-saver';
import {jsPDF} from 'jspdf';
import * as XLSX from 'xlsx';
import jsPDFWithPlugin from 'jspdf';
import html2canvas from 'html2canvas';

//import 'jspdf-autotable';
import autoTable from 'jspdf-autotable';
import { Header } from 'primeng/api';
import { TableBody } from 'primeng/table';
import 'jspdf-autotable';
import { supplier } from '../po-report/domain/product';

@Injectable({
  providedIn: 'root'
})

@Component({
  selector: 'app-rfq-close',
  templateUrl: './rfq-close.component.html',
  styleUrls: ['./rfq-close.component.scss']
})
export class RfqCloseComponent implements OnInit {
 
  rfqList: RfqReportModule = new RfqReportModule();
  rfQData: any = [];
  rfqItem: quotationItems[] = [];
  rfqSubsidiary: subsidiary = new subsidiary();
  rfqSubsidiaryAddress: any = [];

  rfqSupplier:suppliers=new suppliers();
  rfqSupplierAddress:any = [];
  rfqSupplierContact:any = [];

  address: subsidiaryAddress[] = [];
  sadd:supAddr[]=[];
  contact:supCont[]=[];

  exportColumns: any[];
  prReportData: any[];
  SubsidiaryId: any;
  rfqNumber: any;
  supId:any;
  RetloginDetails: any;
  selectedSubsidiaryId: any;
  title = 'angular-app';
  fileName = 'ExcelSheet.xlsx';
  columns: any[] = [];
  //selectedPr: PrReportModule = new PrReportModule();
  totalRecords: number = 0;
  loading: boolean = false;
  //totalPages :number = 0;

  estimatedAmount: any;




  constructor(private httpService: CommonHttpService, private activatedRoute: ActivatedRoute) { }

  ngOnInit(){
      
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    
       this.columns = [
      { field: 'Sl No', header: '#' },
      { field: 'itemName', header: 'Item' },
      { field: 'itemDescription', header: 'Description' },
      { field: 'itemUom', header: 'UOM' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'rate', header: 'Estimated Rate' },
      { field: 'estimatedAmount', header: 'Estimated Amount' },
      { field: 'receivedDate', header: 'Received By Date' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    //this.getApiall();
  }

  
  exportPdf(rfqNumber: any,supId: any) {

    this.rfqNumber = rfqNumber;   //'HPL/10004/RFQ';
    this.supId = supId;           //'154';

    this.rfQData = [];;
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);


    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.columns = [
      { field: 'Sl No', header: '#' },
      { field: 'itemName', header: 'Item' },
      { field: 'itemDescription', header: 'Description' },
      { field: 'itemUom', header: 'UOM' },
      { field: 'quantity', header: 'Quantity' },
      { field: 'receivedDate', header: 'Received By Date' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    this.getAPIData();

  }
   

public getAPIData() {

  this.httpService.
    GetAll(`/procure-ws/quotation/get-by-filter?rfqNumber=${this.rfqNumber}&supplierId=${this.supId}`,this.RetloginDetails.token)
    // .GetAll('/procure-ws/quotation/get-by-filter?rfqNumber='+ this.rfqNumber + '&supplierId=7', this.RetloginDetails.token)
    .subscribe((res) => {
      if (res.status == 401) {
        alert("Unauthorized Access !");
      }
      else if (res.status == 404) {
        alert("Wrong/Invalid Token!");
      }
      else {

        if (res ) {

          this.rfqList = res;
          // this.estimatedAmount = res.estimatedAmount.toFixed(2);
          this.rfqSubsidiary = res.subsidiary;
          this.rfqItem = res.quotationItems;
          this.rfqSupplier=res.supplier;
          console.log("rfq main----"+JSON.stringify(this.rfqList));

          console.log("Supplier----"+JSON.stringify(this.rfqSupplier));
//subsidiary addreess
          if (res.subsidiary && Array.isArray(res.subsidiary.subsidiaryAddresses)) {
            this.rfqSubsidiaryAddress = res.subsidiary?.subsidiaryAddresses;
            this.rfqSubsidiaryAddress.forEach((address: any) => {
              this.rfqSubsidiaryAddress = address;
            });
          } else {
            console.log("Error: invalid response");
          }
          console.log("Subsidiary----"+JSON.stringify(this.rfqSubsidiaryAddress));

//supplier address
          
            if (res.supplier && Array.isArray(res.supplier.supplierAddresses)) {
              this.rfqSupplierAddress = res.supplier?.supplierAddresses;
              this.rfqSupplierAddress.forEach((saddr: any) => {
                this.rfqSupplierAddress = saddr;
              });
            } else {
              console.log("Error: invalid response");
              
            }
            console.log("Sup addr----"+JSON.stringify(this.rfqSupplierAddress));

//supplier contacts
          if (res.supplier && Array.isArray(res.supplier.supplierContacts)) {
            this.rfqSupplierContact = res.supplier?.supplierContacts;
            this.rfqSupplierContact.forEach((scontact: any) => {
              this.rfqSupplierContact = scontact;
            });
          } else {
            console.log("Error: invalid response");
          }
          console.log("Sup contact----"+JSON.stringify(this.rfqSupplierContact));

          this.totalRecords = res.totalRecords;

//tab data push
          for (let i = 0; i < this.rfqItem.length; i++) {
            const receivedDate = new Date(this.rfqItem[i].receivedDate);
            this.rfQData.push([i + 1, 
              this.rfqItem[i].itemName, 
              this.rfqItem[i].itemDescription, 
              this.rfqItem[i].itemUom,
              this.rfqItem[i].quantity?.toFixed(2), 
              receivedDate.toLocaleDateString('en-GB')]);
          }
          this.exportPdfAPI();

        } else {
          // this.rfqList = [];
          this.totalRecords = 0;

        }
        this.loading = false;
        //this.rfqItem= res.rfqItems;
        // console.log(this.rfqList);


      }
    });

}
exportPdfAPI(){

  const doc = new jsPDF('p', 'mm', 'a4');


    // generate table content
    let subsidiaryName = this.rfqSubsidiary?.name || '';

    // define the header and footer
    const header = function () {
      doc.setFontSize(18);
      doc.setFont("Arial", "bolditalic");
      doc.setTextColor(53, 67, 112);
      doc.text(subsidiaryName, 8, 12);
      doc.text('Request For Quotation', 75, 24);
    };
    let rfqNumber: any = this.rfqList?.rfqNumber || '';

    const timestamp = this.rfqList?.rfqDate || '';
    const date = new Date(timestamp);
    const rfqDate = date.toLocaleDateString('en-GB');

    // let projectNameLine = doc.splitTextToSize(projectName || '', 70);

    //subsidiary
    let attention: any = this.rfqSubsidiaryAddress?.attention || '';
    let address: any = doc.splitTextToSize(this.rfqSubsidiaryAddress?.address1 || '' + this.rfqSubsidiaryAddress?.address2 || '', 46);
    let city: any = this.rfqSubsidiaryAddress?.city || '';
    let state: any = this.rfqSubsidiaryAddress?.state || '';
    let zipcode: any = this.rfqSubsidiaryAddress?.zipcode || '';
    let country: any = this.rfqSubsidiaryAddress?.country;
    let email: any = this.rfqSubsidiary?.email || '';
    let website: any = this.rfqSubsidiary?.website || '';
    let registrationCode: any = this.rfqSubsidiaryAddress?.registrationCode || '';
    let openDate: any = new Date(this.rfqList?.bidOpenDate || '')
    let bidOpenDate: any = openDate.toLocaleDateString('en-GB');
    let closeDate: any = new Date(this.rfqList?.bidCloseDate || '');
    let bidCloseDate: any = closeDate.toLocaleDateString('en-GB');
    let memoNotes: any = doc.splitTextToSize(this.rfqList?.memoNotes || '', 110);
    let projectNamelabel: any = doc.splitTextToSize(subsidiaryName, 46);

    //Supplier 
    let sName:any=this.rfqSupplier?.name|| '';
    let sRegType:any=this.rfqSupplierAddress?.registrationType|| '';
    let sRegCode:any=this.rfqSupplierAddress?.taxRegistrationNumber|| '';
    let sContactPerson:any=this.rfqSupplierContact?.name|| '';
    let sContactPerPhone:any=this.rfqSupplierContact?.contactNumber|| '';
    let sContactEmail:any=this.rfqSupplierContact?.email|| '';

    let x = 8; // X coordinate
    let y = 64;
    const headerAfer = function () {

      // Y coordinate
      let rectHeight = 72;
      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.setTextColor(53, 67, 112);

      doc.text('RFQ Number :', x, 36);
      doc.text(rfqNumber || "", 42, 36);
      doc.text('RFQ Date :', 118, 36);
      doc.text(rfqDate || "", 142, 36);
      doc.rect(6, 48, 86, 10, 'F');

      doc.setTextColor(255, 255, 255);
      doc.text('SUBSIDIARY INFORMATION', 20, 54);

      doc.setFillColor(156, 178, 221); // set fill color to yellow
      doc.rect(6, 58, 86, rectHeight, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(10);

      doc.setFont("Arial", "bold");
      doc.text('Name ', x, y);
      doc.setFont("Arial", "normal");
      //doc.text(": " + subsidiaryName || "", 50, y);
     
      projectNamelabel.forEach((proName:any)=>{
        doc.text(': '+proName || "", 50, y);
        y += 4; // Move down to the next line (adjust as needed)
      })

      doc.setFont("Arial", "bold");
      doc.text('Attention Company Person', x, y += 4);
      doc.setFont("Arial", "normal");
      doc.text(": " + attention || '', 50, y);

      let strLength = 0;
      doc.setFont("Arial", "bold");
      doc.text('Address', x, y += 6);
      doc.setFont("Arial", "normal");
      //doc.text(": " + address || '', 50, y);
      address.forEach((address: any) => {
        doc.text(': '+address || "", 50, y);
        y += 4; // Move down to the next line (adjust as needed)
        
      });



      doc.setFont("Arial", "bold");
      doc.text('City', x, y += 4);
      doc.setFont("Arial", "normal");
      doc.text(": " + city || '', 50, y);

      doc.setFont("Arial", "bold");
      doc.text('State', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + state || '', 50, y);

      doc.setFont("Arial", "bold");
      doc.text('Pin/Zip ', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + zipcode, 50 || '', y);

      doc.setFont("Arial", "bold");
      doc.text('Country', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + country || '', 50, y);


      doc.setFont("Arial", "bold");
      doc.text('Email', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + email || '', 50, y);

      doc.setFont("Arial", "bold");
      doc.text('Website', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(": " + website || '', 50, y);

      doc.setFont("Arial", "bold");
      doc.text('Vat Registraion Number', x, y += 6);
      doc.setFont("Arial", "normal");
      doc.text(': ', 50, y);




     
      let totalCount = address.length+projectNamelabel.length;
      if (address.length > 1 || projectNamelabel.length) {
        doc.setFillColor(156, 178, 221);

        doc.rect(6, y, 86, (totalCount*2)+2, 'F');
        doc.setFont("Arial", "bold");
        doc.text('Registraion NO', x, y += 6);
        doc.setFont("Arial", "normal");
        doc.text(": " + registrationCode || "", 50, y);
       
      }
      else {
        doc.setFont("Arial", "bold");
        doc.text('Registraion NO', x, y += 6);
        doc.setFont("Arial", "normal");
        doc.text(": " + registrationCode || "", 50, y);
      }



      let x1 = 120;
      let y2 = 64;


      doc.rect(118, 48, 86, 10, 'F'); // draw a rectangle as background
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont("Arial", "bold");
      doc.text('SUPPLIER INFORMATION', 136, 54);
      doc.setFillColor(156, 178, 221); // set fill color to blue
      doc.rect(118, 58, 86, 72, 'F'); // draw a rectangle as background
      doc.setTextColor(53, 67, 112); // set text color
      doc.setFontSize(10);

      doc.setFont("Arial", "bold");
      doc.text('Name', x1, y2);
      doc.setFont("Arial", "normal");
      doc.text(": "+sName || "", 155, y2);

      doc.setFont("Arial", "bold");
      doc.text('Registration Type', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sRegType || "", 155, y2);

      doc.setFont("Arial", "bold");
      doc.text('Tax Id ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sRegCode || "", 155, y2);

      doc.setFont("Arial", "bold");
      doc.text('Contact Person', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sContactPerson || "", 155, y2);

      doc.setFont("Arial", "bold");
      doc.text('Email Id ', x1, y2 += 6);
      doc.setFont("Arial", "normal");
      doc.text(": "+sContactEmail || "", 155, y2);


      if (memoNotes.length > 1) {
        doc.setFillColor(156, 178, 221);
        doc.rect(118, y2, 86, 20, 'F');
        doc.setFont("Arial", "bold");
        doc.text('Phone', x1, y2 += 6);
        doc.setFont("Arial", "normal");
        doc.text(": "+sContactPerPhone || "", 155, y2);
        
      }
      else {
        doc.setFont("Arial", "bold");
        doc.text('Phone', x1, y2 += 6);
        doc.setFont("Arial", "normal");
        doc.text(": "+sContactPerPhone || "", 155, y2);
      }


      //doc.setFontSize(10);
      doc.setTextColor(0);
      margin: { top: 30 }
    };


    let declarations=this.rfqList?.memoNotes || '';
    const footer = function () {
      doc.setFontSize(12);
      doc.setTextColor(0);
      doc.text('Remarks:', 14, doc.internal.pageSize.height - 36);
      doc.text('Declaration:', 14, doc.internal.pageSize.height - 26);
      doc.text(declarations, 40, doc.internal.pageSize.height - 26);



      doc.text('____________________', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 40);
      doc.text('  Authorized Signature', doc.internal.pageSize.width - 56, doc.internal.pageSize.height - 30);

    };

    // generate the invoice
    (doc as any).autoTable({
      // startY: 70,
      // head: [['Invoice Number', 'Invoice Date', 'Customer Name', 'Customer Email', 'Customer Address']],
      // body: [['Invoice Number', 'Invoice Date', 'Customer Name', 'Customer Email', 'Customer Address']],
      // didDrawPage: function(data:any) {
      //   // add the header and footer to each page
      //   header();
      //   headerAfer();
      //   footer();
      // },


    });


    let startY = y + 78;
    (doc as any).autoTable({

      startY: startY,
      head: [this.exportColumns],
      body: this.rfQData,
      //foot: [['', '', '', '', '', 'Estimated Total:', this.estimatedAmount]],
      margin: { left: 6, bottom: 70, top: startY, right: 6 },
      styles: {
        lineWidth: 0.1,
        lineColor: [37, 37, 37],
        fillColor: [255, 255, 255],
        
      },
  

      headerStyles: {
        fillColor: [53, 67, 110], // set background color of table header
        halign: 'center',


      },
      footStyles: {
        cellPadding: { top: 10, bottom: 2 }, // Set top and bottom padding for cells in the table foot
        border: undefined,
        lineWidth: 0, // Set line width to 0 to remove border
        fillColor: [255, 255, 255] // Set fill color to white to remove any r
      },
      tableStyles: {
        lineColor: [70, 73, 76] // set border color to red
      },
      columnStyles:{
        4:{halign:'right'}
      },
      didParseCell: function (data: any) {
        if (data.section === 'foot') {
          data.cell.styles.fillColor = [53, 67, 110];
          data.cell.styles.LineColor = [0, 0, 0];
          data.cell.styles.border = 0;
          //data.cell.align='right';

          data.cell.border = 0;
          // if (data.pageCount === (doc as any).internal.getNumberOfPages()) {
          //   // add the footer section to the last page
          //   (doc as any).autoTable({
          //     head: false,
          //     body: false,
          //     //foot: [['', '', '', '', '', 'Estimated Total:']],
          //     startY: doc.internal.pageSize.height - 90,
          //     tableWidth: 'wrap',
          //     styles: {
          //       cellPadding: 1,
          //       fontSize: 10,
          //       valign: 'middle',
          //       halign: 'center',
          //       fillColor: [53, 67, 110],
          //     },
          //   });
          // }

        }



      },
      didDrawPage: function (data: any) {
        // add the header and footer to each page
        header();
        headerAfer();
        footer();

        doc.setPage(data.pageNumber);
        //(doc as any).setY(doc.internal.pageSize.height - 50);
        // set the startY option for the autoTable on this page
        startY = (doc as any).autoTable.previous.finalY + 10;
        //(doc as any).setY(startY)
      },

    });

    doc.addPage();
    header();
    // Set the font size and color for the annexure text
    doc.setFont('Arial', 'bold');
    doc.setTextColor(0);
    doc.setFontSize(10);
    (doc as any).text('Annexure:', 14, 40, {
      lineHeightFactor: 1.5,
      baseline: 'top',
      font: { size: 10 },
      textColor: [0, 0, 0],
      startY: 40
    });
    doc.save('report.pdf');
  }







  ngAfterViewInit() { }








  exportexcel() {
    /* pass here the table id */
    let element = document.getElementById('content');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    /* save to file */
    XLSX.writeFile(wb, this.fileName);

  }
}




