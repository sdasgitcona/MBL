export class Employee {
             id: number;
             subsidiaryId: number;
             initials: string;
             designation: string;
             employeeNumber: string;
             email: string;
             department: string;
             salutation: string;
             pan: string;
             currency: string;
             firstName: string;
             middleName: string;
             lastName: string;
             supervisor?: string;
             signatureMetadata: string;
             signature: string;
             imageMetadata:string;
             image: string;
             createdDate: Date;
             createdBy?: string;
             lastModifiedDate: Date;
             lastModifiedBy: string;
             deleted: boolean;
             rcm: boolean;
             itc: boolean;
             employeeContact: EmployeeContact = {};
             employeeAccounting: EmployeeAccounting = {};
             employeeAddresses:Employeeaddresses[] = [];
             employeeAccess: EmployeeAccess = {
                 employeeRoles: []
             };
             status: boolean=true;
             contactNumber: string;
             active: boolean=true;
             fullName:string;
             accountId?:string;
             uniqueTaxNumber?:string
             integratedId?:any;
             access:boolean=true;
}


export class EmployeeContact{
    id?: number;
    employeeId?: number;
    employeeNumber?: string;
    email?: string;
    mobile?: string;
    officeNumber?:string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted?: boolean;
}

export class EmployeeAccounting{
        id?: number;
        employeeId?: number;
        employeeNumber?: string;
        defaultLiabilityAccount?: number;
        createdDate?: Date;
        createdBy?: string;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        deleted?: boolean;
}


export class Employeeaddresses
{
            id: number;
            employeeId: number;
            employeeNumber: string;
            address1: string;
            address2: string;
            city: string;
            state: string;
            pin: string;
            country:string;
            createdDate: Date;
            createdBy: string;
            lastModifiedDate: Date;
            lastModifiedBy: string;
            deleted: boolean;
           
}

export class EmployeeAccess
{
    id?: number;
    employeeId?: number;
    employeeNumber?: string;
    access?: boolean;
    password?: any;
    confirmpassword?:any;
    cnfpassword?: string;
    employeeRoles: EmployeeRoles[] = [];
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted?: boolean;
    accessMail?:string;
    roleId?: any;
    roleName?: string;
}

export class EmployeeRoles{
    id?: number;
    employeeId?: number;
    employeeNumber?: string;
    roleId?: any;
    roleName?: string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted?: boolean;
    name?: string;

}

export class EmployeeRole {
    id?: number;
    employeeId?: number;
    roleId?: string;
    roleName?: string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted?: boolean;
  }
  export class Account {
    id?: string;
    description?: string;
    type?: string;
    code?: string;
  }
  export class file_upload
  {
    file:File;
  }