import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeAddEditComponent } from './employee-add-edit/employee-add-edit.component';
const routes: Routes = [
  {
    path: '',
    component: EmployeeListComponent,
  },
  {
    path: 'list',
    component: EmployeeListComponent,
  },
  {
    path: 'action/:action/:id',
    component: EmployeeAddEditComponent,
  },
  {
    path: 'action/:action',
    component: EmployeeAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmployeeRoutingModule { }
