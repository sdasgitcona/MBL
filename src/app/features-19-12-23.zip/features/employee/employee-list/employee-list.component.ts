import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch, BaseSearchPdf } from '../../supplier/model/supplier-model';
import { Employee ,file_upload} from '../model/employee-module';
import { jsPDF } from 'jspdf'
import autoTable from 'jspdf-autotable';
import { HttpHeaders } from '@angular/common/http';
import { saveAs } from 'file-saver';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss']
})
export class EmployeeListComponent implements OnInit {
  columns: any[];
  departments: any[] = [];
  employeelist: Employee[] = [];
  selectedEmployee: Employee = new Employee();
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  employee: Employee = new Employee();
  newevent:any;
  url:any;
  taxType:any;
  RetloginDetails: any;
  Designation:any[]=[];
  RetRoleDetails:any;
  SubIdList:any=[];
  SubsideryObject:any=[]=[];
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  employeePrint: any[] = [];
  isdisablesubsidiary:boolean=false;
  // For Role Base Access
  departmentOptions: any;
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean; 
  displayModal:boolean;
  showloader:boolean;
  file: File ;
  file_upload:file_upload=new file_upload();
  statusOption:any[]=[];
  // For Role Base Access
  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService) {

      this.Designation = [{id:'Executive',value:'Executive'},{id:'Manager',value:'Manager'}];
      this.statusOption = [{id:'Active',name:"Active"},{id:'Inactive',name:"Inactive"}];
     }
  
  
    ngOnInit(): void {
      if(localStorage.getItem("LoggerDTLS") == null)
      {
        this.router.navigate(['/login']);
      }
      // For Role Base Access
      const retDetails:any = localStorage.getItem("RoleDTLS");
      var role_Dtls = JSON.parse(retDetails);
      this.RetRoleDetails=role_Dtls;
      const LDetails:any=localStorage.getItem("LoggerDTLS");
      this.RetloginDetails = JSON.parse(LDetails);

      for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
      {
        if(role_Dtls[0].rolePermissions[i].accessPoint == "Employee")
        {
          this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
          this.isEditable=role_Dtls[0].rolePermissions[i].edit;
          this.isViewtable=role_Dtls[0].rolePermissions[i].view;
        }
      }
    // End For Role Base Access
    this.GetSubsideryList();
    //this.resetBaseSearch();
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
       { field: 'id', header: 'Internal ID' },
       { field: 'fullName', header: 'Employee Name' },
       { field: 'employeeNumber', header: 'Employee Number' },
       { field: 'designation', header: 'Designation' },
       { field: "active", header: 'Status'},
     ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
    var v = localStorage.getItem("LoggerDTLS");
  }
  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.TAX_RATE_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadEmployee(this.newevent);
  }
  loadEmployee(event: any) {
     try {
      this.newevent=event;
      this.loading = true;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
        this.baseSearch.sortColumn = event.sortField
        ?  event.sortField
        : GlobalConstants.EMPLOYEE_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
        //   if(this.SubIdList.length==0)
        //  {
        //   return;
        //  }
        if(this.SubIdList.length==0 && this.RetloginDetails.userType!='ROOTADMIN')
         {
         return;
         }
          this.HttpService.Insert('/masters-ws/employee/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
          {
            this.employeelist=[];
              if (res && res.list.length > 0) {
                var RetData=res.list;
                for(let i=0;i<RetData.length;i++)
                {
                  if(RetData[i].employeeNumber.includes("messageCode"))
                  {
                    RetData[i].employeeNumber="";
                  }
                  this.employeelist.push(RetData[i]);
                }
                //this.employeelist = res.list;          
                this.totalRecords = res.totalRecords;
              } else {
                this.employeelist = [];
              }
              this.loading = false;
          }

         
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {
    }
  }
  navigateToAdd() {
    this.router.navigate(['/main/supplier/update']);
  }
  // exportPdf() {
  //   import("jspdf").then(jsPDF => {
  //       import("jspdf-autotable").then(x => {
  //           const doc = new jsPDF.default();
  //           (doc as any).autoTable(this.exportColumns, this.employeelist);
  //           doc.save('employee.pdf');
  //       })
  //   });
  // }
  /* Start fetch filter list of supplier from api */
  findby(event: any){
    let subsidyList:any=[];
    subsidyList.push(this.employee.subsidiaryId);

     this.baseSearch.filters={
      name:this.employee.firstName,
      number:this.employee.employeeNumber,
      status:this.employee.status==true?'active':'inactive',
      designation:this.employee.designation,
      subsidiaryId:subsidyList,
      access:this.employee.access==true?'true':'false',
      department:this.employee.department,
      supervisor:this.employee.supervisor,

  }
  this.baseSearch.pageNumber=-1;
    this.loadEmployee(this.newevent);
  }
  navigateToAddViewEdit(
    action: string,
    selectedEmployee: Employee = new Employee()
  ) {
    let employeeId = null;
    if (selectedEmployee?.id) {
      employeeId = selectedEmployee.id;
      this.router.navigate(['/main/employee/action', action, employeeId]);
    } else {
      this.router.navigate(['/main/employee/action', action]);
    }
   }
  Reset()
  {
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.employee.subsidiaryId=0;
    }
    this.employee.firstName ="";
    this.employee.employeeNumber="";
    this.employee.status=true;
    this.employee.designation='';
    this.employee.access=true;
    this.employee.department="";
    this.employee.supervisor="";
    this.resetBaseSearch();
  }
  
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  GetSubsideryList() {
    this.SubsideryObject=[];
  
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.SubsideryObject=res;
        for(let x=0;x<this.SubsideryObject.length;x++)
       { 
        this.SubIdList.push(this.SubsideryObject[x].id);
      }
      this.isdisablesubsidiary=false;
      this.GetDepartmentList();
      }
      },
      (error) => {
        alert(error);
       },

        () => {
        if(localStorage.getItem("EmployeeFilters") != null)
        {const LocDetails:any =localStorage.getItem("EmployeeFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.employee.subsidiaryId=searcheData.filters.subsidiaryId[0];
        this.employee.firstName=searcheData.filters.name;
        this.employee.employeeNumber=searcheData.filters.number;
        this.employee.designation=searcheData.filters.designation;
        this.employee.status=searcheData.filters.status=="active"?true:false;
        this.employee.department=searcheData.filters.department;
        this.employee.supervisor=searcheData.filters.supervisor;

        this.loadEmployee(this.newevent);
        localStorage.removeItem("EmployeeFilters");
        }
        else
       { this.resetBaseSearch();}
      }
    );
  }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.SubsideryObject.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.employee.subsidiaryId= this.SubsideryObject[0].id
      this.GetDepartmentList();
      this.isdisablesubsidiary=true;
      if(localStorage.getItem("EmployeeFilters") != null)
      {const LocDetails:any =localStorage.getItem("EmployeeFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
    
      this.employee.firstName=searcheData.filters.name;
      this.employee.employeeNumber=searcheData.filters.number;
      this.employee.designation=searcheData.filters.designation;
      this.employee.status=searcheData.filters.status=="active"?true:false;
      this.employee.department=searcheData.filters.department;
      this.employee.supervisor=searcheData.filters.supervisor;
      
      this.loadEmployee(this.newevent);      localStorage.removeItem("EmployeeFilters");
      }
      else
     { this.resetBaseSearch();}
    }
  }

  editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("EmployeeFilters") != null)
    {
      localStorage.removeItem("EmployeeFilters");
    }
    localStorage.setItem("EmployeeFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/employee/action', actionType, mainId]);
   }

  getAllSubsidiaryReloadList()
  {
    this.employee.subsidiaryId=0;
    this.GetSubsideryList();
  }

  csvUploadDownload(){
    this.displayModal = true;
  }
  @ViewChild('attachments') attachment: any;

  fileList: File[] = [];
  listOfFiles: any[] = [];
  isLoading = false;
  
  uploadFile(event:any){
    const httpOptions = {
      headers: new HttpHeaders({
       //"Content-Type": "multipart/form-data" 
       "mimeType": "multipart/form-data",
       "Content-Type": "false"
      })
    };
    
    //this.file = event.target.files[0];
    //let fileElement:any;
    //fileElement =document.getElementById('file_');
    //this.file = fileElement.files[0]

    const formData:FormData = new FormData();
    //this.file=event.currentTarget.files[0];
  if(this.file)
  {
    // formData.set('file', this.file);
     formData.append('file', this.file,this.file.name);
     this.showloader=true;
        this.url="/masters-ws/employee/upload?subsidiaryId=" +this.RetRoleDetails[0].subsidiaryId +"&accountId=" + this.RetRoleDetails[0].accountId;
  

    //this.HttpService.uploadFile_("/masters-ws/supplier/upload",formData,{responseType: 'arraybuffer'},this.RetloginDetails.token)
    this.HttpService.uploadFile_(this.url, formData ,{responseType: 'blob'} ,this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
      {  
        this.executeSaveAs(res)
       if (res.error){
         this.toastService.addSingle(
           'error',
           'Error',
           res.error.errorMessage
         );
         }
         else{
          
           this.toastService.addSingle(
             'success',
             'Success',
             'File uploaded Successfully!'
           );
           window.location.reload();
         }
        }
        this.showloader=false;
    },
      (error) => {
        if(error.status == 200)
        {
          this.toastService.addSingle(
            'success',
            'Success',
            'File uploaded Successfully!'
          );
          window.location.reload();
        }
        else
       { this.showAlert(error.message);}
        this.executeSaveAs(error.error.text);
        //this.showAlert(error.error.error);
        this.showloader=false;
      },
      () => {
  
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
    }
    else
  {
    this.showAlert("No Attachment Found !")
  }
  }
  onFileChanged(event: any) {
    this.isLoading = true;
    this.file = event.target.files[0];
    this.listOfFiles=[]
    //this.listOfFiles.push(this.file .name);
    this.listOfFiles.push({subsidiary:this.RetRoleDetails[0].subsidiaryName,file:this.file .name});
     
    //this.fileList = event.target.files[0];
    // for (var i = 0; i <= event.target.files.length - 1; i++) {
    //   var selectedFile = event.target.files[i];
    //   if (this.listOfFiles.indexOf(selectedFile.name) === -1) {
    //     this.fileList.push(selectedFile);
    //     this.listOfFiles.push(selectedFile.name);
    //   }
    // }
    this.isLoading = false;
    //this.attachment.nativeElement.value = '';
  }
  removeSelectedFile(index: number) {
    // Delete the item from fileNames list
    this.listOfFiles.splice(index, 1);
    // delete file from FileList
    this.fileList.splice(index, 1);
  }

  executeSaveAs(content:any){
    //let blob = new Blob([content], {'type': "application/octet-stream"});
   saveAs(content, "employee.xlsx"); // This is from https://github.com/eligrey/FileSaver.js
};

DownloadTemplete() {
  this.HttpService.downloadFile("/masters-ws/employee/download-template",this.RetloginDetails.token)
  .subscribe((res) => {
    //saveAs(res, 'employee.xlsx');
    if(res)
    {this.executeSaveAs(res);}
    //let blob = new Blob([res], {'type': "application/octet-stream"});
    //window.open(res)
  },(error) => {
    alert(error);
   },
   ()=>{
   }
  );

  //window.open(this.HttpService.baseUrl+"/masters-ws/supplier/download-template")
  // this.HttpService
  //   .GetByResponseType('/supplier/download-template','blob')
  //   .subscribe((res) => {
  //     var reader = new FileReader;

  //     reader.onload = function() {
  //       var blobAsDataUrl = reader.result;
 //     };
   
  //     reader.readAsDataURL(res);   
  //   });
}



    //List Export option Start

    //Start PDF
    generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.EMPLOYEE_TABLE_SORT_COLUMN;
      this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};

      this.HttpService.Insert('/masters-ws/employee/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.employeePrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {
                  if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){   
                  this.employeePrint.push({
                    'id': RetData[i].id,    
                    'fullName':RetData[i].fullName, 
                    'employeeNumber': RetData[i].employeeNumber,
                    'designation': RetData[i].designation,
                    'active': RetData[i].active,
                });
              }
                else{
                  this.employeePrint.push({
                    'Internal Id': RetData[i].id,    
                    'Employee Name':RetData[i].fullName, 
                    'Employee Number': RetData[i].employeeNumber,
                    'Designation': RetData[i].designation,
                    'Status': RetData[i].active,
                  });
                }

              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    exportPdf() {
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          //this.= this.employeeExport;
          //this.employeelist=[];
          (doc as any).autoTable(this.exportColumns, this.employeePrint);
          doc.save('employee.pdf');
        })
      })
    }

  //End PDF

  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');

   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.employeePrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.employeePrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'employee');
           this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
  //End Excel 
    //List Export option End

    GetDepartmentList() {
      this.HttpService.GetAll('/masters-ws/department/get/all/lov?subsidiaryId='+this.employee.subsidiaryId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        this.departmentOptions = [];
        Object.keys(res).forEach(key => { 
          this.departmentOptions.push({
              "id":Number(key),
              "departmentName":res[key]
            })   
          });
      }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  
  }

  onRowSelect(event: any) {
    let employeeId = event.data.id;
    
    this.router.navigate(['/main/employee/action/view', employeeId]);
  }

  onRowUnselect(event: any) {
  }

}
