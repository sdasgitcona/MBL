import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CountryInfoListComponent } from './country-info-list/country-info-list.component';
import { CountryInfoAddEditComponent } from './country-info-add-edit/country-info-add-edit.component';

const routes: Routes = [
  {
    path: '',
    component: CountryInfoListComponent,
  },
  {
    path: 'list',
    component: CountryInfoListComponent,
  },
  {
    path: 'list/:status',
    component: CountryInfoListComponent,
  },
  {
    path: 'action/:action/:id/:appid/:isaccid',
    component: CountryInfoAddEditComponent,
  },
  {
    path: 'action/:action',
    component: CountryInfoAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompanyInfoRoutingModule { }
