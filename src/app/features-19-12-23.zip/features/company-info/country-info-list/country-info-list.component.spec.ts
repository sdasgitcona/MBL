import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CountryInfoListComponent } from './country-info-list.component';

describe('CountryInfoListComponent', () => {
  let component: CountryInfoListComponent;
  let fixture: ComponentFixture<CountryInfoListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CountryInfoListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CountryInfoListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
