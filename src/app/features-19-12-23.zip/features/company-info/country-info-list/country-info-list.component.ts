import { Component, OnInit, ViewChild,LOCALE_ID, Inject } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { AddressService } from '../../../shared/shared-components/address/service/address.service';
import { BaseSearch, company,BaseSearchPdf } from '../model/country-model';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { CountryModel,Employee, CityMDL, StateMDL, CountryMDL, companyDataAddress,license_data,Employeeaddresses} from '../model/country-model';
import * as FileSaver from 'file-saver';
import {formatDate } from '@angular/common';
@Component({
  selector: 'app-country-info-list',
  templateUrl: './country-info-list.component.html',
  styleUrls: ['./country-info-list.component.scss']
})
export class CountryInfoListComponent implements OnInit {
  columns: any[];
  departments: any[] = [];
  companylist: company[] = [];
  companysearchlist: company[] = [];
  selectedcompany: company = new company();
  selectedRow: company = new company();
  totalRecords: number = 0;
  loading: boolean = false;
  // baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  // employee: Employee = new Employee();
  employee: [] = [];
  newevent:any;
  Companylist: any[] = [];
  taxType:any;
  showloader:boolean=false;
  mainID:number;
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  baseSearch: BaseSearch = new BaseSearch();
  RetloginDetails:any;
  RetRoleDetails:any;
  isParams: boolean = true;
  status:any;
  before_a_day:any;
  today_date:any;
  after_a_month_date:any;
  before_7_day_date:any;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  CompanyPrint: any[] = [];
  constructor(
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
    private HttpService: CommonHttpService,
    private addressService: AddressService,@Inject(LOCALE_ID) public locale: string
  ) { }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    //this.GetAllCompanylist();
    // For Role Base Access
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
    {
      if(role_Dtls[0].rolePermissions[i].accessPoint == "Company Information")
      {
        this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
        this.isEditable=role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable=role_Dtls[0].rolePermissions[i].view;
      }
    }
  this.GenrateAccessTokenAndGetCountries();
  this.GetAllCompanylist();
  this.GetFilterList();
    
    if(this.RetRoleDetails[0].accountId !== null)
    {
      
      this.httpService.GetAll('/setup-ws/company-data/get-by-account-id?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
         {
         
          if(res.appDataId!=null)
          {
            this.router.navigate(['/main/company/action/view', res.mblId,res.appDataId,1]);
          }
          else
          {
            //this.router.navigate(['/main/company/action/view', res.mblId,0,1]);
          }
        }
        },
        (error) => {
          alert(error);
         },
         ()=>{
         
         //this.loadSuppliers('');
         }
      );

    }
  // End For Role Base Access

  //this.loadCompanyData();

  // For Getting Filtered Data from Dashboard
  let activation_date:any;
  let deactivation_date:any;
  this.activatedRoute.params.subscribe((params) => {
    if (params) {
      if (params['status']) {
        this.isParams = true;
        this.status = params['status']
        if(this.status == 'Pending'){
          this.baseSearch.filters={
            databaseCreated:'pending',
            roleId:this.RetRoleDetails[0].id
          }
          this.loadCompanyData(this.newevent);
        } else if(this.status == 'Inactivated'){
          this.getDate();
          this.baseSearch.filters={
            inactiveDate:deactivation_date = this.before_a_day,
            roleId:this.RetRoleDetails[0].id
          }
          this.loadCompanyData(this.newevent);
        } else if(this.status == 'Recent'){
          this.getDate();
          this.baseSearch.filters={
            sevenMinusDate:this.before_7_day_date, 
            roleId:this.RetRoleDetails[0].id
          }
          this.loadCompanyData(this.newevent);
        } else if(this.status == 'Upcoming'){
          this.getDate();
          this.baseSearch.filters={
            localDate:this.today_date,
            thirtyPlusDate:this.after_a_month_date,
            roleId:this.RetRoleDetails[0].id
          }
          this.loadCompanyData(this.newevent);
        } else {
          // this.baseSearch.filters={
          //   country:this.selectedcompany.country,
          //   company:this.selectedcompany.companyName,
          //   activeDate:activation_date,
          //   inactiveDate:deactivation_date,
          //   roleId:this.RetRoleDetails[0].id
          // }
          // this.loadCompanyData(this.newevent);
        }
      } 
    }
  });
  // END Getting Filtered Data from Dashboard
  this.columns = [
    // { field: 'Sl No', header: 'Sl No' },
    { field: 'Id', header: 'Internal ID' },
    { field: 'Account Id', header: 'Account Id' },
    { field: 'Company Name', header: 'Company Name' },
    { field: 'Country', header: 'Country' },
    { field: 'Attention', header: 'Attention' },
    { field: 'Phone Number', header: 'Phone Number' },
    { field: 'Activation Date', header: 'Activation Date' },
    { field: 'Deactivation Date', header: 'Deactivation Date' },
   ];


  this.exportColumns = this.columns.map(col => ({
    title: col.header,
    dataKey: col.field
  }));
  }

  resetBaseSearch() {
    if(this.RetloginDetails.userType=='ROOTADMIN') {
      this.baseSearch.filters = {roleId:this.RetRoleDetails[0].id};
      this.baseSearch.pageNumber = 0;
      this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
      this.baseSearch.sortColumn = GlobalConstants.COMPANYINFO_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder = GlobalConstants.DESCENDING;
      this.loadCompanyData(this.newevent);
    }
    else {
      this.baseSearch.filters = {roleId:this.RetRoleDetails[0].id};
      this.baseSearch.pageNumber = 0;
      this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
      this.baseSearch.sortColumn = GlobalConstants.COMPANYINFO_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder = GlobalConstants.DESCENDING;
      this.loadCompanyData(this.newevent);
    }
  }

  loadCompanyData(event: any) {
    try {
     this.newevent=event;
     this.loading = true;
     this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
     // this.baseSearch.pageNumber = 1;
     this.baseSearch.pageSize = event.rows;
       this.baseSearch.sortColumn = event.sortField
       ?  event.sortField
       : GlobalConstants.COMPANYINFO_TABLE_SORT_COLUMN;
     this.baseSearch.sortOrder =
       event.sortOrder == -1
         ? GlobalConstants.ASCENDING
         : GlobalConstants.DESCENDING;
         this.HttpService.Insert("/setup-ws/company-data/get/all-pagination",this.baseSearch,this.RetloginDetails.token).subscribe(
        
       (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.companylist = []
          if (res ) {
             this.companylist = res.list;     
                 
            this.totalRecords = res.totalRecords;
          } else {
            this.companylist = [];
          }
          this.loading = false;
        }
       },
       (error) => {
         this.loading = false;
       }
     );
   } catch (err) {
   }
 }

 /*exportPdf() {
  import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          (doc as any).autoTable(this.exportColumns, this.companylist);
          doc.save('employee.pdf');
      })
  })
}*/
/* Start fetch filter list of supplier from api */
findby(event: any){

    let activation_date:any;
    let deactivation_date:any;
    
    if(this.selectedcompany.activationDate!=undefined)
    {
     //let effectiveFrom=this.taxRateRule.effectiveFrom.setDate(this.taxRateRule.effectiveFrom.getDate() - 1)
      let days_from:any = new Date(this.selectedcompany.activationDate).getDate();
      if(days_from<10)
      {
         days_from="0"+days_from;
      }
      let months_from:any = new Date(this.selectedcompany.activationDate).getMonth()+1;
      
      if(months_from<10)
      {
        months_from="0"+months_from;
      }
      let year_from:any = new Date(this.selectedcompany.activationDate).getFullYear();
      activation_date=year_from+"-"+months_from+"-"+days_from;
    }
    if(this.selectedcompany.deActivationDate!=undefined)
    {
     // let effectiveto=this.taxRateRule.effectiveTo.setDate(this.taxRateRule.effectiveTo.getDate() - 1)
      let days_to:any = new Date(this.selectedcompany.deActivationDate).getDate();
      if(days_to<10)
      {
        days_to="0"+days_to;
      }
      let months_to:any = new Date(this.selectedcompany.deActivationDate).getMonth()+1;
      if(months_to<10)
      {
        months_to="0"+months_to;
      }
      let year_to:any = new Date(this.selectedcompany.deActivationDate).getFullYear();
      deactivation_date=year_to+"-"+months_to+"-"+days_to;
    }

  this.baseSearch.filters={
    country:this.selectedcompany.country,
    company:this.selectedcompany.companyName,
    activeDate:activation_date,
    inactiveDate:deactivation_date,
    roleId:this.RetRoleDetails[0].id
}
  this.loadCompanyData(this.newevent);
}

  GetAllCompanylist(){
   
    this.HttpService.GetAll("/setup-ws/company-data/get/all",this.RetloginDetails.token)
    .subscribe(res => {
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        this.companysearchlist = []
        this.companysearchlist=res;
      }
      });
   }

   showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  Reset()
  {
    this.selectedcompany.country=undefined;
    this.selectedcompany.companyName=undefined;
    this.selectedcompany.activationDate=undefined;
    this.selectedcompany.deActivationDate=undefined;
    this.resetBaseSearch();
    
  }

countries: CountryMDL[] = [];
GetCountryList() {
  this.addressService.GetCountryList().subscribe(
    (res) => {
      this.countries = res;
      this.countries.map((item) => {
        item.country = item.country_name;
      });
    },
    (error) => {
      console.log(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    }
  );
}
GenrateAccessTokenAndGetCountries() {
  this.addressService.GetAccessToken().subscribe(
    (res) => {
      console.log(res);
      //this.countryviewModels=res;
      this.GetCountryList();
    },
    (error) => {
      console.log(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    }
  );
}

ReloadCountryList()
{
  this.countries=[];
  this.GenrateAccessTokenAndGetCountries();
}

ReloadCompanyList()
{
  this.companysearchlist=[];
  this.GetAllCompanylist();
}
// createDB(mainId:any){
//   this.showloader=true;
//   this.httpService.GetAll('/setup-ws/company-data/create-database?id='+  mainId,this.RetloginDetails.token).subscribe(
//     (res) => {
//       if (res.status == 401) {
//         this.showAlert("Unauthorized Access !");
//         this.router.navigate(['/login']);
//       }
//       else if (res.status == 404) {
//         this.showAlert("Wrong/Invalid Token!");
//         this.router.navigate(['/login']);
//       }
//       else {
//         if (res.status== 200)  {
//           this.showloader=false;
//          this.showDB();
//          window.location.reload();
//        } 
//        else {
//           this.showloader=false;
//           this.showAlert("Database Creation Failed !")
//        }
//       }
//     },
//     (error) => {
//      this.showloader=false;
//       this.showAlert(error);
//     },
//     () => {}
//   );
// }
createDB(mainId:any){
  this.showloader=true;
  this.httpService.GetAll('/setup-ws/company-data/create-database?id='+  mainId,this.RetloginDetails.token).subscribe(
    (res) => {
      debugger;
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        if (res.status == 500) {
          this.showloader=false;
          // window.location.reload;
           this.showAlert("Database Creation Failed!!!")

      
       } 
       else {
        this.showloader=false;
        //this.showSuccess();
        this.showDB();
        setTimeout(() => {window.location.reload();},300);
      
       }
      }
    },
    (error) => {
     
     this.showloader=false;
      this.showAlert(error);
    },
    () => {}
  );
}
showDB(){
  this.toastService.addSingle(
    'success',
    'Success',
    'Successfully Create Database !'
  );

}

getDate() {
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
  const after_a_month = (currentDate.getMonth() + 2).toString().padStart(2, '0');
  const today = currentDate.getDate().toString().padStart(2, '0');
  const before_day = (currentDate.getDate() - 1).toString().padStart(2, '0');
  const before_seven_day = new Date(currentDate.setDate(currentDate.getDate() - 7));
  const before_seven_day_date = before_seven_day.getDate().toString().padStart(2, '0');
  const month_before_seven_day = (before_seven_day.getMonth() + 1).toString().padStart(2, '0');

  this.today_date = `${year}-${month}-${today}`;
  this.before_a_day = `${year}-${month}-${before_day}`;
  this.before_7_day_date = `${year}-${month_before_seven_day}-${before_seven_day_date}`;
  this.after_a_month_date = `${year}-${after_a_month}-${today}`;
}

      /***((Export Excel)) */
      generatePDFData(exportType:any){
        this.newevent = event;
        this.baseSearchPdf.pageSize = this.totalRecords;
        this.baseSearchPdf.sortColumn =GlobalConstants.COMPANYINFO_TABLE_SORT_COLUMN;
        //this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
    
        this.HttpService.Insert('/setup-ws/company-data/get/all-pagination', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
          (res) => {
            //For Auth
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
              //this.employeelistPrint = [];
              this.CompanyPrint = [];
              if (res && res.list.length > 0) {
                var RetData = res.list;
                for (let i = 0; i < RetData.length; i++) {

                  if (RetData[i].id == undefined) {
                    RetData[i].id = "";
                  }
                  if(exportType == 'PDF'){ 

                    this.CompanyPrint.push({
                      'Id': RetData[i].mblId,    
                      'Account Id':RetData[i].accountId, 
                      'Company Name': RetData[i].companyName,
                      'Country': RetData[i].country,
                      'Attention': RetData[i].attention,
                      'Phone Number':  RetData[i].phone ,  
                      'Activation Date': formatDate(RetData[i].activationDate, 'dd-MM-yyyy' ,this.locale), 
                      'Deactivation Date': formatDate(RetData[i].deActivationDate, 'dd-MM-yyyy' ,this.locale),
                   
                      // 
                      
                  });
                }
                  else{
                    this.CompanyPrint.push({
                      'Internal Id': RetData[i].mblId,    
                      'Account Id':RetData[i].accountId, 
                      'Company Name': RetData[i].companyName,
                      'Country': RetData[i].country,
                      'Attention': RetData[i].attention,
                      'Phone Number':  RetData[i].phone ,  
                      'Activation Date': formatDate(RetData[i].activationDate, 'dd-MM-yyyy' ,this.locale), 
                      'Deactivation Date': formatDate(RetData[i].deActivationDate, 'dd-MM-yyyy' ,this.locale),

                    });
                  }
    
                }
              }
              if(exportType == 'PDF')
              {this.exportPdf();}
            }
          }
        );
      }
      exportPdf() {
        import("jspdf").then(jsPDF => {
          import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            //this.= this.employeeExport;
            //this.employeelist=[];
            (doc as any).autoTable(this.exportColumns, this.CompanyPrint);
            doc.save('company.pdf');
          })
        })
      }
    
    //End PDF
    
    //Start Excel
    exportExcel() {
      this.showloader=true
      this.generatePDFData('');
    
     setTimeout(() => {
      this.exportExcelData()
     }, 250);
      }
      exportExcelData()
      {
        if(this.CompanyPrint.length >0)
        { import('xlsx').then((xlsx) => {
             const worksheet = xlsx.utils.json_to_sheet(this.CompanyPrint);
             const workbook = { 
                 Sheets: { data: worksheet }, 
                 SheetNames: ['data'] 
             };
             const excelBuffer: any = xlsx.write(workbook, {
                 bookType: 'csv',
                 type: 'array',
             });
             this.saveAsExcelFile(excelBuffer, 'company');
             this.showloader=false;
         });}
      }
    
      saveAsExcelFile(buffer: any, fileName: string): void {
          let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
          let EXCEL_EXTENSION = '.csv';
          const data: Blob = new Blob([buffer], {
              type: EXCEL_TYPE,
          });
          FileSaver.saveAs(
              data, fileName + EXCEL_EXTENSION
              //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
          );
      }
    //End Excel 
      //List Export option End
    
       /********Export excel */

editview(actionType:any,mainId:any,appId:any)
   {
    if (localStorage.getItem("CompanyFilters") != null)
    {
      localStorage.removeItem("CompanyFilters");
    }
    localStorage.setItem("CompanyFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/company/action', actionType, mainId,appId,0]);
   }

onRowSelect(event: any) {
 // alert(JSON.stringify(event.data.mblId)+' / '+JSON.stringify(event.data.appDataId));
    let mblId = event.data.mblId;
    let appId = event.data.appDataId;
    this.router.navigate(['/main/company/action/view', mblId,appId,0]);
  }
  
   
 GetFilterList() {
  if(this.RetloginDetails.userType=='SUPERADMIN')
{
      if(localStorage.getItem("CompanyFilters") != null)
      {const LocDetails:any =localStorage.getItem("CompanyFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.selectedcompany.country=searcheData.filters.country;
      this.selectedcompany.companyName=searcheData.filters.company;
      this.selectedcompany.activationDate=searcheData.filters.activeDate != undefined ? new Date(searcheData.filters.activeDate ):undefined;
      this.selectedcompany.deActivationDate=searcheData.filters.inactiveDate != undefined ? new Date(searcheData.filters.inactiveDate ):undefined;
      this.loadCompanyData(this.newevent);
      localStorage.removeItem("CompanyFilters");
      }

  }else if(this.RetloginDetails.userType=='ENDUSER'){
  
    if(localStorage.getItem("CompanyFilters") != null)
    {const LocDetails:any =localStorage.getItem("CompanyFilters");
    let RetLocDetails = JSON.parse(LocDetails);
    this.baseSearch=RetLocDetails;
    let searcheData:any = RetLocDetails;
    this.selectedcompany.country=searcheData.filters.country;
    this.selectedcompany.companyName=searcheData.filters.company;
    this.selectedcompany.activationDate=searcheData.filters.activeDate != undefined ? new Date(searcheData.filters.activeDate ):undefined;
    this.selectedcompany.deActivationDate=searcheData.filters.inactiveDate != undefined ? new Date(searcheData.filters.inactiveDate ):undefined;
  this.loadCompanyData(this.newevent);
    localStorage.removeItem("CompanyFilters");
    }
    else
   { this.resetBaseSearch();}
  }
}


}
