import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CompanyInfoRoutingModule } from './company-info-routing.module';
import { CountryInfoListComponent } from './country-info-list/country-info-list.component';
import { CountryInfoAddEditComponent } from './country-info-add-edit/country-info-add-edit.component';


import { Button, ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { ToastModule } from 'primeng/toast';
import { MegaMenuModule } from 'primeng/megamenu';
import { TableModule } from 'primeng/table';
import { MessageModule } from 'primeng/message';
import { CardModule } from 'primeng/card';
import { ChartModule } from 'primeng/chart';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { CalendarModule } from 'primeng/calendar';
import { SidebarModule } from 'primeng/sidebar';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { MessagesModule } from 'primeng/messages';
import { TabMenuModule } from 'primeng/tabmenu';
import { DialogModule } from 'primeng/dialog';
import { TabViewModule } from 'primeng/tabview';
import { SharedModule } from 'primeng/api';
import { SharedComponentsModule } from 'src/app/shared/shared-components/shared-components.module';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { MultiSelectModule } from 'primeng/multiselect';
import { FieldsetModule } from 'primeng/fieldset';
import { InputSwitchModule } from 'primeng/inputswitch';
import { PasswordModule } from "primeng/password";
import { DividerModule } from "primeng/divider";
import { TagModule } from "primeng/tag";
import {InputNumberModule} from 'primeng/inputnumber';

@NgModule({
  declarations: [
    CountryInfoListComponent,
    CountryInfoAddEditComponent
  ],
  imports: [
    CommonModule,
    CompanyInfoRoutingModule,
    PanelModule,
    TableModule,
    TabMenuModule,
    TabViewModule,
    SharedComponentsModule,
    DialogModule,
    ButtonModule,
    DropdownModule,
    InputTextModule,
    FormsModule,
    CheckboxModule,
    ReactiveFormsModule,
    ToggleButtonModule,
    MultiSelectModule,
    CalendarModule,
    FieldsetModule,
    InputSwitchModule,
    PasswordModule,
    TagModule,
    FieldsetModule,
    DividerModule,
    InputNumberModule,
    ProgressSpinnerModule,
    CardModule,
    OverlayPanelModule,
  ]
})
export class CompanyInfoModule { }
