export class CountryModel {
    country_name?: string;
    country_phone_code?: number;
    country_short_name?: string;
    country?: string;
  }
  export class company{
    id?: any;
    appDataId?:any;
    companyName: any;
    accountId: string;
    dataCenter: string;
    activationDate: any;
    deActivationDate: any;
    email: any;
    fullName: any;
    vat: any;
    website: any;
    currency: any;
    country: any;
    attention: any;
    addressee: any;
    phone: any;
    address1: any;
    address2: any;
    city: any;
    state: any;
    zipCode: any;
    companyLogoMetadata: any;
    companyLogo: any;
    createdDate: any;
    createdBy: any;
    lastModifiedDate: any;
    lastModifiedBy: any;
    deleted: any;
    employee: any;
    companyDataAddress:companyDataAddress={};
    register:boolean;
    databaseCreated:boolean;
    // id:number;
    // companyName:string;
    // accountID:string;
    // dataCenter:string;
    // date:Date;
    // website:string;
    // currency:string;
    // country:string;
    // companyLogoMetadata:string;
    // companyLogo:string;
    // companyDataAddress:companyDataAddress[]=[];
    // createdDate: Date;
    // createdBy?: string;
    // lastModifiedDate: Date;
    // lastModifiedBy: string;
    // deleted:boolean;
    // vat:string;
  }

  export class companyDataAddress
  {
        id?:number;
        companyDataId?:number;
        country?:string;
        attention?:string;
        addressee?:string;
        phone?:string;
        address1?:string;
        address2?:string;
        city?:string;
        state?:string;
        zipcode?:any;
        deleted?:boolean;
  }

  export class Employee {
    id: number;
    subsidiaryId: number;
    initials: string;
    designation: string;
    employeeNumber: string;
    email: string;
    department: string;
    salutation: string;
    pan: string;
    currency: string;
    firstName: string;
    middleName: string;
    employee: string;
    lastName: string;
    supervisor: string;
    signatureMetadata: string;
    signature: string;
    imageMetadata:string;
    image: string;
    createdDate: Date;
    createdBy?: string;
    lastModifiedDate: Date;
    lastModifiedBy: string;
    deleted: boolean;
    rcm: boolean;
    itc: boolean;
    // employeeContact: EmployeeContact = {};
    // employeeAccounting: EmployeeAccounting = {};
    employeeAddresses:Employeeaddresses[] = [];
    // employeeAccess: EmployeeAccess = {
    //     employeeRoles: []
    // };
    status: boolean;
    contactNumber: string;
    active: boolean=true;
    fullName:string;
}

export class Employeeaddresses
{
            id?: number;
            employeeId?: number;
            employeeNumber?: string;
            address1?: string;
            address2?: string;
            city?: string;
            state?: string;
            pin?: string;
            country?:string;
            createdDate?: Date;
            createdBy?: string;
            lastModifiedDate?: Date;
            lastModifiedBy?: string;
            deleted?: boolean;
           
}

export class CountryMDL{
  country_name?: string;
  country_phone_code?: number;
  country_short_name?: string;
  country?: string;
}
export class StateMDL {
  state_name?: string;
  state?: string;
}
export class CityMDL {
  city_name?: string;
  city?: string;
}
// Base seach model for Supplier
export class BaseSearch {
  filters: SupplierFilter | {} = {};
  pageNumber: number = 0;
  pageSize: number = 0;
  sortColumn: string = '';
  sortOrder: string = '';
}
export class SupplierFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}

export class license_data
{
    id:number;
    userId:number;
    description:string;
    description2:string;
    description3:string;
    description4:string;
    segmentName:string;
    price:any;
    numberOfSubsidiary:number;
    minUser:number;
    monthlyPrice:any;
    monthlyUserDisount:any;
    monthlyPricePerApplication:any;
    monthlyApplicationDiscount:any;
    yearlyPrice:any;
    yearlyUserDisount:any;
    yearlyPricePerApplication:any;
    yearlyApplicationDiscount:any;
    createdDate: any;
    createdBy: any;
    lastModifiedDate: any;
    lastModifiedBy: any;
    active:boolean;
    flag:boolean;
    deleted:boolean;
    flag2:boolean;
    flag3:boolean;
    flag4:boolean;
    appAvailable:appAvailable[]=[];
    mblId:number;

}

export class appAvailable
{
  id:number;
  appdataid:number;
  available:string;
  createdDate: any;
  createdBy: any;
  lastModifiedDate: any;
  lastModifiedBy: any;
  deleted:boolean;
}

  // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: companyInfo | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class companyInfo {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}
