import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CountryInfoAddEditComponent } from './country-info-add-edit.component';

describe('CountryInfoAddEditComponent', () => {
  let component: CountryInfoAddEditComponent;
  let fixture: ComponentFixture<CountryInfoAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CountryInfoAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CountryInfoAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
