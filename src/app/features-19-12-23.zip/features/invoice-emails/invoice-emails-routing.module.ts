import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InvoiceEmailsAddEditComponent } from './invoice-emails-add-edit/invoice-emails-add-edit.component';
import { InvoiceEmailsListComponent } from './invoice-emails-list/invoice-emails-list.component';
const routes: Routes = [
  {
    path: '',
    component: InvoiceEmailsListComponent,
  },
  {
    path: 'list',
    component: InvoiceEmailsListComponent,
  },
  {
    path: 'list/:status',
    component: InvoiceEmailsListComponent,
  },
  {
    path: 'action/:action/:id',
    component: InvoiceEmailsAddEditComponent,
  },
  {
    path: 'action/:action',
    component: InvoiceEmailsAddEditComponent,
  },
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InvoiceEmailsRoutingModule { }
