export class invoiceemails
{
    id:number;
    accountId:any;
    email:string;
    password:string;
    plainPassword:string;
    subsidiaryName:string;
    appPassword:string;
    subsidiaryId:any;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted:boolean;
    used:boolean;
}
export class InvoiceEmailsList{
    id:number;
    accountId:string;
    email:string;
    password:string;
    plainPassword:string;
    appPassword:string;
    subsidiaryName:string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    used:boolean;
    deleted:boolean;
}

export class BaseSearch {
    filters?: Filter | {} = {};
    pageNumber?: number = 0;
    pageSize?: number = 0;
    sortColumn?: string = '';
    sortOrder?: string = '';
  }
  
  //this class holds the custom filter values at component level.
  export class Filter {
    subsidiary?: string = '';
    vendorname?: string = '';
    vendornumber?: string = '';
    vendortype?: string = '';
    pan?: string = '';
    active?: string = '';
  }
  export class BaseSearchPdf {
    filters: GRNFIlters | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

  //this class holds the custom filter values at component level.
export class GRNFIlters {
    subsidiary: string = '';
    vendorname: string = '';
    vendornumber: string = '';
    vendortype: string = '';
    pan: string = '';
    active: string = '';
  }