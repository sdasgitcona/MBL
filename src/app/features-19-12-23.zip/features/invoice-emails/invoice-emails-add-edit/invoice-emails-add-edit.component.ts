import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { invoiceemails } from '../model/invoice-emails-module';

@Component({
  selector: 'app-invoice-emails-add-edit',
  templateUrl: './invoice-emails-add-edit.component.html',
  styleUrls: ['./invoice-emails-add-edit.component.scss']
})
export class InvoiceEmailsAddEditComponent implements OnInit {
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  role: any;
  invoiceemails: invoiceemails = new invoiceemails();
  displayAddressDialog: boolean = false;
  SubsideryObject:any[]=[];
  lstaccountId:any[];
  projectHistoryList: HistoryModel[] = [];
  projectStatusOptions: any;
  isReloadSub:boolean;
  showloader:boolean=false;
  RetloginDetails:any;
  emailId:number;
  loginId:any;
  RetRoleDetails:any;
  EmailsHistoryList: HistoryModel[] = [];
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   isviewEditable:boolean=true;
  constructor(private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService) { }

    ngOnInit(): void {
      if(localStorage.getItem("LoggerDTLS") == null)
      {
        this.router.navigate(['/login']);
      }
      // For Role Base Access
   const retDetails:any = localStorage.getItem("RoleDTLS");
   var role_Dtls = JSON.parse(retDetails);
   this.RetRoleDetails=role_Dtls;
  
   const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
  this.loginId= this.RetloginDetails.employeeId;
  
   for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
   {
     if(role_Dtls[0].rolePermissions[i].accessPoint == "Invoice Emails")
     {
       this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
       this.isEditable=role_Dtls[0].rolePermissions[i].edit;
       this.isViewtable=role_Dtls[0].rolePermissions[i].view;
       if(this.isEditable==false)
       this.isviewEditable=false;
     }
   }
  // End For Role Base Access
      this.loadaccountId();
      this.subscription = this.activatedRoute.params.subscribe(
        (params) => {
          if (params) {
            if (params['id']) {
              this.emailId = +params['id']; // (+) converts string 'id' to a number
              this.GetInvoiceEmailsbyId();
              this.LoadHistory();
            }
            this.assignMode(params['action']);       
          } else {
            this.showAlert('cannot get params');
          }
     
        },
        (error) => {
          this.showAlert(error);
        }
      );
    }
    //For Modes
    assignMode(action: string) {
      switch (action) {
        case 'add':
          this.addMode = true;
          this.viewMode = false;
          this.editMode = false;
          break;
        case 'edit':
          this.addMode = false;
          this.viewMode = false;
          this.editMode = true;
          break;
        case 'view':
          this.viewMode = true;
          this.addMode = false;
          this.editMode = false;
          break;
  
        default:
          break;
      }
    }
  
////Save Invoice Emails
  saveinvoiceemails()
  {
    if(this.invoiceemails.accountId==undefined)
    {
      this.showAlert("Please select AccountId");
      return;
    }
    if(this.invoiceemails.email==undefined || this.invoiceemails.email=='')
    {
      this.showAlert("Please input Email");
      return;
    }
    if(this.invoiceemails.plainPassword==undefined || this.invoiceemails.plainPassword=='')
    {
      this.showAlert("Please input Password");
      return;
    }
    if(this.invoiceemails.appPassword==undefined || this.invoiceemails.appPassword=='')
    {
      this.showAlert("Please input Application Password");
      return;
    }
    this.invoiceemails.email=this.invoiceemails.email+"@monstarbill.com";
    this.httpService.Insert('/setup-ws/inv-email/save',  this.invoiceemails ,this.RetloginDetails.token).subscribe(
      (res) => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          if (res) {
            this.showSuccess();
            this.showloader=false;
            this.router.navigate(['/main/invoice-emails/list']);
          } else {
            this.showError();
            this.showloader=false;
          }
        }


        
      },
      (error) => {
       this.showAlert(error);
       this.showloader=false;
      },
      () => {}
    );
  }
//Load accountId Lov
  loadaccountId() {
    debugger
    this.httpService.GetAll("/setup-ws/company-data/get-all-account-ids", this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          this.lstaccountId = res;
        }
      });
  }
  //reload button on accountId
  reloadaccountId()
  {
    this.lstaccountId=[];
    this.loadaccountId();
  }
  //////////////get invoice emails by Id
  GetInvoiceEmailsbyId() {
    this.httpService
      .GetById('/setup-ws/inv-email/get?id=' + this.emailId, this.emailId,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { 
        this.invoiceemails = res;
        const split_emails = this.invoiceemails.email.split("@");
        this.invoiceemails.email=split_emails[0];

       }

      });
  }
////////////load history function
  LoadHistory() {
    if (this.EmailsHistoryList.length == 0)
    {
      this.httpService.GetAll('/setup-ws/inv-email/get/history?id='+this.emailId+'&pageSize=100' ,this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          //console.log(res);
          this.EmailsHistoryList = res;
        }

        
      });
    }

  }

/////////////////////////Messages and alerts////////////////////
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Invoice Emails Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Invoice Emails!'
    );
  }
  chkforstring(event:any)

    {

       let result = this.invoiceemails.email.includes("@");
       let result_ = this.invoiceemails.email.includes(".com");
       if(result)
       {
        this.showAlert("Email contains @ , Please input Email");
        this.invoiceemails.email="";
        return
       }
       else if(result_)
       {
        this.showAlert("Email name contains .com , Please input Email");
        this.invoiceemails.email="";
        return
       }
    }
}
