import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceEmailsAddEditComponent } from './invoice-emails-add-edit.component';

describe('InvoiceEmailsAddEditComponent', () => {
  let component: InvoiceEmailsAddEditComponent;
  let fixture: ComponentFixture<InvoiceEmailsAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InvoiceEmailsAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InvoiceEmailsAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
