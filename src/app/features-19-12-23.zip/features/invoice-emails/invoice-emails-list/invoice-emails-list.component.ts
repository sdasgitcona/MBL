import { Component, OnInit,LOCALE_ID, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { ToastService } from 'src/app/core/services/toast.service';
import { invoiceemails,InvoiceEmailsList,BaseSearch,BaseSearchPdf } from '../model/invoice-emails-module';
@Component({
  selector: 'app-invoice-emails-list',
  templateUrl: './invoice-emails-list.component.html',
  styleUrls: ['./invoice-emails-list.component.scss']
})
export class InvoiceEmailsListComponent implements OnInit {
  isEditable:boolean;
  isCreatetable:boolean=true;
  isViewtable:boolean;
  columns: any[];
  Elist:any;
  invoiceemails: invoiceemails = new invoiceemails();
  selectedinvoiceemails: invoiceemails = new invoiceemails();
  loading: boolean = false;
  totalRecords: number = 0;
  showloader:boolean=false;
  RetloginDetails:any;
  SubIdList:any=[];
  emailId:number;
  loginId:any;
  newevent:any;
  exportColumns: any[];
  Subsidiarylist:any[]=[];
  InvoiceEmailsList: InvoiceEmailsList[]=[];
  baseSearch: BaseSearch = new BaseSearch();
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  RetRoleDetails:any;
  invoiceEmailsId:any;
  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService) { }

    ngOnInit(): void {
      if(localStorage.getItem("LoggerDTLS") == null)
      {
        this.router.navigate(['/login']);
      }
      // For Role Base Access
      const retDetails:any = localStorage.getItem("RoleDTLS");
      var role_Dtls = JSON.parse(retDetails);
      this.RetRoleDetails=role_Dtls;
  
      const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
  
      for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
      {
        if(role_Dtls[0].rolePermissions[i].accessPoint == "Invoice Emails")
        {
          this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
          this.isEditable=role_Dtls[0].rolePermissions[i].edit;
          this.isViewtable=role_Dtls[0].rolePermissions[i].view;
        }
      }
      this.GetSubsideryList();
      this.columns = [
                      { field: 'Id', header: 'Internal ID' },
                      { field: 'Subsidiary', header: 'Subsidiary' },
                      { field: 'GRN Number', header: 'GRN Number' },
                      { field: 'Date', header: 'Date' },
                      { field: 'PO Number', header: 'PO Number' },
                      { field: 'Vendor', header: 'Vendor' },
                      { field: 'Location', header: 'Location' },
                      { field: 'Receiver', header: 'Receiver' },
                      { field: 'Status', header: 'Status' },
  
      
      ];
     this.exportColumns = this.columns.map(col => ({
       title: col.header,
       dataKey: col.field
     }));

    }
   //Navigate to add-edit page 
  navigateToAddViewEdit(action: string,) {
    let employeeId = null;
    if (this.selectedinvoiceemails?.id) {
      this.invoiceEmailsId = this.selectedinvoiceemails.id;
      this.router.navigate(['/main/invoice-emails/action', action, this.invoiceEmailsId]);
    } else {
      this.router.navigate(['/main/invoice-emails/action', action]);
    }
    console.log('Action is ' + action);
   
  }
  //Load Subsidiary LOV
  GetSubsideryList() {
    if(this.RetloginDetails.userType=='SUPERADMIN')
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
     
   // this.HttpService.GetAll("/setup-ws/subsidiary/get/all" ,this.RetloginDetails.token).subscribe(
      (res) => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        { //console.log(res);
          this.Subsidiarylist = res;
          for(let x=0;x<this.Subsidiarylist.length;x++)
          { 
           this.SubIdList.push(this.Subsidiarylist[x].id);
         }
     
        }
       
      },
      (error) => {
        console.log(error);
      },
      () => {

      }
    );
  }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
      this.invoiceemails.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);

    }
  }

  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.INVOICE_EMAILS_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadinvoiceemailsList(this.newevent);
  }
  //Load Invoice List
  loadinvoiceemailsList(event:any) {
    try {
      this.newevent=event
      this.loading = true;
      //this.baseSearch.pageNumber = event.first / event.rows;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      this.baseSearch.pageSize = event.rows;
      this.baseSearch.sortColumn = event.sortField
      ?  event.sortField
      : GlobalConstants.INVOICE_EMAILS_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
        //  this.baseSearch.sortColumn="grn_number";
        if(this.SubIdList.length==0 && this.RetloginDetails.userType!='ROOTADMIN')
        {
         return;
        }
      this.HttpService.Insert('/setup-ws/inv-email/get/all', this.baseSearch ,this.RetloginDetails.token).subscribe(
        (res) => {

          //For Auth
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
          else
          {
            //console.log(res);
            if (res && res.list.length > 0) {
              this.InvoiceEmailsList = res.list;
              this.totalRecords = res.totalRecords;
            } else {
              this.InvoiceEmailsList = [];
              this.totalRecords=0
            }
            this.loading = false;
          }
        },
        (error) => {
          console.log(error);
          this.loading = false;
        }
      );
    } catch (err) {
    }
  }

  findby(event: any){
    let subsidyList:any=[];
    subsidyList.push(this.invoiceemails.subsidiaryId);
    this.baseSearch.filters={
      accountId:this.invoiceemails.accountId,
      used:this.invoiceemails.used==true?"true":"false",
      subsidiaryName:this.invoiceemails.subsidiaryName

  }
   this.baseSearch.pageNumber=-1;
  
   this.loadinvoiceemailsList(this.newevent);
  }

  Reset(){
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.invoiceemails.subsidiaryId =undefined;
    }
    this.invoiceemails.accountId=undefined;
    this.resetBaseSearch();
    this.loadinvoiceemailsList(this.newevent);
  }
  //transfer to edit and view 
  editview(actionType:any,mainId:any)
  {
     this.router.navigate(['/main/invoice-emails/action', actionType, mainId]);
  }

  ///////////Messages and alerts//////////////
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
}
