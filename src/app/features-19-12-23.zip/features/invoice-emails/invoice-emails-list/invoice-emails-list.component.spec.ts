import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceEmailsListComponent } from './invoice-emails-list.component';

describe('InvoiceEmailsListComponent', () => {
  let component: InvoiceEmailsListComponent;
  let fixture: ComponentFixture<InvoiceEmailsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InvoiceEmailsListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InvoiceEmailsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
