import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchases-requisition',
  templateUrl: './purchases-requisition.component.html',
  styleUrls: ['./purchases-requisition.component.scss']
})
export class PurchasesRequisitionComponent implements OnInit {
  constructor(
  ) { }

  ngOnInit(): void {
  }
}
