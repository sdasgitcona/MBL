import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchasesRequisitionListComponent } from './purchases-requisition-list.component';

describe('PurchasesRequisitionListComponent', () => {
  let component: PurchasesRequisitionListComponent;
  let fixture: ComponentFixture<PurchasesRequisitionListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurchasesRequisitionListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PurchasesRequisitionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
