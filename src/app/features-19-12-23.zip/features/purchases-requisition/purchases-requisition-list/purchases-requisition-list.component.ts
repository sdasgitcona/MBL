import { Component, OnInit, ViewChild,LOCALE_ID, Inject} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { PurchasesRequisition, PurchasesRequisitionFilter, BaseSearch, file_upliad,BaseSearchPdf,send_for_approval_object } from '../model/purchases-requisition.model';

import { ToastService } from 'src/app/core/services/toast.service';
import { HttpHeaderResponse, HttpHeaders } from '@angular/common/http';
import { saveAs } from 'file-saver';
import { PrReportComponent } from '../../reports/pr-report/pr-report.component';
import * as FileSaver from 'file-saver';
import {formatDate } from '@angular/common';
@Component({
  selector: 'app-purchases-requisition-list',
  templateUrl: './purchases-requisition-list.component.html',
  styleUrls: ['./purchases-requisition-list.component.scss']
})
export class PurchasesRequisitionListComponent implements OnInit {
  baseSearch: BaseSearch = new BaseSearch();
  prList: PurchasesRequisition[] = [];
  SubsideryObject: any = [];
  exportColumns: any[];
  prFilter: PurchasesRequisitionFilter = new PurchasesRequisitionFilter();
  selectedPr: PurchasesRequisition = new PurchasesRequisition();
  send_for_approval_object:any={};
  //baseSearchPr: BaseSearch = new BaseSearch();
  columns: any[] = [];
  totalRecords: number = 0;
  loading: boolean = false;
  lastPTableSearchEvent: any;
  departmentOptions: any;
  EmployeeList: any[];
  RetloginDetails: any;
  file: File;
  displayModal: boolean;
  file_upliad: file_upliad = new file_upliad();
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  PRPrint: any[] = [];
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  // For Role Base Access
  RetRoleDetails: any;
  SubIdList: any = [];
  showloader: boolean;
  newevent: any;
  PRList:any;
  Locationlist:any;
  priorityOptions: any;
  statusOptions:any;
  ApprovalButtonShowHide: Number = 0;
  isParams: boolean = true;
  status:any;
  date_to:any;
  date_from:any;
  constructor(
    private router: Router,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private activatedRoute: ActivatedRoute,
    private toastService: ToastService,private prReport: PrReportComponent,@Inject(LOCALE_ID) public locale: string
  ) {
    //this.departmentOptions = ["Admin", "HR", "Finance", "Purchase", "Production"]
    this.priorityOptions = ["High", "Medium", "Low"]
    this.statusOptions = ['Draft', 'Pending Approval', 'Partially Approved', 'Approved', 'Rejected', 'Partially Processed', 'Processed'];
  }

  ngOnInit(): void {
    if (localStorage.getItem("LoggerDTLS") == null) {
      this.router.navigate(['/login']);
    }
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails = role_Dtls;

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Purchase Requisition") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
      }
    }
    // End For Role Base Access

    this.GetSubsideryList();
    this.primengConfig.ripple = true;
    this.columns = [
      { field: 'Id', header: 'Internal ID' },
      { field: 'Subsidiary', header: 'Subsidiary' },
      { field: 'Location', header: 'Location' },
      { field: 'PR Date', header: 'PR Date' },
      { field: 'PR Number', header: 'PR Number' },
      { field: 'Department', header: 'Department' },
      { field: 'Project Name', header: 'Project' },
      { field: 'Estimated Total Amount', header: 'Amount' },
      { field: 'Prioritry', header: 'Priority' },
      { field: 'Requestor', header: 'Requestor' },
      { field: 'PR Status', header: 'PR Status' },

    ];
     this.exportColumns = this.columns.map(col => ({
       title: col.header,
       dataKey: col.field
     }));

    // For Getting Filtered Data from Dashboard
    let subsidyList: any = [];
    subsidyList.push(this.prFilter.subsidiaryId);
    this.activatedRoute.params.subscribe((params) => {
      if (params) {
        if (params['status']) {
          this.isParams = true;
          this.status = params['status']
          if(this.status == 'Recent'){
            this.getDate();
            this.baseSearch.filters = {
              subsidiaryId: subsidyList,
              recentlyCreated:this.prFilter.recentlyCreated = true,
              roleId:this.RetRoleDetails[0].id
            }
            this.baseSearch.pageNumber = -1;
            this.loadPrs(this.newevent);
          } else if(this.status == 'High'){
            this.baseSearch.filters = {
              subsidiaryId: subsidyList,
              priority:this.prFilter.priority = this.status,
              roleId:this.RetRoleDetails[0].id
            }
          } else if(this.status == 'null'){
            this.baseSearch.filters = {
              subsidiaryId: subsidyList,
              priority:this.prFilter.priority = this.status,
              roleId:this.RetRoleDetails[0].id
            }
           } else {
            this.baseSearch.filters = {
              subsidiaryId: subsidyList,
              status:this.prFilter.status=this.status,
              roleId:this.RetRoleDetails[0].id
            }
            this.baseSearch.pageNumber = -1;
            this.loadPrs(this.newevent);
          }
        } 
      }
    });
    // For Getting Filtered Data from Dashboard
  }

  /* Start Fetch Subsidery list from api */
  GetSubsideryList() {
    if(this.RetloginDetails.userType=='SUPERADMIN'){
   // if (this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null) {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId=' + this.RetRoleDetails[0].accountId, this.RetloginDetails.token).subscribe(

        //this.HttpService.GetAll('/setup-ws/subsidiary/get/all',this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.SubsideryObject = res;
            for (let x = 0; x < this.SubsideryObject.length; x++) {
              this.SubIdList.push(this.SubsideryObject[x].id);
            }
          }
        },
        (error) => {
          this.showAlert(error);
        },
        () => {
          if(localStorage.getItem("PRFilters") != null)
          {const LocDetails:any =localStorage.getItem("PRFilters");
          let RetLocDetails = JSON.parse(LocDetails);
          this.baseSearch=RetLocDetails;
          let searcheData:any = RetLocDetails;
          this.prFilter.department=searcheData.filters.department;
          this.prFilter.name=searcheData.filters.name;
          this.prFilter.locationId=searcheData.filters.locationId;
          this.prFilter.priority=searcheData.filters.priority;
          this.prFilter.projectName=searcheData.filters.projectName;
          this.prFilter.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
          this.prFilter.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
          this.prFilter.requestor=searcheData.filters.requestor;
          this.prFilter.status=searcheData.filters.status;
          this.loadPrs(this.newevent);
          localStorage.removeItem("PRFilters");
          }
          else
         { this.resetBaseSearch();}
        }
      );
    }
    else if(this.RetloginDetails.userType=='ENDUSER') {
      this.prFilter.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
      this.SubsideryObject.push({
        "id": this.RetRoleDetails[0].subsidiaryId,
        "name": this.RetRoleDetails[0].subsidiaryName
      });
      
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.getLocationList();
      this.fnRequesterList();
      this.GetDepartmentList();
      if(localStorage.getItem("PRFilters") != null)
      {const LocDetails:any =localStorage.getItem("PRFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.prFilter.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.prFilter.department=searcheData.filters.department;
      this.prFilter.name=searcheData.filters.name;
      this.prFilter.locationId=searcheData.filters.locationId;
      this.prFilter.priority=searcheData.filters.priority;
      this.prFilter.projectName=searcheData.filters.projectName;
      this.prFilter.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
      this.prFilter.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.prFilter.requestor=searcheData.filters.requestor;
      this.prFilter.status=searcheData.filters.status;
      this.loadPrs(this.newevent);
      localStorage.removeItem("PRFilters");
      
      }
      else
      {this.resetBaseSearch();}
    }
  }
  resetBaseSearch() {
    this.baseSearch.filters = { subsidiaryId: this.SubIdList,roleId:this.RetRoleDetails[0].id };
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.PR_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.DESCENDING;
    this.loadPrs(this.newevent);
  }

  ReloadSubsidiaryList() {
    this.prFilter.subsidiaryId = undefined;
    this.GetSubsideryList();
  }
  // loadPrs(event: any) {
  //   try {
  //     this.lastPTableSearchEvent = event;
  //     this.loading = true;
  //     let pagecalculate=event.first / event.rows;
  //     this.baseSearchPr.pageNumber =event.first / event.rows;// pagecalculate == 1 || pagecalculate == 2 ? 0 :pagecalculate;
  //     this.baseSearchPr.pageSize = event.rows;
  //     this.baseSearchPr.sortColumn = event.sortField
  //       ? event.sortField
  //       : GlobalConstants.PR_TABLE_SORT_COLUMN;
  //     this.baseSearchPr.sortOrder =
  //       event.sortOrder== -1
  //         ? GlobalConstants.DESCENDING
  //         : GlobalConstants.ASCENDING;
  //     this.HttpService.Insert('/procure-ws/pr/get/all', this.baseSearchPr).subscribe(
  //       (res) => {
  //         if (res && res.list.length > 0) {
  //           this.prList = res.list;
  //           this.totalRecords = res.totalRecords;
  //         } else {
  //           this.prList = [];
  //           this.totalRecords = 0;
  //         }
  //         this.loading = false;
  //       },
  //       (error) => {
  //         this.showAlert(error);
  //         this.loading = false;
  //       }
  //     );
  //   } catch (err) {
  //     this.showAlert(err);
  //   }
  // }

  loadPrs(event: any) {
    try {
      //this.lastPTableSearchEvent = event;
      this.newevent = event;
      this.loading = true;
      //let pagecalculate=event.first / event.rows;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1) ? 0 : (event.first / event.rows);
      //this.baseSearchPr.pageNumber =event.first / event.rows;// pagecalculate == 1 || pagecalculate == 2 ? 0 :pagecalculate;
      this.baseSearch.pageSize = event.rows;
      this.baseSearch.sortColumn = event.sortField
        ? event.sortField
        : GlobalConstants.PR_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
          
          if(this.SubIdList.length==0)
         {
          return;
         }

      this.HttpService.Insert('/procure-ws/pr/get/all', this.baseSearch, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.prList = [];
            if (res && res.list.length > 0) {
              this.prList = res.list;
              this.totalRecords = res.totalRecords;

              for(let x=0;x<this.prList.length;x++) 
              {
                //this.prList[x].amount=this.prList[x].amount.toFixed(2);
                if( this.prList[x].prStatus == 'Pending Approval' || this.prList[x].prStatus == 'Processed' || this.prList[x].prStatus == 'Partially Processed' || this.prList[x].prStatus == 'Approved' || this.prList[x].prStatus == 'Closed' || this.prList[x].prStatus == 'Partially Approved') //Send Approval Mode
                {
                  this.prList[x].isApprovalButtonShowHide = 0;
                //this.ApprovalButtonShowHide=0;
                }
                else{
                  this.prList[x].isApprovalButtonShowHide = 1;
                  //this.ApprovalButtonShowHide=1;
                }
              }
             

            } else {
              this.prList = [];
              this.totalRecords = 0;
            }
            this.loading = false;
          }
        },
        (error) => {
          this.showAlert(error);
          this.loading = false;
        }
      );
    } catch (err) {
      //this.showAlert(err);
    }
  }

  /* Start fetch filter list of supplier from api */
  findby(event: any) {

    let requester="";
    let subsidyList: any = [];
    subsidyList.push(this.prFilter.subsidiaryId);

    let Fromdays: any = new Date(this.prFilter.fromDate).getUTCDate();
    let Frommonths: any = new Date(this.prFilter.fromDate).getUTCMonth() + 1;
    let Fromyear: any = new Date(this.prFilter.fromDate).getUTCFullYear();

    let Todays: any = new Date(this.prFilter.toDate).getUTCDate();
    let Tomonths: any = new Date(this.prFilter.toDate).getUTCMonth() + 1;
    let Toyear: any = new Date(this.prFilter.toDate).getUTCFullYear();

    if(this.prFilter.requestor!=undefined)
    {
      requester = this.prFilter.requestor.toString();
    }
    this.baseSearch.filters = {
      subsidiaryId: subsidyList,//this.prFilter.subsidiaryId !== undefined ?  this.prFilter.subsidiaryId :0,
      fromDate:this.prFilter.fromDate !== undefined ? (Fromyear + '-' + (Frommonths.toString().length == 1 ? "0" + Frommonths : Frommonths) + '-' + (Fromdays.toString().length == 1 ? "0" + Fromdays : Fromdays)) : undefined,
      toDate:this.prFilter.toDate !== undefined ? (Toyear + '-' + (Tomonths.toString().length == 1 ? "0" + Tomonths : Tomonths) + '-' + (Todays.toString().length == 1 ? "0" + Todays : Todays)) : undefined,
      department: this.prFilter.department !== undefined ? this.prFilter.department : 0,
      name:this.prFilter.name,
      locationId:this.prFilter.locationId,
      priority:this.prFilter.priority,
      status:this.prFilter.status,
      projectName:this.prFilter.projectName,
      roleId:this.RetRoleDetails[0].id,
      recentlyCreated:this.prFilter.recentlyCreated,
      requestor: this.prFilter.requestor != "" ? this.prFilter.requestor?.trim():''
      //prDate: this.prFilter.prDate !== undefined ? (year + '-' + (months.toString().length == 1 ? "0" + months : months) + '-' + (days.toString().length == 1 ? "0" + days : days)) : "",
      //requester: this.prFilter.requester !== undefined ? this.prFilter.requester : "",
      //projectName:null
    }
    this.baseSearch.pageNumber = -1;
    if (localStorage.getItem("PRFilters") != null)
    {
      localStorage.removeItem("PRFilters");
    }
    localStorage.setItem("PRFilters", JSON.stringify(this.baseSearch));
    //this.loadPrs(this.lastPTableSearchEvent);
    this.loadPrs(this.newevent);
  }

  Reset() {
    this.prFilter.subsidiaryId = undefined;
    this.prFilter.requester = undefined;
    this.prFilter.department = undefined;
    this.prFilter.fromDate = undefined;
    this.prFilter.toDate = undefined;
    this.prFilter.name = undefined;
    this.prFilter.locationId = undefined;
    this.prFilter.priority = undefined;
    this.prFilter.status = undefined;
    this.prFilter.projectName = undefined;
    this.prFilter.requestor=undefined;
    this.resetBaseSearch();
    this.baseSearch.pageNumber=-1;
    this.loadPrs(this.newevent);
    if (this.RetRoleDetails[0].accountId != null && this.RetRoleDetails[0].subsidiaryId != null) {
     this.prFilter.subsidiaryId =this.RetRoleDetails[0].subsidiaryId;
     
    }
  }
  navigateToAddViewEdit(
    action: string,
    selectedPr: PurchasesRequisition = new PurchasesRequisition()
  ) {
    let supplierId = null;
    if (selectedPr?.id) {
      supplierId = selectedPr.id;
      this.router.navigate(['/main/purchases-requisition/action', action, supplierId]);
    } else {
      this.router.navigate(['/main/purchases-requisition/action', action]);
    }
  }
 /* exportPdf() {
    import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
        const doc = new jsPDF.default();
        (doc as any).autoTable(this.exportColumns, this.prList);
        doc.save('pr.pdf');
      })
    })
  }*/
  //----Suman Addition


  fnRequesterList()
{
  
  this.HttpService.GetById('/masters-ws/employee/get-employee-by-subsidiary?subsidiaryId=' + this.prFilter.subsidiaryId, this.prFilter.subsidiaryId,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

      if (res != undefined) {
        this.EmployeeList=[];
      this.EmployeeList = res;
      }
    }
    },
    (error) => {
      this.showAlert(error);
    },
    ()=>{
    
    }
    );
}
  onSubsidiaryChange()
  {
  //  this.GetPRList();
    this.getLocationList();
    this.fnRequesterList();
    this.GetDepartmentList();
  }
//--PR List
GetPRList() {
  //status--approved, partially processed
    this.HttpService.GetAll('/procure-ws/pr/get-prs-by-subsidiary?subsidiaryId='+this.prFilter.subsidiaryId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
        { 
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { 
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {
       this.PRList=res;  // Edited by Aftab
      }
      },
      (error) => {
       this.showAlert(error);
      }
    );
  }
getLocationList()
{
  this.HttpService.GetAll('/masters-ws/location/get/all/lov?subsidiaryId='+this.prFilter.subsidiaryId ,this.RetloginDetails.token).subscribe(
    (res) => {
      //For Auth
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else
      {
        this.Locationlist=[]
        for (const [key, value] of Object.entries(res)) {
          this.Locationlist.push({locationId:Number(key),name:value})
        }
      } 
    },
    (error) => {
     this.showAlert(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    }
  );
}

  // CSV UPLOAD
  csvUploadDownload() {
    this.displayModal = true;
  }

  @ViewChild('attachments') attachment: any;

  fileList: File[] = [];
  listOfFiles: any[] = [];
  isLoading = false;

  onFileChanged(event: any) {
    this.isLoading = true;
    this.file = event.target.files[0];
    this.listOfFiles = []
    //this.listOfFiles.push(this.file.name);
    this.listOfFiles.push({subsidiary:this.RetRoleDetails[0].subsidiaryName,file:this.file .name});
    this.isLoading = false;
  }

  uploadFile(event: any) {
    const httpOptions = {
      headers: new HttpHeaders({
        "mimeType": "multipart/form-data",
        "Content-Type": "false"
      })
    };

    const formData = new FormData();

    formData.append('file', this.file);
   // this.HttpService.uploadFile_("/procure-ws/pr/upload", formData, {responseType: 'blob'}, this.RetloginDetails.token)
    this.HttpService.uploadFile_("/procure-ws/pr/upload?subsidiaryId=" +this.RetRoleDetails[0].subsidiaryId + '&requestor='+this.RetloginDetails.empName ,formData,{responseType: 'blob'} ,this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.executeSaveAs(res)
          if (res.error) {
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
          }
          else {

            this.toastService.addSingle(
              'success',
              'Success',
              'File uploaded Successfully!'
            );
            window.location.reload();
          }
        }
      },
        error => {
          this.showAlert(error);
        },
        () => { });
  }

  onFileChanged1(event: any) {
    this.file = event.target.files[0];
    this.HttpService.uploadFile("/procure-ws/pr/upload", this.file, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
          }
          else {
            this.toastService.addSingle(
              'success',
              'Success',
              'File uploaded Successfully!'
            );
            window.location.reload();
          }
        }
      },
        error => {
          this.showAlert(error);
        },
        () => {

          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }


  removeSelectedFile(index: number) {
    // Delete the item from fileNames list
    this.listOfFiles.splice(index, 1);
    // delete file from FileList
    this.fileList.splice(index, 1);
  }
  executeSaveAs(content: any) {
   // let blob = new Blob([content], { 'type': "application/octet-stream" });
    saveAs(content, "Purchase Requisition.xlsx"); // This is from https://github.com/eligrey/FileSaver.js
  };


  DownloadTemplete() {
    // let Endurl:any = {
    //   url: this.HttpService.baseUrl+"/procure-ws/pr/download-template",
    //   httpHeaders: { Authorization: 'Bearer '+this.RetloginDetails.token }
    // }
    //window.open(Endurl)
    //window.open(this.HttpService.baseUrl+"/procure-ws/pr/download-template");


    this.HttpService.downloadFile("/procure-ws/pr/download-template", this.RetloginDetails.token)
      .subscribe(res => {
        saveAs(res, 'Purchase Requisition.xlsx');
        //this.executeSaveAs(res);
        //let blob = new Blob([res], {'type': "application/octet-stream"});
        //window.open(res)
      });
  }

    // Download Report 
    DownloadReport_old(prNumber: any) {
      window.open(this.HttpService.ReportUrl + "/run?__report=report/Purchase_Requisition.rptdesign&__format=pdf&pr_number=" + prNumber, '_blank')
    }

  DownloadReport(prNumber:any,type:any){                      //pr pdf changes 140823
    this.showloader=true;
  
  this.prReport.exportPdf(prNumber,type);  //pr pdf changes 140823
  this.showloader=false;

  //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
  }

  showAlert(AlertMSG: any) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }

  selfApproval(id:any){
    let action: string;
    this.showloader=true;
    this.HttpService
      .GetById('/procure-ws/pr/self-approve?prId=' + id, id,this.RetloginDetails.token)

      .subscribe((res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

       // this.pr = res;
       if (res == true) {
        this.toastService.addSingle(
          'success',
          'Success',
          'PR Approved Successfully!'
        );
        this.showloader=false;
        window.location.reload();
       } else {
        this.showAlert(res.errorMessage);
        this.showloader=false;
        //this.router.navigate(['/main/purchases-requisition/action', action, this.prId]);
      }
    }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending PR for Approval!'
          );
          this.showloader=false;
        }
      );
  }
  sendForApproval(id:any,prNumber:any,type:any){          //pr pdf changes 140823
    this.DownloadReport(prNumber,type);    //pr pdf changes 140823
    setTimeout(() => { 
      this.showloader=true;
    this.send_for_approval_object.id=id;
    this.send_for_approval_object.base64=this.prReport.base64;
    let action: string;
    
    this.HttpService.Insert('/procure-ws/pr/send-for-approval', this.send_for_approval_object, this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

       // this.pr = res;
       if (res == true) {
        this.toastService.addSingle(
          'success',
          'Success',
          'PR Sent for Approval Successfully!'
        );
        this.showloader=false;
        window.location.reload();
       } else {
        this.showAlert(res.errorMessage);
        this.showloader=false;
        //this.router.navigate(['/main/purchases-requisition/action', 'view',this.prId]);
        //this.router.navigate(['/main/purchases-requisition/list']);

              // [routerLink]="['/main/purchases-requisition/action/view', item.id]
      
      }
    }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending PR for Approval!'
          );
          this.showloader=false;
        });
        
      },200);
  }

  getDate() {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
    const day = (currentDate.getDate()-1).toString().padStart(2, '0');
    this.date_to = `${year}-${month}-${day}`;
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(currentDate.getDate() - 7);
    const fromYear = sevenDaysAgo.getFullYear();
    const fromMonth = (sevenDaysAgo.getMonth() + 1).toString().padStart(2, '0');
    const fromDay = sevenDaysAgo.getDate().toString().padStart(2, '0');
    this.date_from = `${fromYear}-${fromMonth}-${fromDay}`;
  }

  GetDepartmentList() {

    //this.HttpService.GetAll('/masters-ws/department/get-parent-department-names?subsidiaryId='+this.prFilter.subsidiaryId,this.RetloginDetails.token).subscribe(
  this.HttpService.GetAll('/masters-ws/department/get/all/lov?subsidiaryId='+ this.prFilter.subsidiaryId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      //this.departmentOptions = res;
      this.departmentOptions=[]
      Object.keys(res).forEach(key => { 
        this.departmentOptions.push({
            "id":Number(key),
            "departmentName":res[key]
          })   
        });
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}

editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("PRFilters") != null)
    {
      localStorage.removeItem("PRFilters");
    }
    localStorage.setItem("PRFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/purchases-requisition/action', actionType, mainId,0]);
   }

  /***((Export Excel)) */
  generatePDFData(exportType:any){
    this.newevent = event;
    this.baseSearchPdf.pageSize = this.totalRecords;
    this.baseSearchPdf.sortColumn =GlobalConstants.PR_TABLE_SORT_COLUMN;
    this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
     debugger
    this.HttpService.Insert('/procure-ws/pr/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //this.employeelistPrint = [];
          this.PRPrint = [];
          if (res && res.list.length > 0) {
            var RetData = res.list;
            for (let i = 0; i < RetData.length; i++) {

              if (RetData[i].id == undefined) {
                RetData[i].id = "";
              }



              if(exportType == 'PDF'){ 
                this.PRPrint.push({
                  'Id': RetData[i].id,    
                  'Subsidiary':RetData[i].subsidiaryName, 
                  'Location':  RetData[i].locationName,
                  'PR Date': formatDate(RetData[i].prDate, 'dd-MM-yyyy' ,this.locale),
                  'PR Number': RetData[i].prNumber,
                  'Department': RetData[i].department,  
                  'Project Name':RetData[i].projectName, 
                  'Estimated Total Amount': RetData[i].amount,
                  'Prioritry': RetData[i].priority,
                  'Requestor': RetData[i].requestor,
                  'PR Status': RetData[i].prStatus

                  // 
               
              });
            }
              else{
                this.PRPrint.push({
                  'Internal Id': RetData[i].id,    
                  'Subsidiary':RetData[i].subsidiaryName, 
                  'Location':  RetData[i].locationName,
                  'PR Date': formatDate(RetData[i].prDate, 'dd-MM-yyyy' ,this.locale),
                  'PR Number': RetData[i].prNumber,
                  'Department': RetData[i].department,  
                  'Project Name':RetData[i].projectName, 
                  'Estimated Total Amount': RetData[i].amount,
                  'Prioritry': RetData[i].priority,
                  'Requestor': RetData[i].requestor,
                  'PR Status': RetData[i].prStatus
                });
              }

            }
          }
          if(exportType == 'PDF')
          {this.exportPdf();}
        }
      }
    );
  }
  exportPdf() {
    import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
        const doc = new jsPDF.default();
        //this.= this.employeeExport;
        //this.employeelist=[];
        (doc as any).autoTable(this.exportColumns, this.PRPrint);
        doc.save('pr.pdf');
      })
    })
  }

//End PDF

//Start Excel
exportExcel() {
  this.showloader=true
  this.generatePDFData('');

 setTimeout(() => {
  this.exportExcelData()
 }, 250);
  }
  exportExcelData()
  {
    if(this.PRPrint.length >0)
    { import('xlsx').then((xlsx) => {
         const worksheet = xlsx.utils.json_to_sheet(this.PRPrint);
         const workbook = { 
             Sheets: { data: worksheet }, 
             SheetNames: ['data'] 
         };
         const excelBuffer: any = xlsx.write(workbook, {
             bookType: 'csv',
             type: 'array',
         });
         this.saveAsExcelFile(excelBuffer, 'pr');
         this.showloader=false;
     });}
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
      let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
      let EXCEL_EXTENSION = '.csv';
      const data: Blob = new Blob([buffer], {
          type: EXCEL_TYPE,
      });
      FileSaver.saveAs(
          data, fileName + EXCEL_EXTENSION
          //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
      );
  }
//End Excel 
  //List Export option End

   /********Export excel */

   onRowSelect(event: any) {
    let prId = event.data.id;
    
    this.router.navigate(['/main/purchases-requisition/action/view', prId, 0]);
  }

}
