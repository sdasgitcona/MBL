import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchasesRequisitionComponent } from './purchases-requisition.component';

describe('PurchasesRequisitionComponent', () => {
  let component: PurchasesRequisitionComponent;
  let fixture: ComponentFixture<PurchasesRequisitionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurchasesRequisitionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PurchasesRequisitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
