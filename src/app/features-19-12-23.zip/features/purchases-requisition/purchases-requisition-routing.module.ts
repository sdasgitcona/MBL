import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PurchaseRequisitionApprovalComponent } from './purchase-requisition-approval/purchase-requisition-approval.component';
import { PurchasesRequisitionAddEditComponent } from './purchases-requisition-add-edit/purchases-requisition-add-edit.component';
import { PurchasesRequisitionListComponent } from './purchases-requisition-list/purchases-requisition-list.component';
import { PurchasesRequisitionComponent } from './purchases-requisition.component';

const routes: Routes = [
  {
    path: '',
    component: PurchasesRequisitionComponent,
  },
  {
    path: 'list',
    component: PurchasesRequisitionListComponent,
  },
  {
    path: 'list/:status',
    component: PurchasesRequisitionListComponent,
  },
  {
    path: 'action/:action/:id/:chkid',
    component: PurchasesRequisitionAddEditComponent,
  },
  {
    path: 'action/:action',
    component: PurchasesRequisitionAddEditComponent,
  },
  {
    path: 'pr-approval',
    component: PurchaseRequisitionApprovalComponent,
  },
  {
    path: 'pr-approval/:status',
    component: PurchaseRequisitionApprovalComponent,
  },
 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PurchasesRequisitionRoutingModule { }
