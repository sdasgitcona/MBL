import { approvalPreferenceConditions } from "../../approval-prefference/model/Approval-Prefference-model";

export class PurchasesRequisition {
    id?: number;
    prDate?: any;
    prNumber?: string;
    prStatus?: string;
    department?: string;
    departmentId?:number;
    subsidiaryId?: number;
    type?: string;
    locationId?: number;
    projectName?: string;
    projectId?:number;
    currency?: string;
    requestor?: any;
    exchangeRate?: number;
    netSuiteId?: number;
    rejectedComments?: string;
    approvedBy?: string;
    approvedByName?: string;
    nextApprover?: any;
    nextApproverRole?: string;
    nextApproverLevel?: string;
    approverPreferenceId?: number;
    approverSequenceId?: number;
    approverMaxLevel?: string;
    prItems: PrItem[] = [];
    subsidiaryName?: string;
    locationName?: string;
    totalValue?: string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted?: boolean;
    rfqEnabled?: boolean;
    priority?: string;
    memo?: string;
     // for approval
     approvalRoutingActive?:any;
     selected:boolean;
     NewrejectComments?: any;
     isAdminRole:boolean;
     isApprovalButtonShowHide: any;
     basicAmount:any;
     basicTotalAmount:any;
     comments:any;
     approvers:approvers[]=[];
     amount:any;
}
export class approvers{
    id?:any;
    name?:any;
}
export class PrItem {
    id?:any;
    itemId?: number;
    itemName?: string;
    itemDescription?: any;
    itemUom?: any;
    itemUomName?: string;
    quantity?: number;
    rate?: number;
    estimatedAmount?: any;
    receivedDate?: any;
    memo?: string;
    deleted?: boolean;
    integratedId?: number | null = null;
    poId?: number | null = null;
    isRowDeleted:boolean;
    disabledItem?:boolean=false;
    approvalRoutingActive?:any;
    
}

export class BaseSearch {
    filters: PurchasesRequisitionFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
}

export class PurchasesRequisitionFilter {
    subsidiaryId?: number;
    prDate?: any;
    department?: string;
    requester?: string;
    name?:any;
    toDate?:any;
    fromDate?:any;
    locationId?:any;
    projectName?:any;
    priority?:any
    status?:any;
    requestor?:string;
    recentlyCreated?:any;
}
export class RequesterList {
    id?: number;
    fullName?: any;
}

export class file_upliad
{
  file:File;
}


  // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: PRFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class PRFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}

export class send_for_approval_object
{
  id?:number;
  base64?:any;
  currentApproverId?:number;//employee id of admin and superadmin, do not send it for normal users.
}
