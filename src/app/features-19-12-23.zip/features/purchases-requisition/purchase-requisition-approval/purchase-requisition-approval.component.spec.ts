import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseRequisitionApprovalComponent } from './purchase-requisition-approval.component';

describe('PurchaseRequisitionApprovalComponent', () => {
  let component: PurchaseRequisitionApprovalComponent;
  let fixture: ComponentFixture<PurchaseRequisitionApprovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurchaseRequisitionApprovalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PurchaseRequisitionApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
