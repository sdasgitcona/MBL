import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { supplierApprovalModel } from '../../supplier/model/supplier-model';
import { PurchasesRequisition,send_for_approval_object } from '../model/purchases-requisition.model';
import { PrReportComponent } from '../../reports/pr-report/pr-report.component';
@Component({
  selector: 'app-purchase-requisition-approval',
  templateUrl: './purchase-requisition-approval.component.html',
  styleUrls: ['./purchase-requisition-approval.component.scss']
})
export class PurchaseRequisitionApprovalComponent implements OnInit {
  columns: any[];
  departments: any[] = [];
  prApprovalList: PurchasesRequisition[] = [];
  prSelectedApproval: PurchasesRequisition = new PurchasesRequisition();
  totalRecords: number = 0;
  loading: boolean = false;
  AllSelected:boolean=false;
  isRejectPressed:boolean=true;
  approvalRoutingActive:boolean=false;
  userRoleId:number;
  send_for_approval_object_:send_for_approval_object[]=[];
  empID:number;
  base64_:any;
  approverRoleList: [{ id?: number; name?: string;  }];
  IsLoggerAdmin:string;
  LoggerRoleName:string;
  showloader:boolean = false;
  RetloginDetails:any;
  RetRoleDetails:any;
  visibleSaveButton:boolean=false;
  url:any;
  @ViewChild('dt') dt: Table;
  constructor(
    private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService,private prReport: PrReportComponent

  ) {
   
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
this.RetloginDetails = JSON.parse(LDetails);
     // For Role Base Access
     const logDetails:any = localStorage.getItem("LoggerDTLS");
const LoggerId=JSON.parse(logDetails);
this.empID= LoggerId.employeeId;
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "PR Approval")
   {
     this.userRoleId=role_Dtls[0].rolePermissions[i].roleId 
     
   }
 }
 this.IsLoggerAdmin=role_Dtls[0].selectedAccess;
 this.LoggerRoleName=role_Dtls[0].name;
// End For Role Base Access
if(this.userRoleId != undefined){
  this.loadPRApproval();
}
else
{
  this.router.navigate(['/main/dashboard']);
}

  }

  loadPRApproval() { 
    let ReqData;
    let ReqParam;
    let ReqDataa;
    let ReqParama;
    let reqUrl:any='';
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null) //--User:Super Admin
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      ReqData=this.RetRoleDetails[0].accountId;
      ReqParam='accountId';
      reqUrl='/procure-ws/pr/get-pr-appoval?' + ReqParam + '=' + ReqData;
    }
  //  else if((this.RetRoleDetails[0].selectedAccess == 'ADMIN'|| this.RetRoleDetails[0].selectedAccess == 'ADMIN_APPROVER') && this.RetRoleDetails[0].subsidiaryId != null) //--User:Admin
  else if(this.RetloginDetails.userType=='ENDUSER')
    {
      if( this.RetRoleDetails[0].selectedAccess == 'APPROVER')
      {
        ReqData=this.empID;
        ReqParam='userId';
        ReqDataa=this.RetRoleDetails[0].subsidiaryId;
        ReqParama = 'subsidiaryId';
        reqUrl='/procure-ws/pr/get-pr-appoval?' + ReqParam + '=' + ReqData+'&' +ReqParama+'=' + ReqDataa;
      }
      else
      {
        ReqData=this.RetRoleDetails[0].subsidiaryId;
        ReqParam='subsidiaryId';
        reqUrl='/procure-ws/pr/get-pr-appoval?' + ReqParam + '=' + ReqData;
      }
     
    }
    else //--User:Others
    {
      ReqData=this.empID;
      ReqParam='userId';
      reqUrl='/procure-ws/pr/get-pr-appoval?' + ReqParam + '=' + ReqData;
    }
    try {    


      this.HttpService.GetAll(reqUrl, this.RetloginDetails.token).subscribe(
      //this.HttpService.GetAll('/procure-ws/pr/get-pr-appoval?userId='+this.empID,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

          if (res && res.length > 0) {
          //  for(let i=0;i<res.length;i++)   
          //  {
              this.NextApproverLov(res[0].subsidiaryId)
          //  }      
            this.prApprovalList = res;
            for(let k=0;k<this.prApprovalList.length;k++)
            {
              this.prApprovalList[k].nextApprover=Number(this.prApprovalList[k].nextApprover);
              this.prApprovalList[k].nextApproverRole= this.LoggerRoleName;
              this.prApprovalList[k].isAdminRole=(this.IsLoggerAdmin=="ADMIN" || this.IsLoggerAdmin=="ADMIN_APPROVER")?true:false;
            }
            this.totalRecords = res.length;

          

          } else {
            this.prApprovalList = [];
            this.totalRecords = res.length;

          }
          this.loading = false;
        }
        },
        (error) => {
          this.showAlert(error);
          this.loading = false;
        }
      );
    } catch (err) {
      this.showAlert(err);
    }
  
  }

  navigateToAdd() {
    this.router.navigate(['/main/supplier/update']);
  }
  
  globalSearch(event: any) {
    this.dt.filterGlobal(event.target.value, 'contains')
  }
  approvePR(){
    try { 
      this.showloader = true;
      this.isRejectPressed=false
      var approveList:any=[];   
      let base64:any[];
      this.send_for_approval_object_=[];
      let c=0;
      
      this.prApprovalList.map((data:PurchasesRequisition)=>{
       
        if(data.selected)
        {
          
         this.DownloadReport(data.prNumber,'PR_APP_BUTTON'); 
         setTimeout(() => { 

          if(this.RetloginDetails.userType=='SUPERADMIN')
          {
            this.send_for_approval_object_.push({
              id:data.id,
              base64: this.prReport.base64,
              currentApproverId:this.empID
            })
          }
          else if(this.RetloginDetails.userType=='ENDUSER')
          {
            if(this.RetRoleDetails[0].selectedAccess=="ADMIN"|| this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
            {
                    this.send_for_approval_object_.push({
                      id:data.id,
                      base64: this.prReport.base64,
                      currentApproverId:this.empID
                    })
            }
            else{
                      this.send_for_approval_object_.push({
                        id:data.id,
                        base64: this.prReport.base64,
                        //currentApproverId:this.empID
                      })
            }
           
          }

        
         
         },350);
     
        }
      })

      setTimeout(() => { 
      
      this.HttpService.Insert('/procure-ws/pr/approve-all-prs',this.send_for_approval_object_,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

          if (res.messageCode) {
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
            this.showloader = false;
          } else {
            this.toastService.addSingle(
              'success',
              'Success',
              'Approve selected Purchase Requisition!'
            );
          this.loadPRApproval();
          this.showloader = false;
          }
        }
         // this.loading = false;
        },
        (error) => {
          this.showAlert(error);
          this.showloader = false;
         // this.loading = false;
        }
      );
      

    
    
  },500);  


    } catch (err) {
      this.showAlert(err);
      this.showloader = false;
    }
  }
  
  DownloadReport(prNumber:any,type:any){                      //pr pdf changes 140823
    this.showloader=true;
  
  this.prReport.exportPdf(prNumber,type);  //pr pdf changes 140823
  

  //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
  }
  rejectPR(){
    try { 
      if(this.isRejectPressed){
      var rejectList:any=[];
      var isrejectComments:boolean=false   
      this.prApprovalList.map((data:PurchasesRequisition)=>{
        if(data.selected){
          if(data.NewrejectComments){
            rejectList.push({id:data.id,rejectedComments:data.NewrejectComments})
            isrejectComments=true;
            this.isRejectPressed=true

          }else{
            this.toastService.addSingle(
              'error',
              'Error',
              'Please enter Reject Comments'
            );
           // alert("Please enter rejectComments");
            isrejectComments=false;
            this.isRejectPressed=true
            return;
          }
        }
      })
      if(isrejectComments){
        this.showloader = true;
      this.HttpService.Insert('/procure-ws/pr/reject-all-prs',rejectList,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

          if (res.messageCode) {
            this.isRejectPressed=true
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
            this.showloader = false;
          } else {
            this.toastService.addSingle(
              'success',
              'Success',
              'Reject selected Purchase Requisition!'
            );
            this.loadPRApproval();
            this.showloader = false;
          }
          this.isRejectPressed=false
         // this.loading = false;
        }
        },
        (error) => {
          this.showAlert(error);
          this.showloader = false;
         // this.loading = false;
        }
      );
      }
    }else{
      this.isRejectPressed=true;
      this.showloader = false;
    }
    } catch (err) {
      this.showAlert(err);
      this.showloader = false;
    }
  }

  approveIndividual(mainId:any,prNumber:any)
  {
    try {
      this.isRejectPressed = true
      this.send_for_approval_object_=[];
      this.DownloadReport(prNumber,'PR_APP_BUTTON'); 
      setTimeout(() => { 

       if(this.RetloginDetails.userType=='SUPERADMIN')
       {
         this.send_for_approval_object_.push({
           id:mainId,
           base64: this.prReport.base64,
           currentApproverId:this.empID
         })
       }
       else if(this.RetloginDetails.userType=='ENDUSER')
       {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN"|| this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                      this.send_for_approval_object_.push({
                        id:mainId,
                        base64: this.prReport.base64,
                        currentApproverId:this.empID
                      })
              }
              else{
                      this.send_for_approval_object_.push({
                        id:mainId,
                        base64: this.prReport.base64,
                        //currentApproverId:this.empID
                      })
              }
         
       }
        
       //   if (this.send_for_approval_object_.length > 0) {
        this.showloader = true;
        //this.HttpService.Insert('/masters-ws/supplier/approve-all-supplier', approveList, this.RetloginDetails.token).subscribe(
          this.HttpService.Insert('/procure-ws/pr/approve-all-prs',this.send_for_approval_object_,this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );

            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Approve selected Purchase Requisition!'
              );
              this.loadPRApproval();
            }
            // this.loading = false;
          },
          (error) => {
            this.showAlert(error);
          }
        );
     // }
     
      
      },350);

   
    } catch (err) {
    }
  }
  rejectIndividual(mainId:any,rejectComments:any,RowNo:any)
  {
    try {
      this.prApprovalList[RowNo].selected=true;
      this.isRejectPressed=true;

      if( rejectComments==undefined)
      {
        this.showAlert("Please enter Reject Comments");
        return true;
      }

      if (this.isRejectPressed) {
        var rejectList: any = [];
        var isrejectComments: boolean = false;
        rejectList.push({id:mainId,rejectedComments:rejectComments})
              isrejectComments = true;
              this.isRejectPressed = true
              
        if (isrejectComments) {
          this.showloader = true;
          //this.HttpService.Insert('/masters-ws/supplier/reject-all-supplier', rejectList, this.RetloginDetails.token).subscribe(
            this.HttpService.Insert('/procure-ws/pr/reject-all-prs',rejectList,this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else if (res.messageCode) {
                this.showloader = false;
                this.isRejectPressed = true
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );
                this.prApprovalList[RowNo].selected=false;
                this.isRejectPressed=true;
                isrejectComments=false;
                this.prApprovalList[RowNo].NewrejectComments=undefined;
              }
              else {
                this.showloader = false;
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Reject selected Purchase Requisition!'
                );
                this.loadPRApproval();
              }
              this.isRejectPressed = true
              // this.loading = false;
            },
            (error) => {
            }
          );
        }
      } else {
        this.showAlert("Please enter Reject Comments");
        this.isRejectPressed = true;
        this.showloader = false;
      }
    } catch (err) {
      this.showAlert(err);
    }
  }

  onAllSelectChange(event:any){
    if(event.checked){
      this.prApprovalList.map((data:PurchasesRequisition)=>{
        data.selected=true;
        this.isRejectPressed=true;
        //this.approvalRoutingActive=true;
      })
    }
    else{
      this.prApprovalList.map((data:PurchasesRequisition)=>{
        data.selected=false;
        this.isRejectPressed=true;
       // this.approvalRoutingActive=false;

      })
    }
  }
  onSelectChange(event:any,routingStatus:any){
  if(!event.checked && this.AllSelected){
    alert("123");
    this.prApprovalList[0].selected=true;
    this.AllSelected=false;
      //this.approvalRoutingActive=routingStatus;
    }
    this.isRejectPressed=true

  }
  viewSupplier(id:any){
    const url = this.router.serializeUrl(
      this.router.createUrlTree(["/main/supplier/action/view/"+id])
    );
    this.isRejectPressed=false
    window.open(url)
  }
  NextApproverLov(subsidiaryId:number) {
    try {    
      if(this.RetloginDetails.userType=='SUPERADMIN'){
        this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + subsidiaryId + '&formName=PR Approval';

       }
       else if(this.RetloginDetails.userType=='ENDUSER')
       {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + subsidiaryId + '&formName=PR Approval';
              }
              else{
                this.url='/masters-ws/employee/get-by-role-subsidiary?roleId=' + this.userRoleId + '&subsidiaryId=' + subsidiaryId + '&formName=PR Approval';
              }
         
       }

      this.HttpService.GetAll(this.url,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

          if (res && res.length > 0) {
            this.approverRoleList = res;          
           // this.totalRecords = res.length;
          } else {
            this.approverRoleList = [{}];
           // this.totalRecords = res.length;

          }
          this.loading = false;
        }
        },
        (error) => {
          this.showAlert(error);
          this.loading = false;
        }
      );
    } catch (err) {
      this.showAlert(err);
    }
  }
  OnChangeNextApprover(row:any) {
    if(this.IsLoggerAdmin=="ADMIN")
    {
       if(this.prApprovalList[row].selected)
       {
         //this.prApprovalList[row].isAdminForSave=false;
         this.visibleSaveButton=true;
       }
    }
  }

  onApproverSave() {
    try {    
      let selectedPR;
      let selectedapprover;
      for(let x=0;x<this.prApprovalList.length;x++)
      {
        if(this.prApprovalList[x].selected)
      {
        selectedPR=this.prApprovalList[x].id;
        selectedapprover=this.prApprovalList[x].nextApprover
        break;
      }
      }
            this.HttpService.GetAll(`/procure-ws/pr/update-next-approver?prId=`+selectedPR+ `&approverId=`+selectedapprover,this.RetloginDetails.token).subscribe(
              (res) => {
                if(res.status == 401)
            { 
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { 
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else
            {
      
                if (res == true) {
                  this.toastService.addSingle(
                    'success',
                    'Success',
                    'saved selected Purchase Requisition!'
                  );
                  window.location.reload();
                 } else {
                  this.showAlert(res.errorMessage);
                }
              }
              },
              (error) => {
                this.showAlert(error);
              }
            );
          } catch (err) {
            this.showAlert(err);
          }
  }
  showAlert(AlertMSG:any) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  cancel()
  {
    window.location.reload();
  }
}

