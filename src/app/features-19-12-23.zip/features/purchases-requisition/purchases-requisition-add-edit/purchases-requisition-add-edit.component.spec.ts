import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchasesRequisitionAddEditComponent } from './purchases-requisition-add-edit.component';

describe('PurchasesRequisitionAddEditComponent', () => {
  let component: PurchasesRequisitionAddEditComponent;
  let fixture: ComponentFixture<PurchasesRequisitionAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurchasesRequisitionAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PurchasesRequisitionAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
