import { JsonPipe } from '@angular/common';
import { ThisReceiver } from '@angular/compiler';
import { Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Decimation } from 'chart.js';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { PrItem, PurchasesRequisition,RequesterList,send_for_approval_object} from '../model/purchases-requisition.model';
import { PrReportComponent } from '../../reports/pr-report/pr-report.component';
import * as Stomp from '@stomp/stompjs';
import * as SockJS from 'sockjs-client';
@Component({
  selector: 'app-purchases-requisition-add-edit',
  templateUrl: './purchases-requisition-add-edit.component.html',
  styleUrls: ['./purchases-requisition-add-edit.component.scss']
})
export class PurchasesRequisitionAddEditComponent implements OnInit {

  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  prId: number = 0;
  pr: PurchasesRequisition = new PurchasesRequisition();
  copyPr: PurchasesRequisition = new PurchasesRequisition();
  prHistoryList: HistoryModel[] = [];
  send_for_approval_object:any={};
  RetloginDetails:any;
  approvalStatusOptions: any;
  locationOptions: any;
  prTypeOptions: any;
  SubsidiaryObject: any[]=[];
  priorityOptions: any;
  departmentOptions: any;
  Subsidiarylist: any[] = [];
  subscription: any;
  selectedPrItem: PrItem = new PrItem();
  disableProjectName = true;
  EmployeeList:RequesterList[];
  ProjectList:any[];
  lstCurrencyList: any[];
  locationslist: any[];
  currencyOptions:any;
  AccountCodeList: any[];
  itemDescription:any;
  UOMlist: any;
  OnlyaddMode:boolean;
  OnlyEditMode:boolean;
  logRoleId:number;
  loginId:number;
  ApprovalButtonShowHide:Number=0;
  buttonclicked:boolean = false;
  showloader:boolean = false;
  chkId:any;
  Chktooltip:boolean=false;
  display: boolean = false;
  isviewapprovereject:boolean=false;
    // For Role Base Access
    isEditable:boolean;
    isCreatetable:boolean;
    isViewtable:boolean;
    isviewEditable:boolean=true;
    // For Role Base Access
    fiscalCalenderDTLS: any;
    RetRoleDetails:any;
    isAppSequenceVisivble:boolean=false;
    appSequencelist:any=[];
    OpenChat:boolean=false;
    greetings: string[] = [];
    newmessage: string;
    private stompClient = null;
  constructor(
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,private prReport: PrReportComponent
  ) {

    // this.approvalStatusOptions = ['Pending Approval', 'Approved', 'Open', 'Closed', 'Processed', 'Partially Processed'];
    this.approvalStatusOptions = ['Pending','Approval','Approved','Draft','Close','Processed','Partially Processed','Rejected'];
    this.prTypeOptions = ["Administrative", "Pre-Sale", "Project"]
    this.priorityOptions = ["High", "Medium", "Low"]
    this.UOMlist = [
      { name: 'KG', code: 'KG' },
      { name: 'LTR', code: 'LTR' },
      { name: 'PCS', code: 'PCS' }
    ];
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
  //   window.addEventListener("keyup", disableF5);
  //   window.addEventListener("keydown", disableF5);
  //   window.addEventListener("beforeunload", disableF5, { capture: true });
  //   function disableF5(e:any) {
  //      e.preventDefault(); 
  //  };

     // For Role Base Access
const logDetails:any = localStorage.getItem("LoggerDTLS");
const LoggerId=JSON.parse(logDetails);
this.loginId= LoggerId.employeeId;
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;
 

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Purchase Requisition")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     this.logRoleId=role_Dtls[0].rolePermissions[i].roleId;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access
    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          this.GetSubsideryList();
          if (params['id']) {
            this.prId = +params['id']; // (+) converts string 'id' to a number
            this.gerPrByIdForLocation();
          }
          if (params['chkid']) {
            this.chkId = +params['chkid'];
           }
          this.assignMode(params['action']);
          //this.GetAllEmployeeList();
          //this.GetAllProjectList();
        } else {
         this.showAlert('cannot get params');
        }
      },
      (error) => {
        this.showAlert('add');
      }
    );
    //this.GetSubsideryList();
    if(this.addMode)
{
  this.pr.prDate=new Date();
  this.loadrequestor();
}

setTimeout(() => {
  this.getRanges();
}, 100);
  }

  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        //this.pr.prStatus = 'Open'
        this.OnlyaddMode = true;
        this.OnlyEditMode=true;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.OnlyaddMode = false;
        this.OnlyEditMode=false;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.OnlyaddMode = false;
        this.OnlyEditMode=true;
        break;

      default:
        break;
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
gerPrByIdForLocation()
{
  this.httpService
  .GetById('/procure-ws/pr/get?id=' + this.prId, this.prId,this.RetloginDetails.token)
  .subscribe((res) => {
    if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

   this.GetLocationsList(res.subsidiaryId);
   this.GetAllItemList(res.subsidiaryId);
   this.fnRequesterList(res.subsidiaryId);
   this.GetAllProjectList(res.subsidiaryId);

   this.GetDepartmentList(res.subsidiaryId)
  
   setTimeout(() => this.GetPrbyId(), 150);
  // setTimeout(() => this.GetDepartmentList(), 400);
   
  }
  });
}
  GetPrbyId() {
    this.httpService
      .GetById('/procure-ws/pr/get?id=' + this.prId, this.prId,this.RetloginDetails.token)
      .subscribe((res) => {//async (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

        if(this.chkId==1)
        {
          this.isviewapprovereject=true;
        }

         if( res.prStatus=='Pending Approval' || res.prStatus=='Processed' || res.prStatus=='Partially Processed' || res.prStatus=='Approved' || res.prStatus=='Closed' || res.prStatus=='Partially Approved') //Send Approval Mode
        {
        this.ApprovalButtonShowHide=0;
        }
        else{
          this.ApprovalButtonShowHide=1;
        }
        
        this.pr =res; //.sort((a:any, b:any) => (b - a));
        this.appSequencelist=this.pr.approvers;
        let nextApprover=this.pr.nextApprover;
        let isNextApproverFound:Boolean=false;
        if(this.pr.approvers != null)
        {for(let x=0;x<this.appSequencelist.length;x++)
        {
          let status='';
          if (this.appSequencelist[x].id == nextApprover)
          {
            isNextApproverFound=true;
            status='current';//this.appSequencelist[x]['status']=;
          }
          else
          {
            if(isNextApproverFound)
            {
              status='pending';
              //this.appSequencelist[x]['status']='pending';
            }else{
              status='approved';
              //this.appSequencelist[x]['status']='approved';
            }
          }
          this.appSequencelist[x]['status']=status;
        }}
       /* if(this.pr.requestor != "" || this.pr.requestor != null)
        {
          this.pr.requestor = Number(this.pr.requestor);
        }*/
        this.pr.prDate=this.pr.prDate != null ? new Date(this.pr.prDate) :"";
        this.pr.prItems=this.pr.prItems.sort((a:any,b:any) => a.id - b.id);
        for(let i=0;i<this.pr.prItems.length;i++)
        {
          this.pr.prItems[i].receivedDate=this.pr.prItems[i].receivedDate != null ?new Date(this.pr.prItems[i].receivedDate):"";
          this.pr.prItems[i].disabledItem=true;
          this.pr.prItems[i].estimatedAmount=this.pr.prItems[i].estimatedAmount!=null?this.pr.prItems[i].estimatedAmount.toFixed(2):this.pr.prItems[i].estimatedAmount;
        }
        this.copyPr = JSON.parse(JSON.stringify(this.pr));
        if (this.pr.type == 'Project') {
          this.disableProjectName = false;
        }
        this.calculateSummery();
      }
      });

    
  }

  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 1) {
      this.LoadHistory();
    }
  }
calculateSummery()
{
  if(this.pr.prItems.length > 0)
  this.pr.basicAmount=0;
  this.pr.basicTotalAmount=0;
  {for(let x=0;x<this.pr.prItems.length;x++)
  {
    this.pr.basicAmount += this.pr.prItems[x].estimatedAmount >0 ?Number(this.pr.prItems[x].estimatedAmount):0;
  }
  this.pr.basicAmount= this.pr.basicAmount.toFixed(2);
  this.pr.basicTotalAmount= this.pr.basicAmount
}
}
  handleSubsidiaryChange(event: any) {
    this.pr.prItems=[];
    let Susidiary=event.value;
    this.GetLocationsList(Susidiary);
    this.AssignCurrencyForSubsidiary(Susidiary);
    this.GetAllItemList(Susidiary);
 //   this.fnRequesterList(Susidiary);
    this.GetAllProjectList(Susidiary);
    this.getRanges();
    this.GetDepartmentList(Susidiary);
  }
fnRequesterList(SubID:any)
{
  
  this.httpService.GetById('/masters-ws/employee/get-employee-by-subsidiary?subsidiaryId=' + SubID, SubID,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

      if (res != undefined) {
        this.EmployeeList=[];
      this.EmployeeList = res;
      }
    }
    },
    (error) => {
      this.showAlert(error);
    },
    ()=>{
      if(this.OnlyaddMode)
      this.pr.requestor=this.loginId;
    }
    );
}
  ReloadhandleSubsidiaryChange()
  {
    this.pr.locationId=undefined;
    this.GetLocationsList(this.pr.subsidiaryId);
    this.AssignCurrencyForSubsidiary(this.pr.subsidiaryId);
    this.GetAllItemList(this.pr.subsidiaryId);
  }
  handleLocationChange(event: any) {
    let PRdays: any = new Date(this.pr.prDate).getDate();
    let PRmonths: any = new Date(this.pr.prDate).getMonth() + 1;
    let PRyear: any = new Date(this.pr.prDate).getFullYear();
    let PRDate: any = this.pr.prDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""

    if(this.pr.locationId != undefined){
      this.showloader=true;
      //this.httpService.GetById('/masters-ws/location/get-by-valid-date?locationId=' + this.pr.subsidiaryId, this.pr.subsidiaryId,this.RetloginDetails.token)
      this.httpService.GetAll(`/masters-ws/location/get-by-valid-date?id=${this.pr.locationId}&date=${PRDate}&formName=${'Purchase Requisition'}`,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
        { 
          this.showloader=false;
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { 
          this.showloader=false;
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {
        if (res == false) {
          this.pr.locationId=undefined;
          this.showAlert("This Location not active");

        } 
        this.showloader=false;         
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
             error
          );
          this.showloader=false;
        }
      );
  }  
  }

  handlePrTypeChange(event: any) {
    if (event.value == 'Project') {
      this.disableProjectName = false;
      return;
    }
    this.pr.projectName=undefined;
    this.disableProjectName = true;
  }

  handlePrStatusChange(event: any) {
    this.showAlert('Status Changed is ' + event)
  }

  AssignCurrencyForSubsidiary(subsidiaryId: any) {
    this.httpService.GetById('/setup-ws/subsidiary/get' + '?id=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

        this.pr.currency = res.currency;
      }
         },
         (error) => {
          this.showAlert(error);
         }
       );
    // let subs = this.SubsidiaryObject.find((x: any) => x.id == subsidiaryId);
    // if (subs) {
    //   this.pr.currency = subs.currency;
    // }
    //GET ALL SUBSIDIARY IS RETURNING ONLY LIST OF STRINGS. NO CURRENCY DETAILS. SO ASSIGNING THE SUBS ID FOR NOW.
    //this.pr.currency = subsidiaryId;
  }

  addPrItem() {
    if (
      this.pr.prItems.length > 0 &&
      this.pr.prItems[length - 1] == new PrItem()
    ) {
      return;
    }
    // let prItem = new PrItem();
    // let randomId = Math.floor(Math.random() * 10000);
    // prItem.itemId = randomId;
    this.pr.prItems.push(new PrItem());
  }

  deletePrItemRowLevel(itemToDelete: PrItem) {
    let index = this.findIndexForPrItem(
      itemToDelete,
      this.pr.prItems
    );
    if (index >= 0) this.pr.prItems.splice(index, 1);
  }

  findIndexForPrItem(
    prItem: PrItem,
    prItems: PrItem[]
  ): number {
    return prItems.findIndex(
      (o) =>
        o.estimatedAmount == prItem.estimatedAmount &&
        o.itemId == prItem.itemId &&
        o.itemDescription == prItem.itemDescription &&
        o.itemName == prItem.itemName &&
        o.poId == prItem.poId &&
        o.quantity == prItem.quantity &&
        o.rate == o.rate
    );
  }

  /* Start Fetch Subsidery list from api */
  GetSubsideryList() {
    if(this.RetloginDetails.userType=='SUPERADMIN')
   // if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {

    
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
  
    //this.httpService.GetAll('/setup-ws/subsidiary/get/all',this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        this.SubsidiaryObject = res;
      }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  }
  else if(this.RetloginDetails.userType=='ENDUSER'){
      this.SubsidiaryObject.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
  
    }
  }
  ReloadGetSubsideryList()
  {
    this.pr.subsidiaryId=undefined;
    this.pr.locationId=undefined;
    this.pr.projectName=undefined;
    this.pr.currency=undefined;
    this.pr.requestor=undefined;
    this.locationOptions=[];
    this.ProjectList=[];
    this.EmployeeList=[];
    this.pr.prItems=[];
    this.AccountCodeList=[];
    this.SubsidiaryObject=[];
    this.GetSubsideryList();

  }
  All_CurrencyList() {
    this.httpService.GetAll("/setup-ws/currency/get/all",this.RetloginDetails.token)
      .subscribe(res => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

        this.lstCurrencyList = res;
      }
      });
  }
  
//ITem Code List
GetAllItemList(SubsidiaryId:any) {
  this.httpService.GetAll("/masters-ws/item/find-by-subsidiary?subsidiaryId="+ SubsidiaryId,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

      if (res != undefined) {
      this.AccountCodeList = res;
      }
    }
    },
    (error) => {
      this.showAlert(error);
    }
    );

}

  AllLocationList() {
    try {
      this.httpService.GetAll('/masters-ws/location/get/all',this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

          this.locationslist=res;
        }
        },
        (error) => {
          this.showAlert(error);
        }
      );
    } catch (err) {
      this.showAlert(err);
    }
  }
  /* Start Fetch Subsidery list from api */
  GetLocationsList(subsidiaryId: any) {
   // this.httpService.GetById(GlobalConstants.URL_LOCATION_GET_ALL_LOV + '?subsidiaryId=' + subsidiaryId, subsidiaryId).subscribe(
    this.httpService.GetById('/masters-ws/location/get-parent-location-names' + '?subsidiaryId=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

        this.locationOptions = res;
      }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  }
GetItemDescriptionById(EventItemId: any,RowIndex:any)
{

  for (let i = 0; i < this.pr.prItems.length; i++) {
    //if (i !== index) {
      if (i !== RowIndex && this.pr.prItems[i].itemId == EventItemId.value ) {
        this.showAlert("Same Item can't be added");
        this.pr.prItems[RowIndex]=new PrItem();
        this.pr.prItems[RowIndex].itemDescription=null;
        this.pr.prItems[RowIndex].itemUom=null;
        return;
      }
      else
      {
        this.httpService
        .GetById('/masters-ws/item/get?id=' + EventItemId.value,EventItemId.value,this.RetloginDetails.token)
        .subscribe((res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

          this.pr.prItems[RowIndex].itemDescription = res.description;
          this.pr.prItems[RowIndex].itemUom = res.uom;
        }
        });
      }
  }
}
calculateEAmount(Event: any,RowIndex:any)
{
  if(Event.value !=null && this.pr.prItems[RowIndex].quantity != undefined && this.pr.prItems[RowIndex].rate != undefined)
  {
    var Qty=this.pr.prItems[RowIndex].quantity; 
    let Rate=this.pr.prItems[RowIndex].rate;
    let EAmount=Number(Qty) * Number(Rate);
    this.pr.prItems[RowIndex].quantity=Number(Qty);
    this.pr.prItems[RowIndex].rate=Number(Rate);
    this.pr.prItems[RowIndex].estimatedAmount=EAmount;
  //this.pr.prItems[RowIndex].estimatedAmount= Event.value * parseFloat(this.pr.prItems[RowIndex].estimatedAmount?.toString()).toFixed(2);
  }
}
calculateEMAmount(Event: any,RowIndex:any,type:string)
{
  if(Event.value !=null )
  {
    var Qty=type == "QTY" ?Event.value:this.pr.prItems[RowIndex].quantity?this.pr.prItems[RowIndex].quantity:""; 
    var Rate=type == "ERATE" ?Event.value:this.pr.prItems[RowIndex].rate?this.pr.prItems[RowIndex].rate:"";
    let EAmount=(Qty !=""?Number(Qty):0) * (Rate !=""?Number(Rate):0);
    this.pr.prItems[RowIndex].estimatedAmount=EAmount != 0?EAmount.toFixed(2):"";
    this.calculateSummery();
  //this.pr.prItems[RowIndex].estimatedAmount= Event.value * parseFloat(this.pr.prItems[RowIndex].estimatedAmount?.toString()).toFixed(2);
  }
  else
  {
    this.pr.prItems[RowIndex].estimatedAmount="";
  }
}
//--Received Date
fnCheckReceivedDT(index:any)
{
    let days:any =     new Date(this.pr.prItems[index].receivedDate).getDate();
    let months:any = new Date(this.pr.prItems[index].receivedDate).getMonth()+1;
    let year:any =   new Date(this.pr.prItems[index].receivedDate).getFullYear();

    let PRdays:any =   new Date(this.pr.prDate).getDate();
    let PRmonths:any = new Date(this.pr.prDate).getMonth()+1;
    let PRyear:any =   new Date(this.pr.prDate).getFullYear();

    let RCVDate=this.pr.prItems[index].receivedDate !== undefined ? (year + '-' + (months.toString().length ==1?"0"+months:months) + '-' + (days.toString().length ==1?"0"+days:days)) :""
    let PRDate=this.pr.prDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length ==1?"0"+PRmonths:PRmonths) + '-' + (PRdays.toString().length ==1?"0"+PRdays:PRdays)) :""
    if(RCVDate < PRDate)
    {
      this.pr.prItems[index].receivedDate={};
      this.showAlert("Received Date should be equal or greater than PR Date ");
    }
  //   if(new Date(this.pr.prItems[index].receivedDate) <= new Date(this.pr.prDate) )
  // {
  //   //this.pr.prItems[index].receivedDate="";
  //   this.pr.prItems[index].receivedDate=undefined;
  //   this.showAlert("Received Date should be equal or grater than PR Date ");
  // }
}
  /* Start fetching History details */
  LoadHistory() {
    if (this.prHistoryList.length == 0)
      this.httpService
        .GetById(`/procure-ws/pr/get/history?prNumber=${this.pr.prNumber}&pageSize=200`,
          this.prId,this.RetloginDetails.token
        )
        .subscribe((res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

          this.prHistoryList = res;
        }
        });
  }
  /* End fetching History details */

  clearPrData() {
    this.router.navigate(['/main/purchases-requisition/list']);
    // if(!this.editMode)
    // {
    // this.pr = new PurchasesRequisition();
    // this.ReloadGetSubsideryList();
    // }
    // else{
    // this.router.navigate(['/main/purchases-requisition/list']);
    // }
  }
  //----[Save/Update] - PR
  savePr() {
    if(this.pr.subsidiaryId != undefined && this.pr.departmentId != undefined && this.pr.locationId != undefined
      && this.pr.type != undefined && this.pr.priority !=undefined && this.pr.requestor != undefined)
   {
     if(this.pr.type == "Project" && this.pr.projectId == undefined)
    {
      this.showAlert("Please select Project Name");
      return false;
    }
    else if(this.pr.prItems.length == 0)
    {
      this.showAlert("No Item List Found");
      return false;
    }
    for( let i=0; i<this.pr.prItems.length;i++ )
    {
      if(this.pr.prItems[i].itemId == undefined)
      {
        this.showAlert("Please select Item Code !");
        return false;
      }
      else if(this.pr.prItems[i].quantity == undefined || this.pr.prItems[i].quantity == null)
      {
        this.showAlert("Please enter Quantity !");
        return false;
      }
      else if(this.pr.prItems[i].quantity == 0)
      {
        this.showAlert("Quantity must be greater than 0 !");
        return false;
      }
      else if(this.pr.prItems[i].rate == undefined || this.pr.prItems[i].rate == null )
      {
        this.showAlert("Please enter Rate !");
        this.buttonclicked=false;
        return false;
      }
      else if(this.pr.prItems[i].rate == 0)
      {
        this.showAlert("Rate must be greater than 0 !");
        return false;
      }
      else if(this.pr.prItems[i].receivedDate==undefined || this.pr.prItems[i].receivedDate=="")
      {
        this.showAlert("Received Date is mandatory for Row-" + (i+1));
        return false;
      }
      else{
      let days:any =    new Date(this.pr.prItems[i].receivedDate).getDate();
      let months:any = new Date(this.pr.prItems[i].receivedDate).getMonth()+1;
      let year:any =   new Date(this.pr.prItems[i].receivedDate).getFullYear();

      let PRdays:any =   new Date(this.pr.prDate).getDate();
      let PRmonths:any = new Date(this.pr.prDate).getMonth()+1;
      let PRyear:any =   new Date(this.pr.prDate).getFullYear();

      let RCVDate=this.pr.prItems[i].receivedDate !== undefined ? (year + '-' + (months.toString().length ==1?"0"+months:months) + '-' + (days.toString().length ==1?"0"+days:days)) :""
      let PRDate=this.pr.prDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length ==1?"0"+PRmonths:PRmonths) + '-' + (PRdays.toString().length ==1?"0"+PRdays:PRdays)) :""
      this.pr.prDate=PRDate;
      //this.pr.prItems[i].receivedDate=RCVDate;
      if(RCVDate < PRDate)
      {
        this.pr.prItems[i].receivedDate={};
        this.showAlert("Received Date should be equal or greater than PR Date ");
        return false;
      }
      }
      
      // else if(this.pr.prItems[i].receivedDate < this.pr.prDate )
      // {
      //   this.pr.prItems[i].receivedDate="";
      //   this.showAlert("Received Date should be equal or grater than PR Date ");
      //   this.buttonclicked=false;
      //   return false;
      // }
    }


    // let NewDate=new Date();
    // let Cyear=NewDate.getFullYear();
    // let Pyear=NewDate.getFullYear()-1;
    // let random = Math.floor(Math.random() * 10000);
    // this.pr.prNumber = 'PR/'+Pyear+ '-'+Cyear+'/' + random;
    if(this.OnlyaddMode)
    {
     this.pr.prStatus="";
    }
    this.showloader=true;
    if(this.addMode){
      this.pr.createdBy=this.RetloginDetails.username;this.pr.lastModifiedBy=this.RetloginDetails.username
      }
     else if(!this.addMode){
      this.pr.lastModifiedBy=this.RetloginDetails.username
      }
     
      this.pr.amount= this.pr.basicTotalAmount;

    this.httpService.Insert('/procure-ws/pr/save', this.pr,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

        if (res && res.id > 0) {
          this.showSuccess();
          this.showloader=false;
          if(this.addMode)
          {
            this.router.navigate(['/main/purchases-requisition/action', 'view',res.id,0]);
          }
          else{
          this.router.navigate(['/main/purchases-requisition/list']);
          }
        } else if(res.errorMessage != undefined)
        {
          this.showAlert(res.errorMessage);
          this.buttonclicked=false;
          this.showloader=false;
        }
        else {
          this.showError();
          this.buttonclicked=false;
          this.showloader=false;
        }
      }
      },
      error => {
        this.showAlert(error);
        this.buttonclicked=false;
        this.showloader=false;
       },
       () => {
         // 'onCompleted' callback.
         // No errors, route to new page here
       });
   }
   else{
    if(this.pr.subsidiaryId == undefined || this.pr.subsidiaryId == 0)
    {
     this.showAlert("Please select Subsidiary");
     this.buttonclicked=false;
     return;
    }
    else if( this.pr.departmentId == undefined )
    {
      this.showAlert("Please select Department");
      this.buttonclicked=false;
      return;
    } 
    else if(this.pr.locationId == undefined || this.pr.locationId == 0)
    {
      this.showAlert("Please select Location");
      this.buttonclicked=false;
      return;
    }
    else if(this.pr.type == undefined || this.pr.type == "")
    {
      this.showAlert("Please select PR Type"); 
      this.buttonclicked=false;
      return;
    }
    else if(this.pr.priority == undefined || this.pr.priority == "")
    {
      this.showAlert("Please select Priority"); 
      this.buttonclicked=false;
      return;
    }
    else if(this.pr.requestor == undefined || this.pr.requestor == "")
    {
      this.showAlert("Please select Requester"); 
      this.buttonclicked=false;
      return;
    }

   }
  }

  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'PR Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving PR!'
    );
  }
  showAlert(AlertMSG:any) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }
  GetAllEmployeeList()
  {
   var obj={
     filters:{   
     },
     pageNumber: 0,
     pageSize: 1000,
     sortColumn: "e.id",
     sortOrder: "asc"
  }
  this.httpService.Insert("/masters-ws/employee/get/all",obj,this.RetloginDetails.token)
  .subscribe(res => {
    if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

   this.EmployeeList=res.list;
  }
   });
  }

ReloadGetAllEmployeeList()
{
  this.pr.requestor=undefined;
  this.fnRequesterList(this.pr.subsidiaryId);
}

  GetAllProjectList(subsidiaryId:any)
  {
    this.httpService.GetById('/masters-ws/project/get-by-subsidiary-id?subsidiaryId=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        this.ProjectList=[];
        for(let x=0;x<res.length;x++)
        {
          this.ProjectList.push({
            "id":res[x].id,
            "name":res[x].name
          })
        }
      }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  //  var obj={
  //    filters:{   
  //    },
  //    pageNumber: 0,
  //    pageSize: 1000,
  //    sortColumn: "p.id",
  //    sortOrder: "asc"
  // }
  // this.httpService.Insert("/project/get/all",obj)
  // .subscribe(res => {
  //  this.ProjectList=res.list;
  //  });
  }
  reloadProjectList()
  {
    this.GetAllProjectList(this.pr.subsidiaryId);
    this.pr.projectName=undefined;
  }
  reloadDepartment()
  {
    this.GetDepartmentList(this.pr.subsidiaryId);
    this.pr.departmentId=undefined;
  }
  sendPrForApproval(prNumber:any,type:any){          //pr pdf changes 140823

    this.DownloadReport(prNumber,type);    //pr pdf changes 140823
  
    setTimeout(() => { 
    this.showloader=true;
    this.send_for_approval_object.id=this.prId;
    this.send_for_approval_object.base64=this.prReport.base64;
    let action: string;
    this.showloader=true;
    this.httpService.Insert('/procure-ws/pr/send-for-approval',this.send_for_approval_object,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

       // this.pr = res;
       if (res == true) {
        this.toastService.addSingle(
          'success',
          'Success',
          'PR Sent for Approval Successfully!'
        );
        this.showloader=false;
        if(this.chkId)
       {
         this.router.navigate(['/main/purchases-requisition/pr-approval']);
       }
       else
       {
         this.router.navigate(['/main/purchases-requisition/list']);
       }
       } else {
        this.showAlert(res.errorMessage);
        this.showloader=false;
        //this.router.navigate(['/main/purchases-requisition/action', 'view',this.prId]);
        //this.router.navigate(['/main/purchases-requisition/list']);

              // [routerLink]="['/main/purchases-requisition/action/view', item.id]
      
      }
    }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending PR for Approval!'
          );
          this.showloader=false;
        });
        
      },600);

  }

  selfApproval() {
    let action: string;
    this.showloader=true;
    this.httpService
      .GetById('/procure-ws/pr/self-approve?prId=' + this.prId, this.prId,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

       // this.pr = res;
       if (res == true) {
        this.toastService.addSingle(
          'success',
          'Success',
          'PR Approved Successfully!'
        );
        this.showloader=false;
        window.location.reload();
       } else {
        this.showAlert(res.errorMessage);
        this.showloader=false;
        //this.router.navigate(['/main/purchases-requisition/action', action, this.prId]);
      }
    }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending PR for Approval!'
          );
          this.showloader=false;
        }
      );
  }

  deletePRrowlevel(index: number) {
    if (index >= 0) {
      if(this.editMode){
        let oldRowItems=this.pr.prItems.filter(x=>x.id != null && x.deleted==false).length;
        let newRowItems=this.pr.prItems.filter(x=>x.id == null).length;
        if(oldRowItems + newRowItems>1)
        {
        if( this.pr.prItems[index].id != null)
        {
        this.pr.prItems[index].deleted=true;
        }
        else
        {
          this.pr.prItems.splice(index, 1);
        }
        }
        else
        {
          this.showAlert("Minimum 1 row is required !");
        }
        }else{
            this.pr.prItems.splice(index, 1);
          }
        }
    //if (index >= 0) this.pr.prItems.splice(index, 1);
  }
  numberOnly(event:any): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }
  decimalFilter(event: any) {
    const reg = /^-?\d*(\.\d{0,2})?$/;
    let input = event.target.value + String.fromCharCode(event.charCode);
  
    if (!reg.test(input)) {
        event.preventDefault();
    }
  }
  DownloadReport_old(prNumber:any){
    window.open(this.httpService.ReportUrl+"/run?__report=report/Purchase_Requisition.rptdesign&__format=pdf&pr_number="+prNumber,'_blank')
  }
  DownloadReport(poNumber:any,type:any){                //pr pdf changes made 140823
    this.showloader=true;
    //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
  this.prReport.exportPdf(poNumber,type);  
  this.showloader=false;
  }
  
  getRanges() {
    this.handleLocationChange(null);
    if(this.pr.subsidiaryId != undefined){
    this.httpService
    .GetById('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId=' + this.pr.subsidiaryId, this.pr.subsidiaryId,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

      if (res) {
        this.fiscalCalenderDTLS=res;
        if(this.fiscalCalenderDTLS != null && this.fiscalCalenderDTLS.fiscalCalanderAccounting.length >0)
        {
        let AllowMonths: any = "Allow Months: ";
        let IsDateAvailable:boolean = false;
    
        var Dummymonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    
        let PRdays: any = new Date(this.pr.prDate).getDate();
        let PRmonths: any = new Date(this.pr.prDate).getMonth() + 1;
        let PRyear: any = new Date(this.pr.prDate).getFullYear();
        let PRDate: any = this.pr.prDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""
    
        for (let x = 0; x < this.fiscalCalenderDTLS.fiscalCalanderAccounting.length; x++) {
          AllowMonths += this.fiscalCalenderDTLS.fiscalCalanderAccounting.length == (x + 1) ? this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month : this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month + " , "
    
          if (PRDate >= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].fromDate && PRDate <= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].toDate && this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month == Dummymonths[PRmonths - 1] + "-" + PRyear) {
            IsDateAvailable = true;
          }
        }
    
        if (IsDateAvailable == false) {
          this.showAlert("Selected Date is Not available in Fiscal Calendar ! " + AllowMonths);
          this.pr.prDate = {};
        }
      }
      else
      {
        this.showAlert("Selected Date is Not available in Fiscal Calendar !");
        this.pr.prDate = {};
      }
      } else {
        this.showAlert("No Data Found");
      }
    }
    },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
           error
        );
      }

    );
   
}

  }


//Approve 
  approveIndividual(){}

  //Reject
  rejectIndividual(){

  }

gotopage()
{
  if(this.chkId)
  {
    this.router.navigate(['/main/purchases-requisition/pr-approval']);
  }
  else
  {
    this.router.navigate(['/main/purchases-requisition/list']);
  }
 
}

funapprove()
{
  try { 
   var approveList:any=[];   
   approveList.push(this.prId);
    if(approveList.length>0){
      this.showloader = true;
    this.httpService.Insert('/procure-ws/pr/approve-all-prs',approveList,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {

        if (res.messageCode) {
          this.toastService.addSingle(
            'error',
            'Error',
            res.errorMessage
          );
          this.showloader = false;
        } else {
          this.toastService.addSingle(
            'success',
            'Success',
            'Approve selected Purchase Requisition!'
          );
        //this.loadPRApproval();
        this.showloader = false;
        this.router.navigate(['/main/purchases-requisition/pr-approval']);
        }
      }
       // this.loading = false;
      },
      (error) => {
        this.showAlert(error);
        this.showloader = false;
       // this.loading = false;
      }
    );
    }
  } catch (err) {
    this.showAlert(err);
    this.showloader = false;
  }
}

funreject()
{
 
  try { 
    if(this.pr.comments=="" || this.pr.comments==undefined)
    {
         this.showAlert("Please enter Comments !");
         return;

    }
    else
    {
      var rejectList:any=[];
      var isrejectComments:boolean=false   
      rejectList.push({id:this.prId,rejectedComments:this.pr.comments})
     
        this.showloader = true;
      this.httpService.Insert('/procure-ws/pr/reject-all-prs',rejectList,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
  
          if (res.messageCode) {
           this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
            this.showloader = false;
            this.display=false;
          } else {
            this.toastService.addSingle(
              'success',
              'Success',
              'Reject selected Purchase Requisition!'
            );
            this.display=false;
            this.showloader = false;
            this.router.navigate(['/main/purchases-requisition/pr-approval']);
          }
          
         // this.loading = false;
        }
        },
        (error) => {
          this.display=false;
          this.showAlert(error);
          this.showloader = false;
         // this.loading = false;
        }
      );
    }
   
    
    
 
  } catch (err) {
    this.showAlert(err);
    this.showloader = false;
  }
}

GetDepartmentList(Subsidiary:any) {

   // this.httpService.GetAll('/masters-ws/department/get-parent-department-names?subsidiaryId='+this.pr.subsidiaryId,this.RetloginDetails.token).subscribe(
  //this.httpService.GetAll('/masters-ws/department/get/all/lov?subsidiaryId='+ Subsidiary,this.RetloginDetails.token).subscribe(
    this.httpService.GetAll('/masters-ws/department/get/all/lov?subsidiaryId='+ Subsidiary,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
     // this.departmentOptions = res;
     this.departmentOptions=[];
     this.departmentOptions.push({
      "id":0,
      "departmentName":'+ Add New'
    }); 

     Object.keys(res).forEach(key => { 
       this.departmentOptions.push({
           "id":Number(key),
           "departmentName":res[key]
         })   
       });
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}

hidepopup()
{
  this.display=false;
}
Opendialog()
{
  this.display=true;
}


loadrequestor()
{
  this.httpService.GetAll('/masters-ws/employee/get?id='+this.loginId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.pr.requestor=res.fullName
     
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}
OpenAppSequence()
{
  this.isAppSequenceVisivble=true;
}
recall()
{
  this.showloader = true;
  this.httpService.GetAll('/procure-ws/pr/change-to-draft?id='+  this.prId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.showloader = false;
      this.showSuccessrecall();
      this.router.navigate(['/main/purchases-requisition/list']);
    }
    },
    (error) => {
      this.showloader = false;
      this.showAlert(error);
    }
  );
}

showSuccessrecall() {
  this.toastService.addSingle(
    'success',
    'Success',
    'Recalled Successfully!'
  );
}
fnNewDepartment()
{

  this.router.navigate([]).then(result => {  window.open(`/#/main/department/action/add`, '_blank'); });
}

}
