import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PurchasesRequisitionRoutingModule } from './purchases-requisition-routing.module';
import { PurchasesRequisitionComponent } from './purchases-requisition.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { TabMenuModule } from 'primeng/tabmenu';
import { TabViewModule } from 'primeng/tabview';
import { SharedComponentsModule } from 'src/app/shared/shared-components/shared-components.module';
import { PurchasesRequisitionAddEditComponent } from './purchases-requisition-add-edit/purchases-requisition-add-edit.component';
import { PurchasesRequisitionListComponent } from './purchases-requisition-list/purchases-requisition-list.component';
import { FieldsetModule } from 'primeng/fieldset';
import { CalendarModule } from 'primeng/calendar';
import { PurchaseRequisitionApprovalComponent } from './purchase-requisition-approval/purchase-requisition-approval.component';
import { InputSwitchModule } from 'primeng/inputswitch';
import {InputNumberModule} from 'primeng/inputnumber';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { DialogModule } from 'primeng/dialog';
import {FileUploadModule} from 'primeng/fileupload';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { CardModule } from 'primeng/card';
import { OverlayPanelModule } from 'primeng/overlaypanel';
@NgModule({
  declarations: [
    PurchasesRequisitionComponent,
    PurchasesRequisitionListComponent,
    PurchasesRequisitionAddEditComponent,
    PurchaseRequisitionApprovalComponent
  ],
  imports: [
    CommonModule,
    PurchasesRequisitionRoutingModule,
    PanelModule,
    TableModule,
    TabMenuModule,
    TabViewModule,
    SharedComponentsModule,
    ButtonModule,
    DropdownModule,
    InputTextModule,
    FormsModule,
    FieldsetModule,
    ReactiveFormsModule,
    CalendarModule,
    InputSwitchModule,
    InputNumberModule,
    DialogModule,
    ProgressSpinnerModule,
    CardModule,
    ToggleButtonModule,
    OverlayPanelModule,
  ]
})
export class PurchasesRequisitionModule { }
