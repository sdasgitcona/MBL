import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch } from '../../supplier/model/supplier-model';
import { TaxGroup } from '../model/tax-group-model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-tax-group-list',
  templateUrl: './tax-group-list.component.html',
  styleUrls: ['./tax-group-list.component.scss']
})
export class TaxGroupListComponent implements OnInit {
  columns: any[];
  departments: any[] = [];

  taxGrouplist: TaxGroup[] = [];
  selectedRaxGroup: TaxGroup = new TaxGroup();
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  taxgroups: TaxGroup = new TaxGroup();
  newevent:any;
  taxType:any;
  SubsideryObject:any=[];
  TaxgroupNamelist: TaxGroup[] = [];
  RetRoleDetails:any;
  SubIdList:any=[];
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   // For Role Base Access
   RetloginDetails:any;
   ListToPrint: any[] = [];
   showloader:boolean;

  constructor( private routeStateService: RouteStateService,
    private router: Router,  private toastService: ToastService,
    private HttpService: CommonHttpService)
     {    this.taxType = ['VAT', 'TDS'];
    }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
     const retDetails:any = localStorage.getItem("RoleDTLS");
     var role_Dtls = JSON.parse(retDetails);
   
     this.RetRoleDetails=role_Dtls;
     const LDetails:any=localStorage.getItem("LoggerDTLS");
     this.RetloginDetails = JSON.parse(LDetails);
  
     for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
     {
       if(role_Dtls[0].rolePermissions[i].accessPoint == "Tax Group")
       {
         this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
         this.isEditable=role_Dtls[0].rolePermissions[i].edit;
         this.isViewtable=role_Dtls[0].rolePermissions[i].view;
       }
     }
 // End For Role Base Access

   // this.resetBaseSearch();
    this.GetSubsideryList();
  //  this.loadTaxGroupAll();

    this.columns = [
       { field: 'Sl No', header: 'Sl No' },
       { field: 'Subsidiary', header: 'Subsidiary' },
       { field: 'Name', header: 'Name' },
       { field: 'Description', header: 'Description' },
       { field: 'Country', header: 'Country' }
     ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }
  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.TAX_GROUP_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadTaxGroup(this.newevent);
  }

  loadTaxGroup(event: any) {
    try {
      this.newevent=event;
      this.loading = true;
      console.log('PrimeNg Event is' + event);
      this.baseSearch.pageNumber = event.first / event.rows;
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
        this.baseSearch.sortColumn = event.sortField
        ?  event.sortField
        : GlobalConstants.TAX_GROUP_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
      this.HttpService.Insert('/setup-ws/tax-group/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
         else if (res && res.list.length > 0) {
            this.taxGrouplist = res.list;          
            this.totalRecords = res.totalRecords;
          } else {
            this.taxGrouplist = [];
          }
          this.loading = false;
        },
        (error) => {
         alert(error);
          this.loading = false;
        }
      );
    } catch (err) {
      console.log(err);
    }
  }

  
  navigateToAddViewEdit(
    action: string,
    selectedTaxGroup: TaxGroup = new TaxGroup()
  ) {
    let taxgroupId = null;
    if (selectedTaxGroup?.id) {
      taxgroupId = selectedTaxGroup.id;
      this.router.navigate(['/main/tax-group/action', action, taxgroupId]);
    } else {
      this.router.navigate(['/main/tax-group/action', action]);
    }
    //console.log('Action is ' + action);
  }
  exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.taxGrouplist);
            doc.save('taxgroup.pdf');
        })
    })
}

  /* Start fetch filter list of supplier from api */
  findby(event: any){
    let subsidyList:any=[];
    subsidyList.push(this.taxgroups.subsidiaryId);
    let date_from:any;
    let date_to:any;
    if(this.taxgroups.effectiveFrom!=undefined)
    {
     //let effectiveFrom=this.taxRateRule.effectiveFrom.setDate(this.taxRateRule.effectiveFrom.getDate() - 1)
      let days_from:any = new Date(this.taxgroups.effectiveFrom).getUTCDate();
      if(days_from<10)
      {
         days_from="0"+days_from;
      }
      let months_from:any = new Date(this.taxgroups.effectiveFrom).getUTCMonth()+1;
      
      if(months_from<10)
      {
        months_from="0"+months_from;
      }
      let year_from:any = new Date(this.taxgroups.effectiveFrom).getUTCFullYear();
      date_from=year_from+"-"+months_from+"-"+days_from;
    }
    if(this.taxgroups.effectiveTo!=undefined)
    {
     // let effectiveto=this.taxRateRule.effectiveTo.setDate(this.taxRateRule.effectiveTo.getDate() - 1)
      let days_to:any = new Date(this.taxgroups.effectiveTo).getUTCDate();
      if(days_to<10)
      {
        days_to="0"+days_to;
      }
      let months_to:any = new Date(this.taxgroups.effectiveTo).getUTCMonth()+1;
      if(months_to<10)
      {
        months_to="0"+months_to;
      }
      let year_to:any = new Date(this.taxgroups.effectiveTo).getUTCFullYear();
      date_to=year_to+"-"+months_to+"-"+days_to;
    }

    this.baseSearch.filters={
      name:this.taxgroups.name,
      subsidiaryId:subsidyList,
      //status:this.taxgroups.inactive?"active":"inactive",
      inclusive:this.taxgroups.inclusive?"true":"false",
      effectiveFrom:this.taxgroups.effectiveFrom != "" ? date_from:"",
      effectiveTo:this.taxgroups.effectiveTo != "" ? date_to:""
  }
  this.baseSearch.pageNumber=-1;
  this.loadTaxGroup(this.newevent);
  }
  /* End filter list of supplier from api */
 /* Start Fetch Subsidery list from api */
 GetSubsideryList_old() {
  this.HttpService.GetAll('/setup-ws/subsidiary/get/all',this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
      else {this.SubsideryObject=res.list;}
    },
    (error) => {
      alert(error);
    }
  );
}

GetSubsideryList() {
  this.SubsideryObject=[];

  //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
  if(this.RetloginDetails.userType=='SUPERADMIN')
  {
    this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
     { this.showAlert("Unauthorized Access !");
       this.router.navigate(['/login']);
     }
     else if(res.status == 404)
     { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
     { this.SubsideryObject=res;
      for(let x=0;x<this.SubsideryObject.length;x++)
     { 
      this.SubIdList.push(this.SubsideryObject[x].id);
    }
    }
    },
    (error) => {
      alert(error);
     },
     ()=>{
      if(localStorage.getItem("taxGroupFilters") != null)
      {
      const LocDetails:any =localStorage.getItem("taxGroupFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.taxgroups.subsidiaryId=searcheData.filters.subsidiaryId;
      this.taxgroups.name=searcheData.filters.name;
      this.taxgroups.effectiveFrom=searcheData.filters.effectiveFrom;
      this.taxgroups.effectiveTo=searcheData.filters.effectiveTo;
      this.taxgroups.inclusive=searcheData.filters.inclusive
      this.taxgroups.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
      this.loadTaxGroup(this.newevent);
      localStorage.removeItem("taxGroupFilters");
      }
      else
      this.resetBaseSearch();
     //this.loadSuppliers('');
     }
  );
  }else if(this.RetloginDetails.userType=='ENDUSER'){
    this.SubsideryObject.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });

    this.taxgroups.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
    this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
    if(localStorage.getItem("taxGroupFilters") != null)
      {
      const LocDetails:any =localStorage.getItem("taxGroupFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.taxgroups.subsidiaryId=searcheData.filters.subsidiaryId;
      this.taxgroups.name=searcheData.filters.name;
      this.taxgroups.effectiveFrom=searcheData.filters.effectiveFrom;
      this.taxgroups.effectiveTo=searcheData.filters.effectiveTo;
      this.taxgroups.inclusive=searcheData.filters.inclusive
      this.loadTaxGroup(this.newevent);
      localStorage.removeItem("taxGroupFilters");
      }
      else
    this.resetBaseSearch();
  }
}

 /* Start Fetch Taxgroup list All from api */
 loadTaxGroupAll() {

  this.HttpService.GetAll("/setup-ws/tax-group/get-by-subsidiary?subsidiaryId="+this.taxgroups.subsidiaryId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else {
        this.TaxgroupNamelist=res;
      }
    },
    (error) => {
      alert(error);
    }
  );
}
/* End Fetch Taxgroup list All from api */
showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}
loadtaxname()
{
  this.loadTaxGroupAll();
  
}
generatePDFData(exportType:any){
  this.newevent = event;
  this.baseSearch.pageSize = this.totalRecords;
  this.baseSearch.sortColumn =GlobalConstants.TAX_GROUP_TABLE_SORT_COLUMN;
  this.baseSearch.filters = {subsidiaryId: this.SubIdList};

  this.HttpService.Insert('/setup-ws/tax-group/get/all', this.baseSearch, this.RetloginDetails.token).subscribe(
    (res) => {
      //For Auth
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        //this.employeelistPrint = [];
        this.ListToPrint = [];
        if (res && res.list.length > 0) {
          var RetData = res.list;
          for (let i = 0; i < RetData.length; i++) {
              if (RetData[i].id == undefined) {
              RetData[i].id = "";
            }
            if(exportType == 'PDF'){   
              this.ListToPrint.push({
                'Sl No': i + 1 ,    
                'Subsidiary':RetData[i].subsidiaryName, 
                'Name': RetData[i].name,
                'Description':RetData[i].description,
                'Country':RetData[i].country,
            });
          }
            else{
              this.ListToPrint.push({
                'Sl No': i + 1 ,    
                'Subsidiary':RetData[i].subsidiaryName, 
                'Name': RetData[i].name,
                'Description':RetData[i].description,
                'Country':RetData[i].country,
              });
            }

          }
        }
        if(exportType == 'PDF')
        {this.exportPdf();}
      }
    }
  );
}
//Start Excel
exportExcel() {
  this.showloader=true
  this.generatePDFData('');

 setTimeout(() => {
  this.exportExcelData()
 }, 250);
  }
  exportExcelData()
  {
    if(this.ListToPrint.length >0)
    { import('xlsx').then((xlsx) => {
         const worksheet = xlsx.utils.json_to_sheet(this.ListToPrint);
         const workbook = { 
             Sheets: { data: worksheet }, 
             SheetNames: ['data'] 
         };
         const excelBuffer: any = xlsx.write(workbook, {
             bookType: 'csv',
             type: 'array',
         });
         this.saveAsExcelFile(excelBuffer, 'TaxGroup');
         this.showloader=false;
     });}
  }
  saveAsExcelFile(buffer: any, fileName: string): void {
      let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
      let EXCEL_EXTENSION = '.csv';
      const data: Blob = new Blob([buffer], {
          type: EXCEL_TYPE,
      });
      FileSaver.saveAs(
          data, fileName + EXCEL_EXTENSION
          //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
      );
  }

  editview(actionType:any,mainId:any)
  {
   if (localStorage.getItem("taxGroupFilters") != null)
   {
     localStorage.removeItem("taxGroupFilters");
   }
   localStorage.setItem("taxGroupFilters", JSON.stringify(this.baseSearch));
   this.router.navigate(['/main/tax-group/action', actionType, mainId]);
  }
  Reset() {
    this.taxgroups.name = "";
    this.taxgroups.effectiveFrom = {};
    this.taxgroups.effectiveTo = {};
    this.taxgroups.inclusive = false;
    this.resetBaseSearch();
  }
  onRowSelect(event: any) {
    let tgId = event.data.id;
    
    this.router.navigate(['/main/tax-group/action/view', tgId]);
  }

}
