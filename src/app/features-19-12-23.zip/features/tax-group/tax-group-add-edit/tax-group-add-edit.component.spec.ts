import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxGroupAddEditComponent } from './tax-group-add-edit.component';

describe('TaxGroupAddEditComponent', () => {
  let component: TaxGroupAddEditComponent;
  let fixture: ComponentFixture<TaxGroupAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TaxGroupAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TaxGroupAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
