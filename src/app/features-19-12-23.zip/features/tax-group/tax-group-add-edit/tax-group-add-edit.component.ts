import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { retry } from 'rxjs';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { CountryModel } from 'src/app/shared/shared-components/address/model/address.model';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { RestrictedDepartment, RoleMasterModel, RolePermission } from '../../role/model/role-model';
import { Subsidiary } from '../../subsidiary/Model/subsidiary-model';
import { SubsidiaryAddress, SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { TaxGroup, TaxRateRule } from '../model/tax-group-model';

@Component({
  selector: 'app-tax-group-add-edit',
  templateUrl: './tax-group-add-edit.component.html',
  styleUrls: ['./tax-group-add-edit.component.scss']
})
export class TaxGroupAddEditComponent implements OnInit {
  taxgroup: TaxGroup = new TaxGroup();
  selectedTaxrate: TaxRateRule = new TaxRateRule();
  totalpermisions: number = 0;
  taxGroupId: number;
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  SubIdList:any=[];
  taxGroupHistoryList: HistoryModel[] = [];
  Subsidiarylist:any= [];

  AvailableOptions: any;

  checked: boolean;
  selectedIndex: any
  isReloadSub: boolean;
  adminrole: boolean;
  approverrole: boolean;
  venderrole: boolean;
  department: any;
  TaxRateRuleList: TaxRateRule[] = [];
  showloader: boolean=false;

   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   isviewEditable:boolean=true;
   // For Role Base Access
   RetloginDetails:any;
   RetRoleDetails:any;
  constructor(
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
  ) {

    this.AvailableOptions = ['Purchase Transaction'];

  }
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;

 const LDetails:any=localStorage.getItem("LoggerDTLS");
this.RetloginDetails = JSON.parse(LDetails);

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Tax Group")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access
    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.taxGroupId = +params['id']; // (+) converts string 'id' to a number
            this.GetTaxGroupbyId();
          }
          this.assignMode(params['action']);
          this.GetSubsideryList();
         // this.GetTaxRateRuleList();


        } else {
          console.log('cannot get params');
        }
      },
      (error) => {
        console.log('add');
      }
    );
    this.totalpermisions = this.taxgroup.taxRateRules.length;


  }

  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        //this.role.inactive=false;
        //this.role.rolePermissions.push(new RolePermission());

        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;

      default:
        break;
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  GetTaxGroupbyId() {
    this.httpService
      .GetById('/setup-ws/tax-group/get?id=' + this.taxGroupId, this.taxGroupId,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.GetTaxRateList(res.subsidiaryId);
       setTimeout(() => {
        this.taxgroup = res;
        this.taxgroup.activeDate=this.taxgroup.activeDate != null ?new Date(this.taxgroup.activeDate):"";
        this.taxgroup.inActiveDate=this.taxgroup.inActiveDate != null ?new Date(this.taxgroup.inActiveDate):"";
       }, 100);}
      });
  }

  /* End Fetch Subsidery list from api */

  /* Start fetching History details */
  LoadHistory() {
    if (this.taxGroupHistoryList.length == 0)
      this.httpService
        .GetById(`/setup-ws/tax-group/get/history?id=${this.taxGroupId}&pageSize=100`,
          this.taxGroupId,this.RetloginDetails.token
        )
        .subscribe((res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
         { this.taxGroupHistoryList = res;}
        });
  }
  /* End fetching History details */

  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 1) {
      this.LoadHistory();
    }
  }

  handleToggleEvent(event: any) {
    event.originalEvent.cancelBubble = true;
  }

//--Get Tax Rate Rule By Subsidiary
TaxNameList:any[]=[];
GetTaxRateList(SubsidiaryId:any)
{
  try {
    this.httpService.GetById('/setup-ws/tax-rate/get-tax-rate-by-subsidiary?subsidiaryId=' + SubsidiaryId, SubsidiaryId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else if (res && res.length > 0) {
          this.TaxRateRuleList = res;
        } else {
          this.TaxRateRuleList = [];
        }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  } catch (err) {
    console.log(err);
    }
  }

  saveTaxGroup() {
    var isvalidate=true;
    if(!this.taxgroup.subsidiaryId){
      this.toastService.addSingle(
        'error',
        'Error',
        'Please select Subsidiary'
      );
      return
    }
    if (this.taxgroup.name == undefined || this.taxgroup.name == "")
        {
          this.showAlert('Please enter Tax Group Name !');
          return false;
        }
        if(this.taxgroup.activeDate == undefined )
        {
          this.showAlert('Please select Effective From Date !');
          return false;
        }

    if(this.taxgroup.taxRateRules.length>0){
      if(this.editMode){
        if(this.taxgroup.taxRateRules.every(obj => obj.deleted)){
          this.toastService.addSingle(
            'error',
            'Error',
            'Please select Tax Rate Rule'
          );
          return 
        }
      }
      this.taxgroup.taxRateRules.map((data,index:any)=>{
        if(!data.taxRateId){
          this.toastService.addSingle(
            'error',
            'Error',
            'Please select Tax Rate Rule Name'
          );
          isvalidate=false;
          return;
        }
      })
      }
     else{
        this.toastService.addSingle(
          'error',
          'Error',
          'Please select Tax Rate Rule '
        );
        return 
      }
    if(isvalidate){
      
if(this.addMode){
  this.taxgroup.createdBy=this.RetloginDetails.username;this.taxgroup.lastModifiedBy=this.RetloginDetails.username
  }
 else if(!this.addMode){
  this.taxgroup.lastModifiedBy=this.RetloginDetails.username
  }
    this.httpService.Insert('/setup-ws/tax-group/save', this.taxgroup,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else if (res && res.id > 0) {
          //this.saveAddress();
          this.showSuccess();
          // alert('Data saved successfully');

          if(this.addMode){
            this.router.navigate(['/main/tax-group/action', 'view',res.id]);
          } else {
            this.router.navigate(['/main/tax-group/list']);
          }


          
        } else {
          this.showError();
          // alert('!! Something went wrong');
        }
      },
      (error) => {
        //console.log('error-' + error);
        this.showAlert(error);
      },
      () => { }
    );
    }
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Tax Group Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving tax group!'
    );
  }
  clearTaxGroupData() {

    this.router.navigate(['/main/tax-group/list']);
    /*if (this.editMode) {
      this.router.navigate(['/main/tax-group/list']);
    }
    else {
          this.taxgroup = new TaxGroup();
          this.TaxRateRuleList=[];
    }*/
  }
  checked2: boolean = true;
  // inactive:boolean = true;
  /* Start Reload Subsidery */
  reloadSubsidary() {
    this.isReloadSub = true;
    this.GetSubsideryList();
  }
  /* End Reload Subsidery */

  /* Start Fetch Subsidery list from api */
  GetSubsideryList_old() {

    if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    //this.httpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {this.Subsidiarylist = res;
        this.isReloadSub = false;}
      },
      (error) => {
        this.isReloadSub = false;
        this.showAlert(error);
      }
    );
    }
    else
  {
    this.Subsidiarylist.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });
  }
  }
  /* End Fetch Subsidery list from api */

  GetSubsideryList() {
    this.Subsidiarylist=[];
  
    if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist=res;
        for(let x=0;x<this.Subsidiarylist.length;x++)
       { 
       // this.SubIdList.push(this.Subsidiarylist[x].id);
      }
      }
      },
      (error) => {
        //alert(error);
       },
       ()=>{
       // this.resetBaseSearch();
       //this.loadSuppliers('');
       }
    );
    }else{
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
     // this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
     // this.resetBaseSearch();
    }
  }


  
  addTaxrate() {
   // this.taxgroup.taxRateRules.push(new RolePermission());
   if(this.taxgroup.taxRateRules){
    this.taxgroup.taxRateRules.push(new TaxRateRule());
  }else{
    this.taxgroup.taxRateRules=[];
    this.taxgroup.taxRateRules.push(new TaxRateRule());
  }
  }
  deletepermissons(index: number) {
    // if (index >= 0) {
    //   this.taxgroup.taxRateRules.splice(index, 1);
    // }
    if(this.editMode){
      if( this.taxgroup.taxRateRules[index].id != null)
      {
        this.taxgroup.taxRateRules[index].deleted=true;
      }
      else
      {
        this.taxgroup.taxRateRules.splice(index, 1);
      }
    
      }else{
        if (index >= 0) {
          this.taxgroup.taxRateRules.splice(index, 1);
        }
      }
  }
 

/* Start Reload subsidery */
reloadSubidery(){
  //$('.refsubsidery').addClass('fa-spin');
  this.isReloadSub=false;
  this.taxgroup.subsidiaryId=0;
  this.taxgroup.taxRateRules=[];
  this.TaxRateRuleList=[];
  this.Subsidiarylist=[];
  this.GetSubsideryList();
}
/* End Reload subsidery */
onTaxRatechange(index:number,value:string){
  let that=this;
  this.TaxRateRuleList.find(o =>{ 
    if(o.id === parseInt(value)){
      that.taxgroup.taxRateRules[index].taxRates=o.taxRates;
      that.taxgroup.taxRateRules[index].taxRateType=o.taxType;

    }
  });
  if(this.taxgroup.taxRateRules.length>1)
  {
     for(let i=0;i<this.taxgroup.taxRateRules.length-1;i++)
     {
          //if(this.taxgroup.taxRateRules[i].taxRateId==parseInt(value))
          if(i !=index && this.taxgroup.taxRateRules[i].taxRateId==this.taxgroup.taxRateRules[index].taxRateId)
          {
           this.showAlert("Duplicate Tax Rate Rule Name found !");
           this.taxgroup.taxRateRules[index].taxRateId="";
           this.taxgroup.taxRateRules[index].taxRateType="";
           this.taxgroup.taxRateRules[index].taxRates="";
           //this.taxgroup.taxRateRules.splice(index,1);
           return;
          }
     }
}
}
/* Start Fetch Tax rate rule list from api */

GetTaxRateRuleList(): void {
  let Obj={
    filters:{
    },
    pageNumber: 0,
    pageSize: 200,
    sortColumn: "effectiveFrom",
    sortOrder: "asc"
}
  this.httpService.Insert("/setup-ws/tax-rate/get/all",Obj,this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
     { this.TaxRateRuleList = res.list;}

    });
}
/* Start Fetch Tax rate rule list from api */

onSubsidiaryChange(){
this.GetSubsidiarybyId(this.taxgroup.subsidiaryId);
this.GetTaxRateList(this.taxgroup.subsidiaryId);
this.taxgroup.taxRateRules=[];
//this.GetAccountType('Liability',this.taxRateRule.subsidiaryId);
}

GetSubsidiarybyId(SubsidiaryId:any) {
  this.httpService
    .GetById('/setup-ws/subsidiary/get?id=' + SubsidiaryId, SubsidiaryId,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else if(res){
      this.taxgroup.country = res.country;
      }else{
        this.taxgroup.country = "";
      }
    });
}

checkefectivedate(){
  let Fdays: any = new Date(this.taxgroup.activeDate).getDate();
  let Fmonths: any = new Date(this.taxgroup.activeDate).getMonth() + 1;
  let Fyear: any = new Date(this.taxgroup.activeDate).getFullYear();
  let FromDate: any = this.taxgroup.activeDate !== undefined ? (Fyear + '-' + (Fmonths.toString().length == 1 ? "0" + Fmonths : Fmonths) + '-' + (Fdays.toString().length == 1 ? "0" + Fdays : Fdays)) : "";

  let Tdays: any = new Date(this.taxgroup.inActiveDate).getDate();
  let Tmonths: any = new Date(this.taxgroup.inActiveDate).getMonth() + 1;
  let Tyear: any = new Date(this.taxgroup.inActiveDate).getFullYear();
  let ToDate: any = this.taxgroup.inActiveDate !== undefined ? (Tyear + '-' + (Tmonths.toString().length == 1 ? "0" + Tmonths : Tmonths) + '-' + (Tdays.toString().length == 1 ? "0" + Tdays : Tdays)) : "";

  if(FromDate > ToDate && this.taxgroup.inActiveDate !== undefined){
  //if(new Date(this.taxgroup.inActiveDate) > new Date(this.taxgroup.activeDate)){
    
    this.toastService.addSingle(
      'error',
      'Alert',
      "Effective To date must be greater than Effective From Date"
    );
    setTimeout(() => {
      this.taxgroup.inActiveDate=null
    }, 100);
  }
}

showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}


}
