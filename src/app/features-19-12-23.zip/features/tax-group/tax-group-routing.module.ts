import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TaxGroupAddEditComponent } from './tax-group-add-edit/tax-group-add-edit.component';
import { TaxGroupListComponent } from './tax-group-list/tax-group-list.component';

const routes: Routes = [
  {
    path: '',
    component: TaxGroupListComponent,
  },
  {
    path: 'list',
    component: TaxGroupListComponent,
  },
  {
    path: 'action/:action/:id',
    component: TaxGroupAddEditComponent,
  },
  {
    path: 'action/:action',
    component: TaxGroupAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TaxGroupRoutingModule { }
