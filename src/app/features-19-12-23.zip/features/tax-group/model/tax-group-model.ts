
    export class TaxRateRule {
        id?: number;
        taxGroupId?: number;
        taxRateId?: any;
        createdDate?: Date;
        createdBy?: string;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        taxRateName?: any;
        taxRateType?: any;
        taxRates?: any;
        operation?: any;
        deleted?: boolean;
        taxType?:any;
        CustomtaxAmount?:any=0;
        taxAmount?:any=0;
        basicAmount?:any=0;
    invoiceId?: any;
    invoiceItemId?: any;
    }

    export class TaxGroup {
        id?: number;
        subsidiaryId?: number;
        country?: string;
        name?: string;
        description?: string;
        availableOn?: string;
        createdDate?: any;
        createdBy?: any;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        taxRateRules: TaxRateRule[]=[];
        subsidiaryName?: any;
        deleted?: boolean;
        inactive?: boolean=true;
        inclusive?: boolean;
        active ?:boolean=true;
        status?:string;
        isTaxOverride?:boolean;
        CustomtaxAmount?:any=0;
        integratedId?: string;
        inActiveDate:any;
        activeDate:any;
        taxAmount?:any=0;
        effectiveTo:any;
        effectiveFrom:any;

    }

