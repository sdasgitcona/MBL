import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MakePaymentAddEditComponent } from './make-payment-add-edit.component';

describe('MakePaymentAddEditComponent', () => {
  let component: MakePaymentAddEditComponent;
  let fixture: ComponentFixture<MakePaymentAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MakePaymentAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MakePaymentAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
