import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {  MakePaymentListComponent } from './make-payment-list/make-payment-list.component';
import {  MakePaymentAddEditComponent } from './make-payment-add-edit/make-payment-add-edit.component';
import { MakePaymentApprovalComponent  } from './make-payment-approval/make-payment-approval.component';
const routes: Routes = [
  {
    path: '',
    component: MakePaymentListComponent,
  },
  {
    path: 'list',
    component: MakePaymentListComponent,
  },
  {
    path: 'list/:status',
    component: MakePaymentListComponent,
  },
  {
    path: 'action/:action/:id',
    component: MakePaymentAddEditComponent,
  },
  // {
  //   path: 'action/:action/:id',
  //   component: MakePaymentAddEditComponent,
  // },
  {
    path: 'action/:action/:id/:chkid',
    component: MakePaymentAddEditComponent,
  },
  {
    path: 'action/:action',
    component: MakePaymentAddEditComponent,
  },
  {
    path: 'MP_Approval',
    component: MakePaymentApprovalComponent,
  },
  {
    path: 'MP_Approval/:status',
    component: MakePaymentApprovalComponent,
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MakePaymentRoutingModule { }
