import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { supplierApprovalModel } from '../../supplier/model/supplier-model';
import { mpApproval } from '../model/make-payment-module';

@Component({
  selector: 'app-make-payment-approval',
  templateUrl: './make-payment-approval.component.html',
  styleUrls: ['./make-payment-approval.component.scss']
})
export class MakePaymentApprovalComponent implements OnInit {

  columns: any[];
  departments: any[] = [];

  mpApprovalList: mpApproval[] = [];
  mpSelectedApproval: mpApproval = new mpApproval();
  totalRecords: number = 0;
  loading: boolean = false;
  AllSelected:boolean=false;
  isRejectPressed:boolean=true;
  approvalRoutingActive:boolean=false;
  userRoleId:number;
  empID:number;
  approverRoleList: [{ id?: number; name?: string;  }];
  IsLoggerAdmin:string;
  LoggerRoleName:string;
  showloader:boolean=false;
  visibleSaveButton:boolean;
  url:any;
  @ViewChild('dt') dt: Table;
  RetloginDetails:any;
  RetRoleDetails:any;
  constructor(
    private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService

  ) {
   
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
 const logDetails:any = localStorage.getItem("LoggerDTLS");
 this.RetloginDetails=JSON.parse(logDetails);
 this.empID= this.RetloginDetails.employeeId;

 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;
 
 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Advance Payment Approval")
   {
     this.userRoleId=role_Dtls[0].rolePermissions[i].roleId 
     
   }
 }
 this.IsLoggerAdmin=role_Dtls[0].selectedAccess;
 this.LoggerRoleName=role_Dtls[0].name;
// End For Role Base Access
if(this.userRoleId != undefined){
  this.loadPRApproval();
}
else
{
  this.router.navigate(['/main/dashboard']);
}
  }

  loadPRApproval() {
    let ReqData;
    let ReqParam;
    let ReqDataa;
    let ReqParama;
    let reqUrl:any='';
   // if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null) //--User:Super Admin
   if(this.RetloginDetails.userType=='SUPERADMIN') 
   {
      ReqData=this.RetRoleDetails[0].accountId;
      ReqParam='accountId';
      reqUrl='/finance-ws/payment/get-payment-approval?'+ReqParam+'=' + ReqData;
    }
   // else if((this.RetRoleDetails[0].selectedAccess == 'ADMIN'|| this.RetRoleDetails[0].selectedAccess == 'ADMIN_APPROVER') && this.RetRoleDetails[0].subsidiaryId != null) //--User:Admin
    else if(this.RetloginDetails.userType=='ENDUSER')
    {
      if(this.RetRoleDetails[0].selectedAccess == 'APPROVER')
      {
        ReqData = this.empID;
        ReqParam = 'userId';
        ReqDataa=this.RetRoleDetails[0].subsidiaryId;
        ReqParama = 'subsidiaryId';
        reqUrl='/finance-ws/payment/get-payment-approval?'+ReqParam+'=' + ReqData+'&' +ReqParama+'=' + ReqDataa;
      }
      else
      {
        ReqData = this.RetRoleDetails[0].subsidiaryId;
        ReqParam = 'subsidiaryId';
        reqUrl='/finance-ws/payment/get-payment-approval?'+ReqParam+'=' + ReqData;
      }
    
    }
    else //--User:Others
    {
      ReqData=this.empID;
      ReqParam='userId';
      reqUrl='/finance-ws/payment/get-payment-approval?'+ReqParam+'=' + ReqData;
    }
    try { 
      this.HttpService.GetAll(reqUrl, this.RetloginDetails.token).subscribe(   
      //this.HttpService.GetAll('/finance-ws/payment/get-payment-approval?user='+this.empID,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
         else if (res && res.length > 0) {
          for(let i=0;i<res.length;i++)   
          {
            this.NextApproverLov(res[i].subsidiaryId)
          }      
          this.mpApprovalList = res;
          for(let k=0;k<this.mpApprovalList.length;k++)
          {
            this.mpApprovalList[k].nextApprover=Number(this.mpApprovalList[k].nextApprover);
            this.mpApprovalList[k].nextApproverRole= this.LoggerRoleName;
            this.mpApprovalList[k].isAdminRole=(this.IsLoggerAdmin=="ADMIN" || this.IsLoggerAdmin=="ADMIN_APPROVER")?true:false;
            this.mpApprovalList[k].advanceAmount = this.mpApprovalList[k].advanceAmount;
          }
          this.totalRecords = res.length;

            // this.mpApprovalList = res;
            // for(let i=0; i<res.length; i++){
            //   res[i].advanceAmount = res[i].advanceAmount.toFixed(2);
            // } 
            // this.totalRecords = res.length;
            //this.SubsidiaryId=this.poApprovalList[0]?.subsidiaryId;
            //this.NextApproverLov()
          } else {
            //this.poApprovalList = [];
            this.totalRecords = res.length;

          }
          this.loading = false;
        },
        (error) => {
          console.log(error);
          this.loading = false;
        }
      );
    } catch (err) {
      console.log(err);
    }
  }

  navigateToAdd() {
    this.router.navigate(['/main/supplier/update']);
  }

  globalSearch(event: any) {
    this.dt.filterGlobal(event.target.value, 'contains')
  }

  approveAP(){
    try { 
      this.isRejectPressed=false
      var approveList:any=[];   
      this.mpApprovalList.map((data:mpApproval)=>{
        if(data.selected){
          approveList.push(data.id)
        }
      })
      if(approveList.length>0){
        this.showloader=true;
        if(this.RetloginDetails.userType=='SUPERADMIN'){
          this.url='/finance-ws/payment/approve-all-payments?currentApproverId=' + this.empID;
  
         }
         else if(this.RetloginDetails.userType=='ENDUSER')
         {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                this.url='/finance-ws/payment/approve-all-payments?currentApproverId=' + this.empID;
              }
              else
              {
                this.url='/finance-ws/payment/approve-all-payments'
              }
        
         }
      this.HttpService.Insert(this.url,approveList,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else  if (res.messageCode) {
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
            this.showloader=false;
          } else {
            this.toastService.addSingle(
              'success',
              'Success',
              'Payment approved successfully !'
            );
          
          window.location.reload();
          this.showloader=false;
          }
         // this.loading = false;
        },
        (error) => {
          console.log(error);
         // this.loading = false;
        }
      );
      }
    } catch (err) {
      console.log(err);
    }
  }
  approveIndividual(mainId:any)
  {
    try {
      this.isRejectPressed = false
      var approveList: any = [];
      approveList.push(mainId);

      if (approveList.length > 0) {
        this.showloader = true;
        if(this.RetloginDetails.userType=='SUPERADMIN'){
          this.url='/finance-ws/payment/approve-all-payments?currentApproverId=' + this.empID;
  
         }
         else if(this.RetloginDetails.userType=='ENDUSER')
         {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                this.url='/finance-ws/payment/approve-all-payments?currentApproverId=' + this.empID;
              }
              else
              {
                this.url='/finance-ws/payment/approve-all-payments'
              }
        
         }
          this.HttpService.Insert(this.url,approveList,this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );

            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Payment approved successfully !'
              );
              //this.loadPRApproval();

              window.location.reload();
            }
          },
          (error) => {
            this.showAlert(error);
          }
        );
      }
    } catch (err) {
      this.showAlert(err)
    }
  }
  rejectAP(){
    try { 
      if(this.isRejectPressed){
      var rejectList:any=[];
      var isrejectComments:boolean=false   
      this.mpApprovalList.map((data:mpApproval)=>{
        if(data.selected){
          if(data.rejectedComments){
            rejectList.push({id:data.id,rejectedComments:data.rejectedComments})
            isrejectComments=true;
            this.isRejectPressed=true
          }else{
            this.toastService.addSingle(
              'error',
              'Error',
              'Please enter Reject Comments'
            );
            // alert("Please enter rejectComments");
            isrejectComments=false;
            this.isRejectPressed=true
            return;
          }
        }
      })
      if(isrejectComments){
        this.showloader=true;
      this.HttpService.Insert('/finance-ws/payment/reject-all-payments',rejectList,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
         else  if (res.messageCode) {
            this.isRejectPressed=true
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
            this.showloader=false;
          } else {
            this.toastService.addSingle(
              'success',
              'Success',
              'Reject selected Make Payment!'
            );
            window.location.reload();
            this.showloader=false;
          }
          this.isRejectPressed=true
         // this.loading = false;
        },
        (error) => {
         this.showAlert(error);
          this.showloader=false;
         // this.loading = false;
        }
      );
      }
    }else{
      this.isRejectPressed=true;
    }
    } catch (err) {
     this.showAlert(err);
      this.showloader=false;
    }
  }
  rejectIndividual(mainId:any,rejectComments:any,RowNo:any)
  {
    try {
      this.mpApprovalList[RowNo].selected=true;
      this.isRejectPressed=true;

      if( rejectComments==undefined)
      {
        this.showAlert("Please enter Reject Comments");
        return true;
      }

      if (this.isRejectPressed) {
        var rejectList: any = [];
        var isrejectComments: boolean = false;
        rejectList.push({id:mainId,rejectedComments:rejectComments})
              isrejectComments = true;
              //this.isRejectPressed = true
              
        if (isrejectComments) {
          this.showloader = true;
          this.HttpService.Insert('/finance-ws/payment/reject-all-payments',rejectList,this.RetloginDetails.token).subscribe(
            //this.HttpService.Insert('/finance-ws/advance/reject-all-advance-payments',rejectList ,this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else if (res.messageCode) {
                this.showloader = false;
                this.isRejectPressed = true
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );
                this.mpApprovalList[RowNo].selected=false;
                this.isRejectPressed=true;
                isrejectComments=false;
                this.mpApprovalList[RowNo].NewrejectComments=undefined;
              }
              else {
                this.showloader = false;
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Reject selected Make Payment!'
                );
                this.loadPRApproval();
              }
              this.isRejectPressed = true
              // this.loading = false;
            },
            (error) => {
              this.showAlert(error);
            }
          );
        }
      } else {
        this.showAlert("Please enter Reject Comments");
        this.isRejectPressed = true;
        this.showloader = false;
      }
    } catch (err) {
      this.showAlert(err);
    }
  }
  onAllSelectChange(event:any){
    if(event.checked){
      this.mpApprovalList.map((data:mpApproval)=>{
        data.selected=true;
        this.isRejectPressed=true
        //this.approvalRoutingActive=true;
      })
    }
    else{
      this.mpApprovalList.map((data:mpApproval)=>{
        data.selected=false;
        this.isRejectPressed=true;
       // this.approvalRoutingActive=false;

      })
    }
  }

  onSelectChange(event:any,routingStatus:any){
    if(!event.checked && this.AllSelected){
    this.AllSelected=false;
    //this.approvalRoutingActive=routingStatus;
    }
    this.isRejectPressed=true
  }

  viewSupplier(id:any){
    const url = this.router.serializeUrl(
      this.router.createUrlTree(["/main/supplier/action/view/"+id])
    );
    this.isRejectPressed=false
    window.open(url)
  }

  NextApproverLov(subsidiaryId:number) {
    try {    

      if(this.RetloginDetails.userType=='SUPERADMIN')
      {
         this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + subsidiaryId + '&formName=Make Payment Approval';
        }else if(this.RetloginDetails.userType=='ENDUSER'){
             if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
             {
              this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + subsidiaryId + '&formName=Make Payment Approval';
             }
             else
             {
              this.url='/masters-ws/employee/get-by-role-subsidiary?roleId=' + this.userRoleId + '&subsidiaryId=' + subsidiaryId + '&formName=Make Payment Approval';
             }

        
      }


      this.HttpService.GetAll(this.url,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else  if (res && res.length > 0) {
            this.approverRoleList = res;          
           // this.totalRecords = res.length;
          } else {
            this.approverRoleList = [{}];
           // this.totalRecords = res.length;

          }
          this.loading = false;
        },
        (error) => {
          console.log(error);
          this.loading = false;
        }
      );
    } catch (err) {
      console.log(err);
    }
  }

  OnChangeNextApprover(PrId:number,ApproverId:any) {
    try {    
if(ApproverId != null )
{
  ApproverId=Number(ApproverId);
}
else
{
  ApproverId=0;
}
      this.HttpService.GetAll(`/finance-ws/advance/update-next-approver?advancePaymentId=`+PrId+ `&approverId=`+ApproverId,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
         else if (res == true) {
            this.toastService.addSingle(
              'success',
              'Success',
              'Next Approver Assigned!'
            );
           } else {
            this.showAlert(res.errorMessage);
          }
        },
        (error) => {
          console.log(error);
        }
      );
    } catch (err) {
      console.log(err);
    }
  }

  onApproverSave() {
    try {
      let selectedMP;
      let selectedapprover;
      for(let x=0;x<this.mpApprovalList.length;x++)
      {
        if(this.mpApprovalList[x].selected)
      {
        selectedMP=this.mpApprovalList[x].id;
        selectedapprover=this.mpApprovalList[x].nextApprover
        break;
      }
      }
      this.HttpService.GetAll(`/finance-ws/payment/update-next-approver?paymentId=${selectedMP}&approverId=${selectedapprover}`, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          } else if (res == true) {
            this.showloader = false;
            this.toastService.addSingle(
              'success',
              'Success',
              'saved selected Make Payment!'
            );
            window.location.reload();
            //this.loadSuppliersApproval();
          } 
        },
        (error) => {
        }
      );
    } catch (err) {
    }
  }
  
  showAlert(AlertMSG:any) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  OnChangeVisibleButton(row:any,)
  {
   if(this.IsLoggerAdmin=="ADMIN")
   {
      if(this.mpApprovalList[row].selected)
      {
      //  this.mpApprovalList[row].isAdminForSave=false;
        this.visibleSaveButton=true;
      }
   }
  }

  cancel()
  {
    window.location.reload();
  }




}
