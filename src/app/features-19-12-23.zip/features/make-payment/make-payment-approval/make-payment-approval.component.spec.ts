import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MakePaymentApprovalComponent } from './make-payment-approval.component';

describe('MakePaymentApprovalComponent', () => {
  let component: MakePaymentApprovalComponent;
  let fixture: ComponentFixture<MakePaymentApprovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MakePaymentApprovalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MakePaymentApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
