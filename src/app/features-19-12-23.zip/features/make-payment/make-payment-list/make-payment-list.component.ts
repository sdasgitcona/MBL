import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { makepayment,supplierlist,bank } from '../model/make-payment-module'
import { BaseSearch,SubsidiaryEntry,BaseSearchPdf} from '../../supplier/model/supplier-model';
import { ToastService } from 'src/app/core/services/toast.service';
import { MakePaymentComponent } from '../../reports/make-payment/make-payment.component';
import * as FileSaver from 'file-saver';
declare let $: any;
import { PrimeNGConfig } from 'primeng/api';
@Component({
  selector: 'app-make-payment-list',
  templateUrl: './make-payment-list.component.html',
  styleUrls: ['./make-payment-list.component.scss']
})
export class MakePaymentListComponent implements OnInit {
  columns: any[];
  departments: any[] = [];
  makepaymentList: makepayment[] = [];
  selectedmakepayment: makepayment = new makepayment();
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  makepayment: makepayment = new makepayment();
  vendorTypeOptions:any;
  newevent:any;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  SubsideryObject:any=[];
  Vendorlist: supplierlist[] = [];
  VendorNumberlist: any[] = [];
  Subsidiarylist: SubsidiaryEntry[] = [];
  currencyModel:any[]=[];
  BankaccountList: bank[]=[];
  makepaymentPrint: any[] = [];
  status:any[]=[];
  fromDate:any;
  toDate:any;
  loginId:any;
  // For Role Base Access
  SubIdList:any=[];
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  loginDetails:any;
  RetRoleDetails:any;
  RetloginDetails: any;
  // For Role Base Access
  showloader:boolean;
  ApprovalButtonShowHide: Number = 0;
  isParams: boolean = true;
  filteredStatus:any;
  date_from:any;
  date_to:any;
  constructor(  private routeStateService: RouteStateService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private HttpService: CommonHttpService, private toastService: ToastService,private makePaymentReport: MakePaymentComponent,
    private primengConfig: PrimeNGConfig) {
      this.status = ['Pending Approval', 'Approved', 'Draft', 'Close', 'Rejected', 'Partially Approved', 'Fully Paid', 'Partially Paid', 'Partially Applied', 'Applied','Voided'];
     }
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }

     // For Role Base Access
     const retDetails:any = localStorage.getItem("RoleDTLS");
     var role_Dtls = JSON.parse(retDetails);
     this.RetRoleDetails=role_Dtls;
     const LoginDetails:any=localStorage.getItem("LoggerDTLS");
     this.loginDetails = JSON.parse(LoginDetails);
     const LDetails: any = localStorage.getItem("LoggerDTLS");
     this.RetloginDetails = JSON.parse(LDetails);
     this.loginId= this.RetloginDetails.employeeId;

     this.GetSubsideryList();
     this.getallcurrency();
     for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
     {
       if(role_Dtls[0].rolePermissions[i].accessPoint == "Make Payment")
       {
         this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
         this.isEditable=role_Dtls[0].rolePermissions[i].edit;
         this.isViewtable=role_Dtls[0].rolePermissions[i].view;
       }
     }
 // End For Role Base Access

   // this.resetBaseSearch();
 
   // this.GetAllVendorList();
   // For Getting Filtered Data from Dashboard
  let subsidyList:any=[];
  subsidyList.push(this.makepayment.subsidiaryId);
  this.activatedRoute.params.subscribe((params) => {
    if (params) {
      if (params['status']) {
        this.isParams = true;
        this.filteredStatus = params['status']
        if(this.filteredStatus == 'Recent'){
          this.getDate();
          this.baseSearch.filters={
            subsidiaryId: this.makepayment.subsidiaryId = this.SubsideryObject[0].id,
            recentlyCreated:this.makepayment.recent = true
            }
            this.baseSearch.pageNumber=-1;
            this.loadMakepayment(this.newevent);
            this.findby(this.filteredStatus);
       } else {
        this.baseSearch.filters={
          subsidiaryId: this.makepayment.subsidiaryId = this.SubsideryObject[0].id,
          status: this.makepayment.status = this.filteredStatus,
          }
          this.baseSearch.pageNumber=-1;
          this.loadMakepayment(this.newevent);
          this.findby(this.filteredStatus);
       }
     } 
   }
 });
 // For Getting Filtered Data from Dashboard
 this.columns = [
  // { field: 'Sl No', header: 'Sl No' },
   { field: 'Id', header: 'Internal ID' },
   { field: 'Subsidiary Name', header: 'Subsidiary' },
   { field: 'Supplier Name', header: 'Supplier Name' },
   { field: 'Bank Name', header: ' Bank Account' },
   { field: "Payment Date", header: 'Payment Date'},
   { field: 'Payment Number', header: ' Payment Number' },
   { field: 'Currency', header: 'Currency' },
   { field: "Amount", header: ' Payment Amount'},
   { field: "Creator", header: ' Creator'},
   { field: "Status", header: ' Status'},
   
 ];
this.exportColumns = this.columns.map(col => ({
  title: col.header,
  dataKey: col.field
}));
  }
  GetSubsideryList() {
    this.SubsideryObject=[];
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.loginDetails.token).subscribe(
       (res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
       else {
        this.SubsideryObject=res;
        for (let x = 0; x < this.SubsideryObject.length; x++) {
          this.SubIdList.push(this.SubsideryObject[x].id);
        }
        this.resetBaseSearch();
      }
        
      },
      (error) => {
       
      },
      
      () => {
        if(localStorage.getItem("MakePaymentFilters") != null)
        {const LocDetails:any =localStorage.getItem("MakePaymentFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.makepayment.subsidiaryId=searcheData.filters.subsidiaryId[0];
        this.makepayment.supplierId=searcheData.filters.supplierId;
        this.makepayment.paymentNumber=searcheData.filters.makePaymentNumber;
        this.makepayment.currency=searcheData.filters.currency;
        this.makepayment.status=searcheData.filters.status;
        this.makepayment.FormDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
        this.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
        this.makepayment.Todate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
        this.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
        this.makepayment.bankId=searcheData.filters.bankId;
        this.makepayment.creator=searcheData.filters.creator;
        this.loadsupplier(searcheData.filters.subsidiaryId[0]);
        setTimeout(() => {this.loadMakepayment(this.newevent)},300);
       
        localStorage.removeItem("MakePaymentFilters");
        }
        else
       { this.resetBaseSearch();}
      }
    );
  }else if(this.RetloginDetails.userType=='ENDUSER')
  {
    this.SubsideryObject.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });
    this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
    this.makepayment.subsidiaryId = this.RetRoleDetails[0].subsidiaryId;
    this.loadsupplier(this.RetRoleDetails[0].subsidiaryId)
    if(localStorage.getItem("MakePaymentFilters") != null)
      {
	  const LocDetails:any =localStorage.getItem("MakePaymentFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.makepayment.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.makepayment.supplierId=searcheData.filters.supplierId;
      this.makepayment.paymentNumber=searcheData.filters.makePaymentNumber;
      this.makepayment.currency=searcheData.filters.currency;
      this.makepayment.status=searcheData.filters.status;
      this.makepayment.FormDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
      this.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
      this.makepayment.Todate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.makepayment.bankId=searcheData.filters.bankId;
      this.makepayment.creator=searcheData.filters.creator;
      this.loadsupplier(searcheData.filters.subsidiaryId[0]);
      localStorage.removeItem("MakePaymentFilters");
      }
      else
     { this.resetBaseSearch();}
  }
  }

       navigateToAddViewEdit(
        action: string,
        selectedmakepayment: makepayment = new makepayment()
      ) {
        let makepaymentId = null;
        if (selectedmakepayment?.id) {
          makepaymentId = selectedmakepayment.id;
          this.router.navigate(['/main/make-payment/action', action, makepaymentId]);
        } else {
          this.router.navigate(['/main/make-payment/action', action]);
        }
       }
     /* exportPdf() {
        import("jspdf").then(jsPDF => {
            import("jspdf-autotable").then(x => {
                const doc = new jsPDF.default();
                (doc as any).autoTable(this.exportColumns, this.makepaymentList);
                //doc.save('supplier.pdf');
                doc.save('make-payment.pdf');
            })
        })
      }*/
    findby(event: any){
      let subsidyList:any=[];
      subsidyList.push(this.makepayment.subsidiaryId);
      let date_from:any;
    let date_to:any;
    if(this.makepayment.FormDate!=undefined)
    {
     //let effectiveFrom=this.taxRateRule.effectiveFrom.setDate(this.taxRateRule.effectiveFrom.getDate() - 1)
      let days_from:any = new Date(this.makepayment.FormDate).getUTCDate();
      if(days_from<10)
      {
         days_from="0"+days_from;
      }
      let months_from:any = new Date(this.makepayment.FormDate).getUTCMonth()+1;
      
      if(months_from<10)
      {
        months_from="0"+months_from;
      }
      let year_from:any = new Date(this.makepayment.FormDate).getUTCFullYear();
      date_from=year_from+"-"+months_from+"-"+days_from;
    }
    if(this.makepayment.Todate!=undefined)
    {
     // let effectiveto=this.taxRateRule.effectiveTo.setDate(this.taxRateRule.effectiveTo.getDate() - 1)
      let days_to:any = new Date(this.makepayment.Todate).getUTCDate();
      if(days_to<10)
      {
        days_to="0"+days_to;
      }
      let months_to:any = new Date(this.makepayment.Todate).getUTCMonth()+1;
      if(months_to<10)
      {
        months_to="0"+months_to;
      }
      let year_to:any = new Date(this.makepayment.Todate).getUTCFullYear();
      date_to=year_to+"-"+months_to+"-"+days_to;
    }
      this.baseSearch.filters={
        subsidiaryId: subsidyList,
        //subsidiaryId:this.makepayment.subsidiaryId>0?Number(this.makepayment.subsidiaryId):0,
        supplierId:this.makepayment.supplierId>0?Number(this.makepayment.supplierId):0,
        makePaymentNumber:this.makepayment.paymentNumber,
        currency:this.makepayment.currency,
        // status: this.makepayment.status != undefined ? this.makepayment.status : "",
        status: this.makepayment.status,
        fromDate:date_from,
        toDate:date_to,
        bankId:this.makepayment.bankId,
        creator:this.makepayment.creator,
        recentlyCreated:this.makepayment.recent
    }
    this.baseSearch.pageNumber=-1;
 
      this.loadMakepayment(this.newevent);
    }
    
    loadMakepayment(event: any) {
      try {
        this.newevent=event
        this.loading = true;
        this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
        // this.baseSearch.pageNumber = 1;
        this.baseSearch.pageSize = event.rows;
        // this.baseSearch.sortColumn = event.sortField
        //   ? 's.' + event.sortField
        //   : GlobalConstants.SUPPLIER_TABLE_SORT_COLUMN;
        this.baseSearch.sortColumn = event.sortField
        ?  event.sortField
        : GlobalConstants.MAKEPAYMENT_TABLE_SORT_COLUMN;
        this.baseSearch.sortOrder =
          event.sortOrder == -1
            ? GlobalConstants.ASCENDING
            : GlobalConstants.DESCENDING;
         // this.resetBaseSearch();
         if(this.SubIdList.length==0)
         {
          return;
         }
        this.HttpService.Insert('/finance-ws/payment/get/all', this.baseSearch,this.loginDetails.token).subscribe(
          (res) => {
            if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
             { 
              if (res && res.list.length > 0) {
                this.makepaymentList=[];
              this.makepaymentList = res.list;
              // if(this.baseSearch.filters && (Object.keys(this.baseSearch.filters).length === 0)){
              // this.VenderNameList = res.list;
              // }
              this.totalRecords = res.totalRecords;

              for(let x=0;x<this.makepaymentList.length;x++) {
                if(this.makepaymentList[x].status == 'Pending Approval' || this.makepaymentList[x].status == 'Applied' || this.makepaymentList[x].status == 'Partially Applied' || this.makepaymentList[x].status == 'Approved' || this.makepaymentList[x].status == 'Closed' || this.makepaymentList[x].status == 'Voided' || this.makepaymentList[x].status == 'Partially Approved') //Send Approval Mode
                {
                  this.makepaymentList[x].isApprovalButtonShowHide = 0;
                }else{
                  this.makepaymentList[x].isApprovalButtonShowHide = 1;
                }
              }


            } else {
              
              this.makepaymentList = [];
              this.totalRecords = 0;
            }
            this.loading = false;
          }
          },
          (error) => {
           this.loading = false;
          }
        );
      } catch (err) {
       }
    }
    resetBaseSearch() {
      this.baseSearch.filters = {subsidiaryId: this.SubIdList};
      this.baseSearch.pageNumber = 0;
      this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
      this.baseSearch.sortColumn = GlobalConstants.MAKEPAYMENT_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder = GlobalConstants.DESCENDING;
      this.loadMakepayment(this.newevent);
    }
    Reset()
    {
      if(this.RetloginDetails.userType=='SUPERADMIN')
      {
        this.makepayment.subsidiaryId =undefined;
      }
      this.makepayment.supplierId=undefined;
      this.makepayment.paymentNumber=undefined;
      this.makepayment.currency=undefined;
      this.makepayment.FormDate=undefined;
      this.makepayment.Todate=undefined;
      this.makepayment.bankId=undefined;
      this.makepayment.creator=undefined;
      this.makepayment.status=undefined;
      this.resetBaseSearch();
    }
    showAlert(AlertMSG:string) {
      this.toastService.addSingle(
        'error',
        'Error',
        AlertMSG
      );
    }

    loadsupplier(subsidiaryId:any)
    {
      this.Vendorlist=[];
      this.GetAllVendorList(subsidiaryId);
      this.GetAccountTypeMulticurrency(subsidiaryId);

    }
    GetSupplierCurrencyList(): any {
      this.HttpService.GetAll("/masters-ws/supplier/get-currency-by-supplier?supplierId=" + this.makepayment.supplierId, this.loginDetails.token)
        .subscribe(res => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res.error) {
              //var error = JSON.parse(res.error);
              this.toastService.addSingle(
                'error',
                'Error',
                res.error.errorMessage
              );
              this.currencyModel = [];
            } else {
              this.currencyModel = res;
            }
          }
        },
          error => {
          },
          () => {
            // 'onCompleted' callback.
            // No errors, route to new page here
          });
    }
    
  GetAllVendorList(subsidiaryId:any){
    var obj={
      filters:{},
      "pageNumber": 0,
        "pageSize": 1000,
        "sortColumn": "vendor_type",
        "sortOrder": "asc"
    }
        this.HttpService .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' +subsidiaryId, subsidiaryId, this.loginDetails.token)
        .subscribe(res => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }else
         { 
          this.Vendorlist=res;}
        });
       }

    GetAccountTypeMulticurrency(subsidiaryId:any) {
      this.HttpService.GetAll('/masters-ws/bank/get-by-subsidiary-id?subsidiaryId='+subsidiaryId,this.loginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
          { this.BankaccountList = [];
           for(let i=0;i<res.length;i++)
           {
                if(res[i].active==true)
                {
                  this.BankaccountList.push({id:res[i].id,name:res[i].name})
                }
           }
      }
        },
        (error) => {
          this.showAlert(error);
         },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        }
      );
    }

    
  getallcurrency()
  {
    this.HttpService.GetAll("/setup-ws/currency/get/all",this.loginDetails.token)
    .subscribe(res => {
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        if (res) {
      
          this.currencyModel=res;
          
        
         } else {
          this.currencyModel=[];
           
         }
      }
      },
      error => {
        // console.log(error);
        this.currencyModel=[];
       },
       () => {
         // 'onCompleted' callback.
         // No errors, route to new page here
       });
  }
  DownloadReport(makePmtNo:any){
    this.showloader=true;
    //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
  this.makePaymentReport.exportPdf(makePmtNo);  
  this.showloader=false;
  };

  selfApproval(id:any){
    this.showloader=true;
      this.HttpService
        .GetById('/finance-ws/payment/self-approve?id=' +  id, id, this.RetloginDetails.token)
        .subscribe((res) => {
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
             this.router.navigate(['/login']);
           }
         else if (res == true) {
          this.toastService.addSingle(
            'success',
            'Success',
            'Make Payment Approved Successfully!'
          );
          window.location.reload();
          this.showloader=false;
         } else {
          this.showAlert(res.errorMessage);
          this.showloader=false;
        }
        },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Error',
              'Error occured while sending Make Payment for Approval!'
            );
            this.showloader=false;
          }
  
        );
  }

  sendForApproval(id:any){
    this.showloader=true;
      this.HttpService
        .GetById('/finance-ws/payment/send-for-approval?id='+  id, id, this.RetloginDetails.token)
        .subscribe((res) => {
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
             this.router.navigate(['/login']);
           }
         else if (res == true) {
          this.toastService.addSingle(
            'success',
            'Success',
            'Make Payment Sent for Approval Successfully!'
          );
          window.location.reload();
          this.showloader=false;
         } else {
          this.showAlert(res.errorMessage);
          this.showloader=false;
        }
        },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Error',
              'Error occured while sending Make Payment for Approval!'
            );
            this.showloader=false;
          }
  
        );
  }
  getDate() {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
    const day = (currentDate.getDate()-1).toString().padStart(2, '0');
    this.date_to = `${year}-${month}-${day}`;

    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(currentDate.getDate() - 7);
    const fromYear = sevenDaysAgo.getFullYear();
    const fromMonth = (sevenDaysAgo.getMonth() + 1).toString().padStart(2, '0');
    const fromDay = sevenDaysAgo.getDate().toString().padStart(2, '0');
    this.date_from = `${fromYear}-${fromMonth}-${fromDay}`;
  }
  editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("MakePaymentFilters") != null)
    {
      localStorage.removeItem("MakePaymentFilters");
    }
    localStorage.setItem("MakePaymentFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/make-payment/action', actionType, mainId,0]);
   }



   /***((Export Excel)) */
   generatePDFData(exportType:any){
    this.newevent = event;
    this.baseSearchPdf.pageSize = this.totalRecords;
    this.baseSearchPdf.sortColumn =GlobalConstants.MAKEPAYMENT_TABLE_SORT_COLUMN;
    this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};

    this.HttpService.Insert('/finance-ws/payment/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //this.employeelistPrint = [];
          this.makepaymentPrint = [];
          if (res && res.list.length > 0) {
            var RetData = res.list;
            for (let i = 0; i < RetData.length; i++) {
                if (RetData[i].id == undefined) {
                RetData[i].id = "";
              }
              if(exportType == 'PDF'){ 
              
                this.makepaymentPrint.push({
                  'Id': RetData[i].id,    
                  'Subsidiary Name':RetData[i].subsidiaryName, 
                  'Supplier Name': RetData[i].supplierName,
                  'Bank Name': RetData[i].bankName,
                  'Payment Date': RetData[i].paymentDate,
                  'Payment Number': RetData[i].paymentNumber,    
                  'Currency':RetData[i].currency, 
                  'Amount': RetData[i].amount,
                  'Creator': RetData[i].creator,
                  'Status': RetData[i].status,

                  // 
                  
              });
            }
              else{
                this.makepaymentPrint.push({
                  'Internal Id': RetData[i].id,    
                  'Subsidiary':RetData[i].subsidiaryName, 
                  'Supplier Name': RetData[i].supplierName,
                  'Bank Account': RetData[i].bankName,
                  'Payment Date': RetData[i].paymentDate,
                  'Payment Number': RetData[i].paymentNumber,    
                  'currency':RetData[i].Currency, 
                  'Payment Amount': RetData[i].amount,
                  'Creator': RetData[i].creator,
                  'Status': RetData[i].status,
                });
              }

            }
          }
          if(exportType == 'PDF')
          {this.exportPdf();}
        }
      }
    );
  }
  exportPdf() {
    import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
        const doc = new jsPDF.default();
        //this.= this.employeeExport;
        //this.employeelist=[];
        (doc as any).autoTable(this.exportColumns, this.makepaymentPrint);
        doc.save('makepayment.pdf');
      })
    })
  }

//End PDF

//Start Excel
exportExcel() {
  this.showloader=true
  this.generatePDFData('');

 setTimeout(() => {
  this.exportExcelData()
 }, 250);
  }
  exportExcelData()
  {
    if(this.makepaymentPrint.length >0)
    { import('xlsx').then((xlsx) => {
         const worksheet = xlsx.utils.json_to_sheet(this.makepaymentPrint);
         const workbook = { 
             Sheets: { data: worksheet }, 
             SheetNames: ['data'] 
         };
         const excelBuffer: any = xlsx.write(workbook, {
             bookType: 'csv',
             type: 'array',
         });
         this.saveAsExcelFile(excelBuffer, 'makepayment');
         this.showloader=false;
     });}
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
      let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
      let EXCEL_EXTENSION = '.csv';
      const data: Blob = new Blob([buffer], {
          type: EXCEL_TYPE,
      });
      FileSaver.saveAs(
          data, fileName + EXCEL_EXTENSION
          //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
      );
  }
//End Excel 
  //List Export option End

   /********Export excel */

   sendmail(id:number)
   {
    //{{financeGateway}}/payment/send-mail-to-payment-supplier?paymentId=80
    this.showloader=true;
    this.HttpService.GetAll('/finance-ws/payment/send-mail-to-payment-supplier?paymentId='+id+'&empId='+ this.loginId,this.loginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
     { this.showAlert("Unauthorized Access !");
       this.router.navigate(['/login']);
     }
     else if(res.status == 404)
     { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
    else 
      {
       
        if(res.status == 500)
        {

          this.showloader=false;
          this.showAlert("Error occured while sending mail!")
        }
        else{
          this.showloader=false;
          this.showSuccessMail();
          location.reload();
        }
        
       
      }

      },
      (error) => {
        this.showloader=false;
        this.showAlert(error);
      
       },
      () => {}
      );



   }

   recallStatus(mainId:any)
   {
     this.showloader = true;
     this.HttpService
       .GetAllResponseText('/finance-ws/payment/recall?id=' +mainId, this.RetloginDetails.token)
       .subscribe((res) => {
         //For Auth
         if (res.status == 401) {
           this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if (res.status == 404) {
           this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
         else if (res.status == 200) {
             this.toastService.addSingle(
               'success',
               'Success',
               res.error.text
             );
             this.showloader = false;
             window.location.reload();
         }
         else
         {
           this.toastService.addSingle(
             'error',
             'Error',
             'Error occured !'
           );
           this.showloader = false;
         }
       },
         (error) => {
           this.toastService.addSingle(
             'error',
             'Error',
             'Error occured !'
           );
           this.showloader = false;
         });
   }

   showSuccessMail() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Mail Sent Successfully!'
    );
  }

  onRowSelect(event: any) {
    let mpId = event.data.id;
    
    this.router.navigate(['/main/make-payment/action/view', mpId, 0]);
  }

}
