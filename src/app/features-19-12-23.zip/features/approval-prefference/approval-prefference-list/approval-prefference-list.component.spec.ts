import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovalPrefferenceListComponent } from './approval-prefference-list.component';

describe('ApprovalPrefferenceListComponent', () => {
  let component: ApprovalPrefferenceListComponent;
  let fixture: ComponentFixture<ApprovalPrefferenceListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApprovalPrefferenceListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApprovalPrefferenceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
