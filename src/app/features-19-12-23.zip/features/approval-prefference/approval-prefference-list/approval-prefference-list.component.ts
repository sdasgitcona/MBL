import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import {
  BaseSearch, approvalPreferenceModule, approvalPreferenceConditions, approvalPreferenceSequences,
  CommonDropdown, apList, apSearch
} from '../model/Approval-Prefference-model';
import { ToastService } from 'src/app/core/services/toast.service';
import { PrimeNGConfig } from 'primeng/api';
@Component({
  selector: 'app-approval-prefference-list',
  templateUrl: './approval-prefference-list.component.html',
  styleUrls: ['./approval-prefference-list.component.scss']
})
export class ApprovalPrefferenceListComponent implements OnInit {
  newevent: any;
  columns: any[];
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  totalRecords: number = 0;
  Subsidiarylist: any[] = [];
  approvalList: apList[] = [];
  selectedListData: apList = new apList()
  apFilter: apSearch = new apSearch();
  recordType: any;
  SubTypelist: CommonDropdown[] = [];
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  // For Role Base Access
  RetloginDetails: any;
  SubIdList:any=[];
  RetRoleDetails:any;
  constructor(private routeStateService: RouteStateService,
    private router: Router, private primengConfig: PrimeNGConfig,
    private HttpService: CommonHttpService, private toastService: ToastService) {
    this.recordType = [
      { name: 'Transaction', code: 'Transaction' },
      { name: 'Master', code: 'Master' },
    ];
  }
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Approval Preference") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
      }
    }
    // End For Role Base Access
    this.GetSubsideryList();
    this.primengConfig.ripple = true;
    this.columns = [
      { field: 'id', header: 'Internal ID' },
      { field: 'subsidiaryName', header: 'Subsidiary' },
      { field: 'recordType', header: 'Record Type' },
      { field: 'subType', header: 'Sub Type' },
      { field: 'approvalType', header: 'Approval type' },
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }
  /* Start Fetch Subsidery list from api */
  GetSubsideryList() {
    // this.HttpService.GetAll("/setup-ws/subsidiary/get/all", this.RetloginDetails.token).subscribe(
    //   (res) => {
    //     if (res.status == 401) {
    //       this.showAlert("Unauthorized Access !");
    //       this.router.navigate(['/login']);
    //     }
    //     else if (res.status == 404) {
    //       this.showAlert("Wrong/Invalid Token!");
    //       this.router.navigate(['/login']);
    //     }
    //     else {
    //       this.Subsidiarylist = res.list;
    //       //this.SubsideryObject = res;
    //     }
    //   },
    //   (error) => {
    //   }
    // );
  
    this.Subsidiarylist=[];
   //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
   if(this.RetloginDetails.userType=='SUPERADMIN')
   {
     this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
     (res) => {
       if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
      { this.Subsidiarylist=res;
       for(let x=0;x<this.Subsidiarylist.length;x++)
      { 
       this.SubIdList.push(this.Subsidiarylist[x].id);
     }
     }
     },
     (error) => {
       alert(error);
      },
      ()=>{
       this.resetBaseSearch();
      //this.loadSuppliers('');
      }
   );
   }else if(this.RetloginDetails.userType=='ENDUSER'){
     this.Subsidiarylist.push({
       "id":this.RetRoleDetails[0].subsidiaryId,
       "name":this.RetRoleDetails[0].subsidiaryName
     });
     this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
     this.apFilter.subsidiaryId= this.Subsidiarylist[0].id
     this.resetBaseSearch();
   }
  }

  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.TAX_RATE_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadData(this.newevent);
  }

  ReloadSubsidiaryList() {
    this.apFilter.subsidiaryId = undefined;
    this.GetSubsideryList();
  }
  //--Get SubType List
  GetSubTypeList(RecordType: string) {
    try {
      //this.HttpService.GetById('/roles/get-roles-by-subsidiary?subsidiaryId=' + SubsidiaryId, SubsidiaryId).subscribe(
      this.HttpService.GetAll('/setup-ws/preference/get-approval-routing-by-status?subsidiaryId=' + this.apFilter.subsidiaryId + '&formType=' + RecordType, this.RetloginDetails.token).subscribe(
        // Insert('/get-roles-by-subsidiary?subsidiaryId',obj)
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.length > 0) {
              this.SubTypelist = [];
              for (let i = 0; i < res.length; i++) {
                this.SubTypelist.push({
                  "id": res[i],
                  "name": res[i]
                });
              }
            } else {
              this.SubTypelist = [];
            }
          }
        },
        (error) => {
          this.showAlert(error);
        }
      );
    } catch (err: any) {
      this.showAlert(err);
    }
  }
  loadData(event: any) {
    try {
      this.newevent = event;
      this.loading = true;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
      this.baseSearch.sortColumn = event.sortField
        ? event.sortField
        : GlobalConstants.APPROVAL_PREFERENCE_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
          if(this.SubIdList.length==0 && this.RetloginDetails.userType!='ROOTADMIN'){return;}
      this.HttpService.Insert('/masters-ws/approval-preference/get/all', this.baseSearch, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.approvalList = [];
            if (res && res.list.length > 0) {
              this.approvalList = res.list;
              //this.employeelist = res.list;          
              this.totalRecords = res.totalRecords;
            } else {
              this.approvalList = [];
              this.totalRecords =0;
            }
            this.loading = false;
          }
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {
    }
  }
  findby(event: any) {
    let subsidyList:any=[];
    subsidyList.push(this.apFilter.subsidiaryId);

    this.baseSearch.filters = {
      subsidiaryId: subsidyList,
      recordType: this.apFilter.recordType,
      subType: this.apFilter.subType
    }
    this.baseSearch.pageNumber=-1;
    this.loadData(this.newevent);
  }
  navigateToAddViewEdit(
    action: string,
    selectedData: apList = new apList()
  ) {
    let mainId = null;
    if (selectedData?.internalId) {
      mainId = selectedData.internalId;
      this.router.navigate(['/main/approval-preferences/action', action, mainId]);
    } else {
      this.router.navigate(['/main/approval-preferences/action', action]);
    }
  }
  exportPdf() {
    import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
        const doc = new jsPDF.default();
        (doc as any).autoTable(this.exportColumns, this.approvalList);
        doc.save('Approval Prefference.pdf');
      })
    })
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Data Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving!'
    );
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  Reset() {

    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.apFilter.subsidiaryId = undefined;
    }
   
    this.apFilter.recordType = undefined;
    this.apFilter.subType = undefined;
    this.resetBaseSearch();
  }

  onRowSelect(event: any) {
    let apId = event.data.id;
    
    this.router.navigate(['/main/approval-preferences/action/view', apId]);
  }

}
