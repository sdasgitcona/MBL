import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApprovalPrefferenceListComponent } from './approval-prefference-list/approval-prefference-list.component';
import { ApprovalPrefferenceAddEditComponent } from './approval-prefference-add-edit/approval-prefference-add-edit.component';

const routes: Routes = [
{
  path: 'list',
  component: ApprovalPrefferenceListComponent,
},
{
  path: 'action/:action/:id',
  component: ApprovalPrefferenceAddEditComponent,
},
{
  path: 'action/:action',
  component: ApprovalPrefferenceAddEditComponent,
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ApprovalPrefferenceRoutingModule { }
