export class approvalPreferenceModule {
  id?: number;
  subsidiaryId?: number;
  approvalType: any;
  recordType: string;
  subType: string;
  inactiveDate?: any;
  active?: boolean = true;
  approvalPreferenceConditions: approvalPreferenceConditions[] = [];//new approvalPreferenceConditions ();
  //ApproverDetails:ApproverDetails[]=[];
}
export class approvalPreferenceConditions {
  level?: string;
  roleId?: number;
  approvalPreferenceSequences: approvalPreferenceSequences[] = [];
  deleted?: boolean;
  approvers: ApproverDetails[]
}
export class approvalPreferenceSequences {
  id?: number;
  conditionId?: number;
  sequenceId?: number;
  amountFrom?: any;
  amountTo?: any;
  locationId?: any;
  department?: any;
  departmentId?:any;
  approverId?: number;
  parallelApproverLevel?: boolean;
  deleted?: boolean;
  IsDisabled?: boolean = false;
  natureOfSupply?: any | null = null;
  isStsActive?: boolean = true;
  active?: boolean = true;
  approvers: ApproverDetails[] = [];
}
export class BaseSearch {
  filters: TblFilter | {} = {};
  pageNumber: number = 0;
  pageSize: number = 0;
  sortColumn: string = '';
  sortOrder: string = '';
}
export class TblFilter {
  subsidiaryName: string = '';
  name: string = '';
  active: string = '';
}
export class CommonDropdown {
  id: number;
  name: string;
}
export class apList {
  internalId?: number;
  subsidiaryName?: string;
  recordType?: string;
  subType?: string;
  approvalType?: string;
}
export class apSearch {
  subsidiaryId?: number;
  subType?: string;
  recordType?: string;
}
export class deactiveLineLabel {
  id?: number;
  approvalPreferenceId?: number;
  conditionId?: number;
  sequenceId?: number;
  amountFrom?: any;
  amountTo?: any;
  locationId?: number;
  department?: any;
  natureOfSupply?: any;
  approverId?: number;
  parallelApproverLevel?: any;
  createdDate?: any;
  createdBy?: any;
  lastModifiedDate?: any;
  lastModifiedBy?: any;
  active?: boolean;
  deleted?: boolean;
}
export class ApproverDetails {
  id?:any;
  approverSequence?: any;
  approverId?: any;
  approvername?: any;
  action?: boolean = false;
  deleted?: boolean= false;
  approvalPreferenceId?: any;
  conditionId?: any;
  createdBy?: any;
  createdDate?: any;
  lastModifiedBy?: any;
  lastModifiedDate?: any;
  sequenceId?: any;
  status?: any;
}
export class department{
  departmentName:any;
  id:number;
}

