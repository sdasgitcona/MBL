import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovalPrefferenceAddEditComponent } from './approval-prefference-add-edit.component';

describe('ApprovalPrefferenceAddEditComponent', () => {
  let component: ApprovalPrefferenceAddEditComponent;
  let fixture: ComponentFixture<ApprovalPrefferenceAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApprovalPrefferenceAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApprovalPrefferenceAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
