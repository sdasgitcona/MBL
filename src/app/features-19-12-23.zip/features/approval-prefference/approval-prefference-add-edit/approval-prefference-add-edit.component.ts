import { Component, OnInit, QueryList, ViewChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BaseSearch, approvalPreferenceModule, approvalPreferenceConditions, approvalPreferenceSequences, CommonDropdown, deactiveLineLabel, ApproverDetails,department } from '../model/Approval-Prefference-model';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { PrimeNGConfig } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { TabView, TabPanel } from 'primeng/tabview';
import { TRISTATECHECKBOX_VALUE_ACCESSOR } from 'primeng/tristatecheckbox';
declare let $: any;
//class variable

@Component({
  selector: 'app-approval-prefference-add-edit',
  templateUrl: './approval-prefference-add-edit.component.html',
  styleUrls: ['./approval-prefference-add-edit.component.scss']
})
export class ApprovalPrefferenceAddEditComponent implements OnInit {
  @ViewChild("tabsContainer", { static: true, read: ViewContainerRef }) tabsContainer!: ViewContainerRef;
  newDynamic: any = {};
  Subsidiarylist: any[] = [];
  SubTypelist: CommonDropdown[] = [];
  subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  closeMode: boolean = false;
  HistoryList: HistoryModel[] = [];
  PopupApproverlist: any[] = [];
  selectedApprover: ApproverDetails = new ApproverDetails();
  mainId: number = 0;
  approvalType: any;
  recordType: any;
  apModel: approvalPreferenceModule = new approvalPreferenceModule();
  NewTab: any[] = [];
  roleList: any[] = [];
  TabNo: number;
  ishidedepartment:boolean=false;
  approverlist: any[] = [];
  DepartmentList: department[]=[];
  locationListOptions: any;
  disabledLocationDesignation: boolean;
  AddButtonVisible: boolean = true;
  disableMasterMode: boolean = false;
  DefaultTab: number;
  ForHistroryTab: approvalPreferenceConditions[] = [];
  natureSupplyList: any;
  isAddRowVisible: boolean = true;
  isInactiveDateVisible: boolean;
  showloader: boolean = false;
  display: boolean = false;
  Chktooltip: boolean = false;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  isviewEditable: boolean = true;
  deactiveLineLabel: deactiveLineLabel = new deactiveLineLabel();
  // For Role Base Access
  showForChain: boolean = true;
  RetloginDetails: any;
  popupconditionRow: any;
  popupsequenceRow: any;
  approverSequenceUid: any;
  ConditionRow:any;
  RetRoleDetails:any;
  constructor(private routeStateService: RouteStateService, private activatedRoute: ActivatedRoute,
    private router: Router, private toastService: ToastService,
    private HttpService: CommonHttpService, private primengConfig: PrimeNGConfig,
    private viewContainerRef: ViewContainerRef) {
    this.approvalType = [
      { name: 'Individual', code: 'Individual' },
      { name: 'Chain', code: 'Chain' },
    ];
    this.recordType = [
      { name: 'Transaction', code: 'Transaction' },
      { name: 'Master', code: 'Master' },
    ];
    this.natureSupplyList = [
      { name: 'Service', code: 'Service' },
      { name: 'Goods', code: 'Goods' },
      { name: 'Both', code: 'Both' },
    ];
   

  }
  ngOnInit(): void {
    if (localStorage.getItem("LoggerDTLS") == null) {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails =role_Dtls;

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Approval Preference") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
        if (this.isEditable == false)
          this.isviewEditable = false;
      }
    }
    // End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.mainId = +params['id']; // (+) converts string 'id' to a number
            if (params['action'] != "add") {
              this.GetMasterDatabyId();
              this.AddButtonVisible = false;
              this.LoadHistory();
            }
            //this.LoadHistory();
          }
          this.assignMode(params['action']);
          this.GetSubsideryList();
        } else {
        }
      },
      (error) => {
      });
  }
  //--Assign Mode
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        this.closeMode = true;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.closeMode = false;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = true;
        this.closeMode = false;
        break;

      default:
        break;
    }
  }
  //--Subsidiary List
  GetSubsideryList() {
    // this.HttpService.GetAll('/setup-ws/subsidiary/get/all', this.RetloginDetails.token).subscribe(
    //   (res) => {
    //     if (res.status == 401) {
    //       this.showAlert("Unauthorized Access !");
    //       this.router.navigate(['/login']);
    //     }
    //     else if (res.status == 404) {
    //       this.showAlert("Wrong/Invalid Token!");
    //       this.router.navigate(['/login']);
    //     }
    //     else {
    //       this.Subsidiarylist = res.list;
    //     }
    //   },
    //   (error) => {
    //   }
    // );
    this.Subsidiarylist=[];
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist=res;
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });

    }
  }
  //--Get RoleList
  GetAllRoleList(SubsidiaryId: any) {
    try {
      //this.HttpService.GetById('/roles/get-roles-by-subsidiary?subsidiaryId=' + SubsidiaryId, SubsidiaryId).subscribe(
      this.HttpService.GetAll(`/masters-ws/roles/get-roles-by-subsidiary?subsidiaryId=${SubsidiaryId}&accessType=` + "APPROVER", this.RetloginDetails.token).subscribe(
        // Insert('/get-roles-by-subsidiary?subsidiaryId',obj)
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.length > 0) {
              this.roleList = res;
            } else {
              this.roleList = [];
            }
          }
        },
        (error) => {
        }
      );
    } catch (err) {
    }
  }
  //--Get SubType List
  GetSubTypeList(RecordType: string) {
    if (this.apModel.subsidiaryId == undefined) {
      this.showAlert("Please select Subsidiary");
      return;
    }
    try {
      if(this.apModel.recordType=="Master")
      {
        this.apModel.approvalType="";
        this.approvalType.splice(0,1);
        this.apModel.approvalType="Chain";
        this.ishidedepartment=true;
      }
      else{
        this.approvalType = [
          { name: 'Individual', code: 'Individual' },
          { name: 'Chain', code: 'Chain' },
        ];
        this.apModel.approvalType=undefined;
        this.ishidedepartment=false;
      }
      //this.HttpService.GetById('/roles/get-roles-by-subsidiary?subsidiaryId=' + SubsidiaryId, SubsidiaryId).subscribe(
      this.HttpService.GetAll('/setup-ws/preference/get-approval-routing-by-status?subsidiaryId=' + this.apModel.subsidiaryId + '&formType=' + RecordType, this.RetloginDetails.token).subscribe(
        // Insert('/get-roles-by-subsidiary?subsidiaryId',obj)
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.length > 0) {
              this.SubTypelist = [];
              for (let i = 0; i < res.length; i++) {
                this.SubTypelist.push({
                  "id": res[i],
                  "name": res[i]
                });
              }
            } else {
              this.SubTypelist = [];
            }
          }
        },
        (error) => {
          this.showAlert(error);
          this.SubTypelist = [];
        }
      );
    } catch (err: any) {
      this.showAlert(err);
    }
    if (this.viewMode == false)
      this.fnOnchangeApproval();
    else {
      if (this.apModel.recordType == "Master") {
        this.disableMasterMode = true;
      }
    }
  }
  OnloadSubTypeList(RecordType: string, subsidiaryId: number) {
    if (subsidiaryId == undefined) {
      this.showAlert("Please select Subsidiary");
      return;
    }
    try {
      //this.HttpService.GetById('/roles/get-roles-by-subsidiary?subsidiaryId=' + SubsidiaryId, SubsidiaryId).subscribe(
      this.HttpService.GetAll('/setup-ws/preference/get-approval-routing-by-status?subsidiaryId=' + subsidiaryId + '&formType=' + RecordType, this.RetloginDetails.token).subscribe(
        // Insert('/get-roles-by-subsidiary?subsidiaryId',obj)
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.length > 0) {
              this.SubTypelist = [];
              for (let i = 0; i < res.length; i++) {
                this.SubTypelist.push({
                  "id": res[i],
                  "name": res[i]
                });
              }
            } else {
              this.SubTypelist = [];
            }
          }
        },
        (error) => {
          this.showAlert(error);
          this.SubTypelist = [];
        }
      );
    } catch (err: any) {
      this.showAlert(err);
    }
    if (this.addMode == true)
      this.fnOnchangeApproval();
    else {
      if (RecordType == "Master") {
        this.disableMasterMode = true;
      }
    }
  }
  //-Reload Subsidiary
  getAllSubsidiaryReloadList() {
    this.apModel.subsidiaryId = undefined;
    this.roleList = [];
    this.approverlist = [];
    this.locationListOptions = [];
    this.GetSubsideryList();
  }
  //--[Get-Data By Id]:Edit Mode
  GetMasterDatabyId() {
    this.showloader = true;
    this.HttpService
      .GetById('/masters-ws/approval-preference/get?id=' + this.mainId, this.mainId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.showloader=true;
          this.ForHistroryTab = [];
          //this.OnloadDependentList(res.subsidiaryId);
       this.GetDepartmentList(res.subsidiaryId);
         // this.GetDepartmentList(res.subsidiaryId);
          this.GetLocationsList(res.subsidiaryId);
          this.GetAllRoleList(res.subsidiaryId);
          this.GetApproverList(res.subsidiaryId, res.approvalPreferenceConditions[0].roleId,0)
          this.OnloadSubTypeList(res.recordType, res.subsidiaryId);

          // setTimeout(() => { 
            this.apModel = res;
            if(this.apModel.recordType=="Master")
              {
               this.ishidedepartment=true;
              }
              else{
                this.ishidedepartment=false;
              }
            for(let i=0;i<this.apModel.approvalPreferenceConditions.length;i++)
            {
              for(let j=0;j<this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences.length;j++)
              {
                  if(this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[j].departmentId==null)
                  {
                   
                    this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[j].departmentId=0;
                  }
              }
            }
           
          
          //},600);
        
            if (res.active == false) {
              this.isInactiveDateVisible = true;
              this.apModel.inactiveDate = this.apModel.inactiveDate != null ? new Date(this.apModel.inactiveDate) : "";
            }
            this.showForChain = res.approvalType == "Chain" ? true : false;
            //setTimeout(()=> this.GetSubTypeList(res.recordType),100) ;
            //this.GetSubTypeList(res.recordType);
            if (res.approvalPreferenceConditions.length > 0) {
              this.ForHistroryTab.push(new approvalPreferenceConditions());
            }
           // alert(this.apModel.subType);


           setTimeout(() => {
            this.GetApproverList(this.apModel.subsidiaryId, this.apModel.approvalPreferenceConditions[0].roleId,0)
            this.showloader = false;
          },600);
            
           
         
        }
      },
        (error) => {
          this.showloader = false;
          this.showAlert("error occoured");
        },
        () => {  }
      );
  }

  //--Save/Update Data
  saveMaster() {
    if (this.apModel.subsidiaryId == undefined) {
      this.showAlert("Please select Subsidiary");
      return false;
    }
    else if (this.apModel.approvalType == undefined || this.apModel.approvalType == "") {
      this.showAlert("Please select Approval Type");
      return false;
    }
    else if (this.apModel.recordType == undefined) {
      this.showAlert("Please select Record Type");
      return false;
    }
    else if (this.apModel.subType == undefined) {
      this.showAlert("Please select Sub Type");
      return false;
    }
    else if (this.apModel.active == false && (this.apModel.inactiveDate == undefined || this.apModel.inactiveDate == null || this.apModel.inactiveDate == "")) {
      this.showAlert("Please enter Inactive Date");
      return false;
    }
    for (let i = 0; i < this.apModel.approvalPreferenceConditions.length; i++) {
      if (this.apModel.approvalPreferenceConditions[i].roleId == undefined) {
        this.showAlert("Please select Role");
        return false;
      }
      for (let k = 0; k < this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences.length; k++) {
        // if (this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].locationId == undefined ||
        //   this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].department == undefined ||
        //   this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].approverId == undefined) {
        if (this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].amountFrom == null && this.apModel.recordType == "Transaction") {
          this.showAlert("Please enter Amount From of condition-" + (i + 1) + " , row-" + (k + 1));
          return false;
        }
        else if (this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].amountTo == null && this.apModel.recordType == "Transaction") {
          this.showAlert("Please enter Amount To of condition-" + (i + 1) + " , row-" + (k + 1));
          return false;
        }
        // else  if (this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].locationId == undefined && this.apModel.recordType == "Transaction") {
        //   this.showAlert("Please select Location");
        //   return false;
        // }
        else if (this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].natureOfSupply == undefined && this.apModel.recordType == "Master") {
          this.showAlert("Please select Nature of supply");
          return false;
        }
        // else if (this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].department == undefined && this.apModel.recordType == "Transaction") {
        //   this.showAlert("Please select Department");
        //   return false;
        // }

        else if (this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].approvers.length < 1) {
          this.showAlert("Please select Approver condition-" + (i + 1) + " , row-" + (k + 1));
          return false;
        }

        this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].natureOfSupply = this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].natureOfSupply != "" ? this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].natureOfSupply : null;


        // }
      }
    }

 

    for (let i = 0; i < this.apModel.approvalPreferenceConditions.length; i++) {
      this.apModel.approvalPreferenceConditions[i].level = "L" + (i + 1);
      for (let k = 0; k < this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences.length; k++) {
        this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[k].sequenceId = (k + 1);
      }
    }
    if (this.addMode) {
      this.deactiveLineLabel.createdBy = this.RetloginDetails.username; this.deactiveLineLabel.lastModifiedBy = this.RetloginDetails.username
    }
    else if (!this.addMode) {
      this.deactiveLineLabel.lastModifiedBy = this.RetloginDetails.username
    }

    for(let i=0;i<this.apModel.approvalPreferenceConditions.length;i++)
    {
      for(let j=0;j<this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences.length;j++)
      {
          if(this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[j].departmentId==0)
          {
           
            this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences[j].departmentId=null;
          }
      }
    }


    this.showloader = true;
    this.HttpService.Insert('/masters-ws/approval-preference/save', this.apModel, this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //PR/21-22/10001
          if (res && res.id > 0) {
            this.showloader = false;
            this.showSuccess();

            if(this.addMode){
              this.router.navigate(['/main/approval-preferences/action', 'view',res.id]);
            } else {
              this.router.navigate(['/main/approval-preferences/list']);
            }
  
           


          } else {
            this.showloader = false;
            this.showError();
          }
        }
      },
      (error) => {
        this.showloader = false;
        this.showAlert(error);
      },
      () => { }
    );
  }
  //Subsidiary Dependent List
  GetDependentList() {
    this.GetAllRoleList(this.apModel.subsidiaryId);
    //this.GetApproverList(this.apModel.subsidiaryId);
    this.GetLocationsList(this.apModel.subsidiaryId);
    this.GetDepartmentList(this.apModel.subsidiaryId);
  }
  OnloadDependentList(subsidiaryId: any, RoleId: any) {
    this.GetAllRoleList(subsidiaryId);
    //this.GetApproverList(subsidiaryId);
    this.GetLocationsList(subsidiaryId);
  }
  //--Get Approver
  GetApproverList(SubsidiaryId: any, RoleId: any,ConditionRow:any) {
    //this.apModel.approvalPreferenceConditions[ConditionRow]=ConditionRow;
    let form_name;
    debugger
   if(this.apModel.subType=="Supplier")
    {
      form_name="Supplier Approval";
    }
    else if(this.apModel.subType=="Purchase Requisition")
    {
      form_name="PR Approval";
    }
    else if(this.apModel.subType=="Purchase Order")
    {
      form_name="PO Approval";
    }
    else if(this.apModel.subType=="AP Invoice")
    {
      form_name="AP Invoice Approval";
    }
    else if(this.apModel.subType=="Make Payment")
    {
      form_name="Make Payment Approval";
    }
    else if(this.apModel.subType=="Return to Supplier")
    {
      form_name="RTV Approval";
    }
    else if(this.apModel.subType=="Debit Note")
    {
      form_name="Debit Note Approval";
    }
    else if(this.apModel.subType=="Advance Payment")
    {
      form_name="Advance Payment Approval";
    }
    try {
      this.HttpService
        .GetAll(`/masters-ws/employee/get-by-role-subsidiary?roleId=${RoleId}&subsidiaryId=${SubsidiaryId}&formName=${form_name}`, this.RetloginDetails.token)
        //.GetById('/masters-ws/employee/get-employee-by-subsidiary?subsidiaryId=' + SubsidiaryId, SubsidiaryId, this.RetloginDetails.token)
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.approverlist = res;
            //this.apModel.approvalPreferenceConditions[ConditionRow].approvers= res;
          }
        },
          (error) => {
          }
        );
    } catch (err) {
    }
  }
  //---Location List
  GetLocationsList(subsidiaryId: any) {
    // this.httpService.GetById(GlobalConstants.URL_LOCATION_GET_ALL_LOV + '?subsidiaryId=' + subsidiaryId, subsidiaryId).subscribe(
    this.HttpService.GetById(GlobalConstants.URL_LOCATION_GET_BY_ID + '?subsidiaryId=' + subsidiaryId, subsidiaryId, this.RetloginDetails.token).subscribe(
      async (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.locationListOptions = res;
        }
      },
      (error) => {
      }
    );
  }
  clearData() {
    this.router.navigate(['/main/approval-preferences/list']);
   /* if (this.addMode) {
      let CLearData: approvalPreferenceModule = new approvalPreferenceModule();
      this.apModel = CLearData;
      this.apModel.subType = "";
      this.SubTypelist = [];
    }
    else
      this.router.navigate(['/main/approval-preferences/list']);*/
  }

  /* Start fetching History details */
  LoadHistory() {
    if (this.HistoryList.length == 0)
      this.HttpService
        .GetById(
          `/masters-ws/approval-preference/get/history?id=${this.mainId}`, //--&pageSize=100
          this.mainId, this.RetloginDetails.token
        )
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.HistoryList = res;
          }
        });
  }
  /* End fetching History details */
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Data Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving!'
    );
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  //--On Approval Type Change
  fnOnchangeApproval() {
    this.showForChain = this.apModel.approvalType == "Chain" || this.apModel.approvalType == "Individual" ? true : false;
    this.apModel.approvalPreferenceConditions = [];
    this.addNewTab();
  }
  handleTabChange(event: any) {
    
    if(this.editMode)
    {
      this.GetApproverList(this.apModel.subsidiaryId, this.apModel.approvalPreferenceConditions[event.index].roleId,0)
    }
    if (event.index > 0 && this.viewMode != true) {
      var AppendTabCount = this.apModel.approvalPreferenceConditions.length;//[event.index].approvalPreferenceSequences.length;
      for (let i = 0; i < this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences.length; i++) {
        // if (i+1 <= AppendTabCount) {
        //   {
        if (i + 1 <= this.apModel.approvalPreferenceConditions[event.index].approvalPreferenceSequences.length) {
          if (this.apModel.recordType == "Transaction") {
            //[old] this.apModel.approvalPreferenceConditions[event.index].approvalPreferenceSequences[i].amountFrom = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].amountTo > 0 ? (parseFloat(this.apModel.approvalPreferenceConditions[event.index - 1].approvalPreferenceSequences[i].amountTo) + 0.01) : "";
            this.apModel.approvalPreferenceConditions[event.index].approvalPreferenceSequences[i].amountFrom = this.apModel.approvalPreferenceConditions[event.index - 1].approvalPreferenceSequences[i].amountTo > 0 ? (parseFloat(this.apModel.approvalPreferenceConditions[event.index - 1].approvalPreferenceSequences[i].amountTo) + 0.01) : "";
            this.apModel.approvalPreferenceConditions[event.index].approvalPreferenceSequences[i].locationId = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].locationId;
          }
          this.apModel.approvalPreferenceConditions[event.index].approvalPreferenceSequences[i].departmentId = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].departmentId;
          this.apModel.approvalPreferenceConditions[event.index].approvalPreferenceSequences[i].IsDisabled = true;
          if (this.apModel.recordType == "Master") {
            this.apModel.approvalPreferenceConditions[event.index].approvalPreferenceSequences[i].natureOfSupply = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].natureOfSupply;
          }
          this.apModel.approvalPreferenceConditions[event.index].approvalPreferenceSequences[i].active = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].active

        }
        else {
          this.apModel.approvalPreferenceConditions[event.index].approvalPreferenceSequences.push({
            sequenceId: this.editMode ? i + 1 : 0,
            locationId: this.apModel.recordType == "Transaction" ? this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].locationId : 0,
            amountFrom: this.apModel.recordType == "Transaction" ? (this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].amountTo > 0 ? (parseFloat(this.apModel.approvalPreferenceConditions[event.index - 1].approvalPreferenceSequences[i].amountTo) + 0.01) : "") : "",
            departmentId: this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].departmentId,
            natureOfSupply: this.apModel.recordType == "Master" ? this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].natureOfSupply : "",
            active: this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].active,
            IsDisabled: this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].IsDisabled = true,
            isStsActive: this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].isStsActive,
            approvers: []
          });
        }
      }
    }
    else {
      for (let i = 0; i < this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences.length; i++) {
        this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].IsDisabled = false;
      }
    }

    //this.apModel.approvalPreferenceConditions[event.index].approvalPreferenceSequences[i].active = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].active;
    //}
    // } 
    // else {
    //   this.apModel.approvalPreferenceConditions[event.index].approvalPreferenceSequences.push({
    //     locationId: this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].locationId,
    //     department: this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].department,
    //     isStsActive: this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].isStsActive
    //   }); 
    // }
    //}
    //this.isAddRowVisible=false;
    //}
    // else
    // {
    //   this.isAddRowVisible=true;
    // }

    //Fetch History if the selected tab index is History Tab index
    // if (event.index == 0) {
    //   this.isAddRowVisible=true;
    //   //this.LoadHistory();
    // }
    // else
    // {
    //   this.isAddRowVisible=false;
    // }
    this.TabNo = event.index + 1;
  }
  //New Tab Add Condition
  addNewTab() {
    debugger
    if (this.apModel.recordType != undefined) {
      if (this.apModel.recordType == "Master") {
        this.viewMode = false;
        this.disableMasterMode = true;
      }
      else {
        this.viewMode = false;
        this.disableMasterMode = false;
      }
      if (this.apModel.approvalType == "Chain") {
        this.AddButtonVisible = true;
        if (this.apModel.approvalPreferenceConditions.length > 0) {
          if (this.apModel.recordType == "Transaction") {
            //--Removed required fields
            // for (let i = 0; i < this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences.length; i++) {
            //   if (this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].locationId == undefined) {
            //     this.showAlert("Please select Location for condition-1 ,Row-" + (i + 1));
            //     return;
            //   }
            //   else if (this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].department == undefined) {
            //     this.showAlert("Please select Department for condition-1 ,Row-" + (i + 1));
            //     return;
            //   }
            // }
          }
          else if (this.apModel.recordType == "Master") {
            for (let i = 0; i < this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences.length; i++) {
              if (this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].natureOfSupply == undefined) {
                this.showAlert("Please select Nature of supply for condition-1 ,Row-" + (i + 1));
                return;
              }
              // else if (this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].department == undefined) {
              //   this.showAlert("Please select Department for condition-1 ,Row-" + (i + 1));
              //   return;
              // }
            }
          }
        }

        // if(this.apModel.approvalPreferenceConditions.length >0 &&this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[0].locationId == undefined)
        //   {
        //     this.showAlert("Please select Location for condition-1");
        //     return;
        //   }
        //   else  if(this.apModel.approvalPreferenceConditions.length >0 && this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[0].department == undefined)
        //   {
        //     this.showAlert("Please select Department for condition-1");
        //     return;
        //   }
        //this.apModel.approvalPreferenceConditions[this.apModel.approvalPreferenceConditions.length +1].approvalPreferenceSequences
        this.apModel.approvalPreferenceConditions.push(new approvalPreferenceConditions());
        this.TabNo = this.apModel.approvalPreferenceConditions.length;
        if (this.TabNo - 1 > 0) {

        for (let i = 0; i < this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences.length; i++) {
         
          var NewCondtion: approvalPreferenceConditions = new approvalPreferenceConditions();
          //NewCondtion.approvalPreferenceSequences[0].sequenceId = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].sequenceId;
          NewCondtion.approvalPreferenceSequences[0].locationId = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].locationId;
          NewCondtion.approvalPreferenceSequences[0].natureOfSupply = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].natureOfSupply;
          NewCondtion.approvalPreferenceSequences[0].departmentId = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].departmentId;
          NewCondtion.approvalPreferenceSequences[0].isStsActive = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].isStsActive;
          NewCondtion.approvalPreferenceSequences[0].approvers = [] = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].approvers = [];
          this.apModel.approvalPreferenceConditions[this.TabNo - 1].approvalPreferenceSequences.push(NewCondtion);
          }
        }
        else {
          this.apModel.approvalPreferenceConditions[this.TabNo - 1].approvalPreferenceSequences.push(new approvalPreferenceSequences());
        }
      }
      else if (this.apModel.approvalType == "Individual") {
        this.TabNo = this.apModel.approvalPreferenceConditions.length;
        this.AddButtonVisible = false;
        this.apModel.approvalPreferenceConditions.push(new approvalPreferenceConditions());
        this.apModel.approvalPreferenceConditions[this.TabNo].approvalPreferenceSequences.push(new approvalPreferenceSequences());
        //this.apModel.approvalPreferenceConditions.push( new approvalPreferenceConditions());

      }
      else {
        this.showAlert("Please select Approval Type");
      }
    }
  }
  //New Row Add
  addNewRow() {
    if (this.addMode) {
      this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences.push(new approvalPreferenceSequences());
      this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences.length].approvers?.push(new ApproverDetails());



    }
    else {
      this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences.push(
        {
          sequenceId: this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences.length + 1,
          approvers: []
        });
    }
    // if (this.apModel.approvalType == "Individual") {
    //   this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences.push(new approvalPreferenceSequences());
    // }
    // else {
    //   if (
    //     this.apModel.approvalPreferenceConditions[this.TabNo - 1].approvalPreferenceSequences.length > 0 &&
    //     this.apModel.approvalPreferenceConditions[this.TabNo - 1].approvalPreferenceSequences[length - 1] == new approvalPreferenceSequences()
    //   ) {
    //     return;
    //   }
    //   this.apModel.approvalPreferenceConditions[this.TabNo - 1].approvalPreferenceSequences.push(new approvalPreferenceSequences());
    // }
  }
  //--Delete Condition
  DeleteCondition() {
    if (this.apModel.approvalPreferenceConditions.length > 1) {
      let Index = this.apModel.approvalPreferenceConditions.length - 1
      this.apModel.approvalPreferenceConditions.splice(Index, 1);

    }
  }
  //--From Amount must be grater than To of Previous Row
  fnCheckAmount(TabNo: number, RowIndex: number) {
    //   if(TabNo == 0 && RowIndex>0)
    //   {
    //     if( Number(this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountFrom) <= Number(this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex-1].amountTo ))
    //   {
    //   this.showAlert("Amount From must be greater than [Condition:"+(TabNo+1)+", Row-"+(RowIndex)+"] To Amount");
    //   this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountFrom =undefined;
    //   this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountTo =undefined;
    //   return;
    //  }
    //   }
    if (TabNo > 0) // && RowIndex>0
    {
      if (RowIndex == 0 && Number(this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountFrom) <= Number(this.apModel.approvalPreferenceConditions[TabNo - 1].approvalPreferenceSequences[RowIndex].amountTo)) {
        this.showAlert("Amount From must be greater than [Condition:" + (TabNo) + ", Row-" + (RowIndex + 1) + "] To Amount");
        this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountFrom = null;
        this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountTo = null;

        return;
      }
      else if (Number(this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountFrom) <= Number(this.apModel.approvalPreferenceConditions[TabNo - 1].approvalPreferenceSequences[RowIndex].amountTo)) {
        this.showAlert("Amount From must be greater than [Condition:" + (TabNo) + ", Row-" + (RowIndex + 1) + "] To Amount");
        this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountFrom = null;
        this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountTo = null;

        return;
      }
    }

  }

  //---From Amount must be grater than To
  fnFromToAmount(TabNo: number, RowIndex: number) {
    if (Number(this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountTo) <= Number(this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountFrom)) {
      this.showAlert("Amount To must be greater than From Amount");
      this.apModel.approvalPreferenceConditions[TabNo].approvalPreferenceSequences[RowIndex].amountTo = null;
      return;
    }
  }

  //---check Same Location And Department Exists
  fnCheckSameLocationExist(selectedLocationData: any, selectedDeparmentData: any, selectedNatureofSupply: any, rowIndex: any) {
    let BlankLocation: approvalPreferenceSequences = new approvalPreferenceSequences();

    if (rowIndex > 0) {
      for (let i = 0; i < this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences.length; i++) {
        if (this.apModel.recordType == "Master" && this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].natureOfSupply == selectedNatureofSupply && i !== rowIndex && selectedNatureofSupply != undefined) {
          BlankLocation.conditionId = 1;
          BlankLocation.sequenceId = rowIndex + 1;
          //BlankLocation.natureOfSupply = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[rowIndex].natureOfSupply;

          this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[rowIndex] = BlankLocation;
          this.showAlert("Nature of supply is already exists in another row !");
          return false;
        }
        else if (this.apModel.recordType == "Master" && this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].departmentId == selectedDeparmentData && i !== rowIndex && selectedDeparmentData != undefined) {
          BlankLocation.conditionId = 1;
          BlankLocation.sequenceId = rowIndex + 1;
          BlankLocation.natureOfSupply = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[rowIndex].natureOfSupply;

          this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[rowIndex] = BlankLocation;
          this.showAlert("Deparment is already exists in another row !");
          return false;
        }
        else if (this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].locationId == selectedLocationData
          && this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[i].departmentId == selectedDeparmentData && i !== rowIndex && selectedLocationData != undefined && selectedDeparmentData != undefined) {
          BlankLocation.conditionId = 1;
          BlankLocation.sequenceId = rowIndex + 1;
          BlankLocation.amountFrom = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[rowIndex].amountFrom;
          BlankLocation.amountTo = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[rowIndex].amountTo;
          BlankLocation.approverId = this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[rowIndex].approverId;

          this.apModel.approvalPreferenceConditions[0].approvalPreferenceSequences[rowIndex] = BlankLocation;
          this.showAlert("Location and Deparment are already exists in another row !");
          return false;
        }
      }
    }
  }

  checkDuplicateCombination(conditionNo:any,RowIndex:any,Field:any)
  {
    for (let i = 0; i < this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences.length; i++)
     {
      if (this.apModel.recordType == "Transaction" && i != RowIndex &&
      this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[i].amountFrom == this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[RowIndex].amountFrom  && 
      this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[i].amountTo == this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[RowIndex].amountTo  && 
      this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[i].locationId == this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[RowIndex].locationId  && 
      this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[i].departmentId == this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[RowIndex].departmentId  
      ) 
      {
        let BlankData: approvalPreferenceSequences = new approvalPreferenceSequences();
        this.showAlert("Combination already exist in Row-"+(i+1) + ' of Condition '+(conditionNo+1) );
        
        if(Field=='AMOUNT-FROM')
        {
          this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[RowIndex].amountFrom =null
        }
        else if(Field=='AMOUNT-TO')
        {
          this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[RowIndex].amountTo =null
        }
        else if(Field=='LOCATION')
        {
          this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[RowIndex].locationId =BlankData
        }
        else if(Field=='DEPARTMENT')
        {
          this.apModel.approvalPreferenceConditions[conditionNo].approvalPreferenceSequences[RowIndex].departmentId =BlankData
        }
        return;
      }
     }
  }
  //--Reload 
  getReloadRoleList(index: number, data: any) {
    this.GetAllRoleList(this.apModel.subsidiaryId);
    this.apModel.approvalPreferenceConditions[index].roleId = undefined;
  }
  deleterowlevel(TAB: number, index: number) {
    if (index > 0) {

      // for (let i = 0; i < this.apModel.approvalPreferenceConditions.length; i++) {
      //   for (let k = 0; k < this.apModel.approvalPreferenceConditions[i].approvalPreferenceSequences.length; k++) {
      if (this.editMode && this.apModel.approvalPreferenceConditions[TAB].approvalPreferenceSequences[index].id != null) {
        this.apModel.approvalPreferenceConditions[TAB].approvalPreferenceSequences[index].deleted = true;
      }
      else {
        this.apModel.approvalPreferenceConditions[TAB].approvalPreferenceSequences.splice(index, 1);
      }

      // }
      //}
    }
    else
      this.showAlert("Atleast one condition is required to save Approval Preference");
  }
  numberOnly(event: any): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

  decimalnumberOnly(evt: any) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode == 46 && evt.srcElement.value.split('.').length > 1) {
      return false;
    }
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
      return false;
    return true;
  }

  fnDeactive() {
    if (this.editMode && this.apModel.active == false) {
      this.HttpService.Insert('/masters-ws/approval-preference/validate-preference-inactive', this.apModel, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res.length > 0) {
              this.showAlert("This Approval Preference already in use");
              this.apModel.active = true
              this.isInactiveDateVisible = false;
            } else {
              this.apModel.active = false
              this.isInactiveDateVisible = true;
            }
          }
        },
        (error) => {
          this.showAlert(error);
        },
        () => { }
      );
    }
    else {
      this.isInactiveDateVisible = false;
      this.apModel.inactiveDate = {};
      this.apModel.inactiveDate = undefined;
    }
  }
  fnDeactiveCondition(event: any, Row: number) {
    let ConditionNo = event.level == "L1" ? 0 : event.level == "L2" ? 1 : event.level == "L3" ? 2 : event.level == "L4" ? 3 : event.level == "L5" ? 4 : 0;
    if (this.editMode && event.approvalPreferenceSequences[Row].active == false) {
      this.deactiveLineLabel.id = event.id;
      this.deactiveLineLabel.approvalPreferenceId = event.approvalPreferenceId;
      this.deactiveLineLabel.conditionId = event.id;
      this.deactiveLineLabel.sequenceId = event.approvalPreferenceSequences[Row].sequenceId
      this.deactiveLineLabel.amountFrom = event.amountFrom;
      this.deactiveLineLabel.amountTo = event.amountTo;
      this.deactiveLineLabel.active = event.approvalPreferenceSequences[Row].active

      this.HttpService.Insert('/masters-ws/approval-preference/validate-sequence-inactive', this.deactiveLineLabel, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res.length > 0) {
              this.showAlert("This Approval Preference Sequence already in use");
              this.apModel.approvalPreferenceConditions[ConditionNo].approvalPreferenceSequences[Row].active = true;
              //   this.apModel.active == true
              //   this.isInactiveDateVisible=false;
            } else {
              this.apModel.approvalPreferenceConditions[ConditionNo].approvalPreferenceSequences[Row].active = false;
              //   this.apModel.active == false
              //   this.isInactiveDateVisible=true;
            }
          }
        },
        (error) => {
          this.showAlert(error);
        },
        () => { }
      );
    }
  }

  showDialog(conditionRow: any, sequenceRow: any, approverSequenceUid: any) {
    if (this.editMode) { this.approverSequenceUid = approverSequenceUid }

    if (this.apModel.approvalPreferenceConditions[conditionRow].approvalPreferenceSequences[sequenceRow].approvers?.length == 0) {
      this.PopupApproverlist = [];
      //this.PopupApproverlist.push(new ApproverDetails());
    }
    else {
      this.PopupApproverlist = [];
      for (let x = 0; x < this.apModel.approvalPreferenceConditions[conditionRow].approvalPreferenceSequences[sequenceRow].approvers?.length; x++) {
        this.PopupApproverlist.push(
          {
            'approverSequence': x + 1,
            'approverid': this.apModel.approvalPreferenceConditions[conditionRow].approvalPreferenceSequences[sequenceRow].approvers[x].approverId,
            'action': this.apModel.approvalPreferenceConditions[conditionRow].approvalPreferenceSequences[sequenceRow].approvers[x].action,
            'id': this.apModel.approvalPreferenceConditions[conditionRow].approvalPreferenceSequences[sequenceRow].approvers[x].id,
            'deleted': this.apModel.approvalPreferenceConditions[conditionRow].approvalPreferenceSequences[sequenceRow].approvers[x].deleted,
            'approvalPreferenceId': this.apModel.approvalPreferenceConditions[conditionRow].approvalPreferenceSequences[sequenceRow].approvers[x].approvalPreferenceId,
            'conditionId': this.apModel.approvalPreferenceConditions[conditionRow].approvalPreferenceSequences[sequenceRow].approvers[x].conditionId,
            'sequenceId': this.apModel.approvalPreferenceConditions[conditionRow].approvalPreferenceSequences[sequenceRow].approvers[x].sequenceId
          }
        );

      }

    }

    this.popupconditionRow = conditionRow
    this.popupsequenceRow = sequenceRow
    this.display = true;
  }

  addApprover() {
    if (
      //this.apModel.ApproverDetails.length > 0 && this.apModel.ApproverDetails[length - 1] == new ApproverDetails()
      this.PopupApproverlist.length > 0 && this.PopupApproverlist[length - 1] == new ApproverDetails()
    ) {
      return;
    }
    //this.apModel.ApproverDetails.push(new ApproverDetails());
    var Sequence: ApproverDetails = new ApproverDetails()
    Sequence.approverSequence = this.PopupApproverlist.length + 1;

    this.PopupApproverlist.push(Sequence);

  }
  deleteApprover(index: number) {

    if (this.PopupApproverlist.length == 1) {
      this.showAlert("Minimum one row is required !");
      return false;
    }

    if (this.editMode) {
      this.showloader = true;
      this.HttpService.GetAll(`/masters-ws/approval-preference/validate-approver-inactive?approverSequenceUid=${this.approverSequenceUid}&approverId=${this.PopupApproverlist[index].approverid}`, this.RetloginDetails.token)
        //this.HttpService.Insert('/masters-ws/approval-preference/validate-preference-inactive', this.apModel, this.RetloginDetails.token)
        .subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
              if (res) {
                if (index > 0 && this.editMode && this.PopupApproverlist[index].id !== null) {
                  this.PopupApproverlist[index].deleted = true;
                }
                else {
                  this.PopupApproverlist.splice(index, 1);
                }
              } else {
                this.showAlert("Approver already in use, not allowed to delete this approver !");
              }
            }
            this.showloader = false;
          },
          (error) => {
            this.showAlert(error);
            this.showloader = false;
          },
          () => { this.showloader = false; }
        );
    }
    else {
      this.PopupApproverlist.splice(index, 1);
    }

    for (let x = 0; x < this.PopupApproverlist.length; x++) {
      this.PopupApproverlist[x].approverSequence = x + 1
      // if (this.PopupApproverlist[index].deleted == false) 
      // {  }
    }
  }

  hidepopup() {
    this.display = false;
  }
  Onsavepopup(data: any) {
    for (let i = 0; i < data.length; i++) {
      if (data[i].approverid == undefined || JSON.stringify(data[i].approverid) === '{}') {
        this.showAlert("Select approver for row: " + (i + 1));
        return false;
      }
    }
    this.apModel.approvalPreferenceConditions[this.popupconditionRow].
      approvalPreferenceSequences[this.popupsequenceRow].approvers = []
    for (let x = 0; x < data.length; x++) {
      this.apModel.approvalPreferenceConditions[this.popupconditionRow].
        approvalPreferenceSequences[this.popupsequenceRow].approvers.push({
          approverSequence: x + 1,
          approverId: data[x].approverid,
          action: data[x].action,
          id: data[x].id,
          deleted: data[x].deleted,
          approvalPreferenceId: data[x].approvalPreferenceId,
          conditionId: data[x].conditionId,
          sequenceId: data[x].sequenceId
        })

    }

    this.hidepopup();
  }
  checkDuplicateApprover(rownumber: any) {
    for (let i = 0; i < this.PopupApproverlist.length; i++) {
      //if(this.Vendorlistid[i].value==this.TemplateMapping.templateSuppliers[rownumber].supplierId)
      if (i != rownumber && this.PopupApproverlist[i].approverid == this.PopupApproverlist[rownumber].approverid) {
        this.showAlert("Duplicate approver found !");
        this.PopupApproverlist[rownumber].approverid = {};
        return false;
        //this.deleteSupplierMapping(rownumber);
      }
    }
  }
  GetDepartmentList(id:any) {
    debugger
    this.HttpService.GetAll('/masters-ws/department/get/all/lov?subsidiaryId='+id,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      Object.keys(res).forEach(key => { 
        this.DepartmentList.push({
            "id":Number(key),
            "departmentName":res[key]
          })   
        });
     // for (const [key, value] of Object.entries(res)) {
        //alert(`${key}: ${value}`);
      //  this.DepartmentList.push({
     //     id:parseInt(key),
       //   departmentName:value
        //})
      //}
      //this.DepartmentList=res;
      if(this.editMode)
      {
        this.DepartmentList.push({
          id:0,
          departmentName:"All"
        })
      }
     
     
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}
}
