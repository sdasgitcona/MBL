export class TaxRateRule {
    id: number;
    subsidiaryId: number;
    vendorRegistrationType: string;
    taxType: string;
    taxName: string;
    taxRates?: string;
    availableOn: string;
    effectiveFrom?: any;
    effectiveTo?: any;
    inputTaxAccount?: string;
    outputTaxAccount?: string;
    tdsAccountCode?: string;
    createdDate: Date;
    createdBy?: string;
    lastModifiedDate: Date;
    lastModifiedBy: string;
    deleted: boolean;
    rcm: boolean;
    itc: boolean;
    

}
export class DropdownOptions{
    id?:any;
    code?:string;
}