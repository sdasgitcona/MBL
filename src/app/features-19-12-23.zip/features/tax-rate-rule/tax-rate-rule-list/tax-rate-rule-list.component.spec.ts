import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxRateRuleListComponent } from './tax-rate-rule-list.component';

describe('TaxRateRuleListComponent', () => {
  let component: TaxRateRuleListComponent;
  let fixture: ComponentFixture<TaxRateRuleListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TaxRateRuleListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TaxRateRuleListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
