import { Component, OnInit,LOCALE_ID, Inject } from '@angular/core';
import {formatDate } from '@angular/common';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch } from '../../supplier/model/supplier-model';
import { TaxRateRule } from '../model/tax-rate-rule-module';
import { ToastService } from 'src/app/core/services/toast.service';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-tax-rate-rule-list',
  templateUrl: './tax-rate-rule-list.component.html',
  styleUrls: ['./tax-rate-rule-list.component.scss']
})
export class TaxRateRuleListComponent implements OnInit {

  columns: any[];
  departments: any[] = [];
  SubIdList:any=[];
  taxRateRulelist: TaxRateRule[] = [];
  selectedTaxRateRule: TaxRateRule = new TaxRateRule();
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  taxRateRule: TaxRateRule = new TaxRateRule();
  newevent: any;
  taxType: any;
  SubsideryObject:any [];
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  // For Role Base Access
  RetloginDetails: any;
  RetRoleDetails:any;
  ListToPrint: any[] = [];
  showloader:boolean;
  constructor(private routeStateService: RouteStateService,
    private router: Router, private toastService: ToastService,
    private HttpService: CommonHttpService,@Inject(LOCALE_ID) public locale: string) {
    this.taxType = ['VAT', 'TDS'];
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Tax Rate Rule") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
      }
    }
    // End For Role Base Access
    this.GetSubsideryList();
    //this.resetBaseSearch();
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
      { field: 'Sl No', header: 'Sl No' },
      { field: 'Name', header: 'Name' },
      { field: 'Tax Type', header: 'Tax Type' },
      { field: 'Tax Rate', header: 'Tax Rate' },
      { field: 'Effective From', header: 'Effective From' },
      { field: 'Effective To', header: 'Effective To' },
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }
  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.TAX_RATE_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadTaxRate(this.newevent);
  }

  loadTaxRate(event: any) {
    try {
      this.newevent = event;
      this.loading = true;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);;
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
      this.baseSearch.sortColumn = event.sortField
        ? event.sortField
        : GlobalConstants.TAX_RATE_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.DESCENDING
          : GlobalConstants.ASCENDING;
      this.HttpService.Insert('/setup-ws/tax-rate/get/all', this.baseSearch, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else if (res && res.list.length > 0) {
            this.taxRateRulelist = res.list;
          


            this.totalRecords = res.totalRecords;
          } else {
            this.taxRateRulelist = [];
          }
          this.loading = false;
        },
        (error) => {
         // console.log(error);
          this.loading = false;
        }
      );
    } catch (err) {
      //alert(err);
    }
  }

  navigateToAdd() {
    this.router.navigate(['/main/supplier/update']);
  }
  navigateToAddViewEdit(
    action: string,
    selectedTaxRateRule: TaxRateRule = new TaxRateRule()
  ) {
    let taxRateRuleId = null;
    if (selectedTaxRateRule?.id) {
      taxRateRuleId = selectedTaxRateRule.id;
      this.router.navigate(['/main/tax-rate/action', action, taxRateRuleId]);
    } else {
      this.router.navigate(['/main/tax-rate/action', action]);
    }
  }
  exportPdf() {
    import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
        const doc = new jsPDF.default();
        (doc as any).autoTable(this.exportColumns, this.ListToPrint);
        doc.save('taxraterule.pdf');
      })
    })
  }

  /* Start fetch filter list of supplier from api */
  findby(event: any) {
    debugger
    let days_from:any;
    let months_from:any;
    let year_from:any;
    let days_to:any;
    let months_to:any;
    let year_to:any;
    let subsidyList:any=[];
    let bid_from:any;
    let bid_to:any;
    subsidyList.push(this.taxRateRule.subsidiaryId);
    //let effectiveFrom=this.taxRateRule.effectiveFrom.setDate(this.taxRateRule.effectiveFrom.getDate() - 1)
    if(this.taxRateRule.effectiveFrom!==undefined)
      {
        days_from = new Date(this.taxRateRule.effectiveFrom).getUTCDate();
        months_from = new Date(this.taxRateRule.effectiveFrom).getUTCMonth()+1;
        year_from = new Date(this.taxRateRule.effectiveFrom).getUTCFullYear();
      }

      if(this.taxRateRule.effectiveTo!==undefined)
      {
        days_to = new Date(this.taxRateRule.effectiveTo).getUTCDate();
        months_to = new Date(this.taxRateRule.effectiveTo).getUTCMonth()+1;
        year_to = new Date(this.taxRateRule.effectiveTo).getUTCFullYear();
      }

      this.baseSearch.filters = {
      subsidiaryId:subsidyList,
      type: this.taxRateRule.taxType,
      name: this.taxRateRule.taxName,
      rate: this.taxRateRule.taxRates,
      effectiveFrom: this.taxRateRule.effectiveFrom !== undefined  ? (year_from + '-' + (months_from.toString().length == 1 ? "0" + months_from : months_from) + '-' + (days_from.toString().length == 1 ? "0" + days_from : days_from)) : null,
      effectiveTo:this.taxRateRule.effectiveFrom !== undefined ? (year_to + '-' + (months_to.toString().length == 1 ? "0" + months_to : months_to) + '-' + (days_to.toString().length == 1 ? "0" + days_to : days_to)) : null,
    }
    
    this.loadTaxRate(this.newevent);
  }
  /* End filter list of supplier from api */
  Reset() {
    this.taxRateRule.taxType = "";
    this.taxRateRule.taxName = "";
    this.taxRateRule.effectiveFrom = undefined;
    this.taxRateRule.effectiveTo = undefined;
    this.taxRateRule.taxRates = "";
    this.resetBaseSearch();
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  GetSubsideryList() {
    this.SubsideryObject=[];

    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       {
         this.SubsideryObject=res;
        for(let x=0;x<this.SubsideryObject.length;x++)
       { 
        this.SubIdList.push(this.SubsideryObject[x].id);
      }
      }
      },
      (error) => {
        //alert(error);
       },
       ()=>{
        if(localStorage.getItem("taxRateRuleFilters") != null)
        {const LocDetails:any =localStorage.getItem("taxRateRuleFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.taxRateRule.subsidiaryId=searcheData.filters.subsidiaryId[0];
        this.taxRateRule.taxType=searcheData.filters.type;
        this.taxRateRule.taxName=searcheData.filters.name;
        this.taxRateRule.taxRates=searcheData.filters.rate;
        this.taxRateRule.effectiveFrom=searcheData.filters.effectiveFrom;
        this.taxRateRule.effectiveTo=searcheData.filters.effectiveTo;
        this.loadTaxRate(this.newevent);
        localStorage.removeItem("taxRateRuleFilters");
        }
        else
        this.resetBaseSearch();
       //this.loadSuppliers('');
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.taxRateRule.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
      this.SubsideryObject.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      if(localStorage.getItem("taxRateRuleFilters") != null)
      {const LocDetails:any =localStorage.getItem("taxRateRuleFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.taxRateRule.subsidiaryId=searcheData.filters.subsidiaryId[0];
        this.taxRateRule.taxType=searcheData.filters.type;
        this.taxRateRule.taxName=searcheData.filters.name;
        this.taxRateRule.taxRates=searcheData.filters.rate;
        this.taxRateRule.effectiveFrom=searcheData.filters.effectiveFrom;
        this.taxRateRule.effectiveTo=searcheData.filters.effectiveTo;
      this.loadTaxRate(this.newevent);
      localStorage.removeItem("taxRateRuleFilters");
      }
      else
        this.resetBaseSearch();
      //this.resetBaseSearch();
    }
  }

  ReloadSubsidiaryList()
  {
   this.taxRateRule.subsidiaryId=0;
    this. GetSubsideryList();
  }

  editview(actionType:any,mainId:any)
  {
   if (localStorage.getItem("taxRateRuleFilters") != null)
   {
     localStorage.removeItem("taxRateRuleFilters");
   }
   localStorage.setItem("taxRateRuleFilters", JSON.stringify(this.baseSearch));
   this.router.navigate(['/main/tax-rate/action', actionType, mainId]);
  }
  generatePDFData(exportType:any){
    this.newevent = event;
    this.baseSearch.pageSize = this.totalRecords;
    this.baseSearch.sortColumn =GlobalConstants.TAX_RATE_TABLE_SORT_COLUMN;
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};

    this.HttpService.Insert('/setup-ws/tax-rate/get/all', this.baseSearch, this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //this.employeelistPrint = [];
          this.ListToPrint = [];
          if (res && res.list.length > 0) {
            var RetData = res.list;
            for (let i = 0; i < RetData.length; i++) {
                if (RetData[i].id == undefined) {
                RetData[i].id = "";
              }
              if(exportType == 'PDF'){   
                this.ListToPrint.push({
                  'Sl No': i + 1 ,    
                  'Name':RetData[i].taxName, 
                  'Tax Type': RetData[i].taxType,
                  'Tax Rate':RetData[i].taxRates,
                  'Effective From':RetData[i].effectiveFrom!=null?formatDate(RetData[i].effectiveFrom, 'dd-MM-yyyy' ,this.locale):"",
                  'Effective To':RetData[i].effectiveTo!=null?formatDate(RetData[i].effectiveTo, 'dd-MM-yyyy' ,this.locale):"",
              });
            }
              else{
                this.ListToPrint.push({
                  'Sl No': i + 1 ,    
                  'Name':RetData[i].taxName, 
                  'Tax Type': RetData[i].taxType,
                  'Tax Rate':RetData[i].taxRates,
                  'Effective From':RetData[i].effectiveFrom!=null?formatDate(RetData[i].effectiveFrom, 'dd-MM-yyyy' ,this.locale):"",
                  'Effective To':RetData[i].effectiveTo!=null?formatDate(RetData[i].effectiveTo, 'dd-MM-yyyy' ,this.locale):"",
                });
              }

            }
          }
          if(exportType == 'PDF')
          {this.exportPdf();}
        }
      }
    );
  }
  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');

   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.ListToPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.ListToPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'TaxRateRule');
           this.showloader=false;
       });}
    }
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
    onRowSelect(event: any) {
      let taxruleId = event.data.id;
      
      this.router.navigate(['/main/tax-rate/action/view', taxruleId]);
    }
  
}
