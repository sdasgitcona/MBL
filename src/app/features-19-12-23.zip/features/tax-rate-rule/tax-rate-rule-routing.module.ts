import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TaxRateRuleAddEditComponent } from './tax-rate-rule-add-edit/tax-rate-rule-add-edit.component';
import { TaxRateRuleListComponent } from './tax-rate-rule-list/tax-rate-rule-list.component';

const routes: Routes = [
  {
    path: '',
    component: TaxRateRuleListComponent,
  },
  {
    path: 'list',
    component: TaxRateRuleListComponent,
  },
  {
    path: 'action/:action/:id',
    component: TaxRateRuleAddEditComponent,
  },
  {
    path: 'action/:action',
    component: TaxRateRuleAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TaxRateRuleRoutingModule { }
