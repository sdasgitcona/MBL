import { Component, OnInit } from '@angular/core';
import { flush } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { TaxRateRule,DropdownOptions } from '../model/tax-rate-rule-module';

@Component({
  selector: 'app-tax-rate-rule-add-edit',
  templateUrl: './tax-rate-rule-add-edit.component.html',
  styleUrls: ['./tax-rate-rule-add-edit.component.scss']
})
export class TaxRateRuleAddEditComponent implements OnInit {

  taxRateRule: TaxRateRule = new TaxRateRule();
  Subsidiarylist: any[] = [];
  taxrateruleId: number = 0;
  private subscription: any;
  viewMode: boolean = false;
  itcdis :boolean = false;
  addMode: boolean = false;
  vatMode: boolean = false;
  tdsMode: boolean = false;
  editMode: boolean = false;
  vatHidden:boolean=false;
  vatHidden1:boolean=true;
  tdsHidden1:boolean=true;
  tdsHidden:boolean=false;
  tdsacccode:boolean=false;
  taxaccount:boolean=false;
  role: any;
  addressData: any;
  displayAddressDialog: boolean = false;

  taxrateHistoryList: HistoryModel[] = [];
  taxType: any;
  inputTaxAccount: DropdownOptions[]=[];
  vendorRegistration: any;
  availableOn : any;
  outputTaxAccount: DropdownOptions[]=[];
  tdsAccountcode: DropdownOptions[]=[];
  isReloadSub:boolean;
  disableTDS:boolean=true;
  disableVAT:boolean=true;
  ClsRequiredVAT:string="";
  ClsRequiredTDS:string="";
  hideReloadVAT:boolean;
  hideReloadTDS:boolean;
  showloader: boolean=false;
  RetRoleDetails:any;
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   isviewEditable:boolean=true;
   // For Role Base Access
   RetloginDetails: any;
  constructor(
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
  ) {
    this.taxType = ['VAT', 'TDS'];
    //this.inputTaxAccount = ['Vat on Purchase', 'Asset'];
    this.vendorRegistration = ['Registered', 'Unregistered'];
    this.availableOn = ['Purchase Transaction'];
   // this.outputTaxAccount = ['Vat on Sale', 'Liability'];
    //this.tdsAccountcode = ['text1', 'text2'];
    // this.taxRateRule.itc=true;

  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;
 const LDetails: any = localStorage.getItem("LoggerDTLS");
 this.RetloginDetails = JSON.parse(LDetails);
 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Tax Rate Rule")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.taxrateruleId = +params['id']; // (+) converts string 'id' to a number
            this.GetTaxRateRulebyId();
            this.LoadHistory();
          }
          
          this.assignMode(params['action']);       
          this.GetSubsideryList();
          
        } else {
          console.log('cannot get params');
        }
      },
      (error) => {
        console.log('add');
      }
    );

  }

  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;

      default:
        break;
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
/* Start Fetch tax rate deatils from api */
GetTaxRateRulebyId(): void {
  this.httpService.GetById("/setup-ws/tax-rate/get?id="+this.taxrateruleId, this.taxrateruleId, this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
       else if(res.errorMessage){
        this.showAlert(res.errorMessage)
       }else{
        this.taxRateRule=res;
        this.taxRateRule.effectiveFrom=this.taxRateRule.effectiveFrom?new Date(this.taxRateRule.effectiveFrom):this.taxRateRule.effectiveFrom;
        this.taxRateRule.effectiveTo=this.taxRateRule.effectiveTo?new Date(this.taxRateRule.effectiveTo):this.taxRateRule.effectiveTo;
      }
    },
    error => {
     this.showAlert(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    });
}

/* End Fetch tax rate deatils from api */



GetSubsideryList() {
  this.Subsidiarylist=[];

  if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
  {
    this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
     { this.showAlert("Unauthorized Access !");
       this.router.navigate(['/login']);
     }
     else if(res.status == 404)
     { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
     { this.Subsidiarylist=res;
    
    }
    },
    (error) => {

     },
     ()=>{
;
     }
  );
  }else{
    this.Subsidiarylist.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });

  }
}
  GetSubsideryList_old() {
    this.httpService.GetAll('/setup-ws/subsidiary/get/all', this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist = res.list;
        this.isReloadSub=false;}
      },
      (error) => {
       this.showAlert(error);
        this.isReloadSub=false;
      }
    );
  }
  /* End Fetch Subsidery list from api */

  /* Start fetching History details */
  LoadHistory() {
    if (this.taxrateHistoryList.length == 0)
      this.httpService.GetById(`/setup-ws/tax-rate/get/history?id=${this.taxrateruleId}&pageSize=100`,
          this.taxrateruleId, this.RetloginDetails.token
        )
        .subscribe((res) => {
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
             this.router.navigate(['/login']);
           }
         else { this.taxrateHistoryList = res;}
        });
  }
  /* End fetching History details */

  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 0) {
      this.LoadHistory();
    }
  }

  /* Start save tax rate */
  TaxrateSave(){

    if(this.taxRateRule.subsidiaryId== undefined)
  {
      this.showAlert("Please select Subsidiary");
      return;
  }  
  if(this.taxRateRule.taxType== undefined || this.taxRateRule.taxType == "")
  {
      this.showAlert("Please select Tax Type");
      return;
  }  
  if(this.taxRateRule.taxName == undefined || this.taxRateRule.taxName == "")
  {
      this.showAlert("Please enter Tax Name");
      return;
  }  
  if(this.taxRateRule.vendorRegistrationType==undefined || this.taxRateRule.vendorRegistrationType == "")
  {
      this.showAlert("Please select Vendor Registration Type");
      return;
  }  
  if(this.taxRateRule.availableOn==undefined  || this.taxRateRule.availableOn == "")
  {
      this.showAlert("Please select Available On");
      return;
  }  
  if(this.taxRateRule.taxRates==undefined )
  {
      this.showAlert("Please enter Tax Rate");
      return;
  }  
  if(this.taxRateRule.effectiveFrom==undefined || this.taxRateRule.effectiveFrom == "")
  {
      this.showAlert("Please select Effective From");
      return;
  }  
  if (this.taxRateRule.effectiveTo != undefined && new Date(this.taxRateRule.effectiveFrom) >= new Date(this.taxRateRule.effectiveTo)) {
    this.showAlert("Effective To Date must be greater than Effective From Date");
      return;
  }
  if(this.taxRateRule.taxType=="VAT")
  {
    if(this.taxRateRule.inputTaxAccount==undefined)
    {
      this.showErrorInputTaxAcc();
      return;
    }
    if(this.taxRateRule.outputTaxAccount==undefined)
    {
      this.showErrorOutputTaxAcc();
      return;
    }
  }
  if(this.taxRateRule.taxType=="TDS")
  {
    if(this.taxRateRule.tdsAccountCode==undefined)
    {
      this.showErrorTDSACCCode();
      return;
    }
   
  }

    if(this.taxRateRule.effectiveFrom){
      if(this.addMode){
        this.taxRateRule.createdBy=this.RetloginDetails.username;this.taxRateRule.lastModifiedBy=this.RetloginDetails.username
        }
       else if(!this.addMode){
        this.taxRateRule.lastModifiedBy=this.RetloginDetails.username
        }
   this.httpService.Insert("/setup-ws/tax-rate/save",this.taxRateRule, this.RetloginDetails.token)
   .subscribe(res => {
    if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
   else  if (res && res.id > 0) {
      this.showSuccess();

      
      if(this.addMode){
        this.router.navigate(['/main/tax-rate/action', 'view',res.id]);
      } else {
        this.router.navigate(['/main/tax-rate/list']);
      }
      
    } else {
      this.showError();
    }
     },
     error => {
       this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
    }
  }

  /* End save tax rate */
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Tax Rate Rule Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Tax Rate Rule!'
    );
  }
  showErrorInputTaxAcc() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Input Tax Account'
    );
  }
  showErrorOutputTaxAcc() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Output Tax Account'
    );
  }
  showErrorTDSACCCode() {
    this.toastService.addSingle(
      'error',
      'Error',
      'TDS Account Code is required!'
    );
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  clearTaxrateData() {

    this.router.navigate(['/main/tax-rate/list']);
   /* if(this.editMode){
      this.router.navigate(['/main/tax-rate/list']);
    }
    else{
    this.taxRateRule = new TaxRateRule();
    this.reloadSubidery();
    }*/
  }
/* Start Reload subsidery */
reloadSubidery(){
  //$('.refsubsidery').addClass('fa-spin');
  this.isReloadSub=false;
  this.taxRateRule.subsidiaryId=0
  this.GetSubsideryList();
  this.taxRateRule.inputTaxAccount=undefined;
  this.inputTaxAccount=[];
  this.taxRateRule.outputTaxAccount=undefined;
  this.outputTaxAccount=[];
  this.taxRateRule.tdsAccountCode=undefined;
  this.tdsAccountcode=[];
  
}
diaableitc()
{
  if(this.taxRateRule.taxType=="TDS")
  {
    this.disableTDS=false;
    this.disableVAT=true;
    this.ClsRequiredVAT=""
    this.ClsRequiredTDS="required"
    this.hideReloadVAT=false;
    this.hideReloadTDS=true;
    this.taxRateRule.inputTaxAccount=undefined;
    this.taxRateRule.outputTaxAccount=undefined;
   this.vatMode=false;
   this.taxRateRule.itc=false;
   this.itcdis=true;
   this.vatHidden1=true;
   this.vatHidden=false;
   this.tdsMode=true;
   this.tdsHidden1=false;
   this.tdsHidden=true;
   this.tdsacccode=true;
   //this.GetAccountType('Assets,Liability',this.taxRateRule.subsidiaryId);
   this.GetAccountType(this.taxRateRule.taxType,this.taxRateRule.subsidiaryId);
  }
  else  if(this.taxRateRule.taxType=="VAT"){

    this.disableTDS=true;
    this.disableVAT=false;
    this.ClsRequiredVAT="required";
    this.ClsRequiredTDS="";
    this.hideReloadVAT=true;
    this.hideReloadTDS=false;
    this.taxRateRule.tdsAccountCode=undefined;

    this.vatMode=true;
    this.itcdis=false;
    this.vatHidden1=false;
    this.vatHidden=true;
    this.tdsMode=false;
    this.tdsHidden1=true;
    this.tdsHidden=false;
    this.tdsacccode=true;
    this.taxaccount=true;
    //this.GetAccountType('Assets,Liability',this.taxRateRule.subsidiaryId);
    this.GetAccountType(this.taxRateRule.taxType,this.taxRateRule.subsidiaryId);
  }
  else{
    this.disableTDS=true;
    this.disableVAT=true;
    this.ClsRequiredVAT="";
    this.ClsRequiredTDS="";
  }
}

GetAccountType(type: string,id:number) {

  //this.httpService.GetAll('/account/get-account-by-subsidiary?subsidiaryId='+id+'&type=' + type)
  this.httpService.GetAll('/masters-ws/account/get-account-by-subsidiary-and-tds-tax-code?subsidiaryId='+id+'&tdsTaxCode=' + type,this.RetloginDetails.token)
  .subscribe(
    (res) => {
      // if(type == 'Assets')
      // {
      // this.inputTaxAccount=[];
      // }
      // else if(type == 'Liability')
      // {
      // this.outputTaxAccount=[];
      // this.tdsAccountcode=[];
      // }
      // else
      // {
      //   this.inputTaxAccount=[];
      //   this.outputTaxAccount=[];
      //   this.tdsAccountcode=[];
      // }
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
     else {this.inputTaxAccount=[];
      this.outputTaxAccount=[];
      this.tdsAccountcode=[];
      //res.list.map((x: any, i: any) => {
      for(let i=0;i<res.length;i++)
      {
        if(res[i].type == 'Assets' && res[i].accountSummary==false && res[i].inactive==false)
        {
          this.inputTaxAccount.push({"id":res[i].id,"code":res[i].code }) ;
         
        }
        else if(res[i].type == 'Liability' && res[i].accountSummary==false && res[i].inactive==false)
        {
          this.outputTaxAccount.push({"id":res[i].id,"code":res[i].code }) ;
          this.tdsAccountcode.push({"id":res[i].id,"code":res[i].code }) ;
          //this.outputTaxAccount = res[i];
          //this.tdsAccountcode = res[i];
        }
      }}
    //});
    
    },
    (error) => {
     this.showAlert(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    }
  );
}
/* End Reload subsidery */

reloadInputTaxAccount()
{
  this.taxRateRule.inputTaxAccount=undefined;
  this.GetAccountType(this.taxRateRule.taxType,this.taxRateRule.subsidiaryId);
}
reloadOutputTaxAccount()
{
  //this.outputTaxAccount=[];
  this.taxRateRule.outputTaxAccount=undefined;
  this.GetAccountType(this.taxRateRule.taxType,this.taxRateRule.subsidiaryId);
}
reloadTDSACCCOdeTaxAccount()
{
  //this.tdsAccountcode=[];
  this.taxRateRule.tdsAccountCode=undefined;
  this.GetAccountType(this.taxRateRule.taxType,this.taxRateRule.subsidiaryId);
}
checkefectivedate(){
  let Fdays: any = new Date(this.taxRateRule.effectiveFrom).getDate();
  let Fmonths: any = new Date(this.taxRateRule.effectiveFrom).getMonth() + 1;
  let Fyear: any = new Date(this.taxRateRule.effectiveFrom).getFullYear();
  let FromDate: any = this.taxRateRule.effectiveFrom !== undefined ? (Fyear + '-' + (Fmonths.toString().length == 1 ? "0" + Fmonths : Fmonths) + '-' + (Fdays.toString().length == 1 ? "0" + Fdays : Fdays)) : "";

  let Tdays: any = new Date(this.taxRateRule.effectiveTo).getDate();
  let Tmonths: any = new Date(this.taxRateRule.effectiveTo).getMonth() + 1;
  let Tyear: any = new Date(this.taxRateRule.effectiveTo).getFullYear();
  let ToDate: any = this.taxRateRule.effectiveTo !== undefined ? (Tyear + '-' + (Tmonths.toString().length == 1 ? "0" + Tmonths : Tmonths) + '-' + (Tdays.toString().length == 1 ? "0" + Tdays : Tdays)) : "";

  if(FromDate > ToDate && this.taxRateRule.effectiveTo !== undefined){
  //if(new Date(this.taxgroup.inActiveDate) > new Date(this.taxgroup.activeDate)){
    
    this.toastService.addSingle(
      'error',
      'Alert',
      "Effective To date must be greater than Effective From Date"
    );
    setTimeout(() => {
      this.taxRateRule.effectiveTo=null
    }, 100);
  }
}

}
