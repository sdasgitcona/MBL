import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxRateRuleAddEditComponent } from './tax-rate-rule-add-edit.component';

describe('TaxRateRuleAddEditComponent', () => {
  let component: TaxRateRuleAddEditComponent;
  let fixture: ComponentFixture<TaxRateRuleAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TaxRateRuleAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TaxRateRuleAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
