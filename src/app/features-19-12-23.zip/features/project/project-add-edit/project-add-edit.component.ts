import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { Project } from '../model/project-model';

@Component({
  selector: 'app-project-add-edit',
  templateUrl: './project-add-edit.component.html',
  styleUrls: ['./project-add-edit.component.scss']
})
export class ProjectAddEditComponent implements OnInit {
  project: Project = new Project();
  Subsidiarylist: any[] = [];
  projectId: number = 0;
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  role: any;
  addressData: any;
  RetRoleDetails:any;
  displayAddressDialog: boolean = false;
  SubsideryObject:any[]=[];
  projectHistoryList: HistoryModel[] = [];
  projectStatusOptions: any;
  isReloadSub:boolean;
  showloader:boolean=false;
  RetloginDetails:any;
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   isviewEditable:boolean=true;
   // For Role Base Access

  constructor(
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
    private datepipe:DatePipe
  ) {
    this.projectStatusOptions = ['Closed', 'Awarded','In Progress','Not Awarded','Pending'];
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
   this.RetloginDetails = JSON.parse(LDetails);

     // For Role Base Access
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Project")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.projectId = +params['id']; // (+) converts string 'id' to a number
            this.GetProjectbyId();
            this.LoadHistory();
          }
          this.assignMode(params['action']);       
          this.GetSubsideryList();
          
        } else {
       
        }
      },
      (error) => {
     
      }
    );

  }

  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;

      default:
        break;
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
/* Start Fetch Project deatils from api */
GetProjectbyId(): void {
  this.httpService.GetById("/masters-ws/project/get?id="+this.projectId, this.projectId,this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
     
       if(res.errorMessage){
       
       }else{
        this.project=res;
        //this.project.schedulingStartDate= this.project.schedulingStartDate?new Date(this.project.schedulingStartDate): this.project.schedulingStartDate;
        this.project.schedulingStartDate= this.project.activeDate != null ?new Date(this.project.activeDate): '';
        this.project.schedulingEndDate=this.project.inactiveDate?new Date(this.project.inactiveDate):'';
        //this.project.schedulingEndDate=this.project.schedulingEndDate?new Date(this.project.schedulingEndDate):this.project.schedulingEndDate;
        //this.project.schedulingStartDate =this.datepipe.transform(new Date( this.project.schedulingStartDate!), 'dd/mm/yyyy') ||  this.project.schedulingStartDate;
       // this.project.schedulingEndDate =this.datepipe.transform(new Date( this.project.schedulingEndDate!), 'dd/mm/yyyy') ||  this.project.schedulingEndDate;      
       }
      }
    },
    error => {
   
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    });
}
/* Start Fetch Project deatils from api */


// GetSubsideryList() {
//   this.httpService.GetAll(GlobalConstants.URL_SUPPLIER_GET_ALL_LOV).subscribe(
//     (res) => {
//     
//       //this.Subsidiarylist = res.list;
//       this.SubsideryObject=res;
//       this.isReloadSub=false;
//     },
//     (error) => {
//     
//       this.isReloadSub=false;

//     }
//   );
// }
GetSubsideryList_OLD() {
  this.httpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      this.Subsidiarylist = res.list;
      this.isReloadSub=false;
      }
     //this.SubsideryObject=res;
    },
    (error) => {
      this.isReloadSub=false;

     
    }
  );
}
GetSubsideryList() {
  this.Subsidiarylist=[];

  //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
  if(this.RetloginDetails.userType=='SUPERADMIN') 
  {
    this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
     { this.showAlert("Unauthorized Access !");
       this.router.navigate(['/login']);
     }
     else if(res.status == 404)
     { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
     { this.Subsidiarylist=res;

    }
    },
    (error) => {
      //alert(error);
     },
     ()=>{

     }
  );
  }else if(this.RetloginDetails.userType=='ENDUSER'){
    this.Subsidiarylist.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });

  }
}

  /* End Fetch Subsidery list from api */

  /* Start fetching History details */
  LoadHistory() {
    if (this.projectHistoryList.length == 0)
      this.httpService
        .GetById(
          `/masters-ws/project/get/history?id=${this.projectId}&pageSize=100`,
          this.projectId,this.RetloginDetails.token
        )
        .subscribe((res) => {
          if(res.status == 401)
          { 
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { 
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
          {
          this.projectHistoryList = res;
        }
        });
  }
  /* End fetching History details */

  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 0) {
      this.LoadHistory();
    }
  }

  checkefectivedate(){
    let Fdays: any = new Date(this.project.schedulingStartDate).getDate();
    let Fmonths: any = new Date(this.project.schedulingStartDate).getMonth() + 1;
    let Fyear: any = new Date(this.project.schedulingStartDate).getFullYear();
    let FromDate: any = this.project.schedulingStartDate !== undefined ? (Fyear + '-' + (Fmonths.toString().length == 1 ? "0" + Fmonths : Fmonths) + '-' + (Fdays.toString().length == 1 ? "0" + Fdays : Fdays)) : "";
  
    let Tdays: any = new Date(this.project.schedulingEndDate).getDate();
    let Tmonths: any = new Date(this.project.schedulingEndDate).getMonth() + 1;
    let Tyear: any = new Date(this.project.schedulingEndDate).getFullYear();
    let ToDate: any = this.project.schedulingEndDate !== undefined ? (Tyear + '-' + (Tmonths.toString().length == 1 ? "0" + Tmonths : Tmonths) + '-' + (Tdays.toString().length == 1 ? "0" + Tdays : Tdays)) : "";
  
    if(FromDate > ToDate && this.project.schedulingEndDate !== undefined){
    //if(new Date(this.taxgroup.inActiveDate) > new Date(this.taxgroup.activeDate)){
      
      this.toastService.addSingle(
        'error',
        'Alert',
        "Effective To date must be greater than Effective From Date"
      );
      setTimeout(() => {
        this.project.schedulingEndDate=null
      }, 100);
    }
  }

  /* Start save project */
  SaveProject(){
    this.showloader=true;

 if(this.project.subsidiaryId==undefined)
 {
     this.showSubsidiaryError();
     this.showloader=false;
     return;
 }
 if(this.project.name==undefined || this.project.name=="") 
 {
     this.showProjectNameError();
     this.showloader=false;
     return;
 }
 if(this.project.status==undefined) 
 {
     this.showProjectStatusError();
     this.showloader=false;
     return;
 }
 if(this.project.schedulingStartDate==undefined || this.project.schedulingStartDate=="") 
 {
     this.showProjectStartdateError();
     this.showloader=false;
     return;
 }
//  if (this.project.schedulingEndDate != undefined && new Date(this.project.schedulingStartDate) >= new Date(this.project.schedulingEndDate)) {
//   this.showAlert("End Date must be greater than Start Date");
//   this.showloader=false;
//     return;
// }

if(this.addMode){
  this.project.createdBy=this.RetloginDetails.username;this.project.lastModifiedBy=this.RetloginDetails.username
  }
 else if(!this.addMode){
  this.project.lastModifiedBy=this.RetloginDetails.username
  }

  let FromDate:any;
  let ToDate:any;
  if(this.project.schedulingStartDate!=undefined && this.project.schedulingStartDate !="")
   { let Fdays: any = new Date(this.project.schedulingStartDate).getDate();
    let Fmonths: any = new Date(this.project.schedulingStartDate).getMonth() + 1;
    let Fyear: any = new Date(this.project.schedulingStartDate).getFullYear();
    FromDate = this.project.schedulingStartDate !== undefined ? (Fyear + '-' + (Fmonths.toString().length == 1 ? "0" + Fmonths : Fmonths) + '-' + (Fdays.toString().length == 1 ? "0" + Fdays : Fdays)) : "";
  }

  if(this.project.schedulingEndDate != undefined && this.project.schedulingEndDate !="")
  {
    let Tdays: any = new Date(this.project.schedulingEndDate).getDate();
    let Tmonths: any = new Date(this.project.schedulingEndDate).getMonth() + 1;
    let Tyear: any = new Date(this.project.schedulingEndDate).getFullYear();
    ToDate = this.project.schedulingEndDate !== undefined ? (Tyear + '-' + (Tmonths.toString().length == 1 ? "0" + Tmonths : Tmonths) + '-' + (Tdays.toString().length == 1 ? "0" + Tdays : Tdays)) : "";
  }

  if (this.project.schedulingStartDate != undefined && this.project.schedulingEndDate &&  FromDate > ToDate)
  {
    this.showloader=false;
    this.showAlert('End date must be greater than Start Date !'); 
    return false;  
  }
  
    this.project.active=true;
    this.project.activeDate=FromDate;
    this.project.inactiveDate=ToDate;

  this.httpService.Insert("/masters-ws/project/save",this.project,this.RetloginDetails.token)
   .subscribe((res) => {
    if(res.status == 401)
       { 
         this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { 
         this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
       {
          if (res && res.id > 0) {
            this.showloader=false;
            //this.saveAddress();
            this.showSuccess();
          
            if(this.addMode){
              this.router.navigate(['/main/project/action', 'view',res.id]);
            } else {
              this.router.navigate(['/main/project/list']);
            }
          } else {
            this.showloader=false;
            this.showError();
          
          }
        }
  
     },
     error => {
      this.showloader=false;
       this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
  }
  /* End save project */
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Project Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Project!'
    );
  }
  showSubsidiaryError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Subsidiary!'
    );
  }
  showProjectNameError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter Project Name!'
    );
  }
  showProjectStatusError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Project Status!'
    );
  }
  showProjectStartdateError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter  Start Date'
    );
  }
  clearProjectData() {
      this.router.navigate(['/main/project/list']);
  }
/* Start reload Subsidery list from api */
reloadSubidery(){
  this.isReloadSub=true;
  this.project.subsidiaryId=0;
  this.GetSubsideryList();
}
/* End reload Subsidery list from api */

showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}

}
