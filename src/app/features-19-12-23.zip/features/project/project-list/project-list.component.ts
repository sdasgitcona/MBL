import { Component, OnInit,LOCALE_ID, Inject, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch, SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { Project,BaseSearchPdf } from '../model/project-model';
import { DatePipe } from '@angular/common';
import { ToastService } from 'src/app/core/services/toast.service';
import {formatDate } from '@angular/common';
import * as FileSaver from 'file-saver';
import { saveAs } from 'file-saver';
import { file_upload } from '../../project/model/project-model';
const datepipe: DatePipe = new DatePipe('en-US')

@Component({
  selector: 'app-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.scss']
})
export class ProjectListComponent implements OnInit {
Reset() {
throw new Error('Method not implemented.');
}
  columns: any[];
  departments: any[] = [];
  RetRoleDetails:any;
  projectlist: Project[] = [];
  selectedProject: Project = new Project();
  totalRecords: number = 0;
  SubIdList:any=[];
  showloader:boolean=false;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  ProjectPrint: any[] = [];
  project: Project = new Project();
  vendorTypeOptions:any;
  newevent:any;
  issubsidiaryhidden:boolean=false;
  isdisabledsubsidiary:boolean=false;
  projectnamelist: Project[] = [];
  Subsidiarylist: SubsidiaryEntry[] = [];
  RetloginDetails:any;
     // For Role Base Access
     isEditable:boolean;
     isCreatetable:boolean;
     isViewtable:boolean;

     // For Role Base Access
projectStatusOptions: any;
  //SubsideryObject={}
  SubsideryObject: any[] = [];
  ProjectObject={}
  file: File ;
  file_upload:file_upload=new file_upload();
  displayModal:boolean;
  constructor( private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService,@Inject(LOCALE_ID) public locale: string
    )
     {
      this.projectStatusOptions = ['Closed', 'Awarded','In Progress','Not Awarded','Pending'];
      }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    
      // For Role Base Access
      const retDetails:any = localStorage.getItem("RoleDTLS");
      var role_Dtls = JSON.parse(retDetails);
      this.RetRoleDetails=role_Dtls;
      for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
      {
        if(role_Dtls[0].rolePermissions[i].accessPoint == "Project")
        {
          this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
          this.isEditable=role_Dtls[0].rolePermissions[i].edit;
          this.isViewtable=role_Dtls[0].rolePermissions[i].view;
        }
      }
  // End For Role Base Access


    //this.resetBaseSearch();
    this.GetSubsideryList();
    this.loadProjectLov();
    //this.loadProjectAll();
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
      { field: 'Id', header: 'Internal ID' },
      { field: 'Subsidiary', header: 'Subsidiary' },
      { field: 'Project ID', header: 'Project ID' },
      { field: 'Project Name', header: 'Project Name ' },
      { field: 'Start Date', header: 'Start Date' },
      { field: 'End Date', header: 'End Date' },
     ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }
  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.PROJECT_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadProject(this.newevent);
  }

  loadProject(event: any) {
    try {
      this.newevent=event
      this.loading = true;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
      // this.baseSearch.sortColumn = event.sortField
      //   ? 'p.' + event.sortField
      //   : GlobalConstants.PROJECT_TABLE_SORT_COLUMN;
        this.baseSearch.sortColumn = event.sortField
        ?  event.sortField
        : GlobalConstants.PROJECT_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
          if(this.SubIdList.length==0 && this.RetloginDetails.userType!='ROOTADMIN'){return;}
      this.HttpService.Insert('/masters-ws/project/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
          { 
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { 
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
          {
         if (res && res.list.length > 0) {
            this.projectlist = res.list;
            // if(this.baseSearch.filters && (Object.keys(this.baseSearch.filters).length === 0)){
            //   this.projectnamelist = res.list;
            //   }
            this.totalRecords = res.totalRecords;
          } else {
            this.projectlist = [];
          }
          this.loading = false;
        }
        },
        (error) => {
         this.loading = false;
        }
      );
    } catch (err) {
     
    }
  }

  navigateToAdd() {
    this.router.navigate(['/main/supplier/update']);
  }
  navigateToAddViewEdit(
    action: string,
    selectedProject: Project = new Project()
  ) {
    let projectId = null;
    if (selectedProject?.id) {
      projectId = selectedProject.id;
      this.router.navigate(['/main/project/action', action, projectId]);
    } else {
      this.router.navigate(['/main/project/action', action]);
    }
   
  }
 /* exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.projectlist);
            doc.save('project.pdf');
        })
    })
}*/
 /* Start fetch filter list of supplier from api */
 findby(event: any){
  let subsidyList:any=[];
    subsidyList.push(this.project.subsidiaryId);
    let date_from:any;
    
    if(this.project.schedulingStartDate!=undefined)
    {
     //let effectiveFrom=this.taxRateRule.effectiveFrom.setDate(this.taxRateRule.effectiveFrom.getDate() - 1)
      let days_from:any = new Date(this.project.schedulingStartDate).getUTCDate();
      if(days_from<10)
      {
         days_from="0"+days_from;
      }
      let months_from:any = new Date(this.project.schedulingStartDate).getUTCMonth()+1;
      
      if(months_from<10)
      {
        months_from="0"+months_from;
      }
      let year_from:any = new Date(this.project.schedulingStartDate).getUTCFullYear();
      date_from=year_from+"-"+months_from+"-"+days_from;
    }
  this.baseSearch.filters={
    // subsidiaryName:this.project.subsidiaryName,
    // name: this.project.name,
    // projectId:this.project.projectId,
    subsidiaryId:subsidyList,//?[this.project.subsidiaryName]:'',
    name: this.project.name?this.project.name:'',
    projectId:this.project.projectId?this.project.projectId:'',
    schedulingStartDate:date_from,
    status:this.project.status
    //schedulingStartDate:this.project.schedulingStartDate?datepipe.transform(this.project.schedulingStartDate, 'YYYY-MM-dd'):this.project.schedulingStartDate
}
this.baseSearch.pageNumber=-1;
  this.loadProject(this.newevent);
}
/* End filter list of supplier from api */
 /* Start Fetch Subsidery list from api */
 GetSubsideryList_old() {
  //this.HttpService.GetAll(GlobalConstants.URL_SUPPLIER_GET_ALL_LOV).subscribe(
    this.HttpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
     this.SubsideryObject = res.list;
    }
      //this.SubsideryObject=res;
    },
    (error) => {
    
    }
  );
}
GetSubsideryList() {
  this.SubsideryObject=[];

  //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
  if(this.RetloginDetails.userType=='SUPERADMIN')
  {
    this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
     { this.showAlert("Unauthorized Access !");
       this.router.navigate(['/login']);
     }
     else if(res.status == 404)
     { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
     { this.SubsideryObject=res;
      for(let x=0;x<this.SubsideryObject.length;x++)
     { 
      this.SubIdList.push(this.SubsideryObject[x].id);
    }
    this.issubsidiaryhidden=false;
    this.isdisabledsubsidiary=false;
    }
    },
    (error) => {
      alert(error);
     },
     () => {
        if(localStorage.getItem("ProjectFilters") != null)
        {const LocDetails:any =localStorage.getItem("ProjectFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.project.subsidiaryId=searcheData.filters.subsidiaryId[0];
        this.project.projectId=searcheData.filters.projectId;
        this.project.name=searcheData.filters.name;
        this.project.schedulingStartDate=searcheData.filters.schedulingStartDate;
        this.loadProject(this.newevent);
        localStorage.removeItem("ProjectFilters");
        }
      else
     { this.resetBaseSearch();}
    }
  );
  }else if(this.RetloginDetails.userType=='ENDUSER'){
    this.SubsideryObject.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });
    this.issubsidiaryhidden=true;
    this.isdisabledsubsidiary=true;
    this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
    this.project.subsidiaryId= this.SubsideryObject[0].id;
    this.loadProjectAll(this.SubsideryObject[0].id)
    if(localStorage.getItem("ProjectFilters") != null)
      {const LocDetails:any =localStorage.getItem("ProjectFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.project.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.project.projectId=searcheData.filters.projectId;
      this.project.name=searcheData.filters.name;
      this.project.schedulingStartDate=searcheData.filters.schedulingStartDate;
      this.loadProject(this.newevent);
      localStorage.removeItem("ProjectFilters");
      }
      else
     { this.resetBaseSearch();}
  }
}

/* End Fetch Subsidery list from api */
/* Start Fetch project list lov from api */
loadProjectLov() {
  this.HttpService.GetAll(GlobalConstants.URL_PROJECT_GET_ALL_LOV,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
     this.ProjectObject=res;
      }
    },
    (error) => {
    
    }
  );
}
/* End Fetch project list lov from api */
  /* Start Fetch project list All from api */
  loadProjectAll(subsidiaryId:any) {
    this.HttpService.GetById("/masters-ws/project/get-by-subsidiary-id?subsidiaryId=" + subsidiaryId,subsidiaryId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        this.projectnamelist=res;
      }
      },
      (error) => {
      }
    );
  }
  /* End Fetch project list All from api */
  RefreshPage()
  {
    
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
     this.project.subsidiaryId =undefined;
    }
    
    this.project.name=undefined;
   this.project.projectId=undefined;
   this.project.schedulingStartDate=undefined;
   this.projectnamelist=[];
   this. resetBaseSearch();
}
showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}


editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("ProjectFilters") != null)
    {
      localStorage.removeItem("ProjectFilters");
    }
    localStorage.setItem("ProjectFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/project/action', actionType, mainId]);
   }

    /***((Export Excel)) */
    generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.PROJECT_TABLE_SORT_COLUMN;
      this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
  
      this.HttpService.Insert('/masters-ws/project/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.ProjectPrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {

                if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){ 
                
                
                  this.ProjectPrint.push({
                    'Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'Project ID':  RetData[i].projectId,
                    'Project Name': RetData[i].name,
                    'Start Date':RetData[i].schedulingStartDate!=null?formatDate(RetData[i].schedulingStartDate, 'dd-MM-yyyy' ,this.locale):"",
                    'End Date': RetData[i].schedulingEndDate!=null?formatDate(RetData[i].schedulingEndDate, 'dd-MM-yyyy' ,this.locale):"",  
                    
  
                    // 
                    
                });
              }
                else{
                  this.ProjectPrint.push({
                    'Internal Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'Project ID':  RetData[i].projectId,
                    'Project Name': RetData[i].name,
                    'Start Date':RetData[i].schedulingStartDate!=null?formatDate(RetData[i].schedulingStartDate, 'dd-MM-yyyy' ,this.locale):"",
                    'End Date': RetData[i].schedulingEndDate!=null?formatDate(RetData[i].schedulingEndDate, 'dd-MM-yyyy' ,this.locale):"",  
           
                  });
                }
  
              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    exportPdf() {
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          //this.= this.employeeExport;
          //this.employeelist=[];
          (doc as any).autoTable(this.exportColumns, this.ProjectPrint);
          doc.save('project.pdf');
        })
      })
    }
  
  //End PDF
  
  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');
  
   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.ProjectPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.ProjectPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'project');
           this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
  //End Excel 
    //List Export option End
  
     /********Export excel */

@ViewChild('attachments') attachment: any;

fileList: File[] = [];
listOfFiles: any[] = [];
isLoading = false;

csvUploadDownload(){
  this.displayModal = true;
}
uploadFile(event:any){
  const formData:FormData = new FormData();
if(this.file)
{
   formData.append('file', this.file,this.file.name);
   this.showloader=true;
  //this.HttpService.uploadFile_("/masters-ws/supplier/upload",formData,{responseType: 'arraybuffer'},this.RetloginDetails.token)
  this.HttpService.uploadFile_("/masters-ws/project/upload?subsidiaryId=" +this.RetRoleDetails[0].subsidiaryId, formData ,{responseType: 'blob'} ,this.RetloginDetails.token)
  .subscribe(res => {
    if(res.status == 401)
    { this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { this.showAlert("Wrong/Invalid Token!");
       this.router.navigate(['/login']);
     }
     else
    {  
      this.executeSaveAs(res)
     if (res.error){
       this.toastService.addSingle(
         'error',
         'Error',
         res.error.errorMessage
       );
       }
       else{
        
         this.toastService.addSingle(
           'success',
           'Success',
           'File uploaded Successfully!'
         );
         window.location.reload();
       }
      }
      this.showloader=false;
  },
    (error) => {
      if(error.status == 200)
      {
        this.toastService.addSingle(
          'success',
          'Success',
          'File uploaded Successfully!'
        );
        window.location.reload();
      }
      else
     { this.showAlert(error.message);}
      this.executeSaveAs(error.error.text);
      //this.showAlert(error.error.error);
      this.showloader=false;
    },
    () => {

      // 'onCompleted' callback.
      // No errors, route to new page here
    });
  }
  else
{
  this.showAlert("No Attachment Found !")
}
}

onFileChanged(event: any) {
  this.isLoading = true;
  this.listOfFiles=[]
  this.file = event.target.files[0];
  //this.listOfFiles.push(this.file .name);
  this.listOfFiles.push({subsidiary:this.RetRoleDetails[0].subsidiaryName,file:this.file .name});
   
  this.isLoading = false;
  //this.attachment.nativeElement.value = '';
}
removeSelectedFile(index: number) {
  // Delete the item from fileNames list
  this.listOfFiles.splice(index, 1);
  // delete file from FileList
  this.fileList.splice(index, 1);
}

executeSaveAs(content:any){
  //let blob = new Blob([content], {'type': "application/octet-stream"});
 saveAs(content, "project.xlsx"); // This is from https://github.com/eligrey/FileSaver.js
};

DownloadTemplete() {
this.HttpService.downloadFile("/masters-ws/project/download-template",this.RetloginDetails.token)
.subscribe((res) => {
  //saveAs(res, 'employee.xlsx');
  if(res)
  {this.executeSaveAs(res);}
  //let blob = new Blob([res], {'type': "application/octet-stream"});
  //window.open(res)
},(error) => {
  alert(error);
 },
 ()=>{
 }
);


}

onRowSelect(event: any) {
  let projectId = event.data.id;
  
  this.router.navigate(['/main/project/action/view',projectId]);
}
  
}
