import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProjectAddEditComponent } from './project-add-edit/project-add-edit.component';
import { ProjectListComponent } from './project-list/project-list.component';

const routes: Routes = [
  {
    path: '',
    component: ProjectListComponent,
  },
  {
    path: 'list',
    component: ProjectListComponent,
  },
  {
    path: 'action/:action/:id',
    component: ProjectAddEditComponent,
  },
  {
    path: 'action/:action',
    component: ProjectAddEditComponent,
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectRoutingModule { }
