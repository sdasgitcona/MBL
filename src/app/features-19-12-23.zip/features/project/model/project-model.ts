export class Project {
    id?: number;
    subsidiaryId?: number;
    name?: string;
    projectId?: any;
    customer?: string;
    status?: string;
    schedulingStartDate?: any;
    activeDate?:any;
    inactiveDate?:any;
    schedulingEndDate?: any;
    integrated_id?: string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    subsidiaryName?: any;
    deleted?: boolean;
    active?:boolean;
}

  // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: ProjectFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class ProjectFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}
export class file_upload
{
  file:File;
}