import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentSequenceListComponent } from './document-sequence-list.component';

describe('DocumentSequenceListComponent', () => {
  let component: DocumentSequenceListComponent;
  let fixture: ComponentFixture<DocumentSequenceListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentSequenceListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DocumentSequenceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
