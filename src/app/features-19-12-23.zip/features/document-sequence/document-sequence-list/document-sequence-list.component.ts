import { Component, OnInit,ViewChild,LOCALE_ID, Inject  } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { PrimeNGConfig } from 'primeng/api';
import { BaseSearch,DocumentSequence,BaseSearchPdf } from '../model/document-sequence-model';
import { InputTextModule } from 'primeng/inputtext';
import { Table } from 'primeng/table';
import * as FileSaver from 'file-saver';
import {formatDate } from '@angular/common';
@Component({
  selector: 'app-document-sequence-list',
  templateUrl: './document-sequence-list.component.html',
  styleUrls: ['./document-sequence-list.component.scss']
})
export class DocumentSequenceListComponent implements OnInit {
  
  columns: any[];
  exportColumns: any[];
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  retDocSqncData:DocumentSequence[]=[];
  documentSequence: DocumentSequence = new DocumentSequence();
  RetloginDetails:any;
  SubsideryObject:any [];
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  showloader: boolean=false;
  isViewtable:boolean;
  isviewEditable:boolean=true;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  DSPrint: any[] = [];
  // For Role Base Access
  RetRoleDetails:any;
  ishiddensubsidiary:boolean=false;
  isdisablesubsidiary:boolean=false;
  newevent: any;
  SubIdList:any=[];
  @ViewChild('dt') dt: Table;
  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService, 
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService,@Inject(LOCALE_ID) public locale: string) { }
  SequenceTypeOptions: any;
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;
 const LDetails:any=localStorage.getItem("LoggerDTLS");
this.RetloginDetails = JSON.parse(LDetails);

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Document Sequencing")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access
this.GetSubsideryList();
//this.resetBaseSearch();   

    this.primengConfig.ripple = true;
    this.SequenceTypeOptions = [
      {name: 'AP Invoice', code: 'AP Invoice', id: 'AP Invoice', value: 'AP Invoice'},
      {name: 'Make Payment', code: 'Make Payment',id:'Make Payment', value:'Make Payment'},
      {name: 'Purchase Requisition', code: "Purchase Requisition", id: "Purchase Requisition", value: "Purchase Requisition"},
      {name: 'Request For Quotation', code: 'Request For Quotation', id: 'Request For Quotation', value: 'Request For Quotation'},
      {name: 'Quotation Analysis', code: 'Quotation Analysis', id:'Quotation Analysis',value:'Quotation Analysis'},
      {name: 'Purchase Order', code: 'Purchase Order', id:'Purchase Order', value:'Purchase Order'},
      {name: 'Goods Received Note', code:'Goods Received Note', id: 'Goods Received Note', value: 'Goods Received Note'},
      {name: 'Return to Supplier', code: 'Return to Supplier', id: 'Return to Supplier', value: 'Return to Supplier'},
      {name: 'Debit Note', code: 'Debit Note', id: 'Debit Note', value:'Debit Note'},
      {name: 'Advance Payment', code: 'Advance Payment', id: 'Advance Payment', value: 'Advance Payment' }
    ];
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
     
      { field: 'Id', header: 'Sl No' },
      { field: 'Subsidiary', header: 'Subsidiary' },
      { field: 'Type', header: 'Type' },
      { field: 'Prefix', header: 'Prefix' },
      { field: 'Suffix', header: 'Suffix' },
      { field: 'Maximum Digits', header: 'Minimum Digit' },
      { field: 'Initial Number', header: 'Initial Number' },
      { field: 'Start Date', header: 'Start Date' },
      { field: 'End Date', header: 'End Date' },
     ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }
  loadList(event: any) {
  
    try {
      this.loading = true;
      this.newevent = event;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
      this.baseSearch.sortColumn = event.sortField
        ? event.sortField
        : GlobalConstants.DOCSEQUENCE_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.DESCENDING
          : GlobalConstants.ASCENDING;
          if(this.SubIdList.length==0)
          {
           return;
          }
 
      this.HttpService.Insert('/setup-ws/document-sequence/get/all',this.baseSearch, this.RetloginDetails.token).subscribe(
        (res) => {

          if(res.status == 401){
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
          else {
            if (res && res.list.length > 0) {
              this.retDocSqncData = res.list;
              this.totalRecords =res.totalRecords;// res.length;
            } else {
              this.retDocSqncData = [];
              this.totalRecords=0;
            }
            this.loading = false;
          }
          
          },
          (error) => {
            // console.log(error);
             this.loading = false;
           }

          
      );
    } catch (err) {
      //console.log(err);
    }
  }
  navigateToAddEdit(action: string)
  {
    this.router.navigate(['/main/documentsequence/action', action]);
  }
  navigateToAddViewEdit(
    action: string,
    selectedList: DocumentSequence = new DocumentSequence()
  ) {
    let locationId = null;
    if (selectedList?.id) {
      locationId = selectedList.id;
      this.router.navigate(['/main/documentsequence/action', action, locationId]);
    } else {
      this.router.navigate(['/main/documentsequence/action', action]);
    }
   // console.log('Action is ' + action);
  }
 /* exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.retDocSqncData);
            doc.save('DocumentSequence.pdf');
        })
    })
}*/
globalSearch(event: any) {
  this.dt.filterGlobal(event.value, 'contains')
}

showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}

ReloadSubsidiaryList()
{
  this.documentSequence.subsidiaryId=0;
  
}

findby(event: any) {
  let subsidyList:any=[];
  let start_date:any;
  let end_date:any;
  subsidyList.push(this.documentSequence.subsidiaryId);
  if(this.documentSequence.startDate!=undefined)
  {
   //let effectiveFrom=this.taxRateRule.effectiveFrom.setDate(this.taxRateRule.effectiveFrom.getDate() - 1)
    let days_from:any = new Date(this.documentSequence.startDate).getUTCDate();
    if(days_from<10)
    {
       days_from="0"+days_from;
    }
    let months_from:any = new Date(this.documentSequence.startDate).getUTCMonth()+1;
    
    if(months_from<10)
    {
      months_from="0"+months_from;
    }
    let year_from:any = new Date(this.documentSequence.startDate).getUTCFullYear();
    start_date=year_from+"-"+months_from+"-"+days_from;
  }
  if(this.documentSequence.endDate!=undefined)
  {
   // let effectiveto=this.taxRateRule.effectiveTo.setDate(this.taxRateRule.effectiveTo.getDate() - 1)
    let days_to:any = new Date(this.documentSequence.endDate).getUTCDate();
    if(days_to<10)
    {
      days_to="0"+days_to;
    }
    let months_to:any = new Date(this.documentSequence.endDate).getUTCMonth()+1;
    if(months_to<10)
    {
      months_to="0"+months_to;
    }
    let year_to:any = new Date(this.documentSequence.endDate).getUTCFullYear();
    end_date=year_to+"-"+months_to+"-"+days_to;
  }

  this.baseSearch.filters = {
    subsidiaryId:subsidyList,
    type: this.documentSequence.type,
    startDate: start_date,
    endDate: end_date
  
  }

      this.baseSearch.pageNumber=-1;

      this.loadList(this.newevent);
}
/* End filter list of supplier from api */

GetSubsideryList() {
  this.SubsideryObject=[];

  //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
  if(this.RetloginDetails.userType=='SUPERADMIN')
  {
    this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
     { this.showAlert("Unauthorized Access !");
       this.router.navigate(['/login']);
     }
     else if(res.status == 404)
     { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
     { this.SubsideryObject=res;
      for(let x=0;x<this.SubsideryObject.length;x++)
     { 
      this.SubIdList.push(this.SubsideryObject[x].id);
    }
    this.ishiddensubsidiary=false;
    this.isdisablesubsidiary=false;
    }
    },
    (error) => {
      alert(error);
     },
     () => {
      if(localStorage.getItem("DocSeqFilters") != null)
      {const LocDetails:any =localStorage.getItem("DocSeqFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.documentSequence.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.documentSequence.type=searcheData.filters.type;
      this.documentSequence.startDate=searcheData.filters.startDate != undefined ? new Date(searcheData.filters.startDate ):undefined;
      this.documentSequence.endDate=searcheData.filters.endDate != undefined ? new Date(searcheData.filters.endDate ):undefined;
      this.loadList(this.newevent);
      localStorage.removeItem("DocSeqFilters");
      }
      else
     { this.resetBaseSearch();}
    }
  );
  }else if(this.RetloginDetails.userType=='ENDUSER'){
    this.documentSequence.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
    this.SubsideryObject.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });
    this.ishiddensubsidiary=true;
    this.isdisablesubsidiary=true;
    this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
    if(localStorage.getItem("DocSeqFilters") != null)
    {const LocDetails:any =localStorage.getItem("DocSeqFilters");
    let RetLocDetails = JSON.parse(LocDetails);
    this.baseSearch=RetLocDetails;
    let searcheData:any = RetLocDetails;
    this.documentSequence.subsidiaryId=searcheData.filters.subsidiaryId[0];
    this.documentSequence.type=searcheData.filters.type;
    this.documentSequence.startDate=searcheData.filters.startDate != undefined ? new Date(searcheData.filters.startDate ):undefined;
    this.documentSequence.endDate=searcheData.filters.endDate != undefined ? new Date(searcheData.filters.endDate ):undefined;
    this.loadList(this.newevent);
    localStorage.removeItem("DocSeqFilters");
    }
    else
   { this.resetBaseSearch();}
  }
}
resetBaseSearch() {
  this.baseSearch.filters = {subsidiaryId: this.SubIdList};
  this.baseSearch.pageNumber = 0;
  this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
  this.baseSearch.sortColumn = GlobalConstants.DOCSEQUENCE_TABLE_SORT_COLUMN;
  this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
  this.loadList(this.newevent);
}

ReloadTypeList()
{
  this.documentSequence.type="";
}

Reset() {
  if(this.RetloginDetails.userType=='SUPERADMIN')
  {
  this.documentSequence.subsidiaryId = undefined;
  }
  this.documentSequence.type = undefined;
  this.documentSequence.startDate = "";
  this.documentSequence.endDate = "";
  this.resetBaseSearch();
}

editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("DocSeqFilters") != null)
    {
      localStorage.removeItem("DocSeqFilters");
    }
    localStorage.setItem("DocSeqFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/documentsequence/action', actionType, mainId]);
   }

     /***((Export Excel)) */
     generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.DOCSEQUENCE_TABLE_SORT_COLUMN;
      this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
  
      this.HttpService.Insert('/setup-ws/document-sequence/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.DSPrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {

                if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){ 


                 
                  this.DSPrint.push({
                    'Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'Type':  RetData[i].type,
                    'Prefix': RetData[i].prefix,
                    'Suffix': RetData[i].suffix,
                    'Maximum Digits':  RetData[i].minimumDigit,  
                    'Initial Number': RetData[i].initialNumber,
                    'Start Date': formatDate(RetData[i].startDate, 'dd-MM-yyyy' ,this.locale),
                    'End Date':  formatDate(RetData[i].endDate, 'dd-MM-yyyy' ,this.locale),  
  
                    // 
                    
                });
              }
                else{
                  this.DSPrint.push({
                    'Internal Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'Type':  RetData[i].type,
                    'Prefix': RetData[i].prefix,
                    'Suffix': RetData[i].suffix,
                    'Maximum Digits':  RetData[i].minimumDigit,  
                    'Initial Number': RetData[i].initialNumber,
                    'Start Date': formatDate(RetData[i].startDate, 'dd-MM-yyyy' ,this.locale),
                    'End Date':  formatDate(RetData[i].endDate, 'dd-MM-yyyy' ,this.locale),  

                  });
                }
  
              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    exportPdf() {
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          //this.= this.employeeExport;
          //this.employeelist=[];
          (doc as any).autoTable(this.exportColumns, this.DSPrint);
          doc.save('document-sequence.pdf');
        })
      })
    }
  
  //End PDF
  
  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');
  
   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.DSPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.DSPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'document-sequence');
           this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
  //End Excel 
    //List Export option End
  
     /********Export excel */
     onRowSelect(event: any) {
      let dsId = event.data.id;
      
      this.router.navigate(['/main/documentsequence/action/view', dsId]);
    }

}
