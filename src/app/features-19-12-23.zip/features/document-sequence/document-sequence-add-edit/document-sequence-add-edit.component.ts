import { Component, OnInit,ViewChild } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { PrimeNGConfig } from 'primeng/api';
import { BaseSearch,DocumentSequence } from '../model/document-sequence-model';
import { Table } from 'primeng/table';
declare let $: any;
@Component({
  selector: 'app-document-sequence-add-edit',
  templateUrl: './document-sequence-add-edit.component.html',
  styleUrls: ['./document-sequence-add-edit.component.scss']
})
export class DocumentSequenceAddEditComponent implements OnInit {
  private subscription: any;
  docSequence:DocumentSequence[]=[];
  dynamicRow:DocumentSequence[]=[];
  Subsidiarylist: any[] = [];
  showloader: boolean=false;
  RetloginDetails: any;
  //
// For Role Base Access
isEditable:boolean;
isCreatetable:boolean;
isViewtable:boolean;
// For Role Base Access
  //
  SequenceTypeOptions: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  loading: boolean = false;
  searchTextBox:any;
  RetRoleDetails:any;
  mainId: number = 0;
  @ViewChild('dt') dt: Table;
  


  constructor(private routeStateService: RouteStateService, private activatedRoute: ActivatedRoute,
    private router: Router,
    private HttpService: CommonHttpService, private primengConfig: PrimeNGConfig,
    private toastService: ToastService) {
      this.SequenceTypeOptions = [
        {name: 'AP Invoice', code: 'AP Invoice', id: 'AP Invoice', value: 'AP Invoice'},
        {name: 'Make Payment', code: 'Make Payment',id:'Make Payment', value:'Make Payment'},
        {name: 'Purchase Requisition', code: "Purchase Requisition", id: "Purchase Requisition", value: "Purchase Requisition"},
        {name: 'Request For Quotation', code: 'Request For Quotation', id: 'Request For Quotation', value: 'Request For Quotation'},
        {name: 'Quotation Analysis', code: 'Quotation Analysis', id:'Quotation Analysis',value:'Quotation Analysis'},
        {name: 'Purchase Order', code: 'Purchase Order', id:'Purchase Order', value:'Purchase Order'},
        {name: 'Goods Received Note', code:'Goods Received Note', id: 'Goods Received Note', value: 'Goods Received Note'},
        {name: 'Return to Supplier', code: 'Return to Supplier', id: 'Return to Supplier', value: 'Return to Supplier'},
        {name: 'Debit Note', code: 'Debit Note', id: 'Debit Note', value:'Debit Note'},
        {name: 'Advance Payment', code: 'Advance Payment', id: 'Advance Payment', value: 'Advance Payment' }
      ];
     }

     

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
     const retDetails:any = localStorage.getItem("RoleDTLS");
     var role_Dtls = JSON.parse(retDetails);
     this.RetRoleDetails=role_Dtls;
      const LDetails:any=localStorage.getItem("LoggerDTLS");
      this.RetloginDetails = JSON.parse(LDetails);
 
     for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
     {
       if(role_Dtls[0].rolePermissions[i].accessPoint == "Document Sequencing")
       {
         this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
         this.isEditable=role_Dtls[0].rolePermissions[i].edit;
         this.isViewtable=role_Dtls[0].rolePermissions[i].view;
       }
     }
 // End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          // if (params['action'] =="edit") {
          //   this.GetDocmentSequenceList();
          // }
          if (params['id']) {
            this.mainId = +params['id']; 
            this.GetDocmentSequenceById();
          }
          else
          {
            this.docSequence.push(new DocumentSequence() )
          }
          this.assignMode(params['action']);       
          this.GetSubsideryList();
        } else {
          //console.log('cannot get params');
        }
      },
      (error) => {
        //console.log('add');
      }
    );
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = true;
        break;

      default:
        break;
    }
  }

  GetDocmentSequenceList() {
    var obj;
    obj = {
      pageNumber: 0,
      pageSize: 200,
      sortColumn: "type",
      sortOrder: "desc"
    }
    this.loading = true;
    this.HttpService.Insert("/setup-ws/document-sequence/get/all",obj, this.RetloginDetails.token)
      .subscribe(res => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }

        else {
          this.docSequence=res.list;
         if(this.docSequence.length>0){
          for (let i = 0; i < this.docSequence.length; i++) {
            this.docSequence[i]=this.docSequence[i];
            this.docSequence[i].startDate=(this.docSequence[i].startDate) == null || (this.docSequence[i].startDate) == ""?'':new Date(this.docSequence[i].startDate);
            this.docSequence[i].endDate=(this.docSequence[i].endDate) == null || (this.docSequence[i].endDate) == ""?'':new Date(this.docSequence[i].endDate);
        
          }
         }
         this.loading = false;
        }
         
         
        });
  }
  GetDocmentSequenceById() {
    this.HttpService
      .GetById('/setup-ws/document-sequence/get?id=' + this.mainId, this.mainId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.docSequence.push(res);
         if(this.docSequence.length>0){
          for (let i = 0; i < this.docSequence.length; i++) {
            this.docSequence[i]=this.docSequence[i];
            this.docSequence[i].startDate=(this.docSequence[i].startDate) == null || (this.docSequence[i].startDate) == ""?'':new Date(this.docSequence[i].startDate);
            this.docSequence[i].endDate=(this.docSequence[i].endDate) == null || (this.docSequence[i].endDate) == ""?'':new Date(this.docSequence[i].endDate);
          }
         }
         this.loading = false;
        }
      });
  }
  GetSubsideryList_old() {
    this.HttpService.GetAll('/setup-ws/subsidiary/get/all', this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {this.Subsidiarylist = res.list;}

        
      },
      (error) => {
        //console.log(error);
      }
    );
  }
  GetSubsideryList() {
    this.Subsidiarylist=[];
  
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist=res;
        for(let x=0;x<this.Subsidiarylist.length;x++)
       { 
       
      }
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
       
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
    
    }
  }
  addNewRow()
  {
    //$('#txtSearch').val("");
    if(this.searchTextBox !== undefined )
    {
    this.globalSearch(null);
    this.searchTextBox="";
    }
    this.editMode=false;
    var DS=new DocumentSequence();
    DS.subsidiaryId;
    DS.type="";
    DS.prefix="";
    DS.suffix="";
    DS.minimumDigit;
    DS.initialNumber;
    DS.startDate;
    DS.endDate
    this.docSequence.push(DS);
  }
  addNewRow22() {
    if (
      this.docSequence.length > 0) // && this.docSequence[length - 1] == new DocumentSequence()
      {
        let NewCount=this.docSequence.length+1;
        let count=1;
        for (let i = 1; i < this.docSequence.length; i++) {
          if(count == i)
          {
            this.editMode=true;
            count++;
             if(count == NewCount)
             {
              count++;
             }
          }
          else
          {
        this.editMode=false;
        this.docSequence.push(new DocumentSequence());
          } 
        }
      }
      else
      {
        this.editMode=false;
        this.docSequence.push(new DocumentSequence());
      }
    
    
  }
  saveDocumentSequence()
  {
   
    if(this.docSequence.length == 0)
    {
      this.showAlert("No List Found");
      return false;
    }
    for(let i=0;i<this.docSequence.length;i++){
      if(this.addMode){
        this.docSequence[i].createdBy=this.RetloginDetails.username;this.docSequence[i].lastModifiedBy=this.RetloginDetails.username
        }
       else if(!this.addMode){
        this.docSequence[i].lastModifiedBy=this.RetloginDetails.username
        }

        if(this.docSequence[i].subsidiaryId == undefined || this.docSequence[i].subsidiaryId == 0)
        {
        this.showAlert("Line Number:"+(i+1)+ " Please select Subsidiary");
        return false;
        }
        else if(this.docSequence[i].type == undefined || this.docSequence[i].type == '')
        {
          this.showAlert("Line Number:"+(i+1)+ " Please select Type");
          return false;
        }  
        else if(this.docSequence[i].minimumDigit == undefined )
        {
          this.showAlert("Line Number:"+(i+1)+ " Please enter Maximum Digit");
          return false;
        } 
        else if(this.docSequence[i].initialNumber == undefined || this.docSequence[i].initialNumber == '')
        {
          this.showAlert("Line Number:"+(i+1)+ " Please enter Initial Number");
          return false;
        } 
        else if(this.docSequence[i].startDate == undefined || this.docSequence[i].startDate == '')
        {
          this.showAlert("Line Number:"+(i+1)+ " Please enter Start Date");
          return false;
        }  
        else if(this.docSequence[i].endDate == undefined || this.docSequence[i].endDate == '')
        {
          this.showAlert("Line Number:"+(i+1)+ " Please enter End Date");
          return false;
        }  
        else if(new Date(this.docSequence[i].startDate) >= new Date(this.docSequence[i].endDate))
        {
          this.showAlert("Line Number:"+(i+1)+ " End Date must be greater than Start Date");
          return false;
        }  
     }
  
   

    this.HttpService.Insert('/setup-ws/document-sequence/save', this.docSequence, this.RetloginDetails.token)
    .subscribe(
      (res) => {

        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else
      {
        if (res !== undefined) {
          //this.saveAddress();
          this.showSuccess();

          
          if(this.addMode){
            this.router.navigate(['/main/documentsequence/action', 'view',res.id]);
          } else {
            this.router.navigate(['/main/documentsequence/list']);
          }

          
        }
        else {
          this.showError();
        }
      } 
      },
      (error) => {
        this.showAlert(error);
      },
    );
   
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Data Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving!'
    );
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  globalSearch(event: any) {
    if(event!=null)
    this.dt.filterGlobal(event.target.value, 'contains')
    else
    this.dt.filterGlobal(null,null);
  }
  NumberOnly(event:any):boolean{
    const charCode=(event.which)? event.which:event.keyCode;
    if(charCode > 31 && (charCode <48 || charCode >57))
    {
      return false;
    }
    return true;
   }
    checkforlength(RowIndex:number)
    {
      var NoStart=this.docSequence[RowIndex].initialNumber?.toString().length;
      var MaxNo=this.docSequence[RowIndex].minimumDigit;
      if( Number(NoStart) > Number(MaxNo) )
      {
        this.showAlert("Initial Number Should Not Be Greater Than Maximum Digit");
        let str = NoStart.toString();
        this.docSequence[RowIndex].initialNumber =str.slice(0, -1);
        //this.maxInputNumber=Number(MaxNo);
      }
     //let num:any=this.generalpreferences.numberingPreferences[RowIndex].masterStartsWith?.toString;   
    }
}
