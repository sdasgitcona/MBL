import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentSequenceAddEditComponent } from './document-sequence-add-edit.component';

describe('DocumentSequenceAddEditComponent', () => {
  let component: DocumentSequenceAddEditComponent;
  let fixture: ComponentFixture<DocumentSequenceAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentSequenceAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DocumentSequenceAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
