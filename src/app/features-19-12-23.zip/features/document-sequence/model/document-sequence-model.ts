export class DocumentSequence {
    subsidiaryId: any;
    type:any;
    suffix:string;
    prefix:string;
    startDate:any;
    endDate:any;
    minimumDigit:number;
    initialNumber:any;
    active:boolean=true;
    id:number;
    subsidiaryName:string;
    createdBy:string;
    lastModifiedBy:string;
  }
  
   // Base seach model for Supplier
export class BaseSearch {
  filters: TblFilter | {} = {};
  pageNumber: number = 0;
  pageSize: number = 0;
  sortColumn: string = '';
  sortOrder: string = '';
}

export class TblFilter {
    subsidiaryId: string = '';
    type: string = '';
    startDate:any;
    endDate: any;
    pan: string = '';
    active: string = '';
  }

   // Base seach model for Supplier
   export class BaseSearchPdf {
    filters: DSFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class DSFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}