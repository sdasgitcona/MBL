import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DocumentSequenceListComponent } from './document-sequence-list/document-sequence-list.component';
import { DocumentSequenceAddEditComponent } from './document-sequence-add-edit/document-sequence-add-edit.component';

const routes: Routes = [
  {
    path: 'list',
    component: DocumentSequenceListComponent,
  },
  {
    path: 'action/:action/:id',
    component: DocumentSequenceAddEditComponent,
  },
  {
    path: 'action/:action',
    component: DocumentSequenceAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DocumentSequenceRoutingModule { }
