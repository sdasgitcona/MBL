
export class dashboardSearch { 
  subsidiaryName?:any;
  fromDate?:string;
  toDate?:string;
  supplier?:any;
  currency?:any;
  
  subsidiaryId?:any;
  supplierName?:any;
  supplierId?:any;
  date?:string;
  
  bankId:any;
  bankName:any;
}


