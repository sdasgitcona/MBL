import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { dashboardSearch } from './model/dashboard-report-module';

@Component({
  selector: 'app-dashboard-report',
  templateUrl: './dashboard-report.component.html',
  styleUrls: ['./dashboard-report.component.scss']
})
export class DashboardReportComponent implements OnInit {
  
  displayModal:boolean = false;
  agingDisplayModal:boolean = false;
  agingDetailDisplayModal:boolean = false;
  bankDetailDisplayModal:boolean = false;

  SubsideryObject : any[] = [];
  SupplierObject: any= [];
  CurrencyList:any=[];
  BankObject:any=[];

  subsideryName:string;
  supplierName:string;
  subsideryId:number;
  supplierId:number;

  RetloginDetails:any;
  repModel:dashboardSearch = new dashboardSearch();
  SubIdList:any=[];
  RetRoleDetails:any;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService,

   
  )  { 


  }

  ngOnInit(): void {
    
   // this.displayModal = true;
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Purchase Requisition") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
      }
    }
    // End For Role Base Access

    this.GetSubsideryList();
  }
  
  // GetSubsideryList() {
  //   this.HttpService.GetAll('/setup-ws/subsidiary/get/all', this.RetloginDetails.token).subscribe(
  //     (res) => {
  //       this.SubsideryObject = res.list;
  //     },
  //     (error) => {
  //       this.showAlert(error);
  //     }
  //   );
  // }
 
   GetSubsideryList() {
    this.SubsideryObject=[];
  
    if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.SubsideryObject=res;
        for(let x=0;x<this.SubsideryObject.length;x++)
       { 
        this.SubIdList.push(this.SubsideryObject[x].id);
      }
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
        //this.resetBaseSearch();
       //this.loadSuppliers('');
       }
    );
    }else{
      this.SubsideryObject.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      //this.resetBaseSearch();
    }
  }

  GetSupplierList(SubsideryId: number,SubsideryName : string) {
    this.subsideryName =SubsideryName;
    this.subsideryId=SubsideryId;
   // alert(this.subsideryName+''+this.subsideryId);
    this.SupplierObject = [];
    this.HttpService.GetAll('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId='+ SubsideryId, this.RetloginDetails.token).subscribe(
      (res) => {
       
        
        //alert(res[0].subsidiaryName)
        for (let i = 0; i < res.length; i++) {
         // if (res[i].effectiveTo == null && res[i].parentLocation == true) {
            this.SupplierObject?.push({
              "name": res[i]?.name,
              "id": res[i].id
            });

         // }
          }
         
      },
      (error) => {
        this.showAlert(error);
      }
    );
  }
  
  GetBankList(SubsideryId: number,SubsideryName : string) {
    this.BankObject = []; 
    this.subsideryName =SubsideryName;
    this.subsideryId=SubsideryId;

    this.HttpService.GetAll('/masters-ws/bank/get-bank-lov?subsidiaryId='+ SubsideryId, this.RetloginDetails.token).subscribe(
      (res) => {
        
        for (let i = 0; i < res.length; i++) {
         // if (res[i].effectiveTo == null && res[i].parentLocation == true) {
            this.BankObject?.push({
              "name": res[i]?.name,
              "id": res[i].id
            });

         // }
          }
         
      },
      (error) => {
        this.showAlert(error);
      }
    );
  }


  getAll_CurrencyList(SupplierId:number,SupplierName:string){
    this.supplierName=SupplierName;
    this.supplierId=SupplierId;
    //alert(SupplierId);
    this.HttpService.GetAll("/masters-ws/supplier/get-currency-by-supplier?supplierId="+SupplierId,this.RetloginDetails.token)
    .subscribe(res => {

      this.CurrencyList =[]
      for (let i = 0; i < res.length; i++) {
        // if (res[i].effectiveTo == null && res[i].parentLocation == true) {
           this.CurrencyList?.push({
             "currency": res[i]?.supplierCurrency,
             "id": res[i].id
           });

        // }
         }
      
    });
   }
  
  // navigateToReport(){
    
  //   if(this.repModel.fromDate==undefined || this.repModel.fromDate == '' ||this.repModel.toDate==undefined || this.repModel.toDate == '' || this.repModel.subsidiaryName==undefined || this.repModel.subsidiaryName == '')
  //   {

  //     if(this.repModel.subsidiaryName==undefined){
  //       this.showAlert(this.repModel.subsidiaryName||'Please Select Subsidiary Name')
  //     }

  //     else if(this.repModel.fromDate==undefined){
  //     this.showAlert(this.repModel.fromDate||'Please Select From Date')
  //   }
  //   else if(this.repModel.toDate==undefined){
  //     this.showAlert(this.repModel.toDate||'Please Select To Date')
  //   }
   
    
      
  //   }
  //   else{   
 
  //   const fromDate = new Date(this.repModel.fromDate??'');
  //     const year = fromDate.getFullYear();
  //     const month = ('0' + (fromDate.getMonth() + 1)).slice(-2);
  //     const day = ('0' + fromDate.getDate()).slice(-2);
  //     const frmDate = year+"-"+ month+"-"+ day;

  //   const toDate = new Date(this.repModel.toDate??'');
  //       const year2 = toDate.getFullYear();
  //       const month2 = ('0' + (toDate.getMonth() + 1)).slice(-2);
  //       const day2 = ('0' + toDate.getDate()).slice(-2);
  //       const tooDate = year2+"-"+ month2+"-"+ day2;

    

  //   const currency = this.repModel?.currency??'';
  //   this.router.navigate(['/main/reports/account_statement/action/',this.subsideryName,this.subsideryId,frmDate,tooDate,this.supplierName,this.supplierId,currency]);
    
  //  }


  // }
  navigateToReport(){
    if(this.repModel.fromDate==undefined || this.repModel.fromDate == '' ||this.repModel.toDate==undefined || this.repModel.toDate == '' || this.repModel.subsidiaryName==undefined || this.repModel.subsidiaryName == '')
    {
      if(this.repModel.subsidiaryName==undefined){
        this.showAlert(this.repModel.subsidiaryName||'Please Select Subsidiary Name')
      }
      else if(this.repModel.fromDate==undefined){
        this.showAlert(this.repModel.fromDate||'Please Select From Date')
      }
      else if(this.repModel.toDate==undefined){
        this.showAlert(this.repModel.toDate||'Please Select To Date')
      }
    }
    else{   
    const frDate = new Date(this.repModel.fromDate??'');
    const y = frDate.getFullYear();
    const m = ('0' + (frDate.getMonth() + 1)).slice(-2);
    const d = ('0' + frDate.getDate()).slice(-2);
    const fDate = y+"-"+ m+"-"+ d;
    const toooDate = new Date(this.repModel.toDate??'');
    const y2 = toooDate.getFullYear();
    const m2 = ('0' + (toooDate.getMonth() + 1)).slice(-2);
    const d2 = ('0' + toooDate.getDate()).slice(-2);
    const tDate = y2+"-"+ m2+"-"+ d2;
    const fromDate = new Date(this.repModel.fromDate??'');
    const year =new Date(fromDate).getUTCFullYear();
    const month =new Date(fromDate).getUTCMonth() + 1;
    const day =new Date(fromDate).getUTCDate();
    const frmDate =(year + '-' + (month.toString().length == 1 ? "0" + month : month) + '-' + (day.toString().length == 1 ? "0" + day : day));
    const toDate = new Date(this.repModel.toDate??'');
    const year2 =new Date(toDate).getUTCFullYear();
    const month2 =new Date(toDate).getUTCMonth() + 1;
    const day2 =new Date(toDate).getUTCDate();
    const tooDate = (year2 + '-' + (month2.toString().length == 1 ? "0" + month2 : month2) + '-' + (day2.toString().length == 1 ? "0" + day2 : day2));
    const currency = this.repModel?.currency??'';
    this.router.navigate(['/main/reports/account_statement/action/',this.subsideryName,this.subsideryId,frmDate,fDate,tooDate,tDate,this.supplierName,this.supplierId,currency]);
   }


  }

  accountStatementDisplay(){
    this.displayModal = true;
  }
  agingDisplay(){
    this.agingDisplayModal = true;
  }
  agingDetailDisplay(){
    this.agingDetailDisplayModal = true;
  }
  bankDetailDisplay(){
    this.bankDetailDisplayModal=true;
  }
  
  
  showAlert(AlertMSG: any) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }

  // navigateToApSummaryReport(){

  //   if(this.repModel.date==undefined || this.repModel.date == '' || this.repModel.subsidiaryName==undefined || this.repModel.subsidiaryName == '')
  //   {

  //     if(this.repModel.subsidiaryName ==undefined && this.repModel.date == undefined){
  //       this.showAlert('Please Select Subsidiary Name and Date')
  //     }
  //     else if(this.repModel.subsidiaryName==undefined){
  //       this.showAlert('Please Select Subsidiary Name')
  //     }

  //     else if(this.repModel.date==undefined){
  //     this.showAlert('Please Select Date')
  //   }
      
  //   }
  //   else{    
      

  
  //   const asDate = new Date(this.repModel.date??'');
  //   this.router.navigate(['main/reports/agingSummary/action',this.subsideryId,this.subsideryName,asDate.toLocaleDateString('en-GB')]);
  // }


  // }
  navigateToApSummaryReport(){
    if(this.repModel.date==undefined || this.repModel.date == '' || this.repModel.subsidiaryName==undefined || this.repModel.subsidiaryName == '')
    {
      if(this.repModel.subsidiaryName ==undefined && this.repModel.date == undefined){
        this.showAlert('Please Select Subsidiary Name and Date')
      }
      else if(this.repModel.subsidiaryName==undefined){
        this.showAlert('Please Select Subsidiary Name')
      }
      else if(this.repModel.date==undefined){
        this.showAlert('Please Select Date')
      }
    }
    else{    
      const asDate = new Date(this.repModel.date??'');
      const year = asDate.getFullYear();
      const month = ('0' + (asDate.getMonth() + 1)).slice(-2);
      const day = ('0' + asDate.getDate()).slice(-2);
      const asOfDate = year+"-"+ month+"-"+ day;
      this.router.navigate(['main/reports/agingSummary/action',this.subsideryId,this.subsideryName,asOfDate]);//asDate.toLocaleDateString('en-GB')
    }
  }

  navigateToApDetailsReport(){

    if( this.repModel.supplierName==undefined || this.repModel.supplierName == ''|| this.repModel.subsidiaryName==undefined || this.repModel.subsidiaryName == '' || this.repModel.date==undefined || this.repModel.date == '')
    {

      if(this.repModel.subsidiaryName == undefined && this.repModel.supplierName == undefined && this.repModel.date == undefined){
        this.showAlert('Please Select Subsidiary Name, Supplier Name and Date')
      }
      else if(this.repModel.subsidiaryName == undefined){
        this.showAlert('Please Select Subsidiary Name')
      }
      else if(this.repModel.supplierName == undefined){
        this.showAlert('Please Select Supplier Name')
      }
      else if(this.repModel.date == undefined){
      this.showAlert('Please Select Date')
    }
      
    }
    else{const date = new Date(this.repModel.date);
      const year = date.getFullYear().toString();///.substring(2);
      const month = ('0' + (date.getMonth() + 1)).slice(-2);
      const day = ('0' + date.getDate()).slice(-2);
      const asDate = year+"-"+ month+"-"+ day;   
   // const asDate = new Date(this.repModel.date??'');
    this.router.navigate(['main/reports/agingDetails/action',this.subsideryId??"",this.subsideryName??'',this.supplierId??"",this.supplierName??"",asDate,this.repModel.currency??'']);
  }


  }
  navigateToBankDetailsReport(){

    if( this.repModel.bankId==undefined || this.repModel.bankId == ''|| this.repModel.subsidiaryName==undefined || this.repModel.subsidiaryName == ''
     || this.repModel.fromDate==undefined || this.repModel.fromDate == ''  || this.repModel.toDate==undefined || this.repModel.toDate == '')
    {

      if(this.repModel.subsidiaryName == undefined && this.repModel.bankName == undefined 
        && this.repModel.toDate == undefined){
        this.showAlert('Please Select Subsidiary Name, Supplier Name and Date')
      }
      else if(this.repModel.subsidiaryName == undefined){
        this.showAlert('Please Select Subsidiary Name')
      }
      else if(this.repModel.bankId == undefined){
        this.showAlert('Please Select Bank Name')
      }
      else if(this.repModel.fromDate == undefined){
      this.showAlert('Please Select From Date')
    }
    else if(this.repModel.toDate == undefined){
      this.showAlert('Please Select To Date')
    }
      
    }
    else{const fromDate = new Date(this.repModel.fromDate);
      const fyear = fromDate.getFullYear().toString();///.substring(2);
      const fmonth = ('0' + (fromDate.getMonth() + 1)).slice(-2);
      const fday = ('0' + fromDate.getDate()).slice(-2);
      const fasToDate = fyear+"-"+ fmonth+"-"+ fday;  
      
      const toDate = new Date(this.repModel.toDate);
      const tyear = toDate.getFullYear().toString();///.substring(2);
      const tmonth = ('0' + (toDate.getMonth() + 1)).slice(-2);
      const tday = ('0' + toDate.getDate()).slice(-2);
      const tasToDate = tyear+"-"+ tmonth+"-"+ tday;   
   // const asDate = new Date(this.repModel.date??'');
    this.router.navigate(['main/reports/bankStatementDtl/action',this.subsideryId??"",this.subsideryName??'',this.repModel.bankId??'',fasToDate,tasToDate]);
  }


  }
}