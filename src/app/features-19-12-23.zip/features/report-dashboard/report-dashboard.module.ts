import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { CalendarModule } from 'primeng/calendar';
import { CardModule, } from 'primeng/card';
import { PanelModule } from 'primeng/panel';
import { ReportDashboardRoutingModule } from './report-dashboard-routing.module';
import { DashboardReportComponent } from './dashboard-report/dashboard-report.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    DashboardReportComponent
  ],
  imports: [
    CommonModule,
    DialogModule,
    DropdownModule,
    CalendarModule,
    FormsModule,
    CardModule,
    PanelModule,
    ReportDashboardRoutingModule
  ]
})
export class ReportDashboardModule { }
