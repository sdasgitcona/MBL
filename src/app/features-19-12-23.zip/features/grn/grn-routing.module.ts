import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GrnListComponent } from './grn-list/grn-list.component';
import { GrnAddEditComponent } from './grn-add-edit/grn-add-edit.component';
const routes: Routes = [
  {
    path: '',
    component: GrnListComponent,
  },
  {
    path: 'list',
    component: GrnListComponent,
  },
  {
    path: 'list/:status',
    component: GrnListComponent,
  },
  {
    path: 'action/:action/:id',
    component: GrnAddEditComponent,
  },
  {
    path: 'action/:action',
    component: GrnAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GRNRoutingModule { }
