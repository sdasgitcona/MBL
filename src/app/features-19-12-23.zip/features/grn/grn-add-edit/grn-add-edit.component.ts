import { Component, OnInit } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import { DatePipe } from '@angular/common';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { PrimeNGConfig } from 'primeng/api';
import {grn,BaseSearch,location,POList} from '../../grn/model/grn-module';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { Theme } from '@amcharts/amcharts5';
import { GrnReportComponent } from '../../reports/grn-report/grn-report.component';

@Component({
  selector: 'app-grn-add-edit',
  templateUrl: './grn-add-edit.component.html',
  styleUrls: ['./grn-add-edit.component.scss']
})
export class GrnAddEditComponent implements OnInit {
  grnId:number;
  grn: grn = new grn();
  lstCurrencyList: any[] = [];
  supplierlistid: any[] = [];
  employeelist:any[]=[];
  Transport_mode:any;
  remarks:string;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  isReloadSub:boolean;
  chkpolist:any;
  baseSearch: BaseSearch = new BaseSearch();
  Subsidiarylist: any=[];
  Locationlist:any;
  POList:POList[]=[];
  grnsave:grn[]=[];
  GRNHistoryList: HistoryModel[] = [];
  grnlocation:location[]=[];
  RetloginDetails: any;
  loginId:any;
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  isviewEditable:boolean=true;
  chkgrnitemlist:boolean=false;
  oneInvoiceAvailable:boolean;
  chkcurrency:boolean=false;
  loadstatus:boolean=true;
  showloader:boolean = false;
  fiscalCalenderDTLS: any;
  chkqty:boolean=false;
  dismarkall:boolean=false;
  RetRoleDetails:any;
  // For Role Base Access
  private subscription: any;
  constructor( private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,private grnReport: GrnReportComponent
    )    { 

      this.Transport_mode = [{id:'Road',value:'Road'},{id:'Air',value:'Air'},{id:'Sea',value:'Sea'}];
    }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;

 const LDetails:any=localStorage.getItem("LoggerDTLS");
  this.RetloginDetails = JSON.parse(LDetails);
this.loginId= this.RetloginDetails.employeeId;

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Goods Received Notes")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access
    this.GetSubsideryList();
    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.grnId = +params['id']; // (+) converts string 'id' to a number
            this.GetGRNbyId();
          }
          this.assignMode(params['action']);       
        } else {
          this.showAlert('cannot get params');
        }
        if(this.addMode)
        {this.loadrequestor();}
      },
      (error) => {
        this.showAlert(error);
      }
    );
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;

      default:
        break;
    }
  }

  GetGRNbyId() {
    this.loadstatus=false;
    this.httpService
      .GetById('/procure-ws/grn/get?id=' + this.grnId, this.grnId ,this.RetloginDetails.token)
      .subscribe((res) => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.grn=res;
          this.grn.grnDate=this.grn.grnDate!=null?new Date(this.grn.grnDate):"";
          //this.POList.push({})
          //this.loadPONumber();
          for(let i=0;i<this.grn.grnItem.length;i++)
          {
            this.grn.grnItem[i].receiveqtydisable=true;
            this.grn.grnItem[i].lotnodisable=true;
            //this.grn.grnItem[i].remainQuantity="";
            //this.grn.grnItem[0].invoiceNumber="1";
            if( this.grn.grnItem[i].invoiceNumber !=null)
            {
            this.grn.grnItem[i].disabledIfInvoice=true;
            this.oneInvoiceAvailable=true;
            }
            
            if( this.grn.grnItem[i].status =="Partially Billed" || this.grn.grnItem[i].status =="Billed")
            {
              this.grn.grnItem[i].disabledIfInvoice=true;
              this.dismarkall=true;
            }
            else if(this.grn.grnItem[i].rtvQuantity>0)
            {
              this.grn.grnItem[i].disabledIfInvoice=true;
              this.dismarkall=true;
            }
          }
    
          setTimeout(() => { this.loadlocation();},600);
          setTimeout(() => { this.loadPONumberedit(res.poId,res.poNumber,res.poStatus);},600);
          setTimeout(() => { this.loaditem();},600);
          setTimeout(() => { this.loadstatus=true;},1500); 
        }


        
      }); 
  }

  //--Close Button
  clearGRN()
  {
    this.router.navigate(['/main/grn/list']);
    // if(this.editMode){
    //   this.router.navigate(['/main/grn/list']);
    // }
    // else if(this.viewMode){
    //   this.router.navigate(['/main/grn/list']);
    // }
    // else{
    //   window.location.reload();
    // }
  }
  saveGRN()
  {
    if(this.grn.subsidiaryId==undefined)
    {
       this.showErrorSubsidiary();
       return;
    }
    if(this.grn.locationId==undefined)
    {
      this.showErrorLocation();
      return;
    }
    if(this.grn.poNumber==undefined)
    {
      this.showErrorPO();
      return;
    }
    if(this.grn.grnDate==undefined)
    {
      this.showErrorGRNDate();
      return;
    }
    for(let i=0;i<this.grn.grnItem.length;i++)
    {
      if(this.grn.grnItem[i].active==true)
      {
        this.chkgrnitemlist=true;
        break;
      }

    }

    if(this.chkgrnitemlist==false)
    {
          this.showErrorBlankGRNLinr();
          return;
          
    }
    this.chkgrnitemlist=false;
    
    for(let i=0;i<this.grn.grnItem.length;i++)
    {
      if(this.grn.grnItem[i].active==true)
      {
           if(this.grn.grnItem[i].reciveQuantity<=0 || this.grn.grnItem[i].reciveQuantity==undefined)
           {
                 this.showErrorreciveQuantity();
                 return;
           }
      }
      //else{
       // this.grn.grnItem.splice(i,1);
      //}
    }
    this.grn.grnItem=this.grn.grnItem.filter(x=>x.active==true);
    this.grnsave=[];
    let grn_days:any = new Date(this.grn.grnDate).getDate();
  let grn_months:any = new Date(this.grn.grnDate).getMonth()+1;
  let grn_year:any = new Date(this.grn.grnDate).getFullYear();
  if(grn_months<10)
  {
    grn_months="0".toString()+grn_months.toString();
  }
  if(grn_days<10)
  {
    grn_days="0".toString()+grn_days.toString();
  }
  //this.grn.grnDate=grn_year+"-"+grn_months+"-"+grn_days;
    this.grnsave.push(this.grn);
    this.showloader=true;
    //For Save API Call
if(this.addMode){
  this.grn.createdBy=this.RetloginDetails.username;this.grn.lastModifiedBy=this.RetloginDetails.username
  }
 else if(!this.addMode){
  this.grn.lastModifiedBy=this.RetloginDetails.username
  }

    this.httpService.Insert('/procure-ws/grn/save',  this.grnsave ,this.RetloginDetails.token).subscribe(
      (res) => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          if (res) {
            this.showSuccess();
            this.showloader=false;
            if(this.addMode && res[0].id > 0)
            {
              this.router.navigate(['/main/grn/action/view',res[0].id]);
            }
            else{ this.router.navigate(['/main/grn/list']);
          }
           
          } else {
            this.showError();
            this.showloader=false;
          }
        } 
      },
      (error) => {
       this.showAlert(error);
       this.showloader=false;
      },
      () => {}
    );
  }
  loadlocation()
  {
  this.getFiscalDateRanges();
   if(this.loadstatus==true)
   {
    this.Locationlist=[];
    this.POList=[];
    this.grn.grnItem=[];
    this.grn.currency="";
    this.grn.supplierName=""
   }

    this.httpService.GetAll('/masters-ws/location/get/all/lov?subsidiaryId='+this.grn.subsidiaryId ,this.RetloginDetails.token).subscribe(
      (res) => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.grnlocation=[];
          for (const [key, value] of Object.entries(res)) {
            this.grnlocation.push({locationId:Number(key),name:value})
            this.Locationlist= this.grnlocation;
          }
        }

        
      },
      (error) => {
       this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );

    this.httpService.GetAll('/setup-ws/subsidiary/get?id='+this.grn.subsidiaryId ,this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.grn.subCurrency=res.currency.toString();
        }

        
      },
      (error) => {
        this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
    this.loadreceiver();
  }
  loadPONumber()
  {
    this.httpService.GetAll('/procure-ws/po/get-po-by-location-number?locationId='+this.grn.locationId+'&subsidiaryId='+this.grn.subsidiaryId+'&poStatus=Partially Received,Approved' ,this.RetloginDetails.token).subscribe(
      (res) => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.POList=res;
          this.POList=this.POList.filter(function(element:any){ return element.poStatus == "Partially Billed" || element.poStatus == "Partially Received" || element.poStatus == "Approved"; })
            
        }


       
      },
      (error) => {
        this.showAlert(error);
      },
      () => {
      }
    );
  }
  loadPONumberedit(id:number,poNumber:string,status:string)
  {
    this.httpService.GetAll('/procure-ws/po/get-po-by-location-number?locationId='+this.grn.locationId+'&subsidiaryId='+this.grn.subsidiaryId+'&poStatus=Partially Received,Approved' ,this.RetloginDetails.token).subscribe(
      (res) => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.POList=res;
          this.POList=this.POList.filter(function(element:any){ return element.poStatus == "Partially Billed" || element.poStatus == "Partially Received" || element.poStatus == "Approved"; })

          this.POList.push({
            id:id,
            poNumber:poNumber,
            poStatus:status
          })
        }
      },
      (error) => {
        this.showAlert(error);
      },
      () => {
      }
    );
  }
  reloadSubidery()
  {
    this.grn.subsidiaryId=undefined;
    this.Subsidiarylist=[];
    this.Locationlist=[];
    this.POList=[];
    this.grn.grnItem=[];
    this.grn.currency="";
    this.grn.supplierName=""
    this.GetSubsideryList();
  }
  GetSubsideryList() {
    if(this.RetloginDetails.userType=='SUPERADMIN')
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
     
    //this.httpService.GetAll("/setup-ws/subsidiary/get/all" ,this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.Subsidiarylist = res;
          this.isReloadSub=false;
        }
      },
      (error) => {
        this.isReloadSub=false;
        this.showAlert(error);
      });
  }else if(this.RetloginDetails.userType=='ENDUSER'){
    this.Subsidiarylist.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });
  }
  }
  loaditem()
  {
    this.httpService.GetAll('/procure-ws/po/get?id='+this.grn.poId ,this.RetloginDetails.token).subscribe(
      (res) => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.grn.PODate=res.poDate!=null?new Date(res.poDate):"";
              this.grn.poNumber=res.poNumber;
              if(this.addMode)
              {
                for(let i=0;i<res.purchaseOrderItems.length;i++)
                {
                  if(res.purchaseOrderItems[i].remainQuantity<=0)
                  {
                    res.purchaseOrderItems.splice(i,1);
                  }
                }
              this.grn.grnItem=res.purchaseOrderItems;
              this.grn.grnItem=this.grn.grnItem.filter(x=>x.remainQuantity>0);
              for(let i=0;i<this.grn.grnItem.length;i++)
              {
                this.grn.grnItem[i].receiveqtydisable=true;
                this.grn.grnItem[i].lotnodisable=true;
                this.grn.grnItem[i].poiId=this.grn.grnItem[i].id;
                this.grn.grnItem[i].id=null;
              }
            }
            else
            {
              /* for(let i=0;i<res.purchaseOrderItems.length;i++)
              {
                  if( this.grn.grnItem[i].itemId==res.purchaseOrderItems[i].itemId)
                  {
                    this.grn.grnItem[i].remainQuantity=res.purchaseOrderItems[i].remainQuantity;
                  }
              }*/
            }
        }


      
      },
      (error) => {
      this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
   if(this.addMode || this.editMode || this.viewMode)
   {
    this.httpService.GetAll('/procure-ws/po/get-supplier-currency-by-po?poId='+this.grn.poId ,this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.grn.currency=res[0].currency;
          this.grn.supplierName=res[0].supplierName;
          this.grn.supplierId=res[0].supplierId;

          if(this.grn.currency==this.grn.subCurrency)
          {
              this.chkcurrency=true;
              this.grn.exchangeRate="1";
          }
          else
          {
            this.chkcurrency=false;
          }
        }

        


      },
      (error) => {
        this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
    }
   /* if(this.addMode)
    {
      
    this.httpService.GetAll('/po/get-item-by-po?poId='+this.grn.poId+'&itemNature=Stockable').subscribe(
      (res) => {
        console.log(res);
        this.grn.grnItem=res;
        this.grn.poNumber=this.grn.grnItem[0].poNumber;
        for(let i=0;i<this.grn.grnItem.length;i++)
        {
          this.grn.grnItem[i].receiveqtydisable=true;
          this.grn.grnItem[i].lotnodisable=true;
          this.grn.grnItem[i].poiId=res[i].id;
          this.grn.grnItem[i].id=null;
        }
      
      },
      (error) => {
        console.log(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
    }*/
  }
  reloadLocation()
  {
    this.Locationlist=[];
    this.POList=[];
    this.grn.grnItem=[];
    this.loadlocation();
  }
  reloadPO()
  {
    this.POList=[];
    this.grn.grnItem=[];
    this.loadPONumber();
  }
  loadreceiver()
  {
    this.httpService.GetAll('/masters-ws/employee/get-employee-by-subsidiary?subsidiaryId='+this.grn.subsidiaryId ,this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {this.employeelist=res;}

        
      },
      (error) => {
        this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
  }
  chkenable()
  {
    if(this.grn.markall)
    {
      for(let i=0;i<this.grn.grnItem.length;i++)
      {
        if( this.grn.grnItem[i].invoiceNumber !=null)
          {
            this.grn.grnItem[i].active=false;
            this.grn.grnItem[i].receiveqtydisable=true;
            this.grn.grnItem[i].lotnodisable=true;
          }
          else
          {
            this.grn.grnItem[i].active=true;
            this.grn.grnItem[i].receiveqtydisable=false;
            this.grn.grnItem[i].lotnodisable=false;
          }
      }
    }
      else
      {
        for(let i=0;i<this.grn.grnItem.length;i++)
        {
          this.grn.grnItem[i].active=false;
          this.grn.grnItem[i].receiveqtydisable=true;
          this.grn.grnItem[i].lotnodisable=true;
        }
      }
  }
  fielddisable(rowindex:number)
  {
    if(this.grn.grnItem[rowindex].active==true)
    {
           
            // this.paymentamtdisenb=false;
            this.grn.grnItem[rowindex].receiveqtydisable=false;
            this.grn.grnItem[rowindex].lotnodisable=false;
    }
    else{
             // this.paymentamtdisenb=true;
             this.grn.grnItem[rowindex].receiveqtydisable=true;
             this.grn.grnItem[rowindex].lotnodisable=true;
    }
  }
  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 1) {
      this.LoadHistory();
     // this.displayAddressDialog = false;
    }
  }

  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'GRN Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving GRN!'
    );
  }
  showErrorSubsidiary() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Subsidiary!'
    );
  }
  showErrorLocation() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Plesae select Location!'
    );
  }
  showErrorPO() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select PO Number'
    );
  }
  showErrorGRNDate() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter GRN Date!'
    );
  }
  showErrorQuantity() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Receive Quantity not greater than Order Quantity & Remaining Quantity!'
    );
  }
  showErrorremainQuantity() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Receive Quantity not greater than Remaining Quantity!'
    );
  }
  showErrorBlankGRNLinr() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select atleast one Item !'
    );
  }
  showErrorreciveQuantity() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Receive Quantity must be greater than 0!'
    );
  }
  calcqty(rowindex:number)
  {
    // this.grn.grnItem[rowindex].reciveQuantity>this.grn.grnItem[rowindex].remainQuantity
    if(this.grn.grnItem[rowindex].reciveQuantity>this.grn.grnItem[rowindex].quantity )
    {
      this.showErrorQuantity();
      this.grn.grnItem[rowindex].reciveQuantity=0;
    }
  
   // this.grn.grnItem[rowindex].remainQuantity=this.grn.grnItem[rowindex].quantity-this.grn.grnItem[rowindex].reciveQuantity;
  }

  LoadHistory() {
    if (this.GRNHistoryList.length == 0)
      this.httpService.GetAll('/procure-ws/grn/get/history?grnNumber='+this.grn.grnNumber+'&pageSize=100' ,this.RetloginDetails.token)
        .subscribe((res) => {
          //For Auth
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
          else
          {
            //console.log(res);
            this.GRNHistoryList = res;
          }

          
        });
  }

  checkdate(){
    this.getFiscalDateRanges();
    if(this.grn.PODate != undefined || this.grn.PODate != null)
    {
      let gdays:any =  new Date(this.grn.grnDate).getDate();
      let gmonths:any = new Date(this.grn.grnDate).getMonth()+1;
      let gyear:any =  new Date(this.grn.grnDate).getFullYear();
      let GrnDate=this.grn.grnDate !== undefined ? (gyear + '-' + (gmonths.toString().length ==1?"0"+gmonths:gmonths) + '-' + (gdays.toString().length ==1?"0"+gdays:gdays)) :""
    
      let Podays:any =  new Date(this.grn.PODate).getDate();
      let Pomonths:any = new Date(this.grn.PODate).getMonth()+1;
      let Poyear:any =  new Date(this.grn.PODate).getFullYear();
      let PoDate=this.grn.PODate !== undefined ? (Poyear + '-' + (Pomonths.toString().length ==1?"0"+Pomonths:Pomonths) + '-' + (Podays.toString().length ==1?"0"+Podays:Podays)) :""
    
      
      if(GrnDate < PoDate)
    {
     this.grn.grnDate={};

     this.showAlert("GRN Date must be greater than or equal to PO Date: " + (this.grn.PODate !== undefined ? ((Podays.toString().length ==1?"0"+Podays:Podays)+ '-' +(Pomonths.toString().length ==1?"0"+Pomonths:Pomonths)+ '-' + Poyear  ) :""));
     
     return;

   }
  }
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
// Download Report 
DownloadReport_old(grnNumber:any){
  window.open(this.httpService.ReportUrl+"/run?__report=report/Goods_Receipt_Note.rptdesign&__format=pdf&grn_number="+grnNumber,'_blank')
  }
  DownloadReport(grnNumber:any){
    //window.open(this.HttpService.ReportUrl+"/run?__report=report/Goods_Receipt_Note.rptdesign&__format=pdf&grn_number="+grnNumber,'_blank')
    this.grnReport.exportPdf(grnNumber);//grnNumber-TPL/26/GRN
  }
  getFiscalDateRanges() {
    let Subsidiary=this.grn.subsidiaryId;
    let InputDate=this.grn.grnDate;
    if((Subsidiary != undefined || Subsidiary != "") && (InputDate!= undefined || InputDate!= null)) {

    this.httpService
    .GetById('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId=' + Subsidiary, Subsidiary ,this.RetloginDetails.token)
    .subscribe((res) => {
      //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          if (res) {
            this.fiscalCalenderDTLS=res;
            if(this.fiscalCalenderDTLS != null && this.fiscalCalenderDTLS.fiscalCalanderAccounting.length >0)
            {
            let AllowMonths: any = "Allow Months: ";
            let IsDateAvailable:boolean = false;

            var Dummymonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

            let PRdays: any = new Date(InputDate).getDate();
            let PRmonths: any = new Date(InputDate).getMonth() + 1;
            let PRyear: any = new Date(InputDate).getFullYear();
            let CompareDate: any = InputDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""

            for (let x = 0; x < this.fiscalCalenderDTLS.fiscalCalanderAccounting.length; x++) {
              AllowMonths += this.fiscalCalenderDTLS.fiscalCalanderAccounting.length == (x + 1) ? this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month : this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month + " , "

              if (CompareDate >= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].fromDate && CompareDate <= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].toDate && this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month == Dummymonths[PRmonths - 1] + "-" + PRyear) {
                IsDateAvailable = true;
              }
            }

            if (IsDateAvailable == false) {
              this.showAlert("Selected Date is Not available in Fiscal Calendar  ! " + AllowMonths);
              this.grn.grnDate = {};
            }
          } else
          {
            this.showAlert("Selected Date is Not available in Fiscal Calendar !");
            this.grn.grnDate = {};
          }

          } else {
            this.showAlert("No Data Found");
          }
        }

      


    },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
           error
        );
      }

    );

}
  }
  loadrequestor()
{
  this.httpService.GetAll('/masters-ws/employee/get?id='+this.loginId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.grn.reciver=res.fullName
     
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}
}

