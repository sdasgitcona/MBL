import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GrnAddEditComponent } from './grn-add-edit.component';

describe('GrnAddEditComponent', () => {
  let component: GrnAddEditComponent;
  let fixture: ComponentFixture<GrnAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GrnAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GrnAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
