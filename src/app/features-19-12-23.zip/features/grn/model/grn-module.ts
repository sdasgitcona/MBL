export class grn{
            id: number;
            grnNumber:number;
            subsidiaryId?: number;
            locationId?:number;
            poNumber:string;
            grnDate:any;
            supplierId?:number;
            currency:string;
            memo:string;
            purchaseDate:Date;
            exchangeRate:string;
            modeOfTransport:string;
            vehicleNumber:string;
            awNumber:string;
            reciver:string;
            netsuiteId:string;
            createdDate?: Date;
            createdBy?: string;
            lastModifiedDate?: Date;
            lastModifiedBy?: string;
            poId:number;
            locationName: string;
            subsidiaryName: string;
            supplierName: string;
            grnItem: grnItem[]=[];
            grnItemChk: grnItem[]=[];
            deleted:boolean;
            ewayBillNumber: string;
            markall:boolean;
            subCurrency:string;
            PODate:any;
            status:any;
            rtvStatus:any;
            billStatus:any;
            fromDate:any;
            toDate:any;
            receiver:any;
            suppliername:any;
            recent:any;
}
export class BaseSearch {
    filters?: Filter | {} = {};
    pageNumber?: number = 0;
    pageSize?: number = 0;
    sortColumn?: string = '';
    sortOrder?: string = '';
  }
  
  //this class holds the custom filter values at component level.
  export class Filter {
    subsidiary?: string = '';
    vendorname?: string = '';
    vendornumber?: string = '';
    vendortype?: string = '';
    pan?: string = '';
    active?: string = '';
  }

  export class grnItem{
                id:any;
                grnId:number;
                itemId:number;
                poNumber:string;
                grnNumber:string;
                itemName:string;
                itemDescription:string;
                itemUom:string;
                taxGroupId:number;
                quantity:number;
                reciveQuantity:number;
                remainQuantity:any;
                lotNumber:string;
                rate:number;
                rtvQuantity:number;
                invoiceNumber:string;
                createdDate?: Date;
                createdBy?: string;
                lastModifiedDate?: Date;
                lastModifiedBy?: string;
                deleted:boolean;
                poId?:number;
                poiId?:number;
                amount?:number;
                taxAmount?:number;
                totalTaxAmount?:number;
                totalAmount?:number;
                receivedByDate?:Date;
                prNumber?:string;
                shipToLocationId?:number;
                shipToLocation?:string;
                department?:string;
                memo?:string;
                accountId?:string;
                accountCode?:string;
                itemIntegratedId?:string;
                qaNumber?:string;
                active:boolean;
                receiveqtydisable:boolean;
                lotnodisable:boolean;
                disabledIfInvoice:boolean;
                unbilledQuantity:number;
                status:string;
                rtvStatus:any;
                billStatus:any;
                billQuantity:any;
  }
  export class location
  {
    locationId:number;
    name:any;
  }

  export class POList{
    id:number;
    poNumber:string;
    poStatus:string;
  }

    // Base seach model for Supplier
    export class BaseSearchPdf {
      filters: GRNFIlters | {} = {};
      pageNumber: number = 0;
      pageSize: number = 0;
      sortColumn: string = '';
      sortOrder: string = '';
    }
  
    //this class holds the custom filter values at component level.
  export class GRNFIlters {
      subsidiary: string = '';
      vendorname: string = '';
      vendornumber: string = '';
      vendortype: string = '';
      pan: string = '';
      active: string = '';
    }


