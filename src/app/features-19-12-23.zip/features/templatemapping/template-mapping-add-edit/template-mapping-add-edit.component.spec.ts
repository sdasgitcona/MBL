import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateMappingAddEditComponent } from './template-mapping-add-edit.component';

describe('TemplateMappingAddEditComponent', () => {
  let component: TemplateMappingAddEditComponent;
  let fixture: ComponentFixture<TemplateMappingAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TemplateMappingAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TemplateMappingAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
