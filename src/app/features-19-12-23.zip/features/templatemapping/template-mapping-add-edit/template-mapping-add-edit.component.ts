import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { AddressComponent } from 'src/app/shared/shared-components/address/address.component';
import { MenuItem } from 'primeng/api';
import { concat } from 'rxjs';
import { TemplateMapping,templateSuppliers} from '../Model/template-mapping-model';

@Component({
  selector: 'app-template-mapping-add-edit',
  templateUrl: './template-mapping-add-edit.component.html',
  styleUrls: ['./template-mapping-add-edit.component.scss']
})
export class TemplateMappingAddEditComponent implements OnInit {
  HistoryList: HistoryModel[] = [];
  TemplateMappingId: number;
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  role: any;
  SubsideryObject:any[]=[];
  fieldmapping:any;
  Vendorlist: any[] = [];
  Vendorlistid: any[] = [];
  TemplateMapping: TemplateMapping = new TemplateMapping();
  showloader:boolean=false;
  selectedSupplierDetails: templateSuppliers = new templateSuppliers();
    // For Role Base Access
    isEditable:boolean;
    isCreatetable:boolean;
    isViewtable:boolean;
    isviewEditable:boolean=true;
    // For Role Base Access
    RetloginDetails: any;
    RetRoleDetails:any
  constructor( private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
    private HttpService: CommonHttpService) { }
    ngOnInit(): void {
      if(localStorage.getItem("LoggerDTLS") == null)
      {
        this.router.navigate(['/login']);
      }
    // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;

 const LDetails: any = localStorage.getItem("LoggerDTLS");
 this.RetloginDetails = JSON.parse(LDetails);

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Invoice Template")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access
    this.GetSubsideryList();
    //this.GetAllVendorListbySubsidiaryID();
    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.TemplateMappingId = +params['id']; // (+) converts string 'id' to a number
            this.GetTemplatebyId();
          }
          this.assignMode(params['action']);
         } else {
        }
      },
      (error) => {
      }
    );
    this.fieldmapping = [
      { Level: 'Header', monstarbillfields: 'Invoice Number',suppliertemplate: '' },
      { Level: 'Header', monstarbillfields: 'Invoice Date',suppliertemplate: '' },
      { Level: 'Header', monstarbillfields: 'PO Number',suppliertemplate: '' },
      { Level: 'Line', monstarbillfields: 'SL.No',suppliertemplate: '' },
      { Level: 'Line', monstarbillfields: 'Item',suppliertemplate: '' },
      { Level: 'Line', monstarbillfields: 'Description',suppliertemplate: '' },
      { Level: 'Line', monstarbillfields: 'Billing Qty',suppliertemplate: '' },
      { Level: 'Line', monstarbillfields: 'Rate',suppliertemplate: '' },
    ];
  }
  clearTemplateMapping()
  {
    if(this.editMode){
      this.router.navigate(['/main/template-mapping/list']);
    }
    else{
      this.TemplateMapping = new TemplateMapping();
      this.fieldmapping[0].suppliertemplate="";
      this.fieldmapping[1].suppliertemplate="";
      this.fieldmapping[2].suppliertemplate="";
      this.fieldmapping[3].suppliertemplate="";
      this.fieldmapping[4].suppliertemplate="";
      this.fieldmapping[5].suppliertemplate="";
      this.fieldmapping[6].suppliertemplate="";
      this.Vendorlist=[];
    }
  }
  GetSubsideryList_old() {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all', this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
         { this.SubsideryObject=res.list;}
        },
        (error) => {
         
        }
      );
      }

      GetSubsideryList() {
        this.showloader=true; 
        //if(this.RetRoleDetails[0].selectedAccess == 'ADMIN')
        if(this.RetloginDetails.userType=='SUPERADMIN')
        //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
        {
          this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
        //this.httpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
          (res) => {
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
               this.router.navigate(['/login']);
             }
           else {this.SubsideryObject=res;
            this.showloader=false; }
            // this.GetSubsideryListLov();
          },
          (error) => {
           this.showloader=false;
    
          }
        );
      }else if(this.RetloginDetails.userType=='ENDUSER')
      {
        this.SubsideryObject.push({
          "id":this.RetRoleDetails[0].subsidiaryId,
          "name":this.RetRoleDetails[0].subsidiaryName
        });
        this.showloader=false;
      }
      }
  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 1) {
      this.LoadHistory();
    //  this.displayAddressDialog = false;
    }
  }

   addSupplierMapping() {
    if (
      this.TemplateMapping.templateSuppliers.length > 0 &&
      this.TemplateMapping.templateSuppliers[length - 1] == new templateSuppliers()
    ) {
      return;
    }
    this.TemplateMapping.templateSuppliers.push(new templateSuppliers());
   }
  GetAllVendorList(){
    var obj={
      filters:{},
      "pageNumber": 0,
        "pageSize": 1000,
        "sortColumn": "vendor_type",
        "sortOrder": "asc"
    }
       this.HttpService.Insert("/masters-ws/supplier/get/all",obj, this.RetloginDetails.token)
        .subscribe(res => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
         { this.Vendorlist=res.list;}
        
          });
  }
  GetTemplatebyId() {
    this.httpService
      .GetById('/setup-ws/template/get?templateId=' + this.TemplateMappingId, this.TemplateMappingId, this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { //this.GetAllVendorListbyOnLoadSubsidiaryID(res.subsidiaryId);
        this.GetAllVendorListbySubsidiaryID(res.subsidiaryId,res);
        this.fieldmapping[0].suppliertemplate=res.invoiceNo;
        this.fieldmapping[1].suppliertemplate=res.invoiceDate;
        this.fieldmapping[2].suppliertemplate=res.poNo;
        this.fieldmapping[3].suppliertemplate=res.slNo;
        this.fieldmapping[4].suppliertemplate=res.item;
        this.fieldmapping[5].suppliertemplate=res.description;
        this.fieldmapping[6].suppliertemplate=res.billQty;
        for(let i=0;i<res.templateSuppliers.length;i++)
        {
          this.Vendorlistid.push(res.templateSuppliers[i].supplierId);
        }
        this.TemplateMapping = res;
      for(let i=0;i<this.TemplateMapping.templateSuppliers.length;i++)
      {
        this.httpService.GetAll('/masters-ws/supplier/get?id='+this.TemplateMapping.templateSuppliers[i].supplierId, this.RetloginDetails.token).subscribe(
          (res) => {
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
               this.router.navigate(['/login']);
             }
      
            this.TemplateMapping.templateSuppliers[i].supplierEmail=res.invoiceMail;
          },
          (error) => {
           },
          () => {
         });
        this.TemplateMapping.templateSuppliers[i].isSupplierDisabled=true;
      }
    }
    });
  
  }
  GetAllVendorListbySubsidiaryID(SubsidiaryId:any=null,getData:any=null) {
    let SubId=SubsidiaryId == null ? this.TemplateMapping.subsidiaryId:SubsidiaryId;
    // this.httpService.GetAll('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId='+this.TemplateMapping.subsidiaryId, this.RetloginDetails.token).subscribe(
      this.httpService.GetAll('/masters-ws/supplier/get-supplier-by-subsidiary-and-notin-template?subsidiaryId='+SubId, this.RetloginDetails.token).subscribe( 
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {
          this.Vendorlist=res;
          if(getData)
          {
            for(let x=0;x<getData.templateSuppliers.length;x++)
            {
              this.Vendorlist.push({
                'id':getData.templateSuppliers[x].supplierId,
                'name':getData.templateSuppliers[x].supplierName,
              });
            }
          }
        }
      },
      (error) => {
       },
      () => {
      }
    );
  }
  GetAllVendorListbyOnLoadSubsidiaryID(SubsidiaryId:any) {
    this.httpService.GetAll('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId='+SubsidiaryId, this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       {this.Vendorlist=res;}
      },
      (error) => {
        },
      () => {
     }
    );
  }
  checkforduplicate(rownumber:number,SelectedVendor:any)
  {
   //for(let i=0;i<this.Vendorlistid.length;i++)
   for(let i=0;i<this.TemplateMapping.templateSuppliers.length;i++)
    {
      //if(this.Vendorlistid[i].value==this.TemplateMapping.templateSuppliers[rownumber].supplierId)
      if(i !=rownumber && this.TemplateMapping.templateSuppliers[i].supplierId==this.TemplateMapping.templateSuppliers[rownumber].supplierId)
      {
        this.showDuplicatevendorError();
        this.TemplateMapping.templateSuppliers[rownumber].supplierId={};
        this.TemplateMapping.templateSuppliers[rownumber].supplierEmail="";
        return;
        //this.deleteSupplierMapping(rownumber);
      }
    }
    this.httpService.GetAll('/masters-ws/supplier/get?id='+this.TemplateMapping.templateSuppliers[rownumber].supplierId, this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
    else if(res.invoiceMail==null || res.invoiceMail=="")
      {
        this.showSupplieremailError();
        this.TemplateMapping.templateSuppliers[rownumber].supplierId={};
        this.TemplateMapping.templateSuppliers[rownumber].supplierEmail="";
        return;
        //this.deleteSupplierMapping(rownumber);
      }
        this.TemplateMapping.templateSuppliers[rownumber].supplierEmail=res.invoiceMail;
      },
      (error) => {
       },
      () => {
     }
    );
    this.Vendorlistid.push(this.TemplateMapping.templateSuppliers[rownumber].supplierId);
  }

  showDuplicatevendorError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Duplicate Vendor found!'
    );
  }
  deleteSupplierMapping(index: number) {
    // if (index >= 0) this.supplier.supplierContacts.splice(index, 1);
  if(this.editMode)
  {
    if(this.TemplateMapping.templateSuppliers[index].templateSupplierId != null)
    {
      this.TemplateMapping.templateSuppliers[index].deleted=true;
    }
    else
    {
      this.TemplateMapping.templateSuppliers.splice(index,1);
      this.Vendorlistid.splice(index,1);
    }
    }else{
      this.Vendorlistid.splice(index,1);
      this.TemplateMapping.templateSuppliers.splice(index,1);
      }
       //this.TemplateMapping.templateSuppliers.splice(index, 1);
 }
  saveTemplateMapping() {
    if(this.TemplateMapping.subsidiaryId==undefined)
    {
          this.showSubsidiaryId();
          return;
    }
    if(this.TemplateMapping.templateName==undefined || this.TemplateMapping.templateName==null)
    {
          this.showTemplatename();
          return;
    }
    if(this.fieldmapping[0].suppliertemplate=="" &&
    this.fieldmapping[1].suppliertemplate=="" &&
    this.fieldmapping[2].suppliertemplate=="" &&
    this.fieldmapping[3].suppliertemplate=="" &&
    this.fieldmapping[4].suppliertemplate=="" &&
    this.fieldmapping[5].suppliertemplate=="" &&
    this.fieldmapping[6].suppliertemplate==""
    )
    {
        this.showFieldMapping();
        return;
    }
    if(this.TemplateMapping.templateSuppliers.length<=0)
    {
       this.showSupplierMapping();
       return;
    }
    for(let x=0;x<this.TemplateMapping.templateSuppliers.length;x++)
    {
      if(this.TemplateMapping.templateSuppliers[x].supplierId == undefined || this.TemplateMapping.templateSuppliers[x].supplierId == null)
      {
        this.showCSTMError("Please select Supplier");
        return;
      }
    }
    this.TemplateMapping.invoiceNo=this.fieldmapping[0].suppliertemplate;
    this.TemplateMapping.invoiceDate=this.fieldmapping[1].suppliertemplate;
    this.TemplateMapping.poNo=this.fieldmapping[2].suppliertemplate;
    this.TemplateMapping.slNo=this.fieldmapping[3].suppliertemplate;
    this.TemplateMapping.item=this.fieldmapping[4].suppliertemplate;
    this.TemplateMapping.description=this.fieldmapping[5].suppliertemplate;
    this.TemplateMapping.billQty=this.fieldmapping[6].suppliertemplate;
    this.TemplateMapping.unitPrice=this.fieldmapping[7].suppliertemplate;
    this.showloader=true;
    
if(this.addMode){
  this.TemplateMapping.createdBy=this.RetloginDetails.username;this.TemplateMapping.lastModifiedBy=this.RetloginDetails.username
  }
 else if(!this.addMode){
  this.TemplateMapping.lastModifiedBy=this.RetloginDetails.username
  }

    this.httpService.Insert('/setup-ws/template/save', this.TemplateMapping, this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else if (res) {
          //this.saveAddress();
          this.showSuccess();
          this.showloader=false;
          this.router.navigate(['/main/template-mapping/list']);
        } else {
          this.showloader=false;
          this.showError();
         }
      },
      (error) => {
        this.showloader=false;
        this.showCSTMError(error);
        },
      () => {}
    );
  }

  showSupplieremailError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter email in supplier!'
    );
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Template Mapping Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Template Mapping!'
    );
  }
  showCSTMError(CstmError:any) {
    this.toastService.addSingle(
      'error',
      'Error',
      CstmError
    );
  }
  showTemplatename() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter Template Name!'
    );
  }
  showSubsidiaryId() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Subsidiary!'
    );
  }
  showFieldMapping() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Atleast one Field Mapping is required!!'
    );
    
  }
  showSupplierMapping() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Atleast one Supplier Mapping is required!!!'
    );
    
  }
  getAllSubsidiaryReloadList()
  {
    this.TemplateMapping=new TemplateMapping();
    this.TemplateMapping.templateSuppliers=[];
    this.SubsideryObject=[];
    this.Vendorlist=[];
    this.GetSubsideryList();
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
  
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;
      default:
        break;
    }
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  LoadHistory() {
      this.httpService
        .GetById(`/setup-ws/template/get/history?templateId=${this.TemplateMappingId}&pageSize=200`,
        this.TemplateMappingId,this.RetloginDetails.token
        )
        .subscribe((res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
          this.HistoryList = res;
        }
        });
      }
  
}
