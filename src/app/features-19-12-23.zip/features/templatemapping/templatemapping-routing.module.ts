import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {  TemplateMappingListComponent } from './template-mapping-list/template-mapping-list.component';
import {  TemplateMappingAddEditComponent } from './template-mapping-add-edit/template-mapping-add-edit.component';
const routes: Routes = [
  {
    path: '',
    component: TemplateMappingListComponent,
  },
  {
    path: 'list',
    component: TemplateMappingListComponent,
  },
  {
    path: 'action/:action/:id',
    component: TemplateMappingAddEditComponent,
  },
  {
    path: 'action/:action',
    component: TemplateMappingAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TemplatemappingRoutingModule { }
