import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { TemplateMapping,templateSuppliers,BaseSearch,BaseSearchPdf} from '../Model/template-mapping-model';
//import { BaseSearch } from '../../supplier/model/supplier-model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-template-mapping-list',
  templateUrl: './template-mapping-list.component.html',
  styleUrls: ['./template-mapping-list.component.scss']
})
export class TemplateMappingListComponent implements OnInit {
  Subsidiarylist: any[] = [];
  columns: any[];
  exportColumns: any[];
  newevent:any;
  TemplateMappinglist: TemplateMapping[] = [];
  selectedTemplateMapping: TemplateMapping = new TemplateMapping();
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  TMPrint: any[] = [];
  baseSearch: BaseSearch = new BaseSearch();
  TemplateMapping: TemplateMapping = new TemplateMapping();
  SubsideryObject:any[]=[];
  showloader:boolean=false;
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   // For Role Base Access
   RetloginDetails: any;
   RetRoleDetails:any;
   SubIdList:any=[];

  constructor(private routeStateService: RouteStateService,
    private router: Router,  private toastService: ToastService,
    private HttpService: CommonHttpService) { }
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
    {
      if(role_Dtls[0].rolePermissions[i].accessPoint == "Invoice Template")
      {
        this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
        this.isEditable=role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable=role_Dtls[0].rolePermissions[i].view;
      }
    }
    // End For Role Base Access
    //this.resetBaseSearch();
    this.GetAllSubsidiaryList();
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
      { field: 'Id', header: 'Internal ID' },
      { field: 'Template Name', header: 'Template Name' },
     ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }
  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.TEMPLATEMAPPING_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.DESCENDING;
    this.loadTemplateMapping(this.newevent);
  }
  GetAllSubsidiaryList(){
    this.SubsideryObject=[];
    if(this.RetloginDetails.userType=='SUPERADMIN')
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.SubsideryObject=res;
        for(let x=0;x<this.SubsideryObject.length;x++)
       { 
        this.SubIdList.push(this.SubsideryObject[x].id);
      }
      }
      },
      (error) => {
        alert(error);
       },
       () => {
        if(localStorage.getItem("TMFilters") != null)
        {const LocDetails:any =localStorage.getItem("TMFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.TemplateMapping.subsidiaryId=searcheData.filters.subsidiaryId[0];
        this.loadTemplateMapping(this.newevent);
        localStorage.removeItem("TMFilters");
        }
        else
       { this.resetBaseSearch();}
      }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.SubsideryObject.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.TemplateMapping.subsidiaryId=this.RetRoleDetails[0].subsidiaryId
      if(localStorage.getItem("TMFilters") != null)
      {const LocDetails:any =localStorage.getItem("TMFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.TemplateMapping.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.loadTemplateMapping(this.newevent);
      localStorage.removeItem("TMFilters");
      }
      else
     { this.resetBaseSearch();}
    }
   
    // this.HttpService.GetAll("/setup-ws/subsidiary/get/all", this.RetloginDetails.token)
    // .subscribe(res => {
    //   if(res.status == 401)
    //    { this.showAlert("Unauthorized Access !");
    //      this.router.navigate(['/login']);
    //    }
    //    else if(res.status == 404)
    //    { this.showAlert("Wrong/Invalid Token!");
    //       this.router.navigate(['/login']);
    //     }
    //     else
    //  { this.Subsidiarylist=res.list;}
    //   });
   }
   navigateToAddViewEdit(
    action: string,
    selectedTemplateMapping: TemplateMapping = new TemplateMapping()
  ) {
    let TemplateMappingId = null;
    if (selectedTemplateMapping?.templateNo) {
      TemplateMappingId = selectedTemplateMapping.templateNo;
      this.router.navigate(['/main/template-mapping/action', action, TemplateMappingId]);
    } else {
      this.router.navigate(['/main/template-mapping/action', action]);
    }
   }
  findby(event: any){
    let subsidyList:any=[];
    subsidyList.push(this.TemplateMapping.subsidiaryId); 

    this.baseSearch.filters={
      subsidiaryId:subsidyList//this.TemplateMapping.subsidiaryId,
  }
     this.baseSearch.pageNumber=-1;
    this.loadTemplateMapping(this.newevent);
  }
  loadTemplateMapping(event: any) {
    try {
      this.newevent=event
      this.loading = true;
     this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
      // this.baseSearch.sortColumn = event.sortField
      //   ? 'p.' + event.sortField
      //   : GlobalConstants.PROJECT_TABLE_SORT_COLUMN;
        this.baseSearch.sortColumn = event.sortField
        ?  event.sortField
        : GlobalConstants.TEMPLATEMAPPING_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
          if(this.SubIdList.length==0)
          {
           return;
          }
       this.HttpService.Insert('/setup-ws/template/get/all-pagination', this.baseSearch, this.RetloginDetails.token).subscribe(
        //this.HttpService.GetAll("/template/get/all-pagination").subscribe(
        (res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else if (res) {
            this.TemplateMappinglist = res.list;
            // if(this.baseSearch.filters && (Object.keys(this.baseSearch.filters).length === 0)){
            //   this.projectnamelist = res.list;
            //   }
         this.totalRecords = res.totalRecords;
          } else {
            this.TemplateMappinglist = [];
          }
          this.loading = false;
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {
     }
  }
 /* exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.TemplateMappinglist);
            doc.save('TemplateMapping.pdf');
        })
    })
  }*/
  GetSubsideryList() {
  this.HttpService.GetAll('/setup-ws/subsidiary/get/all', this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
      else {this.SubsideryObject=res.list;}
    },
    (error) => {
     }
  );
  }
  Reset()
  {
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.TemplateMapping.subsidiaryId =0;
    }
    
    this.resetBaseSearch()
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("TMFilters") != null)
    {
      localStorage.removeItem("TMFilters");
    }
    localStorage.setItem("TMFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/template-mapping/action', actionType, mainId]);
   }

      /***((Export Excel)) */
      generatePDFData(exportType:any){
        this.newevent = event;
        this.baseSearchPdf.pageSize = this.totalRecords;
        this.baseSearchPdf.sortColumn =GlobalConstants.TEMPLATEMAPPING_TABLE_SORT_COLUMN;
        this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
    
        this.HttpService.Insert('/setup-ws/template/get/all-pagination', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
          (res) => {
            //For Auth
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
              //this.employeelistPrint = [];
              this.TMPrint = [];
              if (res && res.list.length > 0) {
                var RetData = res.list;
                for (let i = 0; i < RetData.length; i++) {

                  if (RetData[i].id == undefined) {
                    RetData[i].id = "";
                  }
                  if(exportType == 'PDF'){ 
                  
                    this.TMPrint.push({
                      'Id': RetData[i].id,    
                      'Template Name':RetData[i].templateName, 
                                        
                  });
                }
                  else{
                    this.TMPrint.push({
                      'Internal Id': RetData[i].id,    
                      'Template Name':RetData[i].templateName, 
                    });
                  }
    
                }
              }
              if(exportType == 'PDF')
              {this.exportPdf();}
            }
          }
        );
      }
      exportPdf() {
        import("jspdf").then(jsPDF => {
          import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            //this.= this.employeeExport;
            //this.employeelist=[];
            (doc as any).autoTable(this.exportColumns, this.TMPrint);
            doc.save('template-mapping.pdf');
          })
        })
      }
    
    //End PDF
    
    //Start Excel
    exportExcel() {
      this.showloader=true
      this.generatePDFData('');
    
     setTimeout(() => {
      this.exportExcelData()
     }, 250);
      }
      exportExcelData()
      {
        if(this.TMPrint.length >0)
        { import('xlsx').then((xlsx) => {
             const worksheet = xlsx.utils.json_to_sheet(this.TMPrint);
             const workbook = { 
                 Sheets: { data: worksheet }, 
                 SheetNames: ['data'] 
             };
             const excelBuffer: any = xlsx.write(workbook, {
                 bookType: 'csv',
                 type: 'array',
             });
             this.saveAsExcelFile(excelBuffer, 'template-mapping');
             this.showloader=false;
         });}
      }
    
      saveAsExcelFile(buffer: any, fileName: string): void {
          let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
          let EXCEL_EXTENSION = '.csv';
          const data: Blob = new Blob([buffer], {
              type: EXCEL_TYPE,
          });
          FileSaver.saveAs(
              data, fileName + EXCEL_EXTENSION
              //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
          );
      }
    //End Excel 
      //List Export option End
    
       /********Export excel */


}
