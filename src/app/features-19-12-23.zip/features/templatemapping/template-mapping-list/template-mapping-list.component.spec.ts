import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateMappingListComponent } from './template-mapping-list.component';

describe('TemplateMappingListComponent', () => {
  let component: TemplateMappingListComponent;
  let fixture: ComponentFixture<TemplateMappingListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TemplateMappingListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TemplateMappingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
