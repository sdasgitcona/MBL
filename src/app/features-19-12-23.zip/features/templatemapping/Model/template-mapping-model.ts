export class TemplateMapping {
    templateId:number;
    templateNo: string;
    templateName: string;
    subsidiaryId: number;
    invoiceNo: string;
    invoiceDate: Date;
    poNo: string;
    item: string;
    description: string;
    slNo: string;
    uom: string;
    unitPrice: string;
    billQty: string;
    discount: string;
    netAmount: string;
    templateSuppliers:templateSuppliers[]=[];
    createdBy:any;
    lastModifiedBy:any;
}

export class templateSuppliers{
    supplierId?:any;
    supplierEmail?:any;
    deleted?: boolean;
    templateSupplierId?:number;
    isSupplierDisabled: boolean;
}

export class BaseSearch {
    filters: TemplateFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }
  
  //this class holds the custom filter values at component level.
  export class TemplateFilter {
    subsidiary: string = '';
    vendorname: string = '';
    vendornumber: string = '';
    vendortype: string = '';
    pan: string = '';
    active: string = '';
    subsidiaryId:number;
  }

    // Base seach model for Supplier
    export class BaseSearchPdf {
      filters: TemplateMappingFilter | {} = {};
      pageNumber: number = 0;
      pageSize: number = 0;
      sortColumn: string = '';
      sortOrder: string = '';
    }
  
  //this class holds the custom filter values at component level.
  export class TemplateMappingFilter {
    subsidiary: string = '';
    vendorname: string = '';
    vendornumber: string = '';
    vendortype: string = '';
    pan: string = '';
    active: string = '';
  }
  