import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { AccountCodeModule, accountSubsidiaries, accountDepartments, accountCostCenters, BaseSearch, accountLocations, TblFilter } from '../model/accountcode-model';
import { PrimeNGConfig } from 'primeng/api';
import { locations } from 'src/app/features/locationmaster/model/locationmaster-model';

declare let $: any;
import { FormGroup, FormControl, FormArray } from '@angular/forms'
import { TRISTATECHECKBOX_VALUE_ACCESSOR } from 'primeng/tristatecheckbox';
@Component({
  selector: 'app-accountcode-add-edit',
  templateUrl: './accountcode-add-edit.component.html',
  styleUrls: ['./accountcode-add-edit.component.scss']
})
export class AccountcodeAddEditComponent implements OnInit {
  FormDetails = new FormGroup({
    selectedSubsidiary: new FormControl(),
    rollno: new FormControl()
  });
  viewMode: boolean = false;
  addMode: boolean = false;
  OnlyaddMode: boolean = false;
  editMode: boolean = false;
  dissubsidiary: boolean = false;
  EnableMode: boolean = false;
  SpecificDisabled: boolean = false;
  hideCurrency: boolean = false;
  private subscription: any;
  AccountTypeOptions: any;
  DepartmentOptionslist: any;
  CostCenterOptionslist: any;
  Subsidiarylist: any[] = [];
  accountcodeId: number = 0;
  AccountCodeData: AccountCodeModule = new AccountCodeModule();
  lstCurrencyList: any[];
  lstParentList: any[];
  lstTDSlist: any[];
  taxTdsDropdown: boolean;
  taxDropdown: boolean;
  HistoryList: HistoryModel[] = [];
  subOptions: accountSubsidiaries[] = [];
  subsidiriesCopy: accountSubsidiaries[] = [];
  subsidiaryOptions: accountSubsidiaries[] = [];
  Jointsubsidiries: any;
  JointDepartments: any;
  JointLocations: any;
  departmentOptionsCopy: accountDepartments[] = [];
  locationslist: accountLocations[] = [];
  locationOptionsCopy: accountLocations[] = [];
  IsBankVisible: boolean = false;
  ClsRequired: String;
  showloader: boolean = false;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  isviewEditable: boolean = true;
  isvisibleactive:boolean=true;
  isvisibleinactive:boolean=true;
  // For Role Base Access
  RetRoleDetails:any;
  RetloginDetails: any;

  constructor(private HttpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,) {
    this.AccountTypeOptions = [
      { name: 'Assets', code: 'Assets' },
      { name: 'Liability', code: 'Liability' },
      { name: 'Expense', code: 'Expense' },
      { name: 'Income', code: 'Income' },
      { name: 'Bank', code: 'Bank' },
    ];
    this.DepartmentOptionslist = [
      { departmentName: 'HR', departmentId: 1 },
      { departmentName: 'Admin', departmentId: 2 },
      { departmentName: 'Finance', departmentId: 3 },
      { departmentName: 'Purchase', departmentId: 4 },
    ];
    this.CostCenterOptionslist = [
      { costCenterNM: 'NetSuite', costCenter: 'NetSuite' },
      { costCenterNM: 'EBS', costCenter: 'EBS' },
      { costCenterNM: 'SAP', costCenter: 'SAP' }
    ];
    this.lstTDSlist = [
      { taxType: 'VAT', id: 1 },
      { taxType: 'TDS', id: 2 }
    ];
  }

  ngOnInit(): void {
    debugger
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Account Code") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
        if (this.isEditable == false)
          this.isviewEditable = false;
      }
    }
    // End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      async (params) => {
        if (params) {
          this.assignMode(params['action']);
          setTimeout(() => this.GetAllSubsidiaryList(), 200);
          if (params['id']) {
            this.accountcodeId = +params['id']; // (+) converts string 'id' to a number
            this.GetAccountcodebyId();
            this.LoadHistory();
          }

          this.All_CurrencyList();
          this.AccountCodeData.systemId=this.RetRoleDetails[0].accountId;

        } else {

        }
      },
      (error) => {

      }
    );
    this.changeswitch();
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        this.OnlyaddMode = true;
        this.hideCurrency = true;
        this.ClsRequired = "required";
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.OnlyaddMode = false;
        this.hideCurrency = false;
        this.ClsRequired = "required";
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.OnlyaddMode = false;
        this.hideCurrency = false;
        this.ClsRequired = "";
        break;

      default:
        break;
    }
  }
  GetAllSubsidiaryList_old() {
    this.HttpService.GetAll("/setup-ws/subsidiary/get/all", this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          this.Subsidiarylist = [];
          res.list.map((x: any, i: any) => {
            this.Subsidiarylist.push({ "subsidiaryId": x.id, "subsidiaryName": x.name })
          });
          //this.Subsidiarylist=res.list;
          if (this.editMode == true) {
            this.OnLoadParentLocationBySubsidiaryId();
            setTimeout(() => this.GetAccountcodebyId(), 200);
          }
        }
      });
  }
  GetAllSubsidiaryList() {
    this.Subsidiarylist=[];
    //this.RetloginDetails.userType='ENDUSER';
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { 
        //this.Subsidiarylist=res;
        res.map((x: any, i: any) => {
          this.Subsidiarylist.push({ "subsidiaryId": x.id, "subsidiaryName": x.name })
        });
        
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
      
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
     
      this.Subsidiarylist.push({
        "subsidiaryId":this.RetRoleDetails[0].subsidiaryId,
         "subsidiaryName":this.RetRoleDetails[0].subsidiaryName
      });
     
    }
    if (this.editMode == true) {
      this.OnLoadParentLocationBySubsidiaryId();
      setTimeout(() => this.GetAccountcodebyId(), 200);
    }
  }
  GetAccountcodebyId() {
   
    this.AccountCodeData.accountDepartments = [];
    this.HttpService
      .GetById('/masters-ws/account/get?id=' + this.accountcodeId, this.accountcodeId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          this.AccountCodeData = res;
          this.AccountCodeData.inactive = this.AccountCodeData.inactive ? false : true;
          this.AccountCodeData.activeDate = this.AccountCodeData.activeDate ? new Date(this.AccountCodeData.activeDate) : this.AccountCodeData.activeDate;
          this.AccountCodeData.inactiveDate = this.AccountCodeData.inactiveDate ? new Date(this.AccountCodeData.inactiveDate) : this.AccountCodeData.inactiveDate;
          this.changeswitch();
          if (this.AccountCodeData.type == "Bank") {
            this.dissubsidiary = true;
            this.IsBankVisible = true;
          }
          else {
            this.dissubsidiary = false;
            this.IsBankVisible = false;
          }
          //--Subsidiary
          if (
            this.AccountCodeData.accountSubsidiaries &&
            this.AccountCodeData.accountSubsidiaries.length > 0) {
            if (this.EnableMode) {
              var Subsidrylist = this.AccountCodeData.accountSubsidiaries.map(
                (x) => x.subsidiaryId
              );
              this.Jointsubsidiries = Subsidrylist.join(',');
            } else {
              let copiedValue = JSON.parse(
                JSON.stringify(this.AccountCodeData.accountSubsidiaries)
              );
              //this.role.restrictedDepartments = [];
              this.subsidiriesCopy = []//this.AccountCodeData.accountSubsidiaries;
              copiedValue.forEach(async (element: any) => {

                let item = this.Subsidiarylist.find(
                  (o) => o.subsidiaryId == element.subsidiaryId
                );
                if (item) {
                  let data = new accountSubsidiaries();
                  data.subsidiaryId = item.subsidiaryId;
                  data.subsidiaryName = item.subsidiaryName;
                  this.subsidiriesCopy?.push(data);
                }
              });
            }
          }
          else {
            this.subsidiriesCopy = [];
          }

          //--Department
          if (
            this.AccountCodeData.accountDepartments &&
            this.AccountCodeData.accountDepartments.length > 0) {
            if (this.EnableMode) {
              var departmentlist = this.AccountCodeData.accountDepartments.map(
                (x) => x.departmentId
              );
              this.JointDepartments = departmentlist.join(',');
            } else {
              let copiedValue = JSON.parse(
                JSON.stringify(this.AccountCodeData.accountDepartments)
              );
              //this.role.restrictedDepartments = [];
              this.departmentOptionsCopy = []//this.AccountCodeData.accountSubsidiaries;

              copiedValue.forEach((element: any) => {
                let item = this.DepartmentOptionslist.find(
                  (o: any) => o.departmentId == element.departmentId
                );
                if (item) {
                  this.departmentOptionsCopy?.push({
                    departmentId: item.departmentId,
                    departmentName: item.departmentName
                    //disabled:true
                  });
                }
              });
            }
          }
          else {
            this.departmentOptionsCopy = [];
          }

          //--Location
          if (
            this.AccountCodeData.accountLocations &&
            this.AccountCodeData.accountLocations.length > 0) {
            if (this.EnableMode) {
              var loclist = this.AccountCodeData.accountLocations.map(
                (x) => x.locationId
              );
              this.JointLocations = loclist.join(',');
            } else {
              let copiedValue = JSON.parse(
                JSON.stringify(this.AccountCodeData.accountLocations)
              );
              //this.role.restrictedDepartments = [];
              this.locationOptionsCopy = []//this.AccountCodeData.accountSubsidiaries;

              copiedValue.forEach((element: any) => {
                let item = this.locationslist.find(
                  (o: any) => o.locationId == element.locationId
                );
                if (item) {
                  let data = new accountLocations();
                  data.locationId = item.locationId;
                  data.locationName = item.locationName
                  this.locationOptionsCopy?.push(data);
                }
              });
            }
          }
          else {
            this.locationOptionsCopy = [];
          }


          //this.AccountCodeData.accountSubsidiariesList=this.AccountCodeData.accountSubsidiaries.map(c => c.subsidiaryId);
          //this.AccountCodeData.accountDepartmentsList=this.AccountCodeData.accountDepartments.map(d =>d.departmentId);
          //this.AccountCodeData.accountCostCentersList=this.AccountCodeData.accountCostCenters.map(b => b.costCenter);
          if (!this.viewMode) {
            if (this.AccountCodeData.tdsTaxCode != "") {
              this.taxTdsDropdown = false;
              this.taxDropdown = true;
            }
            else if (this.AccountCodeData.taxCode != "") {
              this.taxTdsDropdown = true;
              this.taxDropdown = false;
            }
          }
          else {
            this.taxTdsDropdown = true;
            this.taxDropdown = true;
          }
        }

      });
  }
  SaveAccountCodeMaster() {
    this.showloader = true;

    if (this.AccountCodeData.code == undefined || this.AccountCodeData.code == null) {
      this.showAlert('Please enter Account Code !');
      this.showloader = false;
      return false;
    }
    else if (this.AccountCodeData.description == undefined || this.AccountCodeData.description == "") {
      this.showAlert('Please enter Account Description !');
      this.showloader = false;
      return false;
    }
    else if (this.AccountCodeData.type == undefined || this.AccountCodeData.type == "") {
      this.showAlert('Please select Account Type !');
      this.showloader = false;
      return false;
    }

    if ((this.AccountCodeData.type == 'Bank' && this.AccountCodeData.currency == undefined)) {
      this.showAlert('Currency is mandatory for Account Type- Bank');
      this.showloader = false;
      return false;
    }

    if(this.AccountCodeData.inactive)
    {
      if (this.AccountCodeData.activeDate == undefined || this.AccountCodeData.activeDate == "" || JSON.stringify(this.AccountCodeData.activeDate) === '{}') {
        this.showAlert('Please input Active Date !');
        this.AccountCodeData.activeDate={};
        this.showloader = false;
        return false;
      }
    }
    else
    {
      if (this.AccountCodeData.inactiveDate == undefined || this.AccountCodeData.inactiveDate == "" || JSON.stringify(this.AccountCodeData.inactiveDate) === '{}') {
        this.showAlert('Please input Inactive Date !');
        this.AccountCodeData.inactiveDate={};
        this.showloader = false;
        return false;
      }
    }


    //--Save For Subsidiries
    if (this.subsidiriesCopy.length > 0) {
      var output = this.AccountCodeData.accountSubsidiaries.filter(
        (val: any, i: any) => {
          var t = !this.subsidiriesCopy.find((NewArrayobj: any) => NewArrayobj.subsidiaryId == val.subsidiaryId)

          if (t == false) {
            val.deleted = false;
          } else {
            val.deleted = true;
            if (!val.id) {
              this.AccountCodeData.accountSubsidiaries.splice(i, 1);
            }
          }
        }
      );
      var output1 = this.subsidiriesCopy.filter(
        (val: any) => !this.AccountCodeData.accountSubsidiaries.find((myArrayobj: any) => myArrayobj.subsidiaryId == val.subsidiaryId));

      output1.map((x: any) => {
        this.AccountCodeData.accountSubsidiaries.push({ subsidiaryId: x.subsidiaryId, subsidiaryName: x.subsidiaryName })
      })
    }
    else {
      this.subsidiriesCopy.map((x, i) => {
        this.AccountCodeData.accountSubsidiaries.push({ subsidiaryId: x.subsidiaryId, subsidiaryName: x.subsidiaryName })
      })
    }

    if (this.AccountCodeData.accountSubsidiaries.length == 0) {
      this.showAlert('Please select Subsidiary');
      this.showloader = false;
      return false;
    }
    if (this.AccountCodeData.type == 'Bank' && this.AccountCodeData.accountSubsidiaries.length > 1) {
      this.showAlert('Bank Account Type  must be restricted to a single Subsidiary');
      this.showloader = false;
      return false;
    }

    //--Save For  Departments
    if (this.departmentOptionsCopy.length > 0) {
      this.AccountCodeData.accountDepartments.filter(
        (val: any, i: any) => {
          var t = !this.departmentOptionsCopy.find((NewArrayobj: any) => NewArrayobj.departmentId == val.departmentId)

          if (t == false) {
            val.deleted = false;
          } else {
            val.deleted = true;
            if (!val.id) {
              this.AccountCodeData.accountDepartments.splice(i, 1);
            }
          }
        }
      );
      var output2 = this.departmentOptionsCopy.filter(
        (val: any) => !this.AccountCodeData.accountDepartments.find((myArrayobj: any) => myArrayobj.departmentId == val.departmentId));

      output2.map((x: any) => {
        this.AccountCodeData.accountDepartments.push({ departmentId: x.departmentId, departmentName: x.departmentName })
      })
    }
    else {
      this.departmentOptionsCopy.map((x, i) => {
        this.AccountCodeData.accountDepartments.push({ departmentId: x.departmentId, departmentName: x.departmentName })
      })
    }
    //--Save For  Cost Center
    if (this.locationOptionsCopy.length > 0) {
      this.AccountCodeData.accountLocations.filter(
        (val: any, i: any) => {
          var t = !this.locationOptionsCopy.find((NewArrayobj: any) => NewArrayobj.locationId == val.locationId)

          if (t == false) {
            val.deleted = false;
          } else {
            val.deleted = true;
            if (!val.locationId) {
              this.AccountCodeData.accountLocations.splice(i, 1);
            }
          }
        }
      );
      var output3 = this.locationOptionsCopy.filter(
        (val: any) => !this.AccountCodeData.accountLocations.find((myArrayobj: any) => myArrayobj.locationId == val.locationId));

      output3.map((x: any) => {
        this.AccountCodeData.accountLocations.push({ locationId: x.locationId, locationName: x.locationName })
      })
    }
    else {
      this.locationOptionsCopy.map((x, i) => {
        this.AccountCodeData.accountLocations.push({ locationId: x.locationId, locationName: x.locationName })
      })
    }

    // if(this.AccountCodeData.accountDepartmentsList &&this.AccountCodeData.accountDepartmentsList.length >0)
    // {
    // this.AccountCodeData.accountDepartments.splice(0);
    // this.DepartmentOptions.map((x:any,i:any) => {
    //   this.AccountCodeData.accountDepartmentsList.map((subList:any,i:any) => {
    //   if(x.departmentId == subList)
    //   {
    //     this.AccountCodeData.accountDepartments.push({"departmentId":x.departmentId,"departmentName":x.departmentName})
    //        }
    //     });
    //   });
    //  }

    //   if(this.AccountCodeData.accountCostCentersList && this.AccountCodeData.accountCostCentersList.length > 0)
    //   {
    //     this.AccountCodeData.accountCostCenters.splice(0);
    //     this.CostCenterOptions.map((x:any,i:any) => {
    //     this.AccountCodeData.accountCostCentersList.map((subList:any,i:any) => {
    //     if(x.costCenter == subList)
    //     {
    //       this.AccountCodeData.accountCostCenters.push({"costCenter":subList})
    //     }
    //    });
    //   } );
    //   }
    if (this.addMode) {
      this.AccountCodeData.createdBy = this.RetloginDetails.username; this.AccountCodeData.lastModifiedBy = this.RetloginDetails.username
    } else if (!this.addMode) {
      this.AccountCodeData.lastModifiedBy = this.RetloginDetails.username
    }
    this.AccountCodeData.inactive = this.AccountCodeData.inactive == true ? false : true;
    //this.AccountCodeData.systemId=this.RetRoleDetails[0].accountId;

    this.HttpService.Insert("/masters-ws/account/save", this.AccountCodeData, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          if (res != undefined && res.id > 0) {
            this.showloader = false;
            this.AccountCodeData = res;
            //this.saveAddress();
           
            this.showSuccess();

            
            if(this.addMode){
              this.router.navigate(['/main/accountcode/action', 'view',res.id]);
            } else {
              this.router.navigate(['/main/accountcode/list']);
            }
            
            //window.location.reload();
          }
          else {
            this.AccountCodeData.inactive = this.AccountCodeData.inactive == true ? false : true;
            this.showloader = false;
            this.showError();
          }
        }
      }, (error) => {
        this.AccountCodeData.inactive = this.AccountCodeData.inactive == true ? false : true;
        this.showloader = false;
        this.showAlert(error);
      },);
  }

  OnLoadParentLocationBySubsidiaryId() {
    let SubsidiaryList: any = [];
    this.locationslist = [];
    this.lstParentList = [];
    this.HttpService
      .GetById('/masters-ws/account/get?id=' + this.accountcodeId, this.accountcodeId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          for (let i = 0; i < res.accountSubsidiaries.length; i++) {
            SubsidiaryList.push(res.accountSubsidiaries[i].subsidiaryId);
          }

          //onload Location List
          this.HttpService.GetAll("/masters-ws/location/get-location-names?subsidiaryId=" + SubsidiaryList, this.RetloginDetails.token)
            .subscribe(res => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else {
                //Success:Do your code 
                res.map((x: any, i: any) => {
                  this.locationslist.push({ "locationId": x.id, "locationName": x.locationName })
                });

                //this.locationslist=res;
              }

            }, error => {

            },
              () => {
                // 'onCompleted' callback.
                // No errors, route to new page here
              });

          //Parent List
          this.HttpService.GetAll("/masters-ws/account/get-all-parents-by-subsidiary-id?subsidiaryId=" + SubsidiaryList, this.RetloginDetails.token)
            .subscribe(res => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else {
                //Success:Do your code 
                for (let i = 0; i < res.length; i++) {
                  if (res[i].inactive == false) {
                    this.lstParentList.push({
                      'id': res[i].id,
                      'code': res[i].code
                    });
                  }
                }
                // res.map((x: any, i: any) => {
                //   this.lstParentList.push({ "locationId": x.id, "locationName": x.locationName })
                // });
              }


            }, error => {

            },
              () => {
                // 'onCompleted' callback.
                // No errors, route to new page here
              });
        }


      });
  }
  getAllSubsidiaryReloadList() {
    this.subsidiriesCopy = [];
    this.locationslist = [];
    this.locationOptionsCopy = [];
    this.GetAllSubsidiaryList();
    this.ReloadParentList();
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  /* Start fetching History details */
  LoadHistory() {
    if (this.HistoryList.length == 0)
      this.HttpService
        .GetById(
          `/masters-ws/account/get/history?id=${this.accountcodeId}&pageSize=100`,
          this.accountcodeId, this.RetloginDetails.token
        )
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //Success:Do your code 
            this.HistoryList = res;

          }

        });
  }
  /* End fetching History details */

  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 0) {
      this.LoadHistory();
    }
  }
  lstTAX_list() {
    var obj = {
      filters: {
      },
      pageNumber: 0,
      pageSize: 200,
      sortColumn: "effectiveFrom",
      sortOrder: "asc"
    }
    this.HttpService.Insert("/setup-ws/tax-rate/get/all", obj, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          if (res != undefined) {
            this.lstTDSlist = res.list;

          }
          else {

          }
        }
      });
  }
  //Currency List
  All_CurrencyList() {
    this.HttpService.GetAll("/setup-ws/currency/get/all", this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          this.lstCurrencyList = res;
        }
      });
  }
  ReloadAll_CurrencyList() {
    this.AccountCodeData.currency = undefined;
    this.All_CurrencyList();
  }
  AllLocationList() {
    try {
      this.HttpService.GetAll('/masters-ws/location/get/all', this.RetloginDetails.token).subscribe(
        (res) => {
          res.map((x: any, i: any) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
              //Success:Do your code 
              this.locationslist.push({ "locationId": x.id, "locationName": x.locationName })

            }
          });
          // if (res && res.length > 0) {
          //   this.locationslist = res;
          // } else {
          //   this.locationslist = [];
          // }
        },
        (error) => {

        }
      );
    } catch (err) {

    }
  }
  getlocationbySubsidiaryId(SubsidiaryId: any) {
    let SubsidiaryList: any = [];
    this.locationslist = [];
    this.lstParentList = [];
    this.locationOptionsCopy = [];
    for (let i = 0; i < SubsidiaryId.value.length; i++) {
      SubsidiaryList.push(SubsidiaryId.value[i].subsidiaryId);
    }

    //Location List
    this.HttpService.GetAll("/masters-ws/location/get-location-names?subsidiaryId=" + SubsidiaryList, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code
          res.map((x: any, i: any) => {
            this.locationslist.push({ "locationId": x.id, "locationName": x.locationName })
          });

          //this.locationslist=res; 
        }

      }, error => {

      },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });

    //Parent List
    this.HttpService.GetAll("/masters-ws/account/get-all-parents-by-subsidiary-id?subsidiaryId=" + SubsidiaryList, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          for (let i = 0; i < res.length; i++) {
            if (res[i].inactive == false) {
              this.lstParentList.push({
                'id': res[i].id,
                'code': res[i].code
              });
            }
          }
          // res.map((x: any, i: any) => {
          //   this.lstParentList.push({ "locationId": x.id, "locationName": x.locationName })
          // });
        }

      }, error => {

      },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }

  //Account Parent List
  All_AccountParentList() {
    this.lstParentList = [];
    let SubsidiaryList: any = [];
    for (let i = 0; i < this.subsidiriesCopy.length; i++) {
      SubsidiaryList.push(this.subsidiriesCopy[i].subsidiaryId);
    }
    this.HttpService.GetAll("/masters-ws/account/get-all-parents-by-subsidiary-id?subsidiaryId=" + SubsidiaryList, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          for (let i = 0; i < res.length; i++) {
            if (res[i].inactive == false) {
              this.lstParentList.push({
                'id': res[i].id,
                'code': res[i].code
              });
            }
          }
          // res.map((x: any, i: any) => {
          //   this.lstParentList.push({ "locationId": x.id, "locationName": x.locationName })
          // });
        }
      }, error => {

      },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
    // this.HttpService.GetAll("/account/get-all-parents")
    //   .subscribe(res => {
    //     //this.lstParentList = res;
    //     for(let i=0; i<res.length;i++)
    //     {
    //       if(res[i].inactive == false){
    //       this.lstParentList.push({
    //         'id':res[i].id,
    //         'code':res[i].code
    //       });
    //     }
    //      }
    //   });
  }
  ReloadParentList() {
    this.AccountCodeData.parent = undefined;
    this.AccountCodeData.type = undefined;
    this.AccountCodeData.currency = undefined;
    this.hideCurrency = true;
    this.All_AccountParentList();
    this.SpecificDisabled = false;
  }
  ReloadLocationList() {
    this.locationOptionsCopy = [];
    this.ReloadlocationbySubsidiaryId(this.subsidiriesCopy);

  }
  ReloadlocationbySubsidiaryId(SubsidiaryId: any) {
    let SubsidiaryList: any = [];
    this.locationslist = [];
    for (let i = 0; i < SubsidiaryId.length; i++) {
      SubsidiaryList.push(SubsidiaryId[i].subsidiaryId);
    }
    this.HttpService.GetAll("/masters-ws/location/get-location-names?subsidiaryId=" + SubsidiaryList, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          res.map((x: any, i: any) => {
            this.locationslist.push({ "locationId": x.id, "locationName": x.locationName })
          });

          //this.locationslist=res;
        }

      }, error => {

      },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  EnabledAll() {
    this.taxTdsDropdown = false;
    this.taxDropdown = false;
    this.lstTAX_list();
    this.AccountCodeData.tdsTaxCode = "";
    this.AccountCodeData.taxCode = ""
  }
  EnabeledDisabledByType(data: string) {
    if (this.AccountCodeData.tdsTaxCode != "" && data == "tdstax") {
      this.taxTdsDropdown = false;
      this.taxDropdown = true;

    }
    else if (this.AccountCodeData.taxCode != "" && data == "tax") {
      this.taxTdsDropdown = true;
      this.taxDropdown = false;
    }
    else {
      this.taxTdsDropdown = false;
      this.taxDropdown = false;
      this.AccountCodeData.tdsTaxCode = "";
      this.AccountCodeData.taxCode = "";
    }
  }
  fnGetDetailsParentAccount() {
    if (this.AccountCodeData.parent != "") {
      this.HttpService.GetById('/masters-ws/account/get?id=' + this.AccountCodeData.parent,
        this.AccountCodeData.parent, this.RetloginDetails.token)
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //Success:Do your code 
            this.AccountCodeData.type = res.type;
            this.AccountCodeData.currency = res.currency
            if (this.AccountCodeData.type != "") {
              this.SpecificDisabled = true;
              this.fnOnchangeAccType();
            }
            if (this.AccountCodeData.currency != "") {
              this.SpecificDisabled = true;
              this.hideCurrency = false;
            }
          }
        });
    }
  }
  fnOnchangeAccType() {
    if (this.AccountCodeData.type == "Bank") {
      this.IsBankVisible = true;
      this.AccountCodeData.tdsTaxCode = undefined;
    }
    else {
      this.IsBankVisible = false;
    }
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Data Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving!'
    );
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  CancelData() {
    this.router.navigate(['/main/accountcode/list']);
   /* if (!this.editMode) {
      this.AccountCodeData = new AccountCodeModule();
      this.subsidiriesCopy = [];
      this.departmentOptionsCopy = [];
      this.locationOptionsCopy = [];
      this.getAllSubsidiaryReloadList();
    } else {
      this.router.navigate(['/main/accountcode/list']);
    }*/
  }

  changeswitch()
  {
    
   if(this.AccountCodeData.inactive)
   {
    this.isvisibleactive=false;
    this.isvisibleinactive=true;
   }
   else
   {
    this.isvisibleactive=true;
    this.isvisibleinactive=false;
   }
  }
}
