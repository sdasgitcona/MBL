import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountcodeAddEditComponent } from './accountcode-add-edit.component';

describe('AccountcodeAddEditComponent', () => {
  let component: AccountcodeAddEditComponent;
  let fixture: ComponentFixture<AccountcodeAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccountcodeAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccountcodeAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
