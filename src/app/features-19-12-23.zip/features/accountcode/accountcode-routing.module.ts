import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountcodeListComponent } from './accountcode-list/accountcode-list.component';
import { AccountcodeAddEditComponent } from './accountcode-add-edit/accountcode-add-edit.component';

const routes: Routes = [
  {
    path: 'list',
    component: AccountcodeListComponent,
  },
  {
    path: 'action/:action/:id',
    component: AccountcodeAddEditComponent,
  },
  {
    path: 'action/:action',
    component: AccountcodeAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountcodeRoutingModule { }
