import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { AccountCodeModule, accountSubsidiaries, accountDepartments, accountCostCenters, BaseSearch,SubIdList } from '../model/accountcode-model';
import { PrimeNGConfig } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import * as FileSaver from 'file-saver';
@Component({
  selector: 'app-accountcode-list',
  templateUrl: './accountcode-list.component.html',
  styleUrls: ['./accountcode-list.component.scss']
})
export class AccountcodeListComponent implements OnInit {
  Subsidiarylist: SubIdList[] = [];
  SubSidiarylist: AccountCodeModule[] = [];
  retAccountCodeData: AccountCodeModule[];
  AccountCodeDetails: AccountCodeModule = new AccountCodeModule();
  selectedList: AccountCodeModule = new AccountCodeModule();
  columns: any[];
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  newevent: any;
  AccountCodeList: any[];
  AccountTypeOptions: any;
  RetRoleDetails:any;
  SubIdList:any=[];
  subsidiarylist:any[]=[];
  _subsidiarylist:SubIdList[]=[];
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  // For Role Base Access
  isdisplaysub:boolean=false;
  isdisplayaccountId:boolean=false;

  RetloginDetails: any;
  dataToPrint: any[] = [];
  showloader:boolean;
  status:any;
  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private toastService: ToastService,
    private HttpService: CommonHttpService, private primengConfig: PrimeNGConfig) {
    
    this.status = [{id:'Active',value:'active'},{id:'Inactive',value:'inactive'}];
    this.AccountTypeOptions = [
      { name: 'Assets', code: 'Assets' },
      { name: 'Liability', code: 'Liability' },
      { name: 'Expense', code: 'Expense' },
      { name: 'Income', code: 'Income' },
      { name: 'Bank', code: 'Bank' },
    ];
  }

  ngOnInit(): void {

    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Account Code") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
      }
    }
    // End For Role Base Access

    this.GetAllSubsidiaryList();
    this.GetAllAccountCodeList();
    this.primengConfig.ripple = true;

    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
      { field: 'SL No', header: 'Internal ID' },
      { field: 'Subsidiary', header: 'Subsidiary' },
      { field: 'Account code', header: 'Account Code' },
      { field: 'Account Description', header: 'Account Description' },
      { field: 'Account Type', header: 'Account Type' },
      { field: 'Status', header: 'Status' }
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }
  //Account Code List
  GetAllAccountCodeList() {
    var obj = {
      filters: {
      },
      pageNumber: 0,
      pageSize: 200,
      sortColumn: "id",
      sortOrder: "desc"
    }
  
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.HttpService.GetAll("/masters-ws/account/get-account-by-system-id?systemId="+this.RetRoleDetails[0].accountId, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          this.AccountCodeList = res;
        }
      });

    }else if(this.RetloginDetails.userType='ENDUSER'){
      this.HttpService.GetAll("/masters-ws/account/get-account-by-subsidiaries?subId="+this.RetRoleDetails[0].subsidiaryId, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          this.AccountCodeList = res;
        }

      });


    }

  }
  //-Reload 
  getAccountCodeReload() {
    this.AccountCodeDetails.code = "";
    this.GetAllAccountCodeList();
  }
  GetAllSubsidiaryList_old() {
    this.HttpService.GetAll("/setup-ws/subsidiary/get/all", this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //Success:Do your code 
          this.Subsidiarylist = res.list;
        }

      });
  }

  GetAllSubsidiaryList() {
    this.Subsidiarylist=[];

    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {

      this.isdisplaysub=true;
      this.isdisplayaccountId=false;
      this.AccountCodeDetails.accountcode=this.RetRoleDetails[0].accountId;

      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { 
        this.Subsidiarylist=res;
      
        for(let x=0;x<this.Subsidiarylist.length;x++)
       { 
        this.SubIdList.push(this.Subsidiarylist[x].id);
        }
      }
      },
      (error) => {
        //alert(error);
       },
       ()=>{
        if(localStorage.getItem("AccountMasterFilters") != null)
        {const LocDetails:any =localStorage.getItem("AccountMasterFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.AccountCodeDetails.subsidiaryId=searcheData.filters.subsidiaryId[0];
        this.AccountCodeDetails.code=searcheData.filters.code;
        this.AccountCodeDetails.type=searcheData.filters.type;
        this.AccountCodeDetails.description=searcheData.filters.description;
        this.AccountCodeDetails.inactive=searcheData.filters.status=="ACTIVE"?true:false;//false ? "INACTIVE" : "ACTIVE"
        this.loadList(this.newevent);
        localStorage.removeItem("AccountMasterFilters");
        }
        else
        {this.resetBaseSearch();}
       //this.loadSuppliers('');
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.isdisplaysub=false;
      this.isdisplayaccountId=true;
      this.GetAllAccountCodeList();
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });

      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.AccountCodeDetails.subsidiaryId=this.RetRoleDetails[0].subsidiaryId
      if(localStorage.getItem("AccountMasterFilters") != null)
        {const LocDetails:any =localStorage.getItem("AccountMasterFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.AccountCodeDetails.subsidiaryId=searcheData.filters.subsidiaryId[0];
        this.AccountCodeDetails.code=searcheData.filters.code;
        this.AccountCodeDetails.type=searcheData.filters.type;
        this.AccountCodeDetails.description=searcheData.filters.description;
        this.AccountCodeDetails.inactive=searcheData.filters.status=="ACTIVE"?true:false;//false ? "INACTIVE" : "ACTIVE"
        this.loadList(this.newevent);
        localStorage.removeItem("AccountMasterFilters");
        }
      else {this.resetBaseSearch();}
    }
  }

  getAllSubsidiaryReloadList() {
    this._subsidiarylist=[];
    this.AccountCodeDetails.subsidiaryName = '';
    this.GetAllSubsidiaryList();
  }
  navigateToAddViewEdit(
    action: string,
    selectedList: AccountCodeModule = new AccountCodeModule()
  ) {
    let AccountCodeId = null;
    if (selectedList?.id) {
      AccountCodeId = selectedList.id;
      this.router.navigate(['/main/accountcode/action', action, AccountCodeId]);
    } else {
      this.router.navigate(['/main/accountcode/action', action]);
    }
  }
  loadList(event: any) {
    try {
      this.newevent = event
      this.loading = true;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      this.baseSearch.pageSize = event.rows;
      this.baseSearch.sortColumn = event.sortField
        ? event.sortField
        : GlobalConstants.ACCOUNTCODE_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
      this.HttpService.Insert('/masters-ws/account/get/all', this.baseSearch, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //Success:Do your code 
            if (res && res.list.length > 0) {
              this.retAccountCodeData = res.list;
              for (let i = 0; i < res.list.length; i++) {
                if (res.list[i].subsidiaryName != null && res.list[i].subsidiaryName.length > 15) {
                  //this.AccountCodeList[i].subsidiaryName=
                  this.retAccountCodeData[i].subsidiaryName = res.list[i].subsidiaryName.substring(0, 15) + "...";
                  this.retAccountCodeData[i].inactive;// = this.retAccountCodeData[i].inactive == true ? false : true;
                }
              }
              this.totalRecords = res.totalRecords;
              
            } else {
              this.retAccountCodeData = [];
              this.totalRecords = 0;
            }
            this.loading = false;
          }

        },
        (error) => {

          this.loading = false;
        }
      );
    } catch (err) {

    }
  }

  findby(event: any) {
    let subsidyList:any=[];
    for(let i=0;i<this.SubIdList.length;i++)
    {
     subsidyList.push(this.SubIdList[i]);
    }
    this.baseSearch.filters = {
      subsidiaryId:subsidyList,// this.AccountCodeDetails.subsidiaryName == undefined ? [] : this.AccountCodeDetails.subsidiaryName,
      code: this.AccountCodeDetails.code !== undefined ? this.AccountCodeDetails.code : "",
      type: this.AccountCodeDetails.type !== undefined ? this.AccountCodeDetails.type : "",
      status: this.AccountCodeDetails.inactive == false ? "INACTIVE" : "ACTIVE",
      description:this.AccountCodeDetails.description !== undefined ? this.AccountCodeDetails.description : ""
    }
    this.baseSearch.pageNumber=-1;
    this.loadList(this.newevent);
  }
  Reset() {
    this.AccountCodeDetails.subsidiaryName = "";
    this.AccountCodeDetails.code = undefined;
    this.AccountCodeDetails.type = undefined;
    this.AccountCodeDetails.description = "";
    this.findby("");
  }
  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.ACCOUNTCODE_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadList(this.newevent);
  }
  editview(actionType:any,mainId:any)
  {
   if (localStorage.getItem("AccountMasterFilters") != null)
   {
     localStorage.removeItem("AccountMasterFilters");
   }
   localStorage.setItem("AccountMasterFilters", JSON.stringify(this.baseSearch));
   this.router.navigate(['/main/accountcode/action', actionType, mainId]);
  }
  exportPdf() {
    import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
        const doc = new jsPDF.default();
        (doc as any).autoTable(this.exportColumns, this.dataToPrint);
        doc.save('AccountCode.pdf');
      })
    })
  }

  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Data Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving!'
    );
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');

   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.dataToPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.dataToPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'AccountCode');
           this.showloader=false;
       });}
    }
    generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearch.pageSize = this.totalRecords;
      this.baseSearch.sortColumn =GlobalConstants.ACCOUNTCODE_TABLE_SORT_COLUMN;
      this.baseSearch.filters = {subsidiaryId: this.SubIdList};

      this.HttpService.Insert('/masters-ws/account/get/all', this.baseSearch, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.dataToPrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {
                  if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){   
                  this.dataToPrint.push({
                    'SL No': i+1,    
                    'Subsidiary': RetData[i].subsidiaryName,
                    'Account code':RetData[i].code, 
                    'Account Description': RetData[i].description,
                    'Account Type': RetData[i].type,
                    'Status': RetData[i].inactive?"Inactive":"Active",
                });
              }
                else{
                  this.dataToPrint.push({
                    'SL No': i+1, 
                    'Subsidiary': RetData[i].subsidiaryName,    
                    'Account code':RetData[i].code, 
                    'Account Description': RetData[i].description,
                    'Account Type': RetData[i].type,
                    'Status': RetData[i].inactive?"Inactive":"Active",
                  });
                }

              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }

    saveAsExcelFile(buffer: any, fileName: string): void {
      let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
      let EXCEL_EXTENSION = '.csv';
      const data: Blob = new Blob([buffer], {
          type: EXCEL_TYPE,
      });
      FileSaver.saveAs(
          data, fileName + EXCEL_EXTENSION
          //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
      );
  }
  onRowSelect(event: any) {
    let accId = event.data.id;
    
    this.router.navigate(['/main/accountcode/action/view', accId]);
  }
}
