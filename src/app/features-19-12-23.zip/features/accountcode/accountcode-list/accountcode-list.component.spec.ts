import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountcodeListComponent } from './accountcode-list.component';

describe('AccountcodeListComponent', () => {
  let component: AccountcodeListComponent;
  let fixture: ComponentFixture<AccountcodeListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccountcodeListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccountcodeListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
