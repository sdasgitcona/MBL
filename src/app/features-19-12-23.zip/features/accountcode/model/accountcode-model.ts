export class AccountCodeModule {
    id:number;
    subsidiaryId: number;
    subsidiaryName:string;
    code?:string;
    description:string;
    type?:string;
    currency?:any;
    tdsTaxCode?:any;
    taxCode:string;
    restrictCostCentre:string;
    restrictDepartment:string;
    status:string;
    inactive:boolean=true;
   // Isactive?:boolean=true;
    accountSummary:boolean;
    parent?:string;
    accountDepartmentsId:any;
    accountSubsidiaries: accountSubsidiaries[] = [];
    accountDepartments: accountDepartments[] = [];
    accountCostCenters: accountCostCenters[] = [];
    accountLocations: accountLocations[] = [];
    accountDepartmentsList: any;
    accountCostCentersList: any;
    accountSubsidiariesList: any;
    integratedId?:any
    createdBy?:string;
    lastModifiedBy?:string;
    activeDate?:any;
    inactiveDate?:any;
    systemId?:any;
    accountcode?:any;
  }
  export class accountSubsidiaries{
    id?:number;
    accountId?:number;
    subsidiaryId?:number;
    subsidiaryName?:string;
    deleted?:boolean;
  }
  export class accountDepartments{
    departmentId?:number;
    departmentName?:string;
    deleted?:boolean;
    disabled?:boolean=true;
  }
  export class accountCostCenters{
    costCenter?:string;
  }
  export class accountLocations{
    locationId?:number;
    locationName?:string;
    deleted?:boolean;
  }
  export class BaseSearch {
    filters: TblFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }
  export class TblFilter {
    subsidiaryName: string = '';
    name: string = '';
    active: string = '';
  }

  export class SubIdList{
    id:number;
    name:string;
   
  }