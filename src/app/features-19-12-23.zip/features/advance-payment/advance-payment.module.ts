import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdvancePaymentRoutingModule } from './advance-payment-routing.module';
import { AdvancePaymentListComponent } from './advance-payment-list/advance-payment-list.component';
import { AdvancePaymentAddEditComponent } from './advance-payment-add-edit/advance-payment-add-edit.component';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { TabMenuModule } from 'primeng/tabmenu';
import { TabViewModule } from 'primeng/tabview';
import { SharedComponentsModule } from 'src/app/shared/shared-components/shared-components.module';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { MultiSelectModule } from 'primeng/multiselect';
import { DividerModule } from 'primeng/divider';
import { PasswordModule } from 'primeng/password';
import { TagModule } from 'primeng/tag';
import { FieldsetModule } from 'primeng/fieldset';
import { InputSwitchModule } from 'primeng/inputswitch';
import { CalendarModule } from 'primeng/calendar';
import {InputNumberModule} from 'primeng/inputnumber';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { AdvancePaymentApprovalComponent } from './advance-payment-approval/advance-payment-approval.component';
import { CardModule } from 'primeng/card';
import { OverlayPanelModule } from 'primeng/overlaypanel';

@NgModule({
  declarations: [
    AdvancePaymentListComponent,
    AdvancePaymentAddEditComponent,
    AdvancePaymentApprovalComponent
  ],
  imports: [
    CommonModule,
    AdvancePaymentRoutingModule,
    PanelModule,
    TableModule,
    TabMenuModule,
    TabViewModule,
    SharedComponentsModule,
    DialogModule,
    ButtonModule,
    DropdownModule,
    InputTextModule,
    FormsModule,
    CheckboxModule,
    ReactiveFormsModule,
    ToggleButtonModule,
    MultiSelectModule,
    
    DividerModule,
    PasswordModule,
    TagModule,
    FieldsetModule,
    InputSwitchModule,
    CalendarModule,
    InputNumberModule,
    ProgressSpinnerModule,
    CardModule,
    OverlayPanelModule,
  ]
})
export class AdvancePaymentModule { }
