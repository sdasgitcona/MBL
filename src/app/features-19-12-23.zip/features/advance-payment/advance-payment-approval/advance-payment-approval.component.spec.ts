import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvancePaymentApprovalComponent } from './advance-payment-approval.component';

describe('AdvancePaymentApprovalComponent', () => {
  let component: AdvancePaymentApprovalComponent;
  let fixture: ComponentFixture<AdvancePaymentApprovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvancePaymentApprovalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdvancePaymentApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
