import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdvancePaymentAddEditComponent } from './advance-payment-add-edit/advance-payment-add-edit.component';
import { AdvancePaymentListComponent } from './advance-payment-list/advance-payment-list.component';
import { AdvancePaymentApprovalComponent } from './advance-payment-approval/advance-payment-approval.component';

const routes: Routes = [
  {
    path: '',
    component: AdvancePaymentListComponent,
  },
  {
    path: 'list',
    component: AdvancePaymentListComponent,
  },
  {
    path: 'list/:status',
    component: AdvancePaymentListComponent,
  },
  {
    path: 'action/:action/:id/:chkid',
    component: AdvancePaymentAddEditComponent,
  },
  {
    path: 'action/:action',
    component: AdvancePaymentAddEditComponent,
  },
  {
    path: 'AP_Approval',
    component: AdvancePaymentApprovalComponent,
  },
  {
    path: 'AP_Approval/:status',
    component: AdvancePaymentApprovalComponent,
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdvancePaymentRoutingModule { }
