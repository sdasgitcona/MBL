import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvancePaymentAddEditComponent } from './advance-payment-add-edit.component';

describe('AdvancePaymentAddEditComponent', () => {
  let component: AdvancePaymentAddEditComponent;
  let fixture: ComponentFixture<AdvancePaymentAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvancePaymentAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdvancePaymentAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
