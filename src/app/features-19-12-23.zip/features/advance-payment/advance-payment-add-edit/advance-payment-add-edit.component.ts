import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { AddressComponent } from 'src/app/shared/shared-components/address/address.component';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { locations } from '../../locationmaster/model/locationmaster-model';
import { supplierCurrency } from '../../purchase-order/model/purchase-order-module';
import { Subsidiary } from '../../subsidiary/Model/subsidiary-model';
import { Account, SubsidiaryEntry, Supplier, SupplierAccess, SupplierAddress, SupplierContact } from '../../supplier/model/supplier-model';
import { advancedPayemnt, ApplyModel, Applied,paymentdetails } from '../model/advance-payment-model';
import { AdvancePaymentComponent } from '../../reports/advance-payment/advance-payment.component';
import { TotalHavingAccessSupplierComponent } from 'src/app/dashboard_features/vendor-master/indicators/total-having-access-supplier/total-having-access-supplier.component';
@Component({
  selector: 'app-advance-payment-add-edit',
  templateUrl: './advance-payment-add-edit.component.html',
  styleUrls: ['./advance-payment-add-edit.component.scss']
})
export class AdvancePaymentAddEditComponent implements OnInit {
  aPayemnt: advancedPayemnt = new advancedPayemnt();
  Subsidiarylist: any[] = [];
  aPayemntId: number = 0;
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  role: any;
  url:any;
  empID: number;
  addressData: any;
  displayAddressDialog: boolean = false;
  paymentdetails:paymentdetails[]=[];
  aPayemntHistoryList: HistoryModel[] = [];
  checked: boolean;
  currency: supplierCurrency[] = [] //[{ id?: number; name?: string; code?: string; }];  selectedIndex:any
  isReloadSub: boolean;
  status: any;
  department: any;
  subsidiary: Subsidiary = new Subsidiary();
  supplier: Supplier = new Supplier();
  supplierlist: Supplier[] = [];
  locationlist: locations[] = [];
  apply: ApplyModel[] = []
  applied: Applied[] = []
  markall: boolean;
  markallapplied: boolean;
  ifAvailPaymentAmount: boolean;
  disableMakePayment: boolean;
  unappliedAmountCopy: any;
  showloader: boolean = false;
  fiscalCalenderDTLS: any;
  ApprovalButtonShowHide: Number = 0;
  NotPaymentAmtAvailable: boolean;
  UnApplybuttonavailable: boolean = true;
  hideapply: boolean = false;
  hideunapply: boolean = true;
  invoiceIds: any[] = [];
  POList:any[]=[];
  chkId:any;
  Chktooltip:boolean=false;
  display: boolean = false;
  isviewapprovereject:boolean=false;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  isviewEditable: boolean = true;
  // For Role Base Access
  IsPaymentAmtAvailable: boolean;

  RetloginDetails: any;
  RetRoleDetails:any;
advPmtNo: any;
loginId:number;
appSequencelist:any[]=[];
isAppSequenceVisivble:boolean;
ProjectList:any[];

  constructor(
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
    private advPaymentReport: AdvancePaymentComponent,
  ) {
    this.status = ['Pending Approval', 'Approved', 'Draft', 'Close', 'Rejected', 'Partially Approved', 'Paid', 'Partially Paid', 'Partially Applied', 'Full Applied'];
    // this.departmentOld = ['HR', 'Finance', 'Admin'];
    /*this.department =
      [{ name: "Admin" },
      { name: "HR" },
      { name: "Finance" },
      { name: "Purchase" },
      { name: "Production" }
      ];*/
  }
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    const LoggerId = JSON.parse(LDetails);
    this.empID = LoggerId.employeeId;
    this.loginId= this.RetloginDetails.employeeId;
    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Advance Payment") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
        if (this.isEditable == false)
          this.isviewEditable = false;
      }
    }
    // End For Role Base Access
    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.aPayemntId = +params['id']; // (+) converts string 'id' to a number
            this.GetPaymentbyId();
          }
          if (params['chkid']) {
            this.chkId = +params['chkid'];
           }
          this.assignMode(params['action']);
          this.GetSubsideryList();
          if (this.addMode) {
            this.loadrequestor();
          }

        } else {
        }
      },
      (error) => {
      }
    );
  }

  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.addMode = false;
        this.viewMode = true;
        this.editMode = false;
        break;

      default:
        break;
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  /* start get Get Payment by id */
  GetPaymentbyId() {
    this.httpService
      .GetById('/finance-ws/advance/get?id=' + this.aPayemntId, this.aPayemntId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if(this.chkId==1)
          {
            this.isviewapprovereject=true;
          }
          this.appSequencelist=res.approvers;
          let nextApprover=res.nextApprover;
          let isNextApproverFound:Boolean=false;
          if(this.appSequencelist != null)
       {   for(let x=0;x<this.appSequencelist.length;x++)
          {
            let status='';
            if (this.appSequencelist[x].id == nextApprover)
            {
              isNextApproverFound=true;
              status='current';//this.appSequencelist[x]['status']=;
            }
            else
            {
              if(isNextApproverFound)
              {
                status='pending';
                //this.appSequencelist[x]['status']='pending';
              }else{
                status='approved';
                //this.appSequencelist[x]['status']='approved';
              }
            }
            this.appSequencelist[x]['status']=status;
          }}
          this.isviewEditable =  (res.status == 'Pending Approval' ||  res.status == "Partially Approved" || res.status == 'Approved') ?false:true;
          if (res.status == 'Pending Approval' || res.status == 'Applied' || res.status == 'Partially Applied' || res.status == 'Partially Approved' || res.status == 'Approved' || res.status == 'Closed' || res.status == 'Partially Paid' || res.status == 'Paid') //Send Approval Mode
          {
            this.ApprovalButtonShowHide = 0;

          }
          else {
            this.ApprovalButtonShowHide = 1;

          }

          if (res.status == "Draft" || res.status == "Partially Approved" || res.status == "Pending Approval") {
            this.disableMakePayment = true;
            this.NotPaymentAmtAvailable = true

          }
          else if (res.status == "Approved") {

            this.disableMakePayment = false;
            this.NotPaymentAmtAvailable = true
          }
          else if (res.status == "Partially Paid") {

            this.disableMakePayment = false;
            this.NotPaymentAmtAvailable = false
          }
          else if (res.status == "Paid") {

            this.disableMakePayment = true;
            this.NotPaymentAmtAvailable = false
          }
          else if (res.status == "Partially") {

            this.disableMakePayment = true;
            this.NotPaymentAmtAvailable = false
          }
          else if (res.status == "Applied") {

            this.disableMakePayment = true;
            this.NotPaymentAmtAvailable = true
          }
          else if (res.status == "Rejected") {

            this.disableMakePayment = true;
            this.NotPaymentAmtAvailable = true
          }

          this.aPayemnt = res;
          this.getpaymentdetailsforadvance();
          //this.aPayemnt.unappliedAmount=this.aPayemnt.unappliedAmount.toFixed(2);
          this.unappliedAmountCopy = this.aPayemnt.unappliedAmount.toFixed(2);
          this.aPayemnt.exchangeRate = this.aPayemnt.exchangeRate != null ? this.aPayemnt.exchangeRate.toFixed(2) : "";
          if (this.aPayemnt.paymentAmount) {
            this.ifAvailPaymentAmount = true;
          }
          if (this.aPayemnt.unappliedAmount < this.aPayemnt.paymentAmount) {
            this.disableMakePayment = true;
          }
          this.aPayemnt.prePaymentDate = this.aPayemnt.prePaymentDate == null ? '' : new Date(this.aPayemnt.prePaymentDate);
          this.GetPOList();
          this.GetPOList();
          this.GetSupplierList();
          this.GetLocationList()
          this.GetSupplierCurrencyList();
          this.GetApply()
          this.GetApplied();
          this.GetDepartmentList();
          this.GetAllProjectList(res.subsidiaryId)
          this.aPayemnt.unappliedAmount = this.aPayemnt.unappliedAmount.toFixed(2);
          if (Number(this.aPayemnt.advanceAmount) == Number(this.aPayemnt.paymentAmount)) {
            this.disableMakePayment = true;
            this.fnOnChangeCurrency();
          }
          if (this.aPayemnt.paymentAmount > 0) {
            this.IsPaymentAmtAvailable = true;
          }
          if (this.aPayemnt.paymentAmount == 0) {
            this.NotPaymentAmtAvailable = true;
          }
        }


      });
    
     
  }
  /* end get GetPayment by id */
  GetSubsideryList() {
    if(this.RetloginDetails.userType=='SUPERADMIN')
   // if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    //this.httpService.GetAll("/setup-ws/subsidiary/get/all", this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.Subsidiarylist = res;
          //this.SubsideryObject=res;
          this.isReloadSub = false;
        }
      },
      (error) => {
        this.isReloadSub = false;

      }
    );
    }
    else if(this.RetloginDetails.userType=='ENDUSER')
    { 
      this.Subsidiarylist.push({
        id:this.RetRoleDetails[0].subsidiaryId,
        name:this.RetRoleDetails[0].subsidiaryName
      });
   }
  }
  getSubsidiaryReloadList() { 
    this.Subsidiarylist=[];
    this.GetSubsideryList();
    this.aPayemnt.subsidiaryId = undefined;
    this.aPayemnt.supplierId = undefined;
    this.aPayemnt.locationId = undefined;
    this.supplierlist = [];
    this.locationlist = [];
    this.currency = [];
    this.aPayemnt.exchangeRate = undefined;
  }
  /* Start fetching History details */
  LoadHistory() {
    if (this.aPayemntHistoryList.length == 0)
      this.httpService
        .GetById(`/finance-ws/advance/get/history?payment=${this.aPayemnt.prePaymentNumber}&pageSize=100`,
          this.aPayemntId, this.RetloginDetails.token
        )
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.aPayemntHistoryList = res;
          }
        });
  }
  /* End fetching History details */

  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 0) {

      this.hideapply = false;
      this.hideunapply = true;


    }
    if (event.index == 1) {

      this.hideapply = true;
      this.hideunapply = false;
    }

    if (event.index == 2) {

      this.hideapply = true;
      this.hideunapply = true;
    }
    if (event.index == 4) {

      this.LoadHistory();
      this.hideapply = true;
      this.hideunapply = true;

    }
  }
  handleToggleEvent(event: any) {
    event.originalEvent.cancelBubble = true;
  }
  savePayment() {
    if (this.aPayemnt.subsidiaryId == undefined || this.aPayemnt.subsidiaryId == 0) {
      this.showAlert("Please select Subsidiary !");
      return false;
    }
    else if (this.aPayemnt.supplierId == undefined || this.aPayemnt.supplierId == 0) {
      this.showAlert("Please select Supplier !");
      return false;
    }
    else if (this.aPayemnt.proformaInvoice == undefined || this.aPayemnt.proformaInvoice == "") {
      this.showAlert("Please enter Proforma Invoice Number!");
      return false;
    }
    else if (this.aPayemnt.currency == undefined || this.aPayemnt.currency == "") {
      this.showAlert("Please select Currency !");
      return false;
    }
    else if (this.aPayemnt.exchangeRate == undefined || this.aPayemnt.exchangeRate == "") {
      this.showAlert("Please enter Exchange Rate !");
      return false;
    }
    else if (this.aPayemnt.advanceAmount == undefined || this.aPayemnt.advanceAmount == "") {
      this.showAlert("Please enter Advance Amount !");
      return false;
    }
    else if (this.aPayemnt.prePaymentDate == undefined) {
      this.showAlert("Please select PI Date !");
      return false;
    }
    var totalApplyAmount = 0;
    this.apply.map((data: any, index: any) => {
      totalApplyAmount += data.applyAmount ? data.applyAmount : 0;
    });

    if (this.aPayemnt.paymentAmount < totalApplyAmount) {
      this.toastService.addSingle(
        'error',
        'Error',
        'Summation of Apply Amount must be smaller than Payment Amount!'
      );
      return false;
    }
    if (totalApplyAmount > Number(this.unappliedAmountCopy)) {
      this.showAlert("Total Apply Amount cannot be greater than Unapplied Amount");
      return false;
    }

    let days: any = new Date(this.aPayemnt.prePaymentDate).getDate();
    let months: any = new Date(this.aPayemnt.prePaymentDate).getMonth() + 1;
    let year: any = new Date(this.aPayemnt.prePaymentDate).getFullYear();
    if (months < 10) {
      months = "0".toString() + months.toString();
    }
    if (days < 10) {
      days = "0".toString() + days.toString();
    }
    //this.aPayemnt.prePaymentDate=year+"-"+months+"-"+days;
    if (this.addMode) {
      this.aPayemnt.createdBy = this.RetloginDetails.username; this.aPayemnt.lastModifiedBy = this.RetloginDetails.username
    } else if (!this.addMode) {
      this.aPayemnt.lastModifiedBy = this.RetloginDetails.username
    }
    this.showloader = true;
    this.httpService.Insert('/finance-ws/advance/save', this.aPayemnt, this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res && res.id > 0) {
            this.showloader = false;
            this.showSuccess();
            if(this.addMode)
            {
              this.router.navigate(['/main/advance-payment/action', 'view',res.id,0]);
            }
            else{
            this.router.navigate(['/main/advance-payment/list']);
            }
          } else {
            this.showloader = false;
            this.showError();
          }
        }

      },
      (error) => {
        this.showloader = false;
        this.showAlert(error);
      },
      () => { }
    );
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Advance created successfully!'
    );
  }
  showSuccessvoid() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Advance payment Unapply successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Payment!'
    );
  }
  showErrorVoid() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while Unapply Advanced Payment!'
    );
  }
  clearPaymentData() {
    if (this.editMode) {
      this.router.navigate(['/main/advance-payment/list']);
    }
    else {
      this.aPayemnt = new advancedPayemnt();
      this.getSubsidiaryReloadList();
    }
  }
  checked2: boolean = true;
  // inactive:boolean = true;
  /* Start Reload subsidery */
  reloadSubidery() {
    //$('.refsubsidery').addClass('fa-spin');
    this.isReloadSub = true;

    this.aPayemnt.subsidiaryId = 0;
    this.GetSubsideryList();

  }
  /* End Reload subsidery */
  /* start get Get Subsidiary by Id */
  GetSubsidiarybyId() {
    this.httpService
      .GetById('/setup-ws/subsidiary/get?id=' + this.aPayemnt.subsidiaryId, this.aPayemnt.subsidiaryId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.subsidiary = res;
          this.aPayemnt.subsidiaryCurrency = this.subsidiary.currency;
        }

      });
  }
  /* end  get Get Subsidiary by Id */
  OnSubsidiaryChnage() {
    this.getRanges();
    this.GetSubsidiarybyId();
    this.GetSupplierList();
    this.GetLocationList();
    this.GetDepartmentList();
    this.GetAllProjectList(this.aPayemnt.subsidiaryId)
  }
  OnSupplierChange() {
    this.GetSupplierCurrencyList();
    this.GetPOList();
  }
  /* start get Get Supplier list */
  GetSupplierList() {
    this.httpService
      .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + this.aPayemnt.subsidiaryId, this.aPayemnt.subsidiaryId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.supplierlist = res;
          //this.isReloadSupplier=false;
        }
      });
  }
  getSupplierReloadList() {
    this.GetSupplierList();
    this.aPayemnt.supplierId = undefined;
    this.aPayemnt.currency = "";
    this.aPayemnt.exchangeRate = undefined;
    this.currency = [];
  }
  /* end get Get Supplier list */
  /* start get Get Supplier id */
  GetSupplierbyId() {
    this.httpService
      .GetById('/masters-ws/supplier/get?id=' + this.aPayemnt.supplierId, this.aPayemnt.supplierId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.supplier = res;
          //this.aPayemnt.paymentTerm=this.supplier.paymentTerm!;
          this.supplier.supplierSubsidiary.map((data: any) => {
            if (data.preferredCurrency) {
              this.aPayemnt.currency = data.supplierCurrency;
            }
          })
          //this.aPayemnt.currency=this.supplier.supplierSubsidiary.supplierCurrency!;
        }

      });
  }
  /* end get Get Supplier id */
  /* Start Fetch Currency list by supplier id from api */
  GetSupplierCurrencyList(): any {
    this.httpService.GetAll("/masters-ws/supplier/get-currency-by-supplier?supplierId=" + this.aPayemnt.supplierId, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            //var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            this.currency = [];
          } else {
            this.currency = res;
          }
        }
      },
        error => {
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  getCurrencyReloadList() {
    this.GetSupplierCurrencyList();
    this.aPayemnt.currency = "";
  }
  /* End Fetch Currency list by supplier id from api */
  /* Start Fetch Location list from api */
  GetLocationList() {
    this.httpService.GetAll("/masters-ws/location/get-parent-location-names?subsidiaryId=" + this.aPayemnt.subsidiaryId, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            // var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            this.locationlist = [];
          }
          else {
            this.locationlist = res;
          }
        }
      }, error => {
      },
        () => {
          //this.isReloadlocation=false;
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  getLocationReloadList() {
    this.GetLocationList();
    this.aPayemnt.locationId = 0;
  }
  /* End Fetch Location list from api */
  /* start get apply */
  GetApply() {
    this.httpService
      //.GetAll(`/invoice/get-invoice-by-supplier-and-subsidiary?subsidiaryId=${this.aPayemnt.subsidiaryId}&supplierId=${this.aPayemnt.supplierId}`)
      .GetAll(`/finance-ws/advance/get-invoice-by-supplier-and-subsidiary-and-currency?subsidiaryId=${this.aPayemnt.subsidiaryId}&supplierId=${this.aPayemnt.supplierId}&currency=${this.aPayemnt.currency}`, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.apply = res;
        }
      });
  }
  GetApplied() {
    this.applied = [];
    this.httpService
      //.GetAll(`/invoice/get-invoice-by-supplier-and-subsidiary?subsidiaryId=${this.aPayemnt.subsidiaryId}&supplierId=${this.aPayemnt.supplierId}`)
      .GetAll("/finance-ws/advance/get-advance-payment-apply?advanceId=" + this.aPayemntId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.status != 500) {
            this.applied = res;
            this.applied=this.applied.filter(x=>x.applyAmount!=0.00 && x.unapllied == false)
          }
        }
      });
  }
  /* end get apply */
  chkenable() {
    if (this.markall) {
      for (let i = 0; i < this.apply.length; i++) {
        this.apply[i].selected = true;
        //this.apply[i].paymentamtdisable=false;
      }
    }
    else {
      for (let i = 0; i < this.apply.length; i++) {
        this.apply[i].selected = false;
        this.aPayemnt.unappliedAmount = this.unappliedAmountCopy;
        this.apply[i].applyAmount = "";
        this.apply[i].applyDate = "";
        //this.apply[i].paymentamtdisable=true;
      }
    }
  }

  chkenableapplied() {
    if (this.markallapplied) {
      for (let i = 0; i < this.applied.length; i++) {
        this.applied[i].selected = true;
        this.UnApplybuttonavailable = false;
        //this.apply[i].paymentamtdisable=false;
      }
    }
    else {
      for (let i = 0; i < this.applied.length; i++) {
        this.applied[i].selected = false;
        this.UnApplybuttonavailable = true;

        //this.apply[i].paymentamtdisable=true;
      }
    }
  }
  onDisableUnapply(rowindex: number) {
    let isselected=(this.applied.filter(x=>x.selected==true));
    if (this.applied[rowindex].selected == true) {

      this.UnApplybuttonavailable = false;
    }
    else {
      if(isselected.length==0)
      {
        this.UnApplybuttonavailable = true;
      }
    }

  }

  onDisableChange(rowindex: number) {

    if (this.apply[rowindex].selected == false) {
      this.apply[rowindex].applyAmount = null;
      this.apply[rowindex].applyAmount = undefined;
      this.apply[rowindex].applyDate = "";

    }
    this.getdueamt(rowindex);
  }
  //Calculate header amount in respect of line
  getdueamt(rowindex: number) {
    if (this.apply[rowindex].applyAmount > this.apply[rowindex].amountDue) {
      this.apply[rowindex].applyAmount = null;
      this.apply[rowindex].applyAmount = undefined;
      this.showErrorAmount();
    }
    else {
      // if(this.apply[rowindex].applyAmount != "" || this.apply[rowindex].applyAmount != undefined)
      // {
      // this.apply[rowindex].applyAmount=0;
      // }
      this.apply[rowindex].applyAmount = this.apply[rowindex].applyAmount ? parseFloat(this.apply[rowindex].applyAmount).toFixed(2) : 0;
    }
    var totalApplyAmount = 0;
    this.apply.map((data: any, index: any) => {
      if (data.selected) {
        totalApplyAmount += data.applyAmount ? Number(data.applyAmount) : 0;
      }
    })
    if (totalApplyAmount != 0) {
      this.aPayemnt.unappliedAmount = this.unappliedAmountCopy ? (this.unappliedAmountCopy - totalApplyAmount).toFixed(2) : (this.unappliedAmountCopy - totalApplyAmount).toFixed(2);
    }
    else {
      this.aPayemnt.unappliedAmount = this.unappliedAmountCopy;
      this.apply[rowindex].applyAmount = null;
      this.apply[rowindex].applyAmount = undefined;
    }
    if (this.aPayemnt.paymentAmount < totalApplyAmount) {
      this.apply[rowindex].applyAmount = null;
      this.apply[rowindex].applyAmount = undefined;
      this.toastService.addSingle(
        'error',
        'Error',
        'Summation of Apply Amount must be smaller than Payment Amount!'
      );
      var totalApplyAmount = 0;
      this.apply[rowindex].applyAmount = "";
      this.apply.map((data: any, index: any) => {
        if (data.selected) {
          totalApplyAmount += data.applyAmount ? Number(data.applyAmount) : 0;
        }
      })
      this.aPayemnt.unappliedAmount = this.unappliedAmountCopy ? (this.unappliedAmountCopy - totalApplyAmount).toFixed(2) : (this.unappliedAmountCopy - totalApplyAmount).toFixed(2);
    }
  }
  calculateDueAmount(Event: any, rowindex: number) {
    if (Event.value != null) {
      this.apply[rowindex].applyAmount = Event.value;
      if (this.apply[rowindex].applyAmount > this.apply[rowindex].amountDue) {
        this.showErrorAmount();
        this.apply[rowindex].applyAmount = "0.00";
      }
      else {
        // if(this.apply[rowindex].applyAmount != "" || this.apply[rowindex].applyAmount != undefined)
        // {
        // this.apply[rowindex].applyAmount=0;
        // }
        this.apply[rowindex].applyAmount = this.apply[rowindex].applyAmount ? parseFloat(this.apply[rowindex].applyAmount).toFixed(2) : 0;
      }
      var totalApplyAmount = 0;
      this.apply.map((data: any, index: any) => {
        if (data.selected) {
          totalApplyAmount += data.applyAmount ? Number(data.applyAmount) : 0;
        }
      })
      if (totalApplyAmount != 0) {
        if (totalApplyAmount > Number(this.unappliedAmountCopy)) {
          totalApplyAmount = totalApplyAmount - Number(this.apply[rowindex].applyAmount);
          this.showAlert("Total Apply Amount cannot be greater than Unapplied Amount");
          this.aPayemnt.unappliedAmount = totalApplyAmount > 0 ? Number(this.unappliedAmountCopy) - totalApplyAmount : this.unappliedAmountCopy;
          this.apply[rowindex].applyAmount = null;
          //this.apply[rowindex].applyAmount=undefined;
        }
        else {
          this.aPayemnt.unappliedAmount = this.unappliedAmountCopy ? (this.unappliedAmountCopy - totalApplyAmount).toFixed(2) : (this.unappliedAmountCopy - totalApplyAmount).toFixed(2);
        }
      }
      else {
        this.aPayemnt.unappliedAmount = this.unappliedAmountCopy;
        this.apply[rowindex].applyAmount = "";
      }
      if (this.aPayemnt.paymentAmount < totalApplyAmount) {
        this.toastService.addSingle(
          'error',
          'Error',
          'Summation of Apply Amount must be smaller than Payment Amount!'
        );
        var totalApplyAmount = 0;
        this.apply[rowindex].applyAmount = "";
        this.apply.map((data: any, index: any) => {
          if (data.selected) {
            totalApplyAmount += data.applyAmount ? Number(data.applyAmount) : 0;
          }
        })
        this.aPayemnt.unappliedAmount = this.unappliedAmountCopy ? (this.unappliedAmountCopy - totalApplyAmount).toFixed(2) : (this.unappliedAmountCopy - totalApplyAmount).toFixed(2);

      }
    }
    else {
      var totalApplyAmount = 0;
      this.apply.map((data: any, index: any) => {
        if (data.selected) {
          totalApplyAmount += data.applyAmount ? Number(data.applyAmount) : 0;
        }
      })
      this.aPayemnt.unappliedAmount = totalApplyAmount > 0 ? Number(this.unappliedAmountCopy) - totalApplyAmount : this.unappliedAmountCopy;
      //this.aPayemnt.unappliedAmount=this.unappliedAmountCopy;
    }
  }

  showErrorAmount() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Apply Amount must be smaller than Due Amount!'
    );
  }
  CompareApplyDate(rowindex: number) {
    if (this.apply[rowindex].applyDate < new Date(this.apply[rowindex].invoiceDate)) {
      this.toastService.addSingle(
        'error',
        'Error',
        'Apply Date must be equal or greater than Invoice Date!'
      );
      this.apply[rowindex].applyDate = "";
    }


  }
  showErrorchlpaymentamt() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Payment amount must be greater than 0!'
    );
  }
  onApply() {
    //var object=[]; 
    this.aPayemnt.advancePaymentApply = [];
    var totalApplyAmount = 0;
    for (let i = 0; i < this.apply.length; i++) {
      if (this.apply[i].selected) {
        totalApplyAmount += Number(this.apply[i].applyAmount);
        if (!this.apply[i].applyAmount || this.apply[i].applyAmount <= 0) {
          this.showErrorchlpaymentamt();
          return;
        } else if (!this.apply[i].applyDate) {
          this.toastService.addSingle(
            'error',
            'Error',
            'Please enter apply date'
          );
          return;
        }
        else {
          //   this.aPayemnt.makePaymentList.push({
          //     invoiceId:this.apply[i].invoiceId,
          //     billNo:this.apply[i].invoiceNo,
          //     type:"Advacne Payment",
          //     paymentId:this.aPayemntId,
          //     amount:this.apply[i].applyAmount
          // })
          this.aPayemnt.advancePaymentApply.push({
            invoiceId: this.apply[i].invoiceId,
            prePaymentNumber: this.aPayemnt.prePaymentNumber,
            applyDate: this.apply[i].applyDate,
            curency: this.apply[i].currency,
            invoiceNumber: this.apply[i].invoiceNo,
            invoiceAmount: this.apply[i].invoicePayments,
            applyAmount: this.apply[i].applyAmount,
            amountDue: this.apply[i].amountDue,
            deleted: false
          })
        }
      }
      // var totalApplyAmount=0;
      // totalApplyAmount+=this.apply[i].applyAmount?this.apply[i].applyAmount:0;
    }
    // this.aPayemnt.unappliedAmount=this.aPayemnt.unappliedAmount?(this.aPayemnt.unappliedAmount-totalApplyAmount):this.aPayemnt.paymentAmount-totalApplyAmount;
    if (this.aPayemnt.exchangeRate == undefined || this.aPayemnt.exchangeRate == "") {
      this.showAlert("Please Enter Exchange Rate !");
      return false;
    }
    if (this.aPayemnt.advancePaymentApply.length > 0) {
      if (totalApplyAmount > Number(this.unappliedAmountCopy)) {
        this.showAlert("Total Apply Amount cannot be greater than Unapplied Amount");
        return false;
      }

      let days: any = new Date(this.aPayemnt.prePaymentDate).getDate();
      let months: any = new Date(this.aPayemnt.prePaymentDate).getMonth() + 1;
      let year: any = new Date(this.aPayemnt.prePaymentDate).getFullYear();
      if (months < 10) {
        months = "0".toString() + months.toString();
      }
      if (days < 10) {
        days = "0".toString() + days.toString();
      }
      this.aPayemnt.prePaymentDate = year + "-" + months + "-" + days;
      this.showloader = true;
      this.httpService.Insert('/finance-ws/advance/save-advance-payment-apply', this.aPayemnt, this.RetloginDetails.token).subscribe(
        // this.httpService.Insert('/invoice/save-invoice-payment', this.aPayemnt).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res) {
              this.showloader = false;
              if (this.addMode) {
                this.aPayemnt.createdBy = this.RetloginDetails.username; this.aPayemnt.lastModifiedBy = this.RetloginDetails.username
              }
              else if (!this.addMode) {
                this.aPayemnt.lastModifiedBy = this.RetloginDetails.username
              }
              this.toastService.addSingle(
                'success',
                'Success',
                'Apply Successfully!'
              );
              this.router.navigate(['/main/advance-payment/list']);
            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                'Error occured while Apply!'
              );
            }
          }
        },
        (error) => {
        },
        () => { }
      );
    }
    else {
      this.showloader = false;
      this.toastService.addSingle(
        'error',
        'Error',
        'Atleast apply one line'
      );
    }
  }
  decimalfrection(event: any) {
    this.aPayemnt.advanceAmount = parseFloat(event.target.value).toFixed(2)
  }
  fnOnChangeCurrency() {
    if (this.aPayemnt.subsidiaryCurrency == this.aPayemnt.currency) {
      this.aPayemnt.exchangeRate = (1.00).toFixed(2);
    }
  }
  onMakePayment() {
    var DueAmount = Number(this.aPayemnt.advanceAmount != undefined ? this.aPayemnt.advanceAmount : 0.00) - Number(this.aPayemnt.paymentAmount != undefined ? this.aPayemnt.paymentAmount : 0.00);
    localStorage.setItem("Subsidiary", this.aPayemnt.subsidiaryId);
    localStorage.setItem("Supplier", this.aPayemnt.supplierId);
    localStorage.setItem("Type", "Advance Payment");
    localStorage.setItem("billno", this.aPayemnt.proformaInvoice);
    localStorage.setItem("invoicecurrency", this.aPayemnt.currency);
    localStorage.setItem("invoiceamount", this.aPayemnt.advanceAmount);
    localStorage.setItem("dueamount", DueAmount.toString());
    localStorage.setItem("invoiceId", this.aPayemntId.toString());
    localStorage.setItem("invoiceDate", this.aPayemnt.prePaymentDate);

    this.router.navigate(['/main/make-payment/action/add']);
  }
  decimalFilter(event: any) {
    const reg = /^-?\d*(\.\d{0,2})?$/;
    let input = event.target.value + String.fromCharCode(event.charCode);

    if (!reg.test(input)) {
      event.preventDefault();
    }
  }
  decimalfrectionQuntity(event: any) {
    if (event.target.value != "")
      this.aPayemnt.exchangeRate = parseFloat(event.target.value).toFixed(2);
  }

  getRanges() {
    if (this.aPayemnt.subsidiaryId != undefined && this.aPayemnt.prePaymentDate != undefined) {
      this.httpService
        .GetById('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId=' + this.aPayemnt.subsidiaryId, this.aPayemnt.subsidiaryId, this.RetloginDetails.token)
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res) {
              this.fiscalCalenderDTLS = res;
              if (this.fiscalCalenderDTLS != null && this.fiscalCalenderDTLS.fiscalCalanderAccounting.length > 0) {
                let AllowMonths: any = "Allow Months: ";
                let IsDateAvailable: boolean = false;

                var Dummymonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

                let PRdays: any = new Date(this.aPayemnt.prePaymentDate).getDate();
                let PRmonths: any = new Date(this.aPayemnt.prePaymentDate).getMonth() + 1;
                let PRyear: any = new Date(this.aPayemnt.prePaymentDate).getFullYear();
                let PRDate: any = this.aPayemnt.prePaymentDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""

                for (let x = 0; x < this.fiscalCalenderDTLS.fiscalCalanderAccounting.length; x++) {
                  AllowMonths += this.fiscalCalenderDTLS.fiscalCalanderAccounting.length == (x + 1) ? this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month : this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month + " , "

                  if (PRDate >= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].fromDate && PRDate <= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].toDate && this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month == Dummymonths[PRmonths - 1] + "-" + PRyear) {
                    IsDateAvailable = true;
                  }
                }

                if (IsDateAvailable == false) {
                  this.showAlert("Selected Date is Not available in Fiscal Calendar !" + AllowMonths);
                  this.aPayemnt.prePaymentDate = {};
                }
              }
              else {
                this.showAlert("Selected Date is Not available in Fiscal Calendar !");
                this.aPayemnt.prePaymentDate = {};
              }
            } else {
              this.showAlert("No Data Found");
            }
          }
        },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Error',
              error
            );
          }

        );

    }
  }

  //---Send For Approval
  sendAdvpayForApproval() {
    this.showloader = true;
    this.httpService
      .GetById('/finance-ws/advance/send-for-approval?id=' + this.aPayemntId, this.aPayemntId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          // this.pr = res;
          if (res == true) {
            this.toastService.addSingle(
              'success',
              'Success',
              'Advancd Payment Sent for Approval Successfully!'
            );
            window.location.reload();
            this.showloader = false;
          } else {
            this.showAlert(res.errorMessage);
            this.showloader = false;
          }
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending Advancd Payment for Approval!'
          );
          this.showloader = false;
        }

      );
  }

  //---Self For Approval
  selfadvApproval() {
    this.showloader = true;
    this.httpService
      .GetById('/finance-ws/advance/self-approve?advancePaymentId=' + this.aPayemntId, this.aPayemntId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          // this.pr = res;
          if (res == true) {
            this.toastService.addSingle(
              'success',
              'Success',
              'Advancd Payment Approved Successfully!'
            );
            window.location.reload();
            this.showloader = false;
          } else {
            this.showAlert(res.errorMessage);
            this.showloader = false;
          }
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending Advancd Payment for Approval!'
          );
          this.showloader = false;
        }

      );
  }

  onUnApply() {
    this.invoiceIds = [];
    for (let i = 0; i < this.applied.length; i++) {
      //if (this.applied[i].selected == true) {
         this.invoiceIds.push(this.applied[i].invoiceId);
      //}
    }
    
    this.showloader = true;
    //this.httpService.GetAll('/finance-ws/payment/delete?paymentId=' + this.aPayemntId + '&type=Advance Payment', this.RetloginDetails.token)
    this.httpService.GetAll('/finance-ws/advance/unapply?advanceId=' + this.aPayemntId + '&invoiceId='+this.invoiceIds, this.RetloginDetails.token)  
    .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res) {
            this.showloader = false;
            this.showSuccessvoid();
            this.router.navigate(['/main/advance-payment/list']);
          }
          else {
            this.showloader = false;
            this.showErrorVoid();
          }
        }
      });
  }
  GetPOList(): any {
    this.httpService.GetAll(`/procure-ws/po/getBySupplierSubsidiary?supplierId=${this.aPayemnt.supplierId}&subsidiaryId=${this.aPayemnt.subsidiaryId}`,this.RetloginDetails.token)
        .subscribe(res => {
          //For Auth
      if(res.status == 401)
       { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
       {
        if (res.error){
            //var error = JSON.parse(res.error);
            this.toastService.addSingle(
                'error',
                'Error',
                res.error.errorMessage
              );
              this.POList = [];
              }
              else{
              this.POList = res;
      }
    }
       },
       error => {
          },
          () => {
            // 'onCompleted' callback.
            // No errors, route to new page here
         });
    }
    OnpoChange()
    {
      this.POList = [];
      this.GetPOList();
    }

    DownloadReport(advPmtNo:any){
      this.showloader=true;
      //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
    this.advPaymentReport.exportPdf(advPmtNo);  
    this.showloader=false;
    }

    GetDepartmentList() {

     // this.httpService.GetAll('/masters-ws/department/get-parent-department-names?subsidiaryId='+this.aPayemnt.subsidiaryId,this.RetloginDetails.token).subscribe(
     this.httpService.GetAll('/masters-ws/department/get/all/lov?subsidiaryId='+ this.aPayemnt.subsidiaryId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        //this.department = res;
        this.department=[]
        Object.keys(res).forEach(key => { 
          this.department.push({
              "id":Number(key),
              "departmentName":res[key]
            })   
          });
      }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  
  }
  funapprove()
  {
    try {
       var approveList: any = [];
       approveList.push(this.aPayemntId)
       if (approveList.length > 0) {
        this.showloader = true;
        if(this.RetloginDetails.userType=='SUPERADMIN'){
          this.url='/finance-ws/advance/approve-all-advance-payments?currentApproverId=' + this.empID;
  
         }
         else if(this.RetloginDetails.userType=='ENDUSER')
         {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                this.url='/finance-ws/advance/approve-all-advance-payments?currentApproverId=' + this.empID;
              }
              else
              {
                this.url='/finance-ws/advance/approve-all-advance-payments'
              }
        
         }

        this.httpService.Insert(this.url, approveList, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
              // console.log(res);
              if (res.messageCode) {
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );
                this.showloader = false;
              } else {
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Approve selected advance payment!'
                );
                window.location.reload();
                this.showloader = false;
              }
              // this.loading = false;
            }
          },
          (error) => {
            console.log(error);
            this.showloader = false;
            // this.loading = false;
          }
        );
      }
    } catch (err) {
      console.log(err);
      this.showloader = false;
    }
  }
  funreject()
  {
    try {
      if(this.aPayemnt.comments=="" || this.aPayemnt.comments==undefined)
      {
           this.showAlert("Please enter Comments !");
           return;
  
      }
      else
      {
        var rejectList: any = [];
        var isrejectComments: boolean = false
        rejectList.push({ id: this.aPayemntId, rejectedComments: this.aPayemnt.comments })
        this.showloader = true;
        this.httpService.Insert('/finance-ws/advance/reject-all-advance-payments', rejectList, this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else {
                // console.log(res);
                if (res.messageCode) {
                  this.toastService.addSingle(
                    'error',
                    'Error',
                    res.errorMessage
                  );
                  this.showloader = false;
                } else {
                  this.toastService.addSingle(
                    'success',
                    'Success',
                    'Reject selected Advance Payment!'
                  );
                  this.router.navigate(['main/apinvoice/APlist']);
                  this.showloader = false;
                }
               // this.loading = false;
              }
            },
            (error) => {
              console.log(error);
              this.showloader = false;
              // this.loading = false;
            }
          );
      }
   
    } catch (err:any) {
      this.showAlert(err);
      this.showloader = false;
    }
  }
  gotopage()
  {
    if(this.chkId)
    {
      this.router.navigate(['/main/advance-payment/AP_Approval']);
    }
    else
    {
      this.router.navigate(['/main/advance-payment/list']);
    }
  }
  hidepopup()
  {
   this.display=false;
  }
  opendialog()
  {
    this.display=true;;
  }

  getpaymentdetailsforadvance()
  {
    try {
    
       this.httpService.GetAll('/finance-ws/payment/get-payment-details-for-advance?id='+  this.aPayemntId, this.RetloginDetails.token).subscribe(
         (res) => {
           if (res.status == 401) {
             this.showAlert("Unauthorized Access !");
             this.router.navigate(['/login']);
           }
           else if (res.status == 404) {
             this.showAlert("Wrong/Invalid Token!");
             this.router.navigate(['/login']);
           }
           else {
             // console.log(res);
             if (res.messageCode) {
               this.toastService.addSingle(
                 'error',
                 'Error',
                 res.errorMessage
               );
               this.showloader = false;
             } else {


              this.paymentdetails.push(
                {
                  paymentDate:res.paymentDate,
                  paymentNumber:res.paymentNumber,
                  type:res.type,
                  bankName:res.bankName,
                  amount:res.amount.toFixed(2),
                  deleted:res.deleted
                }
              )
            
              

               this.showloader = false;
             }
             // this.loading = false;
           }
         },
         (error) => {
           console.log(error);
           this.showloader = false;
           // this.loading = false;
         }
       );
     }
    catch (err) {
     console.log(err);
     this.showloader = false;
   }
  }

  loadrequestor()
  {
    this.httpService.GetAll('/masters-ws/employee/get?id='+this.loginId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        this.aPayemnt.creator=res.fullName
       
      }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  
  }
  OpenAppSequence()
{
  this.isAppSequenceVisivble=true;
}

recallStatus(mainId:any)
{
  this.showloader = true;
  this.httpService
    .GetAllResponseText('/finance-ws/advance/recall?id=' +mainId, this.RetloginDetails.token)
    .subscribe((res) => {
      //For Auth
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else if (res.status == 200) {
          this.toastService.addSingle(
            'success',
            'Success',
            res.error.text
          );
          this.showloader = false;
          window.location.reload();
      }
      else
      {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      }
    },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      });
}

GetAllProjectList(subsidiaryId:any)
{
  this.httpService.GetById('/masters-ws/project/get-by-subsidiary-id?subsidiaryId=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      debugger
      this.ProjectList=[];
      this.ProjectList=res;
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );
;
}
reloadProjectList()
{
  this.GetAllProjectList(this.aPayemnt.subsidiaryId);
  this.aPayemnt.projectId=undefined;
}

}