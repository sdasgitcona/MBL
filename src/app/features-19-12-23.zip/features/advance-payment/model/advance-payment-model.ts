import { BarController } from "chart.js";

export class  advancedPayemnt {
    id: number;
    prePaymentNumber: string;
    subsidiaryId?: any;
    supplierId?: any;
    locationId?: any;
    prePaymentDate: any;
    currency: string;
    subsidiaryCurrency: string;
    proformaInvoice: string;
    exchangeRate: any;
    type: string;
    advanceAmount: any;
    paymentAmount: any;
    paymentMode: string;
    memo: string;
    status: string;
    netsuiteId?: any;
    rejectedComments?: any;
    approvedBy: string;
    nextApprover: string;
    nextApproverRole?: any;
    nextApproverLevel: string;
    approverPreferenceId?: any;
    approverSequenceId?: any;
    approverMaxLevel?: any;
    noteToApprover?: any;
    createdDate: Date;
    createdBy: string;
    lastModifiedDate: Date;
    lastModifiedBy: string;
    subsidiaryName?: any;
    supplierName?: any;
    amountDue?: any;
    partPaymentAmount?: any;
    //advancePaymentApply?: any;
    deleted: boolean;
    approvalRoutingActive: boolean;
    unappliedAmount:any;
    advancePaymentApply :AdvancePaymentApply[]=[];
    departmentId?:any;
    poId:number;
    isApprovalButtonShowHide?: any;
    comments?:any;
    creator?:any;
    projectId?:any;
}

export class ApplyModel {
    invoiceId: number;
    supplierId: number;
    subsidiaryId: number;
    poId?: number;
    locationId?: number;
    invoiceNo?: any;
    invStatus: string;
    paymentTerm: string;
    integratedId?: any;
    currency: string;
    billTo: string;
    shipTo: string;
    invoiceCode: string;
    invoiceDate: Date;
    dueDate?: any;
    fxRate: number;
    amount: number;
    taxAmount: any;
    totalAmount: any;
    paymentAmount: number;
    amountDue: any;
    approvedBy: string;
    nextApprover?: any;
    nextApproverRole?: any;
    nextApproverLevel?: any;
    approverPreferenceId?: number;
    approverSequenceId?: number;
    approverMaxLevel: string;
    noteToApprover?: any;
    subsidiaryName?: any;
    supplierName?: any;
    invoiceItems?: any;
    totalPaidAmount: number;
    invoicePayments?: any;
    createdBy: string;
    lastModifiedBy: string;
    createdDate: Date;
    lastModifiedDate: Date;
    approvalRoutingActive: boolean;
    selected:boolean;
    applyDate:any;
    applyAmount:any;

}
export class AdvancePaymentApply{
    invoiceId?: number;
    prePaymentNumber?: string;
    applyDate?: Date;
    curency?: string;
    invoiceNumber?: string;
    invoiceAmount?: number;
    applyAmount?: number;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    amountDue?: number;
    deleted?: boolean;
}
export class filterGrid{
    subsidiaryId?:number;
    supplierId?:number;
    status?:string;
    proformaInvoice?:string;
    currency?:string;
    fromDate?:any;
    toDate?:any;
    recent?:any;
}

//--Amar Addition

export class makepayment {
    id: number;
    paymentNumber: number;
    subsidiaryId: number;
    accountId: number;
    supplierId: number;
    paymentDate: any;
    currency: string;
    subsidiaryCurrency: string;
    exchangeRate: string;
    paymentMode: string;
    amount: number;
    bankTransactionType: string;
    bankReferenceNumber: number;
    memo: string;
    netsuiteId: number;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    subsidiaryName: string;
    supplierName: string;
    bankAccountName: string;
    advancePaymentNumber: string;
    advancePaymentType: string;
    advancePaymentAmount: string;
    paymentAmount: string;
    advancePayment: string;
    makePaymentList:makePaymentList[]=[];
    deleted: boolean;
    markall: boolean;
}

export class makePaymentList
{
           paymentNumber?:string;
           paymentId?:number;
           billNo?:string;
           invoiceId?:number;
           invoiceAmount:number;
           paidAmount:number;
           amountDue:number;
           createdDate?: Date;
           createdBy?: string;
           lastModifiedDate?: Date;
           lastModifiedBy?: string;
           paymentAmount:number;
           deleted?:boolean;
           active?:boolean=false;
           paymentamtdisable?:boolean=true;

}

export class apApproval{
        id: number;
        prePaymentNumber: string;
        subsidiaryId: number;
        supplierId: number;
        locationId: null;
        prePaymentDate: Date;
        currency: string;
        subsidiaryCurrency: any;
        proformaInvoice: any;
        exchangeRate: null;
        type: null;
        advanceAmount: any;
        paymentAmount: any;
        dueAmount: any;
        unappliedAmount: any;
        paymentMode: any;
        memo: string;
        status: string;
        netsuiteId: string;
        rejectedComments: any;
        approvedBy: any;
        nextApprover: any;
        nextApproverRole: any;
        nextApproverLevel: any;
        approverPreferenceId: any;
        approverSequenceId: any;
        approverMaxLevel: any;
        noteToApprover: any;
        nsMessage: any;
        nsStatus: any;
        integratedId: any;
        department: any;
        createdDate: any;
        createdBy: any;
        lastModifiedDate: any;
        lastModifiedBy: any;
        subsidiaryName: string;
        supplierName: string;
        partPaymentAmount: any;
        advancePaymentApply: any;
        deleted: boolean;
        approvalRoutingActive: boolean;
        // for approval
       selected:boolean;
       NewrejectComments?: any;
       isAdminRole:boolean;

}

export class Applied
{
        id:number;
        prePaymentId:number;
        invoiceId:number;
        prePaymentNumber:string;
        applyDate:any
        curency:string;
        invoiceNumber:string;
        invoiceAmount:string;
        applyAmount:number;
        createdDate: any;
        createdBy: any;
        lastModifiedDate: any;
        lastModifiedBy: any;
        amountDue:number;
        deleted:boolean;
        invoiceDate: Date;
        selected:boolean;
        unapllied:boolean;
}


  
export class paymentdetails{
    id?:number;
    paymentNumber?:string;
    subsidiaryId?:number;
    accountId?:number;
    bankId?:number;
    supplierId?:number;
    paymentDate?:any;
    currency?:string;
    subsidiaryCurrency?:string;
    exchangeRate?:string;
    paymentMode?:string;
    amount?:any;
    bankTransactionType?:string;
    bankReferenceNumber?:string;
    memo?:string;
    netsuiteId?:number;
    rejectedComments?:string;
    noteToApprover?:string;
    voidDescription?:string;
    voidDate?:any;
    type?:string;
    status?:string;
    nsMessage?:string;
    nsStatus?:string;
    integratedId?:number;
    approvedBy?:string;
    nextApprover?:string;
    nextApproverUid?:string;
    nextApproverRole?:string;
    nextApproverLevel?:string;
    approverPreferenceId?:string;
    approverSequenceId?:string;
    approverMaxLevel?:string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    subsidiaryName?: string;
    supplierName?: string;
    bankAccountName?: string;
    bankName?: string;
    paymentAmount?: string;
    approvedByName?: string;
    bank?: string;
    subsidiary?: string;
    supplier?: string;
    amountWithSign?: string;
    voided?:boolean;
    deleted?:boolean;
    approvalRoutingActive?:boolean;
}


  // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: advpaymentFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class advpaymentFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}
