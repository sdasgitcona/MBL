import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { supplierApprovalModel } from '../../supplier/model/supplier-model';
import { makepayment, apApproval } from '../model/advance-payment-model';

@Component({
  selector: 'app-advance-payment-approval',
  templateUrl: './advance-payment-approval.component.html',
  styleUrls: ['./advance-payment-approval.component.scss']
})
export class AdvancePaymentApprovalComponent implements OnInit {
  columns: any[];
  departments: any[] = [];

  apApprovalList: apApproval[] = [];
  apSelectedApproval: makepayment = new makepayment();
  totalRecords: number = 0;
  loading: boolean = false;
  AllSelected: boolean = false;
  isRejectPressed: boolean = false;
  approvalRoutingActive: boolean = false;
  userRoleId: number;
  empID: number;
  approverRoleList: [{ id?: number; name?: string; }];
  IsLoggerAdmin: string;
  LoggerRoleName: string;
  RetloginDetails: any;

  @ViewChild('dt') dt: Table;


  constructor(
    private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService

  ) {

  }

  ngOnInit(): void {
    // For Role Base Access
    const logDetails: any = sessionStorage.getItem("LoggerDTLS");
    const LoggerId = JSON.parse(logDetails);
    this.empID = LoggerId.employeeId;
    const retDetails: any = sessionStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Advance Payment Approval") {
        this.userRoleId = role_Dtls[0].rolePermissions[i].roleId

      }
    }
    this.IsLoggerAdmin = role_Dtls[0].selectedAccess;
    this.LoggerRoleName = role_Dtls[0].name;
    // End For Role Base Access
    if (this.userRoleId != undefined) {
      this.loadPRApproval();
    }
    else {
      this.router.navigate(['/main/dashboard']);
    }
  }

  loadPRApproval() {
    try {
      this.HttpService.GetAll('/advance/get-pre-payment-appoval?userId=' + this.empID, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            // console.log(res);
            if (res && res.length > 0) {
              this.apApprovalList = res;
              for (let i = 0; i < res.length; i++) {
                res[i].advanceAmount = res[i].advanceAmount.toFixed(2);
              }
              this.totalRecords = res.length;
              //this.SubsidiaryId=this.poApprovalList[0]?.subsidiaryId;
              //this.NextApproverLov()
            } else {
              //this.poApprovalList = [];
              this.totalRecords = res.length;

            }
            this.loading = false;
          }
        },
        (error) => {
          console.log(error);
          this.loading = false;
        }
      );
    } catch (err) {
      console.log(err);
    }
  }

  navigateToAdd() {
    this.router.navigate(['/main/supplier/update']);
  }

  globalSearch(event: any) {
    this.dt.filterGlobal(event.target.value, 'contains')
  }

  approveAP() {
    try {
      this.isRejectPressed = false
      var approveList: any = [];
      this.apApprovalList.map((data: apApproval) => {
        if (data.selected) {
          approveList.push(data.id)
        }
      })
      if (approveList.length > 0) {
        this.HttpService.Insert('/advance/approve-all-advance-payments', approveList, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
              // console.log(res);
              if (res.messageCode) {
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );

              } else {
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Approve selected Purchases Requisition!'
                );
                this.loadPRApproval();
              }
              // this.loading = false;
            }
          },
          (error) => {
            console.log(error);
            // this.loading = false;
          }
        );
      }
    } catch (err) {
      console.log(err);
    }
  }

  rejectAP() {
    try {
      if (this.isRejectPressed) {
        var rejectList: any = [];
        var isrejectComments: boolean = false
        this.apApprovalList.map((data: apApproval) => {
          if (data.selected) {
            if (data.rejectedComments) {
              rejectList.push({ id: data.id, rejectedComments: data.rejectedComments })
              isrejectComments = true;
              this.isRejectPressed = true
            } else {
              this.toastService.addSingle(
                'error',
                'Error',
                'Please enter Reject Comments'
              );
              // alert("Please enter rejectComments");
              isrejectComments = false;
              this.isRejectPressed = true
              return;
            }
          }
        })
        if (isrejectComments) {
          this.HttpService.Insert('/advance/reject-all-advance-payments', rejectList, this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else {
                // console.log(res);
                if (res.messageCode) {
                  this.isRejectPressed = true
                  this.toastService.addSingle(
                    'error',
                    'Error',
                    res.errorMessage
                  );

                } else {
                  this.toastService.addSingle(
                    'success',
                    'Success',
                    'Reject selected Advance Payment!'
                  );
                  this.loadPRApproval();
                }
                this.isRejectPressed = false
                // this.loading = false;
              }
            },
            (error) => {
              console.log(error);
              // this.loading = false;
            }
          );
        }
      } else {
        this.isRejectPressed = true;
      }
    } catch (err) {
      console.log(err);
    }
  }

  onAllSelectChange(event: any) {
    if (event.checked) {
      this.apApprovalList.map((data: apApproval) => {
        data.selected = true;
        this.isRejectPressed = false
        //this.approvalRoutingActive=true;
      })
    }
    else {
      this.apApprovalList.map((data: apApproval) => {
        data.selected = false;
        this.isRejectPressed = false;
        // this.approvalRoutingActive=false;

      })
    }
  }

  onSelectChange(event: any, routingStatus: any) {
    if (!event.checked && this.AllSelected) {
      this.AllSelected = false;
      //this.approvalRoutingActive=routingStatus;
    }
    this.isRejectPressed = false
  }

  viewSupplier(id: any) {
    const url = this.router.serializeUrl(
      this.router.createUrlTree(["/main/supplier/action/view/" + id])
    );
    this.isRejectPressed = false
    window.open(url)
  }

  NextApproverLov(subsidiaryId: number) {
    try {
      this.HttpService.GetAll('/employee/get-by-role-subsidiary?roleId=' + this.userRoleId + '&subsidiaryId=' + subsidiaryId, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            // console.log(res);
            if (res && res.length > 0) {
              this.approverRoleList = res;
              // this.totalRecords = res.length;
            } else {
              this.approverRoleList = [{}];
              // this.totalRecords = res.length;

            }
            this.loading = false;
          }
        },
        (error) => {
          console.log(error);
          this.loading = false;
        }
      );
    } catch (err) {
      console.log(err);
    }
  }

  OnChangeNextApprover(PrId: number, ApproverId: any) {
    try {
      if (ApproverId != null) {
        ApproverId = Number(ApproverId);
      }
      else {
        ApproverId = 0;
      }
      this.HttpService.GetAll(`/advance/update-next-approver?advancePaymentId=` + PrId + `&approverId=` + ApproverId, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res == true) {
              this.toastService.addSingle(
                'success',
                'Success',
                'Next Approver Assigned!'
              );
            } else {
              this.showAlert(res.errorMessage);
            }
          }
        },
        (error) => {
          console.log(error);
        }
      );
    } catch (err) {
      console.log(err);
    }
  }

  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

}
