import { DatePipe } from '@angular/common';
import { Component, OnInit,LOCALE_ID, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch, SubsidiaryEntry, Supplier } from '../../supplier/model/supplier-model';
import { advancedPayemnt, filterGrid,BaseSearchPdf } from '../model/advance-payment-model';
import { ToastService } from 'src/app/core/services/toast.service';
import { AdvancePaymentComponent } from '../../reports/advance-payment/advance-payment.component';
import * as FileSaver from 'file-saver';
import {formatDate } from '@angular/common';
const datepipe: DatePipe = new DatePipe('en-US')
@Component({
  selector: 'app-advance-payment-list',
  templateUrl: './advance-payment-list.component.html',
  styleUrls: ['./advance-payment-list.component.scss']
})
export class AdvancePaymentListComponent implements OnInit {
  filterSearch: filterGrid = new filterGrid();
  columns: any[];
  paymentlist: advancedPayemnt[] = [];
  selectedpayment: advancedPayemnt = new advancedPayemnt();
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  newevent: any;
  startdate: any;
  enddate: any;
  startdatenew: any;
  enddatenew: any;
  status: any;
  supplierlist: Supplier[] = [];
  Subsidiarylist: any[] = [];
  currencyModel:any[]=[];
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  // For Role Base Access
  RetloginDetails: any;
  
 baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
 AdvpayPrint: any[] = [];

  SubIdList:any=[];
  RetRoleDetails:any;
  showloader: boolean;
  ApprovalButtonShowHide: Number = 0;
  isParams: boolean = true;
  filterStatus: any;
  date_from: any;
  date_to: any;

  constructor(
    private routeStateService: RouteStateService,
    private router: Router,
    private toastService: ToastService,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private activatedRoute: ActivatedRoute,
    private advPaymentReport: AdvancePaymentComponent,
    @Inject(LOCALE_ID) public locale: string
  ) {
    this.status = ['Pending Approval', 'Approved', 'Draft', 'Close', 'Rejected', 'Partially Approved', 'Fully Paid', 'Partially Paid', 'Partially Applied', 'Applied'];
  }
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    this.GetSubsideryList();
    this.getallcurrency();
    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Advance Payment") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
      }
    }
    // End For Role Base Access
    //this.resetBaseSearch();
   
  
    this.primengConfig.ripple = true;
    this.columns = [
      { field: 'Id', header: 'Internal ID' },
      { field: 'Subsidiary', header: 'Subsidiary' },
      { field: 'PI Date', header: 'PI Date' },
      { field: 'PI Number', header: 'PI Number ' },
      { field: 'Proforma Invoice', header: 'Invoice' },
      { field: 'Supplier', header: 'Supplier ' },
      { field: 'Currency', header: 'Currency' },
      { field: 'Advance Amount', header: 'Advance Amount' },
      { field: 'Paid Amount', header: 'Paid Amount' },
      { field: 'Unapplied Amount', header: 'Unapplied Amount' },
      { field: 'Status', header: 'Status' },
      { field: 'Creator', header: 'Creator' },
    
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
    // For Getting Filtered Data from Dashboard
    let subsidyList: any = [];
    subsidyList.push(this.filterSearch.subsidiaryId);
    this.activatedRoute.params.subscribe((params) => {
      if (params) {
        if (params['status']) {
          this.isParams = true;
          this.filterStatus = params['status']
          if (this.filterStatus == 'Recent') {
            this.getDate();
            this.baseSearch.filters = {
              subsidiaryId: this.filterSearch.subsidiaryId = this.Subsidiarylist[0].id,
              recentlyCreated:this.filterSearch.recent = true
            }
            this.baseSearch.pageNumber = -1;
            this.loadPayment(this.newevent);
            this.findby(this.filterStatus);
          } else {
            this.baseSearch.filters = {
              subsidiaryId: this.filterSearch.subsidiaryId = this.Subsidiarylist[0].id,
              status: this.filterSearch.status = this.filterStatus,
            }
            this.baseSearch.pageNumber = -1;
            this.loadPayment(this.newevent);
            this.findby(this.filterStatus);
          }
        }
      }
    });
    // For Getting Filtered Data from Dashboard
  }
  resetBaseSearch() {
    this.baseSearch.filters ={subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.ADVANCE_PAYMENT_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadPayment(this.newevent);
  }
  /* Start Fetch Subsidery list from api */
  /* End Fetch Subsidery list from api */
  loadPayment(event: any) {
    try {
      this.newevent = event
      this.loading = true;
      //this.baseSearch.pageNumber = event.first / event.rows;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
      // this.baseSearch.sortColumn = event.sortField
      //   ? 's.' + event.sortField
      //   : GlobalConstants.SUPPLIER_TABLE_SORT_COLUMN;
      this.baseSearch.sortColumn = event.sortField
        ? event.sortField
        : GlobalConstants.ADVANCE_PAYMENT_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
          
          if(this.SubIdList.length==0)
          {
           return;
          }

      this.HttpService.Insert('/finance-ws/advance/get/all', this.baseSearch, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.list.length > 0) {
              this.paymentlist = res.list;
              this.totalRecords = res.totalRecords;

              for(let x=0;x<this.paymentlist.length;x++) {
              if (this.paymentlist[x].status == 'Pending Approval' || this.paymentlist[x].status == 'Applied' || this.paymentlist[x].status == 'Partially Applied' || this.paymentlist[x].status == 'Partially Approved' || this.paymentlist[x].status == 'Approved' || this.paymentlist[x].status == 'Closed' || this.paymentlist[x].status == 'Partially Paid' || this.paymentlist[x].status == 'Paid') //Send Approval Mode
          {
            this.paymentlist[x].isApprovalButtonShowHide = 0;

          }
          else {
            this.paymentlist[x].isApprovalButtonShowHide = 1;

          }
        }

            } else {
              this.paymentlist = [];
              this.totalRecords=0;
            }
            this.loading = false;
          }
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {
    }
  }
  navigateToAdd() {
    this.router.navigate(['/main/subsidiary/update']);
  }
  navigateToAddViewEdit(
    action: string,
    selectedPayment: advancedPayemnt = new advancedPayemnt()
  ) {
    let paymentId = null;
    if (selectedPayment?.id) {
      paymentId = selectedPayment.id;
      this.router.navigate(['/main/advance-payment/action', action, paymentId]);
    } else {
      this.router.navigate(['/main/advance-payment/action', action]);
    }
  }
  /*exportPdf() {
    import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
        const doc = new jsPDF.default();
        (doc as any).autoTable(this.exportColumns, this.paymentlist);
        doc.save('Advnace payment.pdf');
      })
    })
  }*/
  /* Start fetch filter list of Subsidiary from api */
  findby(event: any) {
    let subsidyList:any=[];
    subsidyList.push(this.filterSearch.subsidiaryId);
    let date_from:any;
    let date_to:any;
    if(this.filterSearch.fromDate!=undefined)
    {
     //let effectiveFrom=this.taxRateRule.effectiveFrom.setDate(this.taxRateRule.effectiveFrom.getDate() - 1)
      let days_from:any = new Date(this.filterSearch.fromDate).getUTCDate();
      if(days_from<10)
      {
         days_from="0"+days_from;
      }
      let months_from:any = new Date(this.filterSearch.fromDate).getUTCMonth()+1;
      
      if(months_from<10)
      {
        months_from="0"+months_from;
      }
      let year_from:any = new Date(this.filterSearch.fromDate).getUTCFullYear();
      date_from=year_from+"-"+months_from+"-"+days_from;
    }
    if(this.filterSearch.toDate!=undefined)
    {
     // let effectiveto=this.taxRateRule.effectiveTo.setDate(this.taxRateRule.effectiveTo.getDate() - 1)
      let days_to:any = new Date(this.filterSearch.toDate).getUTCDate();
      if(days_to<10)
      {
        days_to="0"+days_to;
      }
      let months_to:any = new Date(this.filterSearch.toDate).getUTCMonth()+1;
      if(months_to<10)
      {
        months_to="0"+months_to;
      }
      let year_to:any = new Date(this.filterSearch.toDate).getUTCFullYear();
      date_to=year_to+"-"+months_to+"-"+days_to;
    }

    this.baseSearch.filters = {
      subsidiaryId: subsidyList,
      supplierId: this.filterSearch.supplierId,
      // status: this.filterSearch.status != undefined ? this.filterSearch.status : "",
      status: this.filterSearch.status,
      proformaInvoice: this.filterSearch.proformaInvoice,
      currency:this.filterSearch.currency,
      fromDate:date_from,
      toDate:date_to,
      recentlyCreated:this.filterSearch.recent

    }
    this.baseSearch.pageNumber=-1;
       this.loadPayment(this.newevent);
  }
  Reset() {
    if(this.RetloginDetails.userType=='SUPERADMIN')
     {
      this.filterSearch.subsidiaryId = undefined;
     }
    //this.filterSearch.subsidiaryId = undefined;
    this.filterSearch.supplierId = undefined;
    this.filterSearch.status = undefined;
    this.filterSearch.proformaInvoice= undefined;
    //this.findby("");
    this.resetBaseSearch();
  }
  /* End filter list of Subsidiary from api */
  GetSubsideryList() {
    if(this.RetloginDetails.userType=='SUPERADMIN')
   // if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    //this.HttpService.GetAll("/setup-ws/subsidiary/get/all", this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.Subsidiarylist = res;
          for(let x=0;x<this.Subsidiarylist.length;x++)
       { 
        this.SubIdList.push(this.Subsidiarylist[x].id);
      }
        }
      },
      (error) => {
      },
      () => {
        if(localStorage.getItem("AdvancePaymentFilters") != null)
        {const LocDetails:any =localStorage.getItem("AdvancePaymentFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.filterSearch.supplierId=searcheData.filters.supplierId;
        this.filterSearch.status=searcheData.filters.status;
        this.filterSearch.proformaInvoice=searcheData.filters.proformaInvoice;
        this.filterSearch.currency=searcheData.filters.currency;
        this.filterSearch.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
        this.filterSearch.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
        this.loadPayment(this.newevent);
        localStorage.removeItem("AdvancePaymentFilters");
        }
        else
       { this.resetBaseSearch();}
      }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        id:this.RetRoleDetails[0].subsidiaryId,
        name:this.RetRoleDetails[0].subsidiaryName
      });
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.filterSearch.subsidiaryId = this.RetRoleDetails[0].subsidiaryId;
      this.GetSupplierList(this.RetRoleDetails[0].subsidiaryId);
      if(localStorage.getItem("AdvancePaymentFilters") != null)
      {const LocDetails:any =localStorage.getItem("AdvancePaymentFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.filterSearch.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.filterSearch.supplierId=searcheData.filters.supplierId;
      this.filterSearch.status=searcheData.filters.status;
      this.filterSearch.proformaInvoice=searcheData.filters.proformaInvoice;
      this.filterSearch.currency=searcheData.filters.currency;
      this.filterSearch.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
      this.filterSearch.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.loadPayment(this.newevent);
      localStorage.removeItem("AdvancePaymentFilters");
      }
      else
     { this.resetBaseSearch();}
    }
  }
  GetSupplierList(SubID:any) {
    this.HttpService
      .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + SubID, SubID, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.supplierlist = res;
        }
      });
  }

  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }



  getallcurrency()
  {
    this.HttpService.GetAll("/setup-ws/currency/get/all",this.RetloginDetails.token)
    .subscribe(res => {
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        if (res) {
      
          this.currencyModel=res;
          
        
         } else {
          this.currencyModel=[];
           
         }
      }
      },
      error => {
        // console.log(error);
        this.currencyModel=[];
       },
       () => {
         // 'onCompleted' callback.
         // No errors, route to new page here
       });
  }


  ReloadSubsidiaryList()
  {
    this.Subsidiarylist=[];
    this.filterSearch.subsidiaryId=0;
    this.supplierlist=[];
    this.GetSubsideryList();
  }
  ReloadCurrencyList()
  {
    this.currencyModel=[];
  this.getallcurrency();
  }

  ReloadSupplierList()
  {
    this.supplierlist=[];
  
    this.GetSupplierList(this.filterSearch.subsidiaryId);
  }

  DownloadReport(advPmtNo:any){
    this.showloader=true;
    //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
  this.advPaymentReport.exportPdf(advPmtNo);  
  this.showloader=false;
  };


  selfApproval(id:any){
    this.showloader = true;
    this.HttpService
      .GetById('/finance-ws/advance/self-approve?advancePaymentId=' + id, id, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          // this.pr = res;
          if (res == true) {
            this.toastService.addSingle(
              'success',
              'Success',
              'Advancd Payment Approved Successfully!'
            );
            window.location.reload();
            this.showloader = false;
          } else {
            this.showAlert(res.errorMessage);
            this.showloader = false;
          }
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending Advancd Payment for Approval!'
          );
          this.showloader = false;
        }

      );
  }

  sendForApproval(id:any){
    this.showloader = true;
    this.HttpService
      .GetById('/finance-ws/advance/send-for-approval?id=' + id, id, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          // this.pr = res;
          if (res == true) {
            this.toastService.addSingle(
              'success',
              'Success',
              'Advancd Payment Sent for Approval Successfully!'
            );
            window.location.reload();
            this.showloader = false;
          } else {
            this.showAlert(res.errorMessage);
            this.showloader = false;
          }
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending Advancd Payment for Approval!'
          );
          this.showloader = false;
        }

      );
  }
  getDate() {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
    const day = (currentDate.getDate()-1).toString().padStart(2, '0');
    this.date_to = `${year}-${month}-${day}`;

    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(currentDate.getDate() - 7);
    const fromYear = sevenDaysAgo.getFullYear();
    const fromMonth = (sevenDaysAgo.getMonth() + 1).toString().padStart(2, '0');
    const fromDay = sevenDaysAgo.getDate().toString().padStart(2, '0');
    this.date_from = `${fromYear}-${fromMonth}-${fromDay}`;
  }

  editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("AdvancePaymentFilters") != null)
    {
      localStorage.removeItem("AdvancePaymentFilters");
    }
    localStorage.setItem("AdvancePaymentFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/advance-payment/action', actionType, mainId,0]);
   }

       /***((Export Excel)) */
       generatePDFData(exportType:any){
        this.newevent = event;
        this.baseSearchPdf.pageSize = this.totalRecords;
        this.baseSearchPdf.sortColumn =GlobalConstants.ADVANCE_PAYMENT_TABLE_SORT_COLUMN;
        this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
    
        this.HttpService.Insert('/finance-ws/advance/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
          (res) => {
            //For Auth
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
              //this.employeelistPrint = [];
              this.AdvpayPrint = [];
              if (res && res.list.length > 0) {
                var RetData = res.list;
                for (let i = 0; i < RetData.length; i++) {

                  if (RetData[i].id == undefined) {
                    RetData[i].id = "";
                  }
                  if(exportType == 'PDF'){ 

                  
                    this.AdvpayPrint.push({
                      'Id': RetData[i].id,    
                      'Subsidiary':RetData[i].subsidiaryName, 
                      'PI Date':  formatDate(RetData[i].prePaymentDate, 'dd-MM-yyyy' ,this.locale),
                      'PI Number': RetData[i].prePaymentNumber,
                      'Proforma Invoice':   RetData[i].proformaInvoice,  
                      'Supplier':  RetData[i].supplierName, 
                      'Currency': RetData[i].currency,
                      'Advance Amount': RetData[i].advanceAmount,
                      'Paid Amount': RetData[i].paymentAmount,
                      'Unapplied Amount': RetData[i].unappliedAmount,
                      'Status': RetData[i].status,
                      'Creator': RetData[i].creator
    
                      // 
                      
                  });
                }
                  else{
                    this.AdvpayPrint.push({
                      'Internal Id': RetData[i].id,    
                      'Subsidiary':RetData[i].subsidiaryName, 
                      'PI Date':  formatDate(RetData[i].prePaymentDate, 'dd-MM-yyyy' ,this.locale),
                      'PI Number': RetData[i].prePaymentNumber,
                      'Proforma Invoice':   RetData[i].proformaInvoice,  
                      'Supplier':  RetData[i].supplierName, 
                      'Currency': RetData[i].currency,
                      'Advance Amount': RetData[i].advanceAmount,
                      'Paid Amount': RetData[i].paymentAmount,
                      'Unapplied Amount': RetData[i].unappliedAmount,
                      'Status': RetData[i].status,
                      'Creator': RetData[i].creator
                    });
                  }
    
                }
              }
              if(exportType == 'PDF')
              {this.exportPdf();}
            }
          }
        );
      }
      exportPdf() {
        import("jspdf").then(jsPDF => {
          import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            //this.= this.employeeExport;
            //this.employeelist=[];
            (doc as any).autoTable(this.exportColumns, this.AdvpayPrint);
            doc.save('advance-payment.pdf');
          })
        })
      }
    
    //End PDF
    
    //Start Excel
    exportExcel() {
      this.showloader=true
      this.generatePDFData('');
    
     setTimeout(() => {
      this.exportExcelData()
     }, 250);
      }
      exportExcelData()
      {
        if(this.AdvpayPrint.length >0)
        { import('xlsx').then((xlsx) => {
             const worksheet = xlsx.utils.json_to_sheet(this.AdvpayPrint);
             const workbook = { 
                 Sheets: { data: worksheet }, 
                 SheetNames: ['data'] 
             };
             const excelBuffer: any = xlsx.write(workbook, {
                 bookType: 'csv',
                 type: 'array',
             });
             this.saveAsExcelFile(excelBuffer, 'advance-payment');
             this.showloader=false;
         });}
      }
    
      saveAsExcelFile(buffer: any, fileName: string): void {
          let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
          let EXCEL_EXTENSION = '.csv';
          const data: Blob = new Blob([buffer], {
              type: EXCEL_TYPE,
          });
          FileSaver.saveAs(
              data, fileName + EXCEL_EXTENSION
              //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
          );
      }
    //End Excel 
      //List Export option End
    
       /********Export excel */
       recallStatus(mainId:any)
       {
         this.showloader = true;
         this.HttpService
           .GetAllResponseText('/finance-ws/advance/recall?id=' +mainId, this.RetloginDetails.token)
           .subscribe((res) => {
             //For Auth
             if (res.status == 401) {
               this.showAlert("Unauthorized Access !");
               this.router.navigate(['/login']);
             }
             else if (res.status == 404) {
               this.showAlert("Wrong/Invalid Token!");
               this.router.navigate(['/login']);
             }
             else if (res.status == 200) {
                 this.toastService.addSingle(
                   'success',
                   'Success',
                   res.error.text
                 );
                 this.showloader = false;
                 window.location.reload();
             }
             else
             {
               this.toastService.addSingle(
                 'error',
                 'Error',
                 'Error occured !'
               );
               this.showloader = false;
             }
           },
             (error) => {
               this.toastService.addSingle(
                 'error',
                 'Error',
                 'Error occured !'
               );
               this.showloader = false;
             });
       }

       onRowSelect(event: any) {
        let apId = event.data.id;
        
        this.router.navigate(['/main/advance-payment/action/view', apId, 0]);
      }
}