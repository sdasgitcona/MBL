import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QuotationAnalysisListComponent } from './quotation-analysis-list/quotation-analysis-list.component';
import { QuotationAnalysisAddEditComponent } from './quotation-analysis-add-edit/quotation-analysis-add-edit.component';

const routes: Routes = [
  {
    path: 'list',
    component: QuotationAnalysisListComponent,
  },
  {
    path: 'action/:action/:id',
    component: QuotationAnalysisAddEditComponent,
  },
  {
    path: 'action/:action',
    component: QuotationAnalysisAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class QuotationAnalysisRoutingModule { }
