import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { QAModel, quotationAnalysisItems, listSupplier, listItem, EmailDetails, Currencyline } from '../model/qa';

@Component({
  selector: 'app-quotation-analysis-add-edit',
  templateUrl: './quotation-analysis-add-edit.component.html',
  styleUrls: ['./quotation-analysis-add-edit.component.scss']
})
export class QuotationAnalysisAddEditComponent implements OnInit {
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  QAHistoryList: HistoryModel[] = [];
  SubsidiaryObject: any[] = [];
  subscription: any;
  QAData = new QAModel();
  mdlDisplay: boolean;
  mainId: number = 0;
  ProjectList:any[];
  RfqBiddingType: any;
  url:any;
  approvedSupplierList: listSupplier[] = [];
  itemList: listItem[] = [];
  uomOptions: any;
  selectedItems: quotationAnalysisItems = new quotationAnalysisItems();
  Currencylist: Currencyline[] = [];
  mdlEmailDisplay: boolean;
  RFQlist: any[] = [];
  mailDetails: EmailDetails = new EmailDetails();
  checkDate: any;
  check: Boolean = false;
  btnsavehide: boolean = false;
  RetRoleDetails:any;
  isawardeditself:boolean=true;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  isviewEditable: boolean = true;
  disqadate: boolean = true;
  RetloginDetails: any;
  showsave: boolean = true;
  isbidetype:boolean=false;
  // For Role Base Access
  showloader: boolean = false;
  loginId:number;
  constructor(private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
    private changeDetectorRef: ChangeDetectorRef) {
    this.RfqBiddingType = [
      { name: 'Open', code: 'Open' },
      { name: 'Close', code: 'Close' }
    ];
    this.uomOptions = [{ name: "KG", code: "KG" }, { name: "LTR", code: "LTR" }, { name: "PCS", code: "PCS" }];
  }

  ngOnInit(): void {
    if (localStorage.getItem("LoggerDTLS") == null) {
      this.router.navigate(['/login']);
    }
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    this.loginId= this.RetloginDetails.employeeId;
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    for(let i=0;i<this.RetRoleDetails.length;i++)
    {
      for(let j=0;j<this.RetRoleDetails[i].rolePermissions.length;j++)
      {
             if(this.RetRoleDetails[i].rolePermissions[j].accessPoint=="Quotation Analysis Approval" && this.RetRoleDetails[i].rolePermissions[j].create==true)
             {
                
                this.isawardeditself=false;
             }
      }
    }


    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Quotation Analysis") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
        if (this.isEditable == false)
          this.isviewEditable = false;
      }
    }
    // End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          this.assignMode(params['action']);
          this.GetSubsideryList();
          this.GetAllCurrencyList();
          if (this.addMode) {
            this.AddNewRow();
            this.loadrequestor();
          }
          if (params['id']) {
            this.mainId = +params['id']; // (+) converts string 'id' to a number
            this.GetMasterDatabyId();
            //this.LoadHistory();
          }
        } else {
          this.showAlert('cannot get params');
        }
      },
      (error) => {
        this.showAlert('add');
      }
    );
  }
  GetMasterDatabyId() {
    this.httpService
      .GetById('/procure-ws/quotation-analysis/get?id=' + this.mainId, this.mainId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          let chkpoRef: boolean;
          chkpoRef = false;
          for (let i = 0; i < res.quotationAnalysisItems.length; i++) {
            if (res.quotationAnalysisItems[i].poRef == null) {
              chkpoRef = true;
            }
          }
          this.QAData = res;
          this.GetAllProjectList(this.QAData.subsidiaryId);
          this.GetDepartmentList_edit_line();
          if(this.QAData.bidType=="Close")
          {
            this.isbidetype=true;
          }
          else
          {
            this.isbidetype=false;
          }
          this.QAData.qaDate = this.QAData.qaDate != null ? new Date(this.QAData.qaDate) : "";
          this.QAData.bidOpenDate = this.QAData.bidOpenDate ? new Date(this.QAData.bidOpenDate) : this.QAData.bidOpenDate;
          this.QAData.bidCloseDate = this.QAData.bidCloseDate ? new Date(this.QAData.bidCloseDate) : this.QAData.bidCloseDate;
          //this.QAData.rfqId=Number(this.QAData.rfqNumber);
          this.fnRFQlist();
          this.fnGetDetailsByRFQ_No();
          //this.BankMasterData.effectiveFrom=(this.BankMasterData.effectiveFrom) == null || (this.BankMasterData.effectiveFrom) == "" ?'':new Date(this.BankMasterData.effectiveFrom);
          //this.BankMasterData.effectiveTo=(this.BankMasterData.effectiveTo) == null || (this.BankMasterData.effectiveTo) == ""?'':new Date(this.BankMasterData.effectiveTo);
          this.QAData.quotationAnalysisItems.sort((a: any, b: any) => a.id - b.id);

          for (let i = 0; i < this.QAData.quotationAnalysisItems.length; i++) {
            this.getItemListRFQVendor(i);
            if (this.QAData.quotationAnalysisItems[i].poRef != null) {
              this.QAData.quotationAnalysisItems[i].isprocessedPo = true;
              this.QAData.quotationAnalysisItems[i].isawardeditself = true;
              this.QAData.quotationAnalysisItems[i].isawarded = true;
            }
            else {
            
              if (this.QAData.quotationAnalysisItems[i].awarded == false) {
                if(this.isawardeditself==false)
                {
                this.QAData.quotationAnalysisItems[i].isawardeditself = false;
                }
                else
                {
                  this.QAData.quotationAnalysisItems[i].isawardeditself = true;
                }
                this.QAData.quotationAnalysisItems[i].isawarded = false;
              }
              else {
                if(this.isawardeditself==false)
                {
                this.QAData.quotationAnalysisItems[i].isawardeditself = false;
                }
                else
                {
                  this.QAData.quotationAnalysisItems[i].isawardeditself = true;
                }
                this.QAData.quotationAnalysisItems[i].isawarded = true;
              }

              if (this.QAData.quotationAnalysisItems[i].processedPo == true) {
                this.QAData.quotationAnalysisItems[i].isprocessedPo = true;
              }
              else {
                this.QAData.quotationAnalysisItems[i].isprocessedPo = false;
              }

            }
            this.QAData.quotationAnalysisItems[i].disabledFields = this.QAData.quotationAnalysisItems[i].awarded ? false : true;
            this.QAData.quotationAnalysisItems[i].recievedDate = (this.QAData.quotationAnalysisItems[i].recievedDate) == null || (this.QAData.quotationAnalysisItems[i].recievedDate) == "" ? '' : new Date(this.QAData.quotationAnalysisItems[i].recievedDate);
            this.QAData.quotationAnalysisItems[i].expectedDate = (this.QAData.quotationAnalysisItems[i].expectedDate) == null || (this.QAData.quotationAnalysisItems[i].expectedDate) == "" ? '' : new Date(this.QAData.quotationAnalysisItems[i].expectedDate);

            if (this.QAData.quotationAnalysisItems[i].approvedSupplier != null) {
              this.loadsuppliercurrency(this.QAData.quotationAnalysisItems[i].approvedSupplier, i);
            }
            else {
              this.httpService.GetAll("/setup-ws/currency/get/all", this.RetloginDetails.token).subscribe(res => {
                if (res.status == 401) {
                  this.showAlert("Unauthorized Access !");
                  this.router.navigate(['/login']);
                }
                else if (res.status == 404) {
                  this.showAlert("Wrong/Invalid Token!");
                  this.router.navigate(['/login']);
                }
                else {
                  this.Currencylist = res;
                  this.QAData.quotationAnalysisItems[i].currencylist = res;
                }
              });
            }

          }

          this.fnOnchangePO(0);
          this.allowButton = false;

          if (this.QAData.quotationAnalysisItems.find(x => x.processedPo == true)) {
            for (let i = 0; i < this.QAData.quotationAnalysisItems.length; i++) {

              if (this.QAData.quotationAnalysisItems[i].poRef == null) {
                this.check = true;
              }
            }
            if (this.check == true) {
              // this.allowButton = true;
              this.btnsavehide = false;
            }
          }
          else {
            this.allowButton = false;
          }


          if (chkpoRef == false) {
            this.allowButton = false;

          }
          chkpoRef == false;
        }
      });
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;

        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;

      default:
        break;
    }
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  GetSubsideryList_old() {
    this.httpService.GetAll("/setup-ws/subsidiary/get/all", this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          this.SubsidiaryObject = res.list;
        }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  }
  GetSubsideryList() {
    this.SubsidiaryObject=[];
    if(this.RetloginDetails.userType=='SUPERADMIN')
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       {
        this.SubsidiaryObject=res;
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
       
       //this.loadSuppliers('');
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.SubsidiaryObject.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
     
    
    }
  }


  ReloadGetSubsideryList() {
    this.QAData.subsidiaryId=undefined;
    if (this.addMode) {
      for (let i = 0; i < this.QAData.quotationAnalysisItems.length; i++) {
        this.QAData.quotationAnalysisItems[i].itemlist = [];
        this.QAData.quotationAnalysisItems[i].quantity = 0;
        this.QAData.quotationAnalysisItems[i].uom = undefined;
        this.QAData.quotationAnalysisItems[i].currency = undefined;
        this.QAData.quotationAnalysisItems[i].exchangeRate = undefined;
        this.QAData.quotationAnalysisItems[i].ratePerUnit = undefined;
        this.QAData.quotationAnalysisItems[i].actualRate = 0.00;
        this.QAData.quotationAnalysisItems[i].expectedDate = undefined;
        this.QAData.quotationAnalysisItems[i].leadTime = undefined;
        this.QAData.quotationAnalysisItems[i].prNumber = undefined;
        this.QAData.quotationAnalysisItems[i].prLocationId = undefined;
        this.QAData.quotationAnalysisItems[i].prLocation = undefined;
        this.QAData.quotationAnalysisItems[i].poRef = undefined;
      }
    }
    this.SubsidiaryObject = [];
    this.RFQlist = [];
    this.GetSubsideryList();
    this.QAData.bidType = undefined;
    this.QAData.bidOpenDate = undefined;
    this.QAData.bidCloseDate = undefined;
    this.QAData.currency = undefined;
    this.QAData.projectId = undefined;
    // this.QAData.quotationAnalysisItems=[];
    this.approvedSupplierList = [];
  }
  //--Supplier and Item List
  getapprovedSupplierList() {
    let subsidiary_Id = this.QAData.subsidiaryId;
    if (this.QAData.bidType == "Open") {
      //--Supplier List
      this.httpService.GetAll('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + subsidiary_Id, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {

            if (res != undefined) {
              this.approvedSupplierList = [];
              res.map((x: any, i: any) => {
                this.approvedSupplierList.push({ "id": x.id, "name": x.name })
              });
            }
          }
        },
        (error) => {
          this.showAlert(error);
        }
      );
      //--Item List
      this.httpService.GetAll('/procure-ws/quotation/get-items-by-rfq?rfqId=' + this.QAData.rfqId, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res != undefined) {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
        
              this.itemList = [];
              res.map((x: any, i: any) => {
                //this.itemList.push({ "id": x.itemId, "name": x.itemNameToDisplay })
                this.itemList.push({ "id": x.itemId, "name": x.itemWithDescription,
                "departmentId":x.departmentId,"departmentName":x.departmentName
               }) // Added by Aftab
              });
              this.QAData.quotationAnalysisItems[0].itemlist = this.itemList;
            }
          }
        },
        (error) => {
          this.showAlert(error);
        }
      );
    }
    else if (this.QAData.bidType == "Close") {
      //--Supplier List
      this.httpService.GetAll('/procure-ws/quotation/get-vendors-by-rfq-id?rfqId=' + this.QAData.rfqId, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {

            if (res != undefined) {
              this.approvedSupplierList = [];
              res.map((x: any, i: any) => {
                this.approvedSupplierList.push({ "id": x.vendorId, "name": x.vendorName })
              });
            }
          }
        },
        (error) => {
          this.showAlert(error);
        }
      );

      if (this.viewMode || this.editMode) {
        for (let a = 0; a < this.QAData.quotationAnalysisItems.length; a++) {
          this.getItemListRFQVendor(a);
        }
      }
    }
  }
  //--Get ItemList AGainst RFQ & Vendor
  getItemListRFQVendor(rowIndex: number) {
debugger
    for (let i = 0; i < this.QAData.quotationAnalysisItems.length - 1; i++) {

      if (this.addMode) {

        if (this.QAData.quotationAnalysisItems[i].approvedSupplier == this.QAData.quotationAnalysisItems[rowIndex].approvedSupplier && this.QAData.quotationAnalysisItems[i].itemId == this.QAData.quotationAnalysisItems[rowIndex].itemId) {
          this.showAlert("Supplier and Item combination already exists");
          this.QAData.quotationAnalysisItems[rowIndex].approvedSupplier = undefined;
          this.QAData.quotationAnalysisItems[rowIndex].itemId = undefined;
          if (this.QAData.bidType != "Open") {
            this.QAData.quotationAnalysisItems[rowIndex].itemlist = [];
          }
          else {
            // this.QAData.quotationAnalysisItems[RowIndex].itemId=undefined;
            this.QAData.quotationAnalysisItems[rowIndex].itemlist = [];


          }
          return;
        }
      }

    }


    if (this.QAData.bidType == "Close") {
      this.httpService.GetAll('/procure-ws/quotation/get-items-by-vendor-and-rfq?rfqId=' + this.QAData.rfqId
        + "&vendorId=" + this.QAData.quotationAnalysisItems[rowIndex].approvedSupplier, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
               debugger
              if (res != undefined) {
                this.itemList = [];
                res.map((x: any, i: any) => {
                  // this.itemList.push({ "id": x.itemId, "name": x.itemNameToDisplay })
                  this.itemList.push({ "id": x.itemId, "name": x.itemName ,
                  "departmentId":x.departmentId,"departmentName":x.departmentName}) // Added by Aftab
                });
                this.QAData.quotationAnalysisItems[rowIndex].itemlist = this.itemList;
              }
            }
          },
          (error) => {
            this.showAlert(error);
          }
        );
    }
    else {

      if (this.editMode) {
        this.httpService.GetAll('/procure-ws/quotation/get-items-by-rfq?rfqId=' + this.QAData.rfqId, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {

              if (res != undefined) {
                this.itemList = [];
                res.map((x: any, i: any) => {
                  //this.itemList.push({ "id": x.id, "name": x.name })
                  // this.itemList.push({ "id": x.itemId, "name": x.itemNameToDisplay })
                  this.itemList.push({ "id": x.itemId, "name": x.itemWithDescription,
                  "departmentId":x.departmentId,"departmentName":x.departmentName }) // Added by Aftab
                });
              }
              this.QAData.quotationAnalysisItems[rowIndex].itemlist = this.itemList;
            }
          },
          (error) => {
            this.showAlert(error);
          }
        );
      }
      else {
        this.QAData.quotationAnalysisItems[rowIndex].itemlist = this.itemList;
      }


    }


    // else
    // {
    //   this.showAlert("Bid type not found");
    // }

    this.loadsuppliercurrency(this.QAData.quotationAnalysisItems[rowIndex].approvedSupplier, rowIndex);




  }
  //--On Change Exchange Rate
  fnOnCurrencyChange(RowIndex: number) {
    if (this.QAData.bidType == undefined || this.QAData.bidType == "") {
      this.showAlert("no Rfq currency found ");
      return;
    }
    if (this.QAData.quotationAnalysisItems[RowIndex].currency == this.QAData.currency) {
      this.QAData.quotationAnalysisItems[RowIndex].disableExchangeRate = true;
      this.QAData.quotationAnalysisItems[RowIndex].exchangeRate = 1;
    }
    else {
      this.QAData.quotationAnalysisItems[RowIndex].disableExchangeRate = false;
      this.QAData.quotationAnalysisItems[RowIndex].exchangeRate = undefined;
    }

    if (this.QAData.quotationAnalysisItems[RowIndex].exchangeRate != undefined && this.QAData.quotationAnalysisItems[RowIndex].ratePerUnit != undefined) {
      let eRate: any = this.QAData.quotationAnalysisItems[RowIndex].exchangeRate;
      let qaRtae: any = this.QAData.quotationAnalysisItems[RowIndex].ratePerUnit;
      this.QAData.quotationAnalysisItems[RowIndex].actualRate = eRate * qaRtae;
    }
    else {
      this.QAData.quotationAnalysisItems[RowIndex].actualRate = 0.00;
    }
  }
  fnCalculateActualRate(RowIndex: number) {

    if (this.QAData.quotationAnalysisItems[RowIndex].exchangeRate != undefined && this.QAData.quotationAnalysisItems[RowIndex].ratePerUnit != undefined) {
      let eRate: any = this.QAData.quotationAnalysisItems[RowIndex].exchangeRate;
      let qaRtae: any = this.QAData.quotationAnalysisItems[RowIndex].ratePerUnit;
      this.QAData.quotationAnalysisItems[RowIndex].actualRate = eRate * qaRtae;
    }
    else {
      this.QAData.quotationAnalysisItems[RowIndex].actualRate = 0.00;
    }

  }
  //--All Currency List
  GetAllCurrencyList() {
    this.httpService.GetAll("/setup-ws/currency/get/all", this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          this.Currencylist = res;
          this.QAData.quotationAnalysisItems[0].currencylist = res;
        }
      });
  }

  //--Subsidiary Dependent Data 
  fnLoadSubsidiaryDependany() {
    //this.GetAllCurrencyList();
    // this.httpService.GetById("/quotation-analysis/get-qa-number-by-subsidiary?subsidiaryId=" + this.QAData.subsidiaryId, this.QAData.subsidiaryId)
    //   .subscribe(res => {
    //     this.QAData.qaNumber = res[0]
    //   });
    this.getFiscalDateRanges();
    if (this.addMode) {
      for (let i = 0; i < this.QAData.quotationAnalysisItems.length; i++) {
        this.QAData.quotationAnalysisItems[i].itemlist = [];
        this.QAData.quotationAnalysisItems[i].quantity = 0;
        this.QAData.quotationAnalysisItems[i].uom = undefined;
        this.QAData.quotationAnalysisItems[i].currency = undefined;
        this.QAData.quotationAnalysisItems[i].exchangeRate = undefined;
        this.QAData.quotationAnalysisItems[i].ratePerUnit = undefined;
        this.QAData.quotationAnalysisItems[i].actualRate = 0.00;
        this.QAData.quotationAnalysisItems[i].expectedDate = undefined;
        this.QAData.quotationAnalysisItems[i].leadTime = undefined;
        this.QAData.quotationAnalysisItems[i].prNumber = undefined;
        this.QAData.quotationAnalysisItems[i].prLocationId = undefined;
        this.QAData.quotationAnalysisItems[i].prLocation = undefined;
        this.QAData.quotationAnalysisItems[i].poRef = undefined;
      }
    }
    this.fnRFQlist();
    this.GetAllProjectList(this.QAData.subsidiaryId);
  }
  //--Check QA Date
  fnCheckQADate() {
    this.getFiscalDateRanges();
    if (this.QAData.qaDate != undefined || this.QAData.qaDate != null) {

      if (this.QAData.bidOpenDate != undefined) {
        if (new Date(this.QAData.qaDate) <= new Date(this.QAData.bidOpenDate)) {

          let qaDate: any = new Date(this.QAData.qaDate).getDate();
          let qaMonths: any = new Date(this.QAData.qaDate).getMonth() + 1;
          let qaYear: any = new Date(this.QAData.qaDate).getFullYear();

          let bidopenDate: any = new Date(this.QAData.bidOpenDate).getDate();
          let bidopenMonths: any = new Date(this.QAData.bidOpenDate).getMonth() + 1;
          let bidopenYear: any = new Date(this.QAData.bidOpenDate).getFullYear();

          if (qaDate == bidopenDate && qaMonths == bidopenMonths && qaYear == bidopenYear) {

          }
          else {
            this.QAData.qaDate = {};
            this.showAlert("Selected date must be greater than Bidding start date !");
            return false;
          }

        }
      }
      else {
        this.QAData.qaDate = null;
      }
    }
  }

  fnGeneratePO() {
    //  var v;
    //  var Chkcurrency;
    //  var POallow=false;
    //  var count=0;
    //  this.popupArray=[];
    //  this.QaSubData.QAChildModule[this.fieldArray.length]={};
    //  if(this.QaSubData.QAChildModule.length>0){
    //    for (let i = 0; i < this.QaSubData.QAChildModule.length-1; i++) {
    //   if(i==0) 
    //   {
    //    v= this.QaSubData.QAChildModule[i].supplier  != "Select One" ? this.QaSubData.QAChildModule[i].supplier :"";
    //    Chkcurrency=this.QaSubData.QAChildModule[i].currency != "Select One" ? this.QaSubData.QAChildModule[i].currency:"" ;

    //   }
    //   if(this.QaSubData.QAChildModule.length-1>1 && v == this.QaSubData.QAChildModule[i].supplier && Chkcurrency == this.QaSubData.QAChildModule[i].currency)
    //   {
    //    count++;
    //   }
    //   else if(this.QaSubData.QAChildModule.length-1 == 1){
    //    count++;
    //   }
    //   if(this.QaSubData.QAChildModule.length-1 == count)
    //   {
    //    POallow =true;
    //   }
    //    }
    //    for (let i = 0; i < this.QaSubData.QAChildModule.length-1; i++) {
    //      if(this.QaSubData.QAChildModule[i].PO == true && this.QaSubData.QAChildModule[i].clientQA != "" && POallow == true )
    //      {
    //  this.newDynamic = {};
    //  this.popupArray.push(this.newDynamic);
    //      }

    //    }
    //  }
    //  if(POallow == true && this.popupArray.length >0 )
    //  {
    //    $('#mdlPOModal').modal("show");
    //  }
    //  else
    //      {
    //        if(this.popupArray.length == 0)
    //    {
    //      alert("Condition not matched for generate po");
    //    }
    //    else if(POallow == false)
    //        alert("Suppliers are different");
    //      }
  }
  fnActiveMail(RowIndex: number) {
    if (this.QAData.quotationAnalysisItems[RowIndex].awarded == true) {

      this.QAData.quotationAnalysisItems[RowIndex].disabledFields = false;
      this.QAData.quotationAnalysisItems[RowIndex].isawarded = true;
    }
    else {
      this.QAData.quotationAnalysisItems[RowIndex].disabledFields = true;
      this.QAData.quotationAnalysisItems[RowIndex].processedPo = false;
      this.QAData.quotationAnalysisItems[RowIndex].isawarded = false;
    }
  }
  AddNewRow() {
    this.btnsavehide=false;
    this.QAData.quotationAnalysisItems.push(new quotationAnalysisItems());
    // alert(this.QAData.quotationAnalysisItems.length);
    if (this.QAData.bidType == "Open") {
      this.QAData.quotationAnalysisItems[this.QAData.quotationAnalysisItems.length - 1].itemlist = this.itemList;
    }
    else {
      this.QAData.quotationAnalysisItems[this.QAData.quotationAnalysisItems.length - 1].itemlist = [];

    }
    this.httpService.GetAll("/setup-ws/currency/get/all", this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          this.Currencylist = res;
          this.QAData.quotationAnalysisItems[this.QAData.quotationAnalysisItems.length - 1].currencylist = res;
        }
      });




  }
  deleterowlevel(index: any) {
    if (this.editMode) {
      this.QAData.quotationAnalysisItems[index].deleted = true;
    } else {
      this.QAData.quotationAnalysisItems.splice(index, 1);
    }
  }
  fnRFQlist() {

      if(this.QAData.projectId!=undefined)
      {
             this.url="/procure-ws/quotation/get-by-subsidiary?subsidiaryId=" + this.QAData.subsidiaryId +"&projectId="+this.QAData.projectId;
      }
      else
      {
             this.url="/procure-ws/quotation/get-by-subsidiary?subsidiaryId=" + this.QAData.subsidiaryId;
      }




    this.httpService.GetAll(this.url, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          this.RFQlist = res;
        }
      });
  }
  ReloadRFQList() {


    if (this.addMode) {
      this.disqadate = true;
      this.QAData.quotationAnalysisItems = [];
      /*for(let i=0;i<this.QAData.quotationAnalysisItems.length;i++)
      {
        this.QAData.quotationAnalysisItems[i].itemlist=[];
        this.QAData.quotationAnalysisItems[i].quantity=0;
        this.QAData.quotationAnalysisItems[i].uom=undefined;
        this.QAData.quotationAnalysisItems[i].currency=undefined;
        this.QAData.quotationAnalysisItems[i].exchangeRate=undefined;
        this.QAData.quotationAnalysisItems[i].ratePerUnit=undefined;
        this.QAData.quotationAnalysisItems[i].actualRate=0.00;
        this.QAData.quotationAnalysisItems[i].expectedDate=undefined;
        this.QAData.quotationAnalysisItems[i].leadTime=undefined;
        this.QAData.quotationAnalysisItems[i].prNumber=undefined;
        this.QAData.quotationAnalysisItems[i].prLocationId=undefined;
        this.QAData.quotationAnalysisItems[i].prLocation=undefined;
        this.QAData.quotationAnalysisItems[i].poRef=undefined;
      }*/
    }
    this.fnRFQlist();
    this.QAData.bidType = undefined;
    this.QAData.bidOpenDate = undefined;
    this.QAData.bidCloseDate = undefined;
    this.QAData.currency = undefined;
    this.QAData.rfqId = undefined;
    //this.QAData.quotationAnalysisItems=[];
    this.approvedSupplierList = [];
    //this.QAData.quotationAnalysisItems=[];
    // this.QAData.rfqNumber = undefined;
  }
  fnGetDetailsByRFQ_No() {
    if (this.addMode) {
      this.disqadate = false;
      for (let i = 0; i < this.QAData.quotationAnalysisItems.length; i++) {
        this.QAData.quotationAnalysisItems[i].itemlist = [];
        this.QAData.quotationAnalysisItems[i].quantity = 0;
        this.QAData.quotationAnalysisItems[i].uom = undefined;
        this.QAData.quotationAnalysisItems[i].currency = undefined;
        this.QAData.quotationAnalysisItems[i].exchangeRate = undefined;
        this.QAData.quotationAnalysisItems[i].ratePerUnit = undefined;
        this.QAData.quotationAnalysisItems[i].actualRate = 0.00;
        this.QAData.quotationAnalysisItems[i].expectedDate = undefined;
        this.QAData.quotationAnalysisItems[i].leadTime = undefined;
        this.QAData.quotationAnalysisItems[i].prNumber = undefined;
        this.QAData.quotationAnalysisItems[i].prLocationId = undefined;
        this.QAData.quotationAnalysisItems[i].prLocation = undefined;
        this.QAData.quotationAnalysisItems[i].poRef = undefined;
      }
    }


    let RFQ = this.QAData.rfqId;//.rfqNumber;
    this.approvedSupplierList = [];
    this.httpService.GetById("/procure-ws/quotation/get?id=" + RFQ, RFQ, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          if (res != undefined) {
            let Openday = new Date(res.bidOpenDate).getDate();
            let Openmonth = new Date(res.bidOpenDate).getMonth() + 1; // add 1 because months are indexed from 0
            let Openyear = new Date(res.bidOpenDate).getFullYear();

            let Closeday = new Date(res.bidCloseDate).getDate();
            let Closemonth = new Date(res.bidCloseDate).getMonth() + 1; // add 1 because months are indexed from 0
            let Closeyear = new Date(res.bidCloseDate).getFullYear();

            this.QAData.bidType = res.bidType;
            if(this.QAData.bidType=="Close")
            {
              this.isbidetype=true;
            }
            else
            {
              this.isbidetype=false;
            }
            this.QAData.bidOpenDate = new Date(res.bidOpenDate);//((Openday.toString().length==1?"0"+Openday:Openday) + '/' + (Openmonth.toString().length==1?"0"+Openmonth:Openmonth) + '/' + Openyear);
            this.QAData.bidCloseDate = new Date(res.bidCloseDate);//((Closeday.toString().length==1?"0"+Closeday:Closeday) + '/' + (Closemonth.toString().length==1?"0"+Closemonth:Closemonth) + '/' + Closeyear);
            this.QAData.currency = res.currency;
          }
        }
      },
        error => {
          this.showAlert(error);
        },
        () => {
          this.getapprovedSupplierList();
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
    //setTimeout(() => this.getapprovedSupplierList(), 300);
  }
  //--Get Item List When BID [OPEN]
  getItemList() {
    if (this.QAData.bidType == "Open") {
      this.httpService.GetAll('/procure-ws/quotation/get-items-by-rfq?rfqId=' + this.QAData.rfqId, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {

            if (res != undefined) {
              this.itemList = [];
              res.map((x: any, i: any) => {
                //this.itemList.push({ "id": x.id, "name": x.name })
                // this.itemList.push({ "id": x.itemId, "name": x.itemNameToDisplay })
                this.itemList.push({ "id": x.itemId, "name": x.itemWithDescription }) // Added by Aftab
              });
            }
          }
        },
        (error) => {
          this.showAlert(error);
        }
      );
    }
  }
  GetItemDetailsById(EventItemId: any, RowIndex: any) {
    debugger
    for (let i = 0; i < this.QAData.quotationAnalysisItems.length - 1; i++) {
      if (this.QAData.quotationAnalysisItems[i].approvedSupplier == this.QAData.quotationAnalysisItems[RowIndex].approvedSupplier && this.QAData.quotationAnalysisItems[i].itemId == this.QAData.quotationAnalysisItems[RowIndex].itemId) {
        this.showAlert("Supplier and Item combination already exists");
        this.QAData.quotationAnalysisItems[RowIndex].approvedSupplier = undefined;
        this.QAData.quotationAnalysisItems[RowIndex].itemId = undefined;
        if (this.QAData.bidType != "Open") {
          this.QAData.quotationAnalysisItems[RowIndex].itemlist = [];
        }
        else {
          // this.QAData.quotationAnalysisItems[RowIndex].itemId=undefined;
          this.QAData.quotationAnalysisItems[RowIndex].itemlist = [];
        }
        return;
      }
    }


    this.httpService
      .GetById('/masters-ws/item/get?id=' + EventItemId.value, EventItemId.value, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          this.QAData.quotationAnalysisItems[RowIndex].uom = res.uom;
          var item_dept=[];
          item_dept=this.itemList.filter(x=>x.id==EventItemId.value);
          this.QAData.quotationAnalysisItems[RowIndex].departmentName = item_dept[0].departmentName;
          this.QAData.quotationAnalysisItems[RowIndex].departmentId = item_dept[0].departmentId;
        }
      });
    this.getItemPRLocation(EventItemId.value, RowIndex)

  }

  getItemPRLocation(itemId: string, rowIndex: number) {

    this.httpService.GetAll('/procure-ws/quotation/get-items-by-rfq?rfqId=' + this.QAData.rfqId, this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          if (res != undefined) {
            for (let i = 0; i < res.length; i++) {
              if (res[i].itemId == itemId) {
                this.QAData.quotationAnalysisItems[rowIndex].prNumber = res[i].prNumber;
                this.QAData.quotationAnalysisItems[rowIndex].prLocationId = res[i].prLocation;
                this.QAData.quotationAnalysisItems[rowIndex].prLocation = res[i].prLocationName;
                this.QAData.quotationAnalysisItems[rowIndex].quantity = res[i].quantity;
                this.QAData.quotationAnalysisItems[rowIndex].prId = res[i].prId; // Added by Aftab

                //this.QAData.quotationAnalysisItems[rowIndex].poRef=res[i].rfqNumber;
              }
            }
          }
        }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  }
  fnOpenMailWindow(index: number) {
    this.mdlEmailDisplay = true;
    this.getSupplierEmailId(index);
  }
  // Validate Quotation Received Date 
  fnValidateQuationReceivedDT(rowIndex: number) {
    if (this.QAData.bidOpenDate != undefined || this.QAData.bidCloseDate != undefined) {
      if (new Date(this.QAData.quotationAnalysisItems[rowIndex].recievedDate) >= new Date(this.QAData.bidOpenDate) && new Date(this.QAData.quotationAnalysisItems[rowIndex].recievedDate) <= new Date(this.QAData.bidCloseDate)) {
      }
      else {
        this.QAData.quotationAnalysisItems[rowIndex].recievedDate = null;
        this.showAlert("Selected date is not between Bidding start date & Bidding end date !");
        return;
      }
    }
  }
  // Validate Expected Date 
  fnValidateExpectedDT(rowIndex: number) {
    if (this.QAData.bidCloseDate != undefined) {
      let exdays: any = new Date(this.QAData.quotationAnalysisItems[rowIndex].expectedDate).getDate();
      let exmonths: any = new Date(this.QAData.quotationAnalysisItems[rowIndex].expectedDate).getMonth() + 1;
      let exyear: any = new Date(this.QAData.quotationAnalysisItems[rowIndex].expectedDate).getFullYear();

      let closedays: any = new Date(this.QAData.bidCloseDate).getDate();
      let closemonths: any = new Date(this.QAData.bidCloseDate).getMonth() + 1;
      let closeyear: any = new Date(this.QAData.bidCloseDate).getFullYear();



      if (new Date(this.QAData.quotationAnalysisItems[rowIndex].expectedDate) < new Date(this.QAData.bidCloseDate)) {
        this.QAData.quotationAnalysisItems[rowIndex].expectedDate = {};
        this.showAlert("Expected date must be greater than Bidding end date !");
        return;
      }
    }
    if (new Date(this.QAData.quotationAnalysisItems[rowIndex].expectedDate) < new Date(this.QAData.quotationAnalysisItems[rowIndex].recievedDate)) {

      this.showAlert("Expected Date must be greater than Received Date");
      this.QAData.quotationAnalysisItems[rowIndex].expectedDate = {};
      return;

    }
  }
  hideEmailDialog() {
    this.mdlEmailDisplay = false;
  }
  showQADialog() {
    this.mdlDisplay = true;
  }
  hideQADialog() {
    this.mdlDisplay = false;
  }

  clearData() {
    this.router.navigate(['/main/quotation-analysis/list']);
    // if (this.editMode)
    //   this.router.navigate(['/main/quotation-analysis/list']);
    // else
    //   this.QAData = new QAModel();
    // this.RFQlist = [];
    // this.approvedSupplierList = [];
  }
  //----[Save/Update] - QA
  ModalSave(SaveType: any) {
    let saveURL: any;
    
    if (this.QAData.subsidiaryId == undefined) {
      this.showAlert("Please select Subsidiary !");
      return false;
    }
    else if (this.QAData.rfqId == undefined) {
      this.showAlert("Please select RFQ No !");
      return false;
    }
    else if (this.QAData.quotationAnalysisItems.length == 0) {
      this.showAlert("No tems found!");
      return false;
    }
    else if (this.QAData.qaDate == undefined || this.QAData.qaDate == "[object Object]") {
      this.showAlert("Please enter QA Date !");
      return false;
    }
    else if (this.QAData.qaDate != undefined) {

      // if (this.QAData.bidOpenDate != undefined) {
      //   if (new Date(this.QAData.qaDate) <= new Date(this.QAData.bidOpenDate)) {
      //     let qadays: any = new Date(this.QAData.qaDate).getDate();
      //     let qamonths: any = new Date(this.QAData.qaDate).getMonth() + 1;
      //     let qayear: any = new Date(this.QAData.qaDate).getFullYear();

      //     let biddays: any = new Date(this.QAData.bidOpenDate).getDate();
      //     let bidmonths: any = new Date(this.QAData.bidOpenDate).getMonth() + 1;
      //     let bidyear: any = new Date(this.QAData.bidOpenDate).getFullYear();

      //     if(qadays==biddays && qamonths==bidmonths && qayear==bidyear)
      //     {

      //     }
      //     else
      //     {
      //       this.QAData.qaDate = {};
      //       this.showAlert("Selected date must be greater Bidding start date !");
      //       return false;
      //     }
      //   }
      // }
      // else
      // {
      //   this.QAData.qaDate={};
      //   return false;
      // }

    }
    for (let i = 0; i < this.QAData.quotationAnalysisItems.length; i++) {

      if (this.QAData.quotationAnalysisItems[i].deleted != true) {
        if (this.QAData.bidType != "Open") {
          if (this.QAData.quotationAnalysisItems[i].approvedSupplier == undefined) {
            this.showAlert("Please select Approved supplier in line items " + Number(i + 1));
            return;
          }
        }
        if (this.QAData.quotationAnalysisItems[i].itemId == undefined) {
          this.showAlert("Please select Item Code in line items " + Number(i + 1));
          return;
        }
        if (this.QAData.quotationAnalysisItems[i].quantity == undefined || this.QAData.quotationAnalysisItems[i].quantity == null) {
          this.showAlert("Please select Quantity in line items " + Number(i + 1));
          return;
        }
        if (this.QAData.quotationAnalysisItems[i].currency == undefined) {
          this.showAlert("Please select Currency in line items " + Number(i + 1));
          return;
        }
        if (this.QAData.quotationAnalysisItems[i].ratePerUnit == undefined || this.QAData.quotationAnalysisItems[i].ratePerUnit == null) {
          this.showAlert("Please select QA Rate/Unit in line items " + Number(i + 1));
          return;
        }
        if (this.editMode) {

          if (this.QAData.quotationAnalysisItems[i].awarded == true) {
            if (this.QAData.quotationAnalysisItems[i].approvedSupplier == null) {
              this.showAlert("Please select Approved Supplier in line items " + Number(i + 1));
              // this.QAData.quotationAnalysisItems[i].awarded=false;
              return;
            }
          }
        }


      }

      //  if(this.QAData.quotationAnalysisItems[i].poRef!=null)
      //{
      //   this.QAData.quotationAnalysisItems[i].awarded=false;
      // }

    }
    if (SaveType == "PO")
      saveURL = "/procure-ws/po/generate-po-by-qa";
    else if (SaveType == "")
      saveURL = "/procure-ws/quotation-analysis/save";
    this.QAData.rfqId = this.QAData.rfqId
    this.QAData.qaId = this.QAData.id;
    if (this.addMode) {
      this.QAData.qaNumber = "";

    }
    if (SaveType == "PO") {
      this.QAData.quotationAnalysisItems = this.QAData.quotationAnalysisItems.filter(x => x.awarded == true && x.processedPo == true);
    }
    if (this.addMode) {
      this.QAData.createdBy = this.RetloginDetails.username; this.QAData.lastModifiedBy = this.RetloginDetails.username
    }
    else if (!this.addMode) {
      this.QAData.lastModifiedBy = this.RetloginDetails.username
    }
    this.showloader = true;
    this.httpService.Insert(saveURL, this.QAData, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          if (res != undefined) {
            this.showloader = false;
            this.showSuccess();
            if(this.addMode)
            this.router.navigate(['/main/quotation-analysis/action', 'view',res.id]);
            else
            this.router.navigate(['/main/quotation-analysis/list']);
          } else if (res.errorMessage != undefined) {
            this.showAlert(res.errorMessage);
            this.showloader = false;
          }
          else {
            this.showError();
            this.showloader = false;
          }
        }
      },
        error => {
          this.showAlert(error);
          this.showloader = false;
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }

  //--Get EmailId From Supplier
  getSupplierEmailId(RowIndex: number) {
    this.httpService
      .GetById('/masters-ws/supplier/get?id=' + this.QAData.quotationAnalysisItems[RowIndex].approvedSupplier, this.QAData.quotationAnalysisItems[RowIndex].approvedSupplier, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          this.mailDetails.toMail = res.supplierAccess.accessMail;
        }
      });
  }
  //--Onchange PO Button 
  allowButton: boolean = false;
  fnOnchangePO(index: any) {
    if (this.QAData.quotationAnalysisItems[index].processedPo == true) {
      this.btnsavehide = true;
      this.allowButton=true;
    }
    else {
    
      this.btnsavehide = false;
      this.allowButton=false;
    }


    let count = 0;
    for (let c = 0; c < this.QAData.quotationAnalysisItems.length; c++) {
      if (this.QAData.quotationAnalysisItems[c].processedPo == true) {
        count++;
      }
    }
    if (count > 0) {
    //  alert("hehe");
     // this.allowButton = true;
    }
    else {
      {
        this.allowButton = false;
      }
    }
  }
  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 1) {
      this.LoadHistory();
    }
  }
  LoadHistory() {
    if (this.QAHistoryList.length == 0)
      this.httpService
        .GetById(`/procure-ws/quotation-analysis/get/history?qaNumber=${this.QAData.qaNumber}&pageSize=200`,
          this.QAData.qaNumber, this.RetloginDetails.token
        )
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {

            this.QAHistoryList = res;
          }
        });
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Data Saved Successfully!'
    );
  }
  showSuccessclose() {
    this.toastService.addSingle(
      'success',
      'Success',
      'QA Close Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving!'
    );
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  CheckdateforQuotation(Index: number) {
    if (new Date(this.QAData.quotationAnalysisItems[Index].expectedDate) < new Date(this.QAData.quotationAnalysisItems[Index].recievedDate)) {

      this.showAlert("Expected Date must be greater than Received Date");
      this.QAData.quotationAnalysisItems[Index].expectedDate = "";
      return;

    }
  }

  reloadSupplier(index: any) {
    let RFQ = this.QAData.rfqId;//.rfqNumber;
    this.approvedSupplierList = [];
    this.httpService.GetById("/procure-ws/quotation/get?id=" + RFQ, RFQ, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          if (res != undefined) {
            let Openday = new Date(res.bidOpenDate).getDate();
            let Openmonth = new Date(res.bidOpenDate).getMonth() + 1; // add 1 because months are indexed from 0
            let Openyear = new Date(res.bidOpenDate).getFullYear();

            let Closeday = new Date(res.bidCloseDate).getDate();
            let Closemonth = new Date(res.bidCloseDate).getMonth() + 1; // add 1 because months are indexed from 0
            let Closeyear = new Date(res.bidCloseDate).getFullYear();

            this.QAData.bidType = res.bidType;
            this.QAData.bidOpenDate = new Date(res.bidOpenDate);//((Openday.toString().length==1?"0"+Openday:Openday) + '/' + (Openmonth.toString().length==1?"0"+Openmonth:Openmonth) + '/' + Openyear);
            this.QAData.bidCloseDate = new Date(res.bidCloseDate);//((Closeday.toString().length==1?"0"+Closeday:Closeday) + '/' + (Closemonth.toString().length==1?"0"+Closemonth:Closemonth) + '/' + Closeyear);
            this.QAData.currency = res.currency;
          }
        }
      },
        error => {
          this.showAlert(error);
        },
        () => {
          this.getapprovedSupplierList();
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }

  getFiscalDateRanges() {
    let fiscalCalenderDTLS: any;
    let Subsidiary = this.QAData.subsidiaryId;
    let InputDate = this.QAData.qaDate;
    if ((Subsidiary != undefined || Subsidiary != "") && (InputDate != undefined || InputDate != null)) {
      this.httpService
        .GetById('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId=' + Subsidiary, Subsidiary, this.RetloginDetails.token)
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res) {
              fiscalCalenderDTLS = res;
              if (fiscalCalenderDTLS != null && fiscalCalenderDTLS.fiscalCalanderAccounting.length > 0) {
                let AllowMonths: any = "Allow Months: ";
                let IsDateAvailable: boolean = false;

                var Dummymonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

                let PRdays: any = new Date(InputDate).getDate();
                let PRmonths: any = new Date(InputDate).getMonth() + 1;
                let PRyear: any = new Date(InputDate).getFullYear();
                let CompareDate: any = InputDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""

                for (let x = 0; x < fiscalCalenderDTLS.fiscalCalanderAccounting.length; x++) {
                  AllowMonths += fiscalCalenderDTLS.fiscalCalanderAccounting.length == (x + 1) ? fiscalCalenderDTLS.fiscalCalanderAccounting[x].month : fiscalCalenderDTLS.fiscalCalanderAccounting[x].month + " , "

                  if (CompareDate >= fiscalCalenderDTLS.fiscalCalanderAccounting[x].fromDate && CompareDate <= fiscalCalenderDTLS.fiscalCalanderAccounting[x].toDate && fiscalCalenderDTLS.fiscalCalanderAccounting[x].month == Dummymonths[PRmonths - 1] + "-" + PRyear) {
                    IsDateAvailable = true;
                  }
                }

                if (IsDateAvailable == false) {
                  this.showAlert("Selected Date is Not available in Fiscal Calendar ! " + AllowMonths);
                  this.QAData.qaDate = {};
                }
              } else {
                this.showAlert("Selected Date is Not available in Fiscal Calendar !");
                this.QAData.qaDate = {};
              }
            } else {
              this.showAlert("No Data Found");
            }
          }
        },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Error',
              error
            );
          }
        );
    }
  }

  loadsuppliercurrency(suppid: any, index: any) {
    this.httpService.GetAll("/masters-ws/supplier/get-currency-by-supplier?supplierId=" + suppid, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          //console.log(res);
          if (res.error) {
            var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              error.errorMessage
            );
            this.itemList = [];
          } else {
            this.Currencylist = [];
            for (let i = 0; i < res.length; i++) {
              this.Currencylist.push({ code: res[i].supplierCurrency });
            }
            this.QAData.quotationAnalysisItems[index].currencylist = this.Currencylist;

          }
        }
      },
        error => {
          this.showAlert(error);
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }

  closeqa()
  {
    //{{procureGateway}}/quotation-analysis/close-status-by-id?id=5

    this.httpService.GetAll("/procure-ws/quotation-analysis/close-status-by-id?id=" + this.mainId, this.RetloginDetails.token)
    .subscribe(res => {
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        //console.log(res);
        if (res) {
          this.showSuccessclose();
          this.router.navigate(['/main/quotation-analysis/list']);
        }
      }
    },
      error => {
        this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });


  }
  loadrequestor()
  {
    this.httpService.GetAll('/masters-ws/employee/get?id='+this.loginId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        this.QAData.creator=res.fullName
       
      }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  
  }
  Loadrfq()
  {
    this.fnRFQlist();
  }
  reloadProjectList()
  {

  }

  GetAllProjectList(subsidiaryId:any)
{
  this.httpService.GetById('/masters-ws/project/get-by-subsidiary-id?subsidiaryId=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      debugger
      this.ProjectList=[];
      for(let x=0;x<res.length;x++)
      {
        this.ProjectList.push({
          "id":res[x].id,
          "name":res[x].name
        })
      }
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}
GetDepartmentList_edit_line() {
  for(let i=0;i<this.QAData.quotationAnalysisItems.length;i++)
  {
    if(this.QAData.quotationAnalysisItems[i].departmentId!=null)
    {
      this.httpService.GetById("/masters-ws/department/get?id="+this.QAData.quotationAnalysisItems[i].departmentId, this.QAData.quotationAnalysisItems[i].departmentId, this.RetloginDetails.token)
      .subscribe(res => {
        if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
         else if(res.errorMessage){
          this.showAlert(res.errorMessage)
         }else{
         
          this.QAData.quotationAnalysisItems[i].departmentName= res.departmentName;
        }
      },
      error => {
       this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
    }

  }



}


}
