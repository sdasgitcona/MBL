import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuotationAnalysisAddEditComponent } from './quotation-analysis-add-edit.component';

describe('QuotationAnalysisAddEditComponent', () => {
  let component: QuotationAnalysisAddEditComponent;
  let fixture: ComponentFixture<QuotationAnalysisAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuotationAnalysisAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuotationAnalysisAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
