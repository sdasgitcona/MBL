import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuotationAnalysisListComponent } from './quotation-analysis-list.component';

describe('QuotationAnalysisListComponent', () => {
  let component: QuotationAnalysisListComponent;
  let fixture: ComponentFixture<QuotationAnalysisListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuotationAnalysisListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuotationAnalysisListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
