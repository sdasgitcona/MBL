import { Component, OnInit, LOCALE_ID, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch ,QAsearch,QAlist,BaseSearchPdf} from '../../quotation-analysis/model/qa';
import { User } from 'src/app/core/models/user.model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as FileSaver from 'file-saver';
import {formatDate } from '@angular/common';
declare let $: any;
@Component({
  selector: 'app-quotation-analysis-list',
  templateUrl: './quotation-analysis-list.component.html',
  styleUrls: ['./quotation-analysis-list.component.scss']
})
export class QuotationAnalysisListComponent implements OnInit {
  columns: any[];
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  qaMDL:QAlist []=[];
  selectedRow: QAlist = new QAlist();
  QAsearch:QAsearch=new QAsearch();
  totalRecords: number = 0;
  newevent:any;
  SubsideryObject:any [];
  rfqTypeList:any;
  ishiddensubsidiary:boolean=false;
  isdisabledsubsidiary:boolean=false;
  user:User;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  RetloginDetails:any;
  qaPrint: any[] = [];
  showloader: boolean = false;
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  SubIdList:any=[];
  // For Role Base Access
  RetRoleDetails:any;
  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService, private toastService: ToastService, @Inject(LOCALE_ID) public locale: string) { 
      this.rfqTypeList = [ 
        { name: 'Open Bid', code: 'Open' },
        { name: 'Close Bid', code: 'Close' }
      ]
    }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    
     // For Role Base Access
     const retDetail:any = localStorage.getItem("RoleDTLS");
     var role_Dtls = JSON.parse(retDetail);
     this.RetRoleDetails=role_Dtls;
     for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
     {
       if(role_Dtls[0].rolePermissions[i].accessPoint == "Quotation Analysis")
       {
         this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
         this.isEditable=role_Dtls[0].rolePermissions[i].edit;
         this.isViewtable=role_Dtls[0].rolePermissions[i].view;
       }
     }
 // End For Role Base Access
    
this.GetSubsideryList();
    const retDetails:any = localStorage.getItem("LoggerDTLS");
    const L_Dtls = JSON.parse(retDetails);
    var v=L_Dtls.email;
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
      { field: 'Id', header: 'Internal ID' },
      { field: 'Subsidiary', header: 'Subsidiary' },
      { field: 'QA Date', header: 'QA Date' },
      { field: 'QA Number', header: 'QA Number' },
      { field: 'RFQ Number', header: 'RFQ Number' },
      { field: 'Bid Open Date & Time', header: 'Bid Open Date & Time' },
      { field: 'Bid Close Date & Time', header: 'Bid Close Date & Time' },
      { field: 'RFQ Bidding Type', header: 'RFQ Bidding Type' },
      { field: 'RFQ Currency', header: 'RFQ Currency' },
      { field: 'Creator', header: 'Creator' },
      { field: 'QA Status', header: 'QA Status' },
     ];


    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }

   getSession() {
    var obj = {};
    if (typeof sessionStorage.key !== "undefined") {
      //obj = JSON.parse(sessionStorage.getItem("LoggerDTLS"));
    }
    return obj;
  }
    /* Start Fetch Subsidery list from api */
    GetSubsideryList_old() {
      this.HttpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
          this.SubsideryObject = res.list;
        }
        },
        (error) => {
          this.showAlert(error);
        }
      );
    }
    GetSubsideryList() {
      this.SubsideryObject=[];
      if(this.RetloginDetails.userType=='SUPERADMIN')
      //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
      {
        this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
         {
           this.SubsideryObject=res;
          for(let x=0;x<this.SubsideryObject.length;x++)
         { 
          this.SubIdList.push(this.SubsideryObject[x].id);
        }
        this.ishiddensubsidiary=false;
        this.isdisabledsubsidiary=false;
        }
        },
        (error) => {
          //alert(error);
         },
         () => {
          if(localStorage.getItem("QAFilters") != null)
          {const LocDetails:any =localStorage.getItem("QAFilters");
          let RetLocDetails = JSON.parse(LocDetails);
          this.baseSearch=RetLocDetails;
          let searcheData:any = RetLocDetails;
          this.QAsearch.subsidiaryId=searcheData.filters.subsidiaryId[0];
          this.QAsearch.qaFromDate=searcheData.filters.qaFromDate != undefined ? new Date(searcheData.filters.qaFromDate ):undefined;
          this.QAsearch.bidType=searcheData.filters.type;
          this.QAsearch.qaToDate=searcheData.filters.qaToDate != undefined ? new Date(searcheData.filters.qaToDate ):undefined;
          this.QAsearch.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
          this.QAsearch.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
          this.loadData(this.newevent);
          localStorage.removeItem("QAFilters");
          }
          else
         { this.resetBaseSearch();}
        }
      );
      }else if(this.RetloginDetails.userType=='ENDUSER'){
        this.SubsideryObject.push({
          "id":this.RetRoleDetails[0].subsidiaryId,
          "name":this.RetRoleDetails[0].subsidiaryName
        });
        this.QAsearch.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
        this.ishiddensubsidiary=true;
        this.isdisabledsubsidiary=true;
        this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
        if(localStorage.getItem("QAFilters") != null)
        {
      const LocDetails:any =localStorage.getItem("QAFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.QAsearch.qaFromDate=searcheData.filters.qaFromDate != undefined ? new Date(searcheData.filters.qaFromDate ):undefined;
        this.QAsearch.bidType=searcheData.filters.type;
        this.QAsearch.qaToDate=searcheData.filters.qaToDate != undefined ? new Date(searcheData.filters.qaToDate ):undefined;
        this.QAsearch.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
        this.QAsearch.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.loadData(this.newevent);
        localStorage.removeItem("QAFilters");
        }
        else
       { this.resetBaseSearch();}
      }
    }


    ReloadSubsidiaryList()
    {
      this.QAsearch.subsidiaryId=undefined;
      this. GetSubsideryList();
    }

  loadData(event: any) {
    try {
     this.newevent=event;
     this.loading = true;
     this.baseSearch.pageNumber =(this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);;
     // this.baseSearch.pageNumber = 1;
     this.baseSearch.pageSize = event.rows;
       this.baseSearch.sortColumn = event.sortField
       ?  event.sortField
       : GlobalConstants.QA_TABLE_SORT_COLUMN;
     this.baseSearch.sortOrder =
       event.sortOrder == -1
         ? GlobalConstants.ASCENDING
         : GlobalConstants.DESCENDING;
         
         if(this.SubIdList.length==0)
         {
          return;
         }

         this.HttpService.Insert('/procure-ws/quotation-analysis/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(
       (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

         this.qaMDL=[];
         if (res && res.list.length > 0) {
          this.qaMDL=res.list;
           //this.employeelist = res.list;          
           this.totalRecords = res.totalRecords;
        
         } else {
           this.qaMDL = [];
           this.totalRecords=0;
         }
         this.loading = false;
        }
       },
       (error) => {
        this.showAlert(error);
         this.loading = false;
       }
     );
   } catch (err) {
    //this.showAlert(err);
   }
 }
 
/* exportPdf() {
  import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          (doc as any).autoTable(this.exportColumns, this.qaMDL);
          doc.save('QA.pdf');
      })
  })
}*/

/* Start fetch filter list of supplier from api */
findby(event: any){
  let subsidyList:any=[];
  subsidyList.push(this.QAsearch.subsidiaryId);

 let bid_from=undefined;
 let bid_to=undefined;
 let QA_from=undefined;
 let QA_to=undefined;

if(this.QAsearch.fromDate!=undefined)
{
  let days_from:any = new Date(this.QAsearch.fromDate).getDate();
  if(days_from<10)
  {
    days_from="0"+days_from;
  }
  let months_from:any = new Date(this.QAsearch.fromDate).getMonth()+1;
  if(months_from<10)
  {
    months_from="0"+months_from;
  }
  let year_from:any = new Date(this.QAsearch.fromDate).getFullYear();
  bid_from=year_from+"-"+months_from+"-"+days_from;
}
if(this.QAsearch.toDate!=undefined)
{
  let days_to:any = new Date(this.QAsearch.toDate).getDate();
  if(days_to<10)
  {
    days_to="0"+days_to;
  }
  let months_to:any = new Date(this.QAsearch.toDate).getMonth()+1;
  if(months_to<10)
  {
    months_to="0"+months_to;
  }
  let year_to:any = new Date(this.QAsearch.toDate).getFullYear();
  bid_to=year_to+"-"+months_to+"-"+days_to;
}
if(this.QAsearch.qaFromDate!=undefined)
{
  let days_QAFrom:any = new Date(this.QAsearch.qaFromDate).getDate();
  if(days_QAFrom<10)
  {
    days_QAFrom="0"+days_QAFrom;
  }
  let months_QAFrom:any = new Date(this.QAsearch.qaFromDate).getMonth()+1;
  if(months_QAFrom<10)
  {
    months_QAFrom="0"+months_QAFrom;
  }
  let year_QAFrom:any = new Date(this.QAsearch.qaFromDate).getFullYear();
  QA_from=year_QAFrom+"-"+months_QAFrom+"-"+days_QAFrom;
}
if(this.QAsearch.qaToDate!=undefined)
{
  let days_qa:any = new Date(this.QAsearch.qaToDate).getDate();
  if(days_qa<10)
  {
    days_qa="0"+days_qa;
  }
  let months_qa:any = new Date(this.QAsearch.qaToDate).getMonth()+1;
  if(months_qa<10)
  {
    months_qa="0"+months_qa;
  }
  let year_qa:any = new Date(this.QAsearch.qaToDate).getFullYear();
  QA_to=year_qa+"-"+months_qa+"-"+days_qa;
}

  this.baseSearch.filters={
    subsidiaryId:subsidyList,
    type:this.QAsearch.bidType,
    fromDate:bid_from,
    toDate:bid_to,
    qaFromDate:QA_from,
    qaToDate:QA_to,
    
}
this.baseSearch.pageNumber=-1;

this.loadData(this.newevent);
}
navigateToAddViewEdit(
  action: string,
  selectedData: QAlist = new QAlist()
) {
  let mainId = null;
  if (selectedData?.id) {
    mainId = selectedData.id;
    this.router.navigate(['/main/quotation-analysis/action', action, mainId]);
  } else {
    this.router.navigate(['/main/quotation-analysis/action', action]);
  }
}
showAlert(AlertMSG:any) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}


  Reset()
  {
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.QAsearch.subsidiaryId =undefined;
    }
  
    this.QAsearch.qaFromDate=undefined;
    this.QAsearch.bidType=undefined;
    this.QAsearch.qaToDate=undefined;
    this.QAsearch.fromDate=undefined;
    this.QAsearch.toDate=undefined;
   // this.resetBaseSearch();
    this.baseSearch.pageNumber=-1;
    this.loadData(this.newevent);
  }

  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.QA_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.DESCENDING;
    this.loadData(this.newevent);
  }

  editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("QAFilters") != null)
    {
      localStorage.removeItem("QAFilters");
    }
    localStorage.setItem("QAFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/quotation-analysis/action', actionType, mainId]);
   }

      /***((Export Excel)) */
      generatePDFData(exportType:any){
        this.newevent = event;
        this.baseSearchPdf.pageSize = this.totalRecords;
        this.baseSearchPdf.sortColumn =GlobalConstants.QA_TABLE_SORT_COLUMN;
        this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
    
        this.HttpService.Insert('/procure-ws/quotation-analysis/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
          (res) => {
            //For Auth
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
              //this.employeelistPrint = [];
              this.qaPrint = [];
              if (res && res.list.length > 0) {
                var RetData = res.list;
                for (let i = 0; i < RetData.length; i++) {

                  if (RetData[i].id == undefined) {
                    RetData[i].id = "";
                  }
                  if(exportType == 'PDF'){ 

                  
                    this.qaPrint.push({
                      'Id': RetData[i].id,    
                      'Subsidiary':RetData[i].subsidiaryName, 
                      'QA Date':  formatDate(RetData[i].qaDate, 'dd-MM-yyyy' ,this.locale),
                      'QA Number': RetData[i].qaNumber,
                      'RFQ Number': RetData[i].rfqNumber,
                      'Bid Open Date & Time':  formatDate(RetData[i].bidOpenDate, 'dd-MM-yyyy hh:mm' ,this.locale),  
                      'Bid Close Date & Time': formatDate(RetData[i].bidCloseDate, 'dd-MM-yyyy hh:mm' ,this.locale), 
                      'RFQ Bidding Type': RetData[i].bidType,
                      'RFQ Currency': RetData[i].currency,
                      'Creator': RetData[i].creator,
                      'QA Status': RetData[i].status
    
                      // 
                      
                  });
                }
                  else{
                    this.qaPrint.push({
                      'Internal Id': RetData[i].id,    
                      'Subsidiary':RetData[i].subsidiaryName, 
                      'QA Date': formatDate(RetData[i].qaDate, 'dd-MM-yyyy' ,this.locale),
                      'QA Number': RetData[i].qaNumber,
                      'RFQ Number': RetData[i].rfqNumber,
                      'Bid Open Date & Time': formatDate(RetData[i].bidOpenDate, 'dd-MM-yyyy hh:mm' ,this.locale).toString(),    
                      'Bid Close Date & Time':formatDate(RetData[i].bidCloseDate, 'dd-MM-yyyy hh:mm' ,this.locale), 
                      'RFQ Bidding Type': RetData[i].bidType,
                      'RFQ Currency': RetData[i].currency,
                      'Creator': RetData[i].creator,
                      'QA Status': RetData[i].status
                    });
                  }
    
                }
              }
              if(exportType == 'PDF')
              {this.exportPdf();}
            }
          }
        );
      }
      exportPdf() {
        import("jspdf").then(jsPDF => {
          import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            //this.= this.employeeExport;
            //this.employeelist=[];
            (doc as any).autoTable(this.exportColumns, this.qaPrint);
            doc.save('QA.pdf');
          })
        })
      }
    
    //End PDF
    
    //Start Excel
    exportExcel() {
      this.showloader=true
      this.generatePDFData('');
    
     setTimeout(() => {
      this.exportExcelData()
     }, 250);
      }
      exportExcelData()
      {
        if(this.qaPrint.length >0)
        { import('xlsx').then((xlsx) => {
             const worksheet = xlsx.utils.json_to_sheet(this.qaPrint);
             const workbook = { 
                 Sheets: { data: worksheet }, 
                 SheetNames: ['data'] 
             };
             const excelBuffer: any = xlsx.write(workbook, {
                 bookType: 'csv',
                 type: 'array',
             });
             this.saveAsExcelFile(excelBuffer, 'QA');
             this.showloader=false;
         });}
      }
    
      saveAsExcelFile(buffer: any, fileName: string): void {
          let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
          let EXCEL_EXTENSION = '.csv';
          const data: Blob = new Blob([buffer], {
              type: EXCEL_TYPE,
          });
          FileSaver.saveAs(
              data, fileName + EXCEL_EXTENSION
              //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
          );
      }
    //End Excel 
      //List Export option End
    
       /********Export excel */

       onRowSelect(event: any) {
        let qaId = event.data.id;
        
        this.router.navigate(['/main/quotation-analysis/action/view', qaId]);
      }


}
