export class QAModel{
    id?:number;
    qaNumber?: string;
    qaId?: number;
    rfqNumber?: any;
    rfqId?: number;
    subsidiaryId?: number;
    qaDate: any;
    bidType?:string;
    bidOpenDate?:any ;
    bidCloseDate?:any;
    currency?:any;
    quotationAnalysisItems:quotationAnalysisItems[]=[];
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    status?:any;
    creator?:any;
    department?:string;
    departmentId?:number;
    projectId?:number;
    //rfqDetails:RFQDetails={};
}
export class quotationAnalysisItems{
    clientQaNumber?: string;
    recievedDate?: any;
    generalSupplier?: string;
    approvedSupplier?:number;
    itemId?: number;
    itemlist:listItem[]=[];
    currencylist:Currencyline[]=[];
    currency?: string;
    quantity?:number;
    uom?:string;
    exchangeRate?: number;
    ratePerUnit?: number;
    actualRate?: number;
    expectedDate?: any;
    leadTime?: any;
    prLocationId?: number;
    prLocation?: string;
    prNumber?: string;
    prId?:number;
    poRef?: boolean;
    processedPo?: boolean;
    awarded?: boolean=false;
    deleted?: boolean=false;
    disabledFields?:boolean=true;
    disableExchangeRate?:boolean=false;
    isawarded:boolean=false;
    isawardeditself:boolean=true;
    isprocessedPo:boolean=true;
    departmentName?:string;
    departmentId?:number;
    itemWithDescription:any;
}
export class RFQDetails{
    rfqBiddingType?:string;
    rfqBiddingStartDate?:any;
    rfqBiddingEndDate?:any;
    rfqBiddingCurrency?:string;
}
export class QAsearch{
    subsidiaryId?: number;
    bidType?:string;
    fromDate?:any;
    toDate?:any;
    qaFromDate?:any;
    qaToDate?:any;
}
export class QAlist{
    id?:number;
    subsidiary?:number;
    subsidiaryName?:string;
    qaNumber?:string;
    rfqNumber?:string;
    qaDate?: any;
    bidOpenDate?: any;
    bidCloseDate?: any;
    currency?:string;
    rfqType?: string;
    itemName?: string;
    approvedSupplier?:string;
    bidType?:string;
}

// Base seach model for Supplier
export class BaseSearch {
    filters: TblFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }
  
  export class TblFilter {
      subsidiary: string = '';
      vendorname: string = '';
      vendornumber: string = '';
      vendortype: string = '';
      pan: string = '';
      active: string = '';
    }
    export class  listSupplier{
        id?:number;
        name?:string;
    }
    export class  listItem{
        id?:number;
        name?:string;
        departmentName?:string;
        departmentId?:number;
    }
    export class EmailDetails
    {
        toMail?:string;
    }

    export class Currencyline{
        code?:string;
    }

      // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: QAFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

  //this class holds the custom filter values at component level.
export class QAFilter {
    subsidiary: string = '';
    vendorname: string = '';
    vendornumber: string = '';
    vendortype: string = '';
    pan: string = '';
    active: string = '';
  }