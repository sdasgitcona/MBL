export class RfqPoList{
    id:number;
    prNumber:string;
    prId:number
    subsidiaryId:number;
    type:string;
    locationId:number;
    projectName:string;
    prDate:Date;
    currency:string;
    supplierCurrency:string;
    requestor:string;
    priority:string;
    memo:string;
    exchangeRate:number;
    netSuiteId:string;
    rejectedComments:string;
    department:string;
    prStatus:string;
    approvedBy:string;
    nextApprover:string;
    nextApproverRole:string;
    nextApproverLevel:string;
    approverPreferenceId:number;
    approverSequenceId:number;
    approverMaxLevel:string;
    createdDate: Date;
    createdBy?: string;
    lastModifiedDate: Date;
    lastModifiedBy: string;
    prItems:string;
    subsidiaryName:string;
    locationName:string;
    totalValue:number;
    approvedByName:string;
    deleted:boolean;
    approvalRoutingActive:boolean;
    rfqEnabled:boolean;
    fromDate?:any;
    toDate?:any;
    markallrfq: boolean;
    markallpo: boolean;
    activerfq:boolean;
    activepo:boolean;
    bidType:string;
    supplierId:number;
    transactionalDate:any;
    isdisabledbidtypesingle:boolean=true;
    isdisabledsuppliersingle:boolean=true;
    isdisabledsuppliercurrsingle:boolean=true;
    partiallyProcessedFor:string;
    departmentId:any;
    Suppliercurrency:Suppliercurrency[]=[];
    projectId?:number;
}

// Base seach model for Supplier
export class BaseSearch {
    filters: RfqPOFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }
  
  //this class holds the custom filter values at component level.
  export class RfqPOFilter {
    fromDate: string = '';
    toDate: string = '';
    subsidiaryId: number = 0;
    status: string = '';
 
  }

  export class generateporfq
  {
    createCommonRfqPo:boolean;
    moduleName:string;
    rfqPoRequests:rfqPoRequests[]=[];

  }


  export class rfqPoRequests
  {
    subsidiaryId?: number;
    prId?:number;
    prNumber?: string;
    prDate?: Date;
    prCurrency?: string
    prLocationId?: number
    prLocation?: string
    bidType?: string;
    supplierId?: number;
    transactionalDate?: any;
    supplierCurrency?:string;
    requestor?:any;
    creator?:any;
    departmentId?:number;
    projectId?:number;
  }

  export class Suppliercurrency
  {
    id:number;
    code:string;

  }