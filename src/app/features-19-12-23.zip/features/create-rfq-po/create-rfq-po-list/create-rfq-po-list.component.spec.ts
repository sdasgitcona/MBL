import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateRfqPoListComponent } from './create-rfq-po-list.component';

describe('CreateRfqPoListComponent', () => {
  let component: CreateRfqPoListComponent;
  let fixture: ComponentFixture<CreateRfqPoListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateRfqPoListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateRfqPoListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
