import {
  asNativeElements,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { MenuItem } from 'primeng/api';
import { concat } from 'rxjs';
import { RfqPoList,BaseSearch,generateporfq,rfqPoRequests,Suppliercurrency } from '../modal/create-rfq-po';
import { fakeAsync, tick } from '@angular/core/testing';


@Component({
  selector: 'app-create-rfq-po-list',
  templateUrl: './create-rfq-po-list.component.html',
  styleUrls: ['./create-rfq-po-list.component.scss']
})
export class CreateRfqPoListComponent implements OnInit {

  Subsidiarylist:any;
  RfqPoList:RfqPoList[]=[];
  rfqpo:RfqPoList=new RfqPoList();
  PrStatus:any;
  bidtype:any;
  baseSearch: BaseSearch = new BaseSearch();
  RetRoleDetails:any;
  columns: any[];
  departments: any[] = [];
  requestor:any;
  generateporfq: generateporfq = new generateporfq();
  rfqPoRequestslist: rfqPoRequests[] = [];
  rfqpolist: RfqPoList[] = [];
  selectedrfqpolist: RfqPoList = new RfqPoList();
  totalRecords: number = 0;
  loading: boolean = false;
  exportColumns: any[];
  vendorTypeOptions:any;
  newevent:any;
  Supplierlist:any;
  lstCurrencyList:any;
  ishiddienrfq:boolean=true;
  ishiddienpo:boolean=true;
  suppliercurrency:Suppliercurrency[]=[];
  empID:number;
  subsidiaryId:number;
  fiscalCalenderDTLS:any;
  RetloginDetails:any;
  SubIdList:any=[];
  pageNumber:any;
  constructor(private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
    private HttpService: CommonHttpService) { 
    this.PrStatus = [{id:'Partially Processed',value:'Partially Processed'},{id:'Approved',value:'Approved'}];
    this.bidtype = [{id:'Open',value:'Open'},{id:'Close',value:'Close'}];
    }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const logDetails:any = localStorage.getItem("LoggerDTLS");
    const LoggerId=JSON.parse(logDetails);
    this.empID= LoggerId.employeeId;
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
   
    if(role_Dtls[0].selectedAccess=="ADMIN")
    {
      this.subsidiaryId=0;
      this.GetSubsideryList();
    }
    else
    {
      this.subsidiaryId=role_Dtls[0].subsidiaryId;
      this.GetSubsideryListbyId();
    }

    this.loadrequestor();
    this.GetAllVendorList();
    this.All_CurrencyList();
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
       { field: 'id', header: 'Internal ID' },
       { field: 'firstName', header: 'Employee Name' },
       { field: 'employeeNumber', header: 'Employee Number' },
       { field: 'contactNumber', header: 'Phone Number' },
       { field: 'designation', header: 'Designation' },
     ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
 
  
  }
  GetSubsideryList_old() {
    this.Subsidiarylist=[];
    this.httpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          console.log(res);
          this.Subsidiarylist = res.list;
        
     
          //this.SubsideryObject=res;
        }
      },
      (error) => {
        
        console.log(error);
      }
    );
  }

  GetSubsideryList() {
    this.Subsidiarylist=[];
    if(this.RetloginDetails.userType=='SUPERADMIN')
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist=res;
        for(let x=0;x<this.Subsidiarylist.length;x++)
       { 
        this.SubIdList.push(this.Subsidiarylist[x].id);
      }
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
        this.resetBaseSearch();
       //this.loadSuppliers('');
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.rfqpo.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;

     
      this.baseSearch.filters={
       subsidiaryId:this.RetRoleDetails[0].subsidiaryId,
       }
      this.findby(event);
      this.resetBaseSearch();
    }
  }
  GetSubsideryListbyId() {
    this.Subsidiarylist=[];
    this.httpService.GetAll("/setup-ws/subsidiary/get?id="+this.subsidiaryId,this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          console.log(res);
          this.Subsidiarylist.push({
           id:res.id,
           name:res.name
          })
        
          this.rfqpo.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
          //this.SubsideryObject=res;
        }
      },
      (error) => {
        
        console.log(error);
      }
    );
  }

  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.CREATERFQPO_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadrfqpo(this.newevent);
  }


  loadrfqpo(event: any)
  {
    try {
      this.newevent=event
      this.loading = true;
      console.log('PrimeNg Event is' + event);
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
      // this.baseSearch.sortColumn = event.sortField
      //   ? 's.' + event.sortField
      //   : GlobalConstants.SUPPLIER_TABLE_SORT_COLUMN;
      this.baseSearch.sortColumn = event.sortField
      ?  event.sortField
      : GlobalConstants.CREATERFQPO_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
       // this.resetBaseSearch();
      this.HttpService.Insert('/procure-ws/pr/get-approved-pr?subsidiaryId='+this.subsidiaryId, this.baseSearch,this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            console.log(res);
            if (res && res.list.length > 0) {
              // debugger
              this.RfqPoList = res.list;
              this.pageNumber=res.pageNumber ;
              for(let i=0;i<this.RfqPoList.length;i++)
              {
                this.RfqPoList[i].isdisabledbidtypesingle=true;
                this.RfqPoList[i].isdisabledsuppliersingle=true;
                this.RfqPoList[i].isdisabledsuppliercurrsingle=true;
              }
              // if(this.baseSearch.filters && (Object.keys(this.baseSearch.filters).length === 0)){
              // this.VenderNameList = res.list;
              // }
  
              if(this.rfqpo.markallrfq)
              {
                this.chkenablerfq();
              }
  
              if(this.rfqpo.markallpo)
              {
                this.chkenablepo();
              }
              this.totalRecords = res.totalRecords;
            } else {
              this.RfqPoList = [];
              this.totalRecords=0;
            }
            this.loading = false;
          }
        },
        (error) => {
          console.log(error);
          this.loading = false;
        }
      );
    } catch (err) {
    }
  }

  chkenablerfq()
  {
    
    this.ishiddienrfq=false;
    this.ishiddienpo=true;
    for(let i=0;i<this.RfqPoList.length;i++)
    {
    this.RfqPoList[i].activepo=false;
    this.RfqPoList[i].isdisabledsuppliersingle=true;
    this.RfqPoList[i].isdisabledsuppliercurrsingle=true;
  
    }
    if(this.rfqpo.markallrfq)
    {
      this.rfqpo.markallpo=false;
      for(let i=0;i<this.RfqPoList.length;i++)
      {

        if(this.RfqPoList[i].partiallyProcessedFor!='Purchase Order')
        {
            this.RfqPoList[i].activerfq=true;
            this.RfqPoList[i].activepo=false;
            this.RfqPoList[i].isdisabledbidtypesingle=false;
        }
     
      }
    }
      else
      {
        for(let i=0;i<this.RfqPoList.length;i++)
        {
        this.RfqPoList[i].activerfq=false;
        this.RfqPoList[i].isdisabledbidtypesingle=true;
       
      
        }
  
      }
  }

  chkenablepo()
  {
    this.ishiddienrfq=true;
    this.ishiddienpo=false;
    for(let i=0;i<this.RfqPoList.length;i++)
        {
        this.RfqPoList[i].activerfq=false;
        this.RfqPoList[i].isdisabledbidtypesingle=true;
       
      
        }
    if(this.rfqpo.markallpo)
    {
      this.rfqpo.markallrfq=false;
      for(let i=0;i<this.RfqPoList.length;i++)
      {
        if(this.RfqPoList[i].partiallyProcessedFor!='Request For Quotation')
        {
                this.RfqPoList[i].activepo=true;
                this.RfqPoList[i].activerfq=false;
                this.RfqPoList[i].isdisabledsuppliersingle=false;
                this.RfqPoList[i].isdisabledsuppliercurrsingle=false;
        }
      }
    }
      else
      {
        
        for(let i=0;i<this.RfqPoList.length;i++)
        {
           this.RfqPoList[i].activepo=false;
           this.RfqPoList[i].isdisabledsuppliersingle=true;
           this.RfqPoList[i].isdisabledsuppliercurrsingle=true;
       //this.isdisabledsupplier=true;
        //this.isdisabledsuppliercurr=true;
      
        }
  
      }
  }
  GetAllVendorList(){
         
         this.HttpService.GetAll("/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId="+this.subsidiaryId,this.RetloginDetails.token)
        .subscribe(res => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.Supplierlist=res;
            // console.log(this.Vendorlist);
          }
          });
       }

       All_CurrencyList() {
        this.httpService.GetAll("/setup-ws/currency/get/all",this.RetloginDetails.token)
          .subscribe(res => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
              this.lstCurrencyList = res;
            }
          });
      }
      exportPdf() {
        import("jspdf").then(jsPDF => {
            import("jspdf-autotable").then(x => {
                const doc = new jsPDF.default();
                (doc as any).autoTable(this.exportColumns, this.rfqpolist);
                doc.save('GRN.pdf');
            })
        })
    }

   /* chkenablerfqsingle(status:boolean,index:number)
    {

    
    this.ishiddienrfq=false;
    this.ishiddienpo=true;
      if(status)
      {
      
        
        this.rfqpo.markallpo=false;
        for(let i=0;i<this.RfqPoList.length;i++)
        { 
         
        this.RfqPoList[i].activepo=false;
        this.RfqPoList[i].isdisabledsuppliersingle=true;
        this.RfqPoList[i].isdisabledsuppliercurrsingle=true;
        this.RfqPoList[i].supplierId=0;
        this.RfqPoList[i].supplierCurrency="";
      
        }
        if(index<this.RfqPoList.length)
        {
        this.RfqPoList[index].isdisabledbidtypesingle=false;
        this.RfqPoList[index].isdisabledsuppliersingle=true;
        this.RfqPoList[index].isdisabledsuppliercurrsingle=true;
        }
        else
        {
          
                
          this.RfqPoList[index%10].isdisabledbidtypesingle=false;
          this.RfqPoList[index%10].isdisabledsuppliersingle=true;
          this.RfqPoList[index%10].isdisabledsuppliercurrsingle=true;
        }
        
      }
      else
      {
        this.RfqPoList[index].isdisabledbidtypesingle=true;
       
      }
    }

    chkenableposingle(status:boolean,index:number)
    {
      this.ishiddienrfq=true;
      this.ishiddienpo=false;
      if(status)
      {
        this.rfqpo.markallrfq=false;
        for(let i=0;i<this.RfqPoList.length;i++)
        {
        this.RfqPoList[i].activerfq=false;
        this.RfqPoList[i].isdisabledbidtypesingle=true;
        this.RfqPoList[i].bidType="";
        }
        this.RfqPoList[index].isdisabledbidtypesingle=true;
        this.RfqPoList[index].isdisabledsuppliersingle=false;
        this.RfqPoList[index].isdisabledsuppliercurrsingle=false;
      }
      else
      {
        
        this.RfqPoList[index].isdisabledsuppliersingle=true;
        this.RfqPoList[index].isdisabledsuppliercurrsingle=true;
        this.RfqPoList[index].supplierId=0;
        this.RfqPoList[index].supplierCurrency="";
      }
    }*/
    chkenablerfqsingle(status:boolean,index:number)
    {

    this.ishiddienrfq=false;
    this.ishiddienpo=true;
      if(status)
      {
         
        
        this.rfqpo.markallpo=false;
        for(let i=0;i<this.RfqPoList.length;i++)
        { 
         
        this.RfqPoList[i].activepo=false;
        this.RfqPoList[i].isdisabledsuppliersingle=true;
        this.RfqPoList[i].isdisabledsuppliercurrsingle=true;
        this.RfqPoList[i].supplierId=0;
        this.RfqPoList[i].supplierCurrency="";
      
        }
        if(this.pageNumber==0)
        {
         
        this.RfqPoList[index].isdisabledbidtypesingle=false;
        this.RfqPoList[index].isdisabledsuppliersingle=true;
        this.RfqPoList[index].isdisabledsuppliercurrsingle=true;
       }
        else
        {
          
            
          this.RfqPoList[index-this.pageNumber].isdisabledbidtypesingle=false;
          this.RfqPoList[index-this.pageNumber].isdisabledsuppliersingle=true;
          this.RfqPoList[index-this.pageNumber].isdisabledsuppliercurrsingle=true;
        }
        
      }
      else
      {

        if(this.pageNumber==0)
        {
        this.RfqPoList[index].isdisabledbidtypesingle=true;
        this.RfqPoList[index].isdisabledsuppliersingle=true;
        this.RfqPoList[index].isdisabledsuppliercurrsingle=true;
        this.RfqPoList[index].bidType="Select";
        }
        else
        {
          
           
          this.RfqPoList[index-this.pageNumber].isdisabledbidtypesingle=true;
          this.RfqPoList[index-this.pageNumber].isdisabledsuppliersingle=true;
          this.RfqPoList[index-this.pageNumber].isdisabledsuppliercurrsingle=true;
          this.RfqPoList[index-this.pageNumber].bidType="Select";
        }
        //this.RfqPoList[index].isdisabledbidtypesingle=true;
       
      }
    }

    chkenableposingle(status:boolean,index:number)
    {

     
      this.ishiddienrfq=true;
      this.ishiddienpo=false;
      if(status)
      {
        this.rfqpo.markallrfq=false;
        for(let i=0;i<this.RfqPoList.length;i++)
        {
        this.RfqPoList[i].activerfq=false;
        this.RfqPoList[i].isdisabledbidtypesingle=true;
        this.RfqPoList[i].bidType="";
        }
        if(this.pageNumber==0)
        {
        this.RfqPoList[index].isdisabledbidtypesingle=true;
        this.RfqPoList[index].isdisabledsuppliersingle=false;
        this.RfqPoList[index].isdisabledsuppliercurrsingle=false;
        }
        else
        {
          this.RfqPoList[index-this.pageNumber].isdisabledbidtypesingle=true;
          this.RfqPoList[index-this.pageNumber].isdisabledsuppliersingle=false;
          this.RfqPoList[index-this.pageNumber].isdisabledsuppliercurrsingle=false;
        
        }
      }
      else
      {
        if(this.pageNumber==0)
        {
          this.RfqPoList[index].isdisabledsuppliersingle=true;
          this.RfqPoList[index].isdisabledsuppliercurrsingle=true;
          this.RfqPoList[index].supplierId=0;
          this.RfqPoList[index].supplierCurrency="";
        }
        else
        {
          this.RfqPoList[index-this.pageNumber].isdisabledsuppliersingle=true;
          this.RfqPoList[index-this.pageNumber].isdisabledsuppliercurrsingle=true;
          this.RfqPoList[index-this.pageNumber].supplierId=0;
          this.RfqPoList[index-this.pageNumber].supplierCurrency="";
        }
        
       
      }
    }
    // chkenablerfqsingle(status:boolean,index:number)
    // {

    
    // this.ishiddienrfq=false;
    // this.ishiddienpo=true;
    //   if(status)
    //   {
      
        
    //     this.rfqpo.markallpo=false;
    //     for(let i=0;i<this.RfqPoList.length;i++)
    //     { 
         
    //     this.RfqPoList[i].activepo=false;
    //     this.RfqPoList[i].isdisabledsuppliersingle=true;
    //     this.RfqPoList[i].isdisabledsuppliercurrsingle=true;
    //     this.RfqPoList[i].supplierId=0;
    //     this.RfqPoList[i].supplierCurrency="";
      
    //     }
    //     if(index<this.RfqPoList.length)
    //     {
    //     this.RfqPoList[index].isdisabledbidtypesingle=false;
    //     this.RfqPoList[index].isdisabledsuppliersingle=true;
    //     this.RfqPoList[index].isdisabledsuppliercurrsingle=true;
    //     }
    //     else
    //     {
          
                
    //       this.RfqPoList[index%10].isdisabledbidtypesingle=false;
    //       this.RfqPoList[index%10].isdisabledsuppliersingle=true;
    //       this.RfqPoList[index%10].isdisabledsuppliercurrsingle=true;
    //     }
        
    //   }
    //   else
    //   {

    //     if(index<this.RfqPoList.length)
    //     {
    //     this.RfqPoList[index].isdisabledbidtypesingle=true;
    //     this.RfqPoList[index].isdisabledsuppliersingle=true;
    //     this.RfqPoList[index].isdisabledsuppliercurrsingle=true;
    //     this.RfqPoList[index].bidType="Select";
    //     }
    //     else
    //     {
          
                
    //       this.RfqPoList[index%10].isdisabledbidtypesingle=true;
    //       this.RfqPoList[index%10].isdisabledsuppliersingle=true;
    //       this.RfqPoList[index%10].isdisabledsuppliercurrsingle=true;
    //       this.RfqPoList[index%10].bidType="Select";
    //     }
    //     //this.RfqPoList[index].isdisabledbidtypesingle=true;
       
    //   }
    // }

    // chkenableposingle(status:boolean,index:number)
    // {
    //   this.ishiddienrfq=true;
    //   this.ishiddienpo=false;
    //   if(status)
    //   {
    //     this.rfqpo.markallrfq=false;
    //     for(let i=0;i<this.RfqPoList.length;i++)
    //     {
    //     this.RfqPoList[i].activerfq=false;
    //     this.RfqPoList[i].isdisabledbidtypesingle=true;
    //     this.RfqPoList[i].bidType="";
    //     }
    //     if(index<this.RfqPoList.length)
    //     {
    //     this.RfqPoList[index].isdisabledbidtypesingle=true;
    //     this.RfqPoList[index].isdisabledsuppliersingle=false;
    //     this.RfqPoList[index].isdisabledsuppliercurrsingle=false;
    //     }
    //     else
    //     {
    //       this.RfqPoList[index%10].isdisabledbidtypesingle=true;
    //       this.RfqPoList[index%10].isdisabledsuppliersingle=false;
    //       this.RfqPoList[index%10].isdisabledsuppliercurrsingle=false;
        
    //     }
    //   }
    //   else
    //   {
    //     if(index<this.RfqPoList.length)
    //     {
    //       this.RfqPoList[index].isdisabledsuppliersingle=true;
    //       this.RfqPoList[index].isdisabledsuppliercurrsingle=true;
    //       this.RfqPoList[index].supplierId=0;
    //       this.RfqPoList[index].supplierCurrency="";
    //     }
    //     else
    //     {
    //       this.RfqPoList[index%10].isdisabledsuppliersingle=true;
    //       this.RfqPoList[index%10].isdisabledsuppliercurrsingle=true;
    //       this.RfqPoList[index%10].supplierId=0;
    //       this.RfqPoList[index%10].supplierCurrency="";
    //     }
        
       
    //   }
    // }

    saverfqpo(savetype:string)
    {
      this.rfqPoRequestslist=[];
     
     if(savetype=="createrfq")    
     {
        
      for(let i=0;i<this.RfqPoList.length;i++)
      {
      
       if(this.RfqPoList[i].activerfq)
       {
        if(this.RfqPoList[i].bidType==undefined)
        {
         this.showErrorSubsidiary();
         return;
        }
        if(this.RfqPoList[i].transactionalDate==undefined)
        {
         this.showErrortransactionalDate();
         return;
        }

        let transactional_days:any = new Date(this.RfqPoList[i].transactionalDate).getDate();
        let transactional_months:any = new Date(this.RfqPoList[i].transactionalDate).getMonth()+1;
        let transactional_year:any = new Date(this.RfqPoList[i].transactionalDate).getFullYear();
        if(transactional_months<10)
        {
          transactional_months="0".toString()+transactional_months.toString();
        }
        if(transactional_days<10)
        {
          transactional_days="0".toString()+transactional_days.toString();
        }
       
        this.rfqPoRequestslist.push({
             subsidiaryId:this.RfqPoList[i].subsidiaryId,
             prId:this.RfqPoList[i].id,
             //prNumber:this.RfqPoList[i].prNumber,
             prDate:this.RfqPoList[i].prDate,
             prCurrency:this.RfqPoList[i].currency,
             prLocationId:this.RfqPoList[i].locationId,
             prLocation:this.RfqPoList[i].locationName,
             bidType:this.RfqPoList[i].bidType,
             supplierId:this.RfqPoList[i].supplierId,
             transactionalDate: transactional_year+"-"+transactional_months+"-"+transactional_days,
             projectId:this.RfqPoList[i].projectId,
             departmentId:this.RfqPoList[i].departmentId
             
        })
      }
      }
      this.generateporfq.createCommonRfqPo=true;
      this.generateporfq.moduleName="Request For Quotation";
      this.generateporfq.rfqPoRequests=this.rfqPoRequestslist;
     }
     else if(savetype=="createpo")   
     {
      for(let i=0;i<this.RfqPoList.length;i++)
      {
      if(this.RfqPoList[i].activepo)
      {
        if(this.RfqPoList[i].supplierId==undefined)
        {
         this.showErrorSupplier();
         return;
        }
        if(this.RfqPoList[i].supplierCurrency==undefined)
        {
         this.showErrorSuppliercurrency();
         return;
        }
        if(this.RfqPoList[i].transactionalDate==undefined)
        {
         this.showErrortransactionalDate();
         return;
        }

        let transactional_days:any = new Date(this.RfqPoList[i].transactionalDate).getDate();
        let transactional_months:any = new Date(this.RfqPoList[i].transactionalDate).getMonth()+1;
        let transactional_year:any = new Date(this.RfqPoList[i].transactionalDate).getFullYear();
        if(transactional_months<10)
        {
          transactional_months="0".toString()+transactional_months.toString();
        }
        if(transactional_days<10)
        {
          transactional_days="0".toString()+transactional_days.toString();
        }
     
       this.rfqPoRequestslist.push({
            subsidiaryId:this.RfqPoList[i].subsidiaryId,
            prId:this.RfqPoList[i].id,
            //prNumber:this.RfqPoList[i].prNumber,
            prDate:this.RfqPoList[i].prDate,
            prCurrency:this.RfqPoList[i].currency,
            prLocationId:this.RfqPoList[i].locationId,
            prLocation:this.RfqPoList[i].locationName,
            //bidType:this.RfqPoList[i].bidType,
            supplierId:this.RfqPoList[i].supplierId,
            transactionalDate: transactional_year+"-"+transactional_months+"-"+transactional_days,
            //transactionalDate:"2023-01-02",
            supplierCurrency:this.RfqPoList[i].supplierCurrency,
            projectId:this.RfqPoList[i].projectId,
            departmentId:this.RfqPoList[i].departmentId
            
       })
     }
     }

     this.generateporfq.createCommonRfqPo=true;
     this.generateporfq.moduleName="Purchase Order";
     this.generateporfq.rfqPoRequests=this.rfqPoRequestslist;
    } 
  // for(let i=0;i<this.generateporfq.rfqPoRequests.length;i++)
  // {
  //   this.generateporfq.rfqPoRequests[i].requestor= this.requestor;
  // }
  if(savetype=="createpo")   
     {
          for(let i=0;i<this.generateporfq.rfqPoRequests.length;i++)
          {
            this.generateporfq.rfqPoRequests[i].requestor= this.requestor;
          }
     }
     else if(savetype=="createrfq") 
     {
          for(let i=0;i<this.generateporfq.rfqPoRequests.length;i++)
          {
            this.generateporfq.rfqPoRequests[i].creator= this.requestor;
          }
     }

    this.httpService.Insert('/procure-ws/po/generate-po-rfq',  this.generateporfq,this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          console.log(res);
       
          if (res) {
           
           
            if(savetype=="createpo")  
            {
              this.showSuccesspo();
              this.router.navigate(['/main/purchase-order/list']);
            }
            else if(savetype=="createrfq")   
            {
              this.showSuccessrfq();
              this.router.navigate(['/main/request-quatation/list']);
            }
  
            //location.reload();
           
          } else {
            this.showError();
           
          }
        }
      },
      (error) => {
        console.log('error-' + error);
      },
      () => {}
    );
    
    }

    findby(event: any){
      let subsidyList:any=[];
      subsidyList.push(this.rfqpo.subsidiaryId);
       if(this.rfqpo.subsidiaryId!=undefined || this.rfqpo.subsidiaryId=="")
       {
        this.subsidiaryId=this.rfqpo.subsidiaryId;
       }

       let PRfromdate:any;
       let PRtodate:any;
       if(this.rfqpo.fromDate!=undefined)
       {
          let fromdays:any = new Date(this.rfqpo.fromDate).getDate();
          let frommonths:any = new Date(this.rfqpo.fromDate).getMonth()+1;
          let fromyear:any = new Date(this.rfqpo.fromDate).getFullYear();
          if(fromdays<10)
          {
            fromdays="0".toString()+fromdays.toString();
          }
          if(frommonths<10)
          {
            frommonths="0".toString()+frommonths.toString();
          }

          PRfromdate=fromyear+"-"+frommonths+"-"+fromdays;
      
       }

       if(this.rfqpo.toDate!=undefined)
       {
          let todays:any = new Date(this.rfqpo.toDate).getDate();
          let tomonths:any = new Date(this.rfqpo.toDate).getMonth()+1;
          let toyear:any = new Date(this.rfqpo.toDate).getFullYear();
          if(todays<10)
          {
            todays="0".toString()+todays.toString();
          }
          if(tomonths<10)
          {
            tomonths="0".toString()+tomonths.toString();
          }

          PRtodate=toyear+"-"+tomonths+"-"+todays;
      
       }
      
      this.baseSearch.filters={
        fromDate: PRfromdate,
        toDate: PRtodate,
        subsidiaryId:this.rfqpo.subsidiaryId,
        status:this.rfqpo.prStatus
      
    }
    this.baseSearch.pageNumber=-1;
     this.loadrfqpo(this.newevent);
     this.GetAllVendorList();
    }
    Reset() {
      this.rfqpo.fromDate=undefined;
      this.rfqpo.toDate=undefined;
      this.rfqpo.prStatus='';
      this.resetBaseSearch();
      this.loadrfqpo(this.newevent);
    }
    showSuccessrfq() {
      this.toastService.addSingle(
        'success',
        'Success',
        'RFQ created successfully!'
      );
    }
    showSuccesspo() {
      this.toastService.addSingle(
        'success',
        'Success',
        'PO created successfully!'
      );
    }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Crete -Rfq-PO Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Crete -Rfq-PO!'
    );
  }
  showErrorSubsidiary() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Bid Type!'
    );
  }
  showErrortransactionalDate() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Transaction Date!'
    );
  }
  showErrorSupplier() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Supplier!'
    );
  }
  
  showErrorSuppliercurrency() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Supplier Currency!'
    );
  }
  selectcurr(suppid:number,index:number)
  {

    if(this.pageNumber==0)
    {
      index=index;
    }
    else
    {
      index=index-this.pageNumber;
    }
    this.suppliercurrency=[];
    this.httpService.GetAll('/masters-ws/supplier/get?id='+suppid,this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          console.log(res);
          // this.Locationlist=res;
   
          for(let i=0;i<res.supplierSubsidiary.length;i++)
          {
               if(res.supplierSubsidiary[i].preferredCurrency==true)
               {
                   this.RfqPoList[index].supplierCurrency=res.supplierSubsidiary[i].supplierCurrency;
               }
                   this.suppliercurrency.push({
                     id:res.supplierSubsidiary[i].id,
                     code:res.supplierSubsidiary[i].supplierCurrency,
                   })
          }
          this.RfqPoList[index].Suppliercurrency= this.suppliercurrency;
        }
      },
      (error) => {
        console.log(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
  }


  loadSubsidiaryandrole() {
  
    try {    
      this.HttpService.GetAll('/procure-ws/pr/get-pr-appoval?userId='+this.empID,this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            console.log(res);
            if (res && res.length > 0) {
              for(let i=0;i<res.length;i++)   
              {
              this.subsidiaryId=res[i].subsidiaryId
              }
            
            } else {
             
            }
            this.loading = false;
          }
        },
        (error) => {
          console.log(error);
          this.loading = false;
        }
      );
    } catch (err) {
      console.log(err);
    }
  
  }

  getsubsidiary()
  {
    const logDetails:any = localStorage.getItem("LoggerDTLS");
    const LoggerId=JSON.parse(logDetails);
    this.empID= LoggerId.employeeId;
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    if(role_Dtls[0].selectedAccess=="ADMIN")
    {
      this.subsidiaryId=this.rfqpo.subsidiaryId;
    }
    this.loadrfqpo(this.newevent);

    this.resetBaseSearch();
    this.GetAllVendorList();
    this.All_CurrencyList();

  }

  openPr(id:number)
  {
    const url = this.router.serializeUrl(
      this.router.createUrlTree(["/#/main/purchases-requisition/action/view",id,0])
    );
    window.open(decodeURIComponent(url))
  }

  checkdate(index:number)
  {
    if(index<this.RfqPoList.length)
    {
      index=index;
    }
    else
    {
     index=index%10;
    }

    let days:any =     new Date(this.RfqPoList[index].transactionalDate).getDate();
    let months:any = new Date(this.RfqPoList[index].transactionalDate).getMonth()+1;
    let year:any =   new Date(this.RfqPoList[index].transactionalDate).getFullYear();
  
    let PRdays:any =   new Date(this.RfqPoList[index].prDate).getDate();
    let PRmonths:any = new Date(this.RfqPoList[index].prDate).getMonth()+1;
    let PRyear:any =   new Date(this.RfqPoList[index].prDate).getFullYear();
  
    let InvDate=this.RfqPoList[index].transactionalDate !== undefined ? (year + '-' + (months.toString().length ==1?"0"+months:months) + '-' + (days.toString().length ==1?"0"+days:days)) :""
    let PRDate=this.RfqPoList[index].prDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length ==1?"0"+PRmonths:PRmonths) + '-' + (PRdays.toString().length ==1?"0"+PRdays:PRdays)) :""
    if(InvDate < PRDate)
    {
      //this.showAlert("Invoice Date must be greater or equal than PO Date !");
      this.showAlert("PO/RFQ Date must be greater than and equal to PR Date");
      this.RfqPoList[index].transactionalDate={};
      //this.invoiceDetails.invoiceDate={};
      //this.invoiceDetails.dueDate={};
      return false;
    }

  //   if(new Date(this.RfqPoList[index].transactionalDate)<new Date(this.RfqPoList[index].prDate))
  //   {
  //    this.showAlert("PO/RFQ Date must be greater than and equal to PR Date");
  //    this.RfqPoList[index].transactionalDate="";
  //    return;
  //  }
   
   this.getFiscalDateRanges(this.RfqPoList[index].transactionalDate,index);
  }

  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  chkprtodate()
  {
          
    if(new Date(this.rfqpo.toDate) < new Date(this.rfqpo.fromDate))
    {
     this.showAlert("PR To Date must be greater than PR From Date");
     this.rfqpo.toDate={};
     return;
    }

  }

  chkprfromdate()
  {
    if(new Date(this.rfqpo.fromDate) > new Date(this.rfqpo.toDate))
    {
     this.showAlert("PR From Date must be less than PR To Date");
     this.rfqpo.fromDate={};
     return;
    }
  }

  getFiscalDateRanges(tDate:any,RowNo:number) {
    this.fiscalCalenderDTLS=null;
    let AllowMonths: any = "Allow Months: ";
    let IsDateAvailable:boolean = false;
    let Dummymonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  
    if(this.rfqpo.subsidiaryId != undefined && tDate !=undefined){
      this.httpService
      .GetById('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId=' + this.rfqpo.subsidiaryId, this.rfqpo.subsidiaryId,this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res) {
            this.fiscalCalenderDTLS=res;
            if(this.fiscalCalenderDTLS != null && this.fiscalCalenderDTLS.fiscalCalanderAccounting.length >0)
            {
            
            let PRdays: any = new Date(tDate).getDate();
            let PRmonths: any = new Date(tDate).getMonth() + 1;
            let PRyear: any = new Date(tDate).getFullYear();
            let PRDate: any = tDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""
        
            for (let x = 0; x < this.fiscalCalenderDTLS.fiscalCalanderAccounting.length; x++) {
              AllowMonths += this.fiscalCalenderDTLS.fiscalCalanderAccounting.length == (x + 1) ? this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month : this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month + " , "
        
              if (PRDate >= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].fromDate && PRDate <= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].toDate && this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month == Dummymonths[PRmonths - 1] + "-" + PRyear) {
                IsDateAvailable = true;
              }
            }
        
            if (IsDateAvailable == false) {
              this.showAlert("Selected Date is Not available in Fiscal Calendar ! " + AllowMonths);
              this.RfqPoList[RowNo].transactionalDate = {};
            }
          }
          else
          {
            this.showAlert("Selected Date is Not available in Fiscal Calendar !");
            this.RfqPoList[RowNo].transactionalDate = {}; 
          }
  
          } else {
            this.showAlert("No Data Found");
          }
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
             error
          );
        }
  
      );

      // this.httpService
      // .GetAll('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId='+this.invoiceDetails.subsidiaryId)
      // .subscribe((res) => {
      //   if (res != undefined) {
      //     this.fiscalCalenderDTLS=res;
      //   } else {
      //     this.showAlert("No Data Found");
      //   }
      // });
      
  }
  }

  loadrequestor()
{
  this.httpService.GetAll('/masters-ws/employee/get?id='+this.empID,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
     
      this.requestor=res.fullName
     
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}

onRowSelect(id: any) {
    this.router.navigate(['/main/purchases-requisition/action/view', id, 0]);
}
  
}
