import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateRfqPoListComponent } from './create-rfq-po-list/create-rfq-po-list.component';

const routes: Routes = [
  {
    path: '',
    component: CreateRfqPoListComponent,
  },
  {
    path: 'list',
    component: CreateRfqPoListComponent,
  },
  {
    path: 'action/:action/:id',
    component: CreateRfqPoListComponent,
  },
  {
    path: 'action/:action',
    component: CreateRfqPoListComponent,
  },
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CreateRfqPoRoutingModule { }
