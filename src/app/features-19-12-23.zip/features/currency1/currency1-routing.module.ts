import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CurrencyAddEditComponent } from './currency-add-edit/currency-add-edit.component';
const routes: Routes = [
  {
    path: '',
    component: CurrencyAddEditComponent,
  },
  {
    path: 'list',
    component: CurrencyAddEditComponent,
  },
  {
    path: 'action/:action/:id',
    component: CurrencyAddEditComponent,
  },
  {
    path: 'action/:action',
    component: CurrencyAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Currency1RoutingModule { }
