export class Currency {
    id: number;
    line: Currencyline[] = [];
    createdBy:string;
    lastModifiedBy:string;
}

export class Currencyline {
    id: number;
    name:string;
    code:string;
    symbol:string;
    inactive:boolean=true;
 
}