import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { Currency,Currencyline } from '../model/currency-module';
import { ToastService } from 'src/app/core/services/toast.service';
//import { AutoFocus } from '../scroll-to-bottom.directive';

import { Table } from 'primeng/table';
@Component({
  selector: 'app-currency-add-edit',
  templateUrl: './currency-add-edit.component.html',
  styleUrls: ['./currency-add-edit.component.scss']
})
export class CurrencyAddEditComponent implements OnInit {
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  showloader: boolean=false;
  role: any;
  currencyModel:Currencyline[]=[];
  columns: any[];
  currency: Currency = new Currency();
  RetloginDetails:any;
  @ViewChild('dt') dt: Table;
  constructor( private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,) { }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    this.getallcurrency();
  }
  deleteCurrency(index: number) {

    if (index >= 0) this.currencyModel.splice(index, 1);
   }
   addCueerecy() {
     
     if (
       this.currencyModel.length > 0 &&
       this.currencyModel[length - 1] == new Currencyline()
     ) {
       return;
     }
     this.currencyModel.push(new Currencyline());
    // this.dt._rows
     
   }

   CurrencySave(){
    console.log(this.currencyModel);
    for(let i=0;i<this.currencyModel.length;i++)
    {
      if(this.currencyModel[i].name==undefined)
      {
        this.currencyModel.splice(i, 1);
      }
    }

    
    this.httpService.Insert("/setup-ws/currency/save",this.currencyModel,this.RetloginDetails.token)
    .subscribe(res => {
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        if (res !== undefined) {
          if(this.addMode){
            this.currency.createdBy=this.RetloginDetails.username;this.currency.lastModifiedBy=this.RetloginDetails.username
            }
           else if(!this.addMode){
            this.currency.lastModifiedBy=this.RetloginDetails.username
            }
           this.showSuccess();
           this.getallcurrency();
           //this.router.navigate(['/main/tax-rate/list']);
         } else {
           this.showError();
         }
      }
      },
      // error => {
      //   console.log(error);
      //  },
       () => {
         // 'onCompleted' callback.
         // No errors, route to new page here
       });
   }
   showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Currency Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Currency!'
    );
  }

  getallcurrency()
  {
    this.httpService.GetAll("/setup-ws/currency/get/all",this.RetloginDetails.token)
    .subscribe(res => {
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        if (res) {
      
          this.currencyModel=res;
          
          this.addCueerecy();
          
         
          // console.log(this.currencyModel);
           //this.showSuccess();
           //this.router.navigate(['/main/tax-rate/list']);
         } else {
          this.currencyModel=[];
           
         }
      }
      },
      error => {
        // console.log(error);
        this.currencyModel=[];
       },
       () => {
         // 'onCompleted' callback.
         // No errors, route to new page here
       });
  }
  globalSearch(event: any) {
    this.dt.filterGlobal(event.target.value, 'contains')
  }

  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

}
