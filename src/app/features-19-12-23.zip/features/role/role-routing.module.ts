import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RoleAddEditComponent } from './role-add-edit/role-add-edit.component';
import { RoleListComponent } from './role-list/role-list.component';

const routes: Routes = [
  {
    path: '',
    component: RoleListComponent,
  },
  {
    path: 'list',
    component: RoleListComponent,
  },
  {
    path: 'action/:action/:id',
    component: RoleAddEditComponent,
  },
  {
    path: 'action/:action',
    component: RoleAddEditComponent,
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RoleRoutingModule { }
