
    export class RestrictedDepartment {
        id?: number;
        roleId?: number;
        departmentId?: number;
        departmentName?: string;
        createdDate?: Date;
        createdBy?: string;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        deleted?: boolean;
    }

    export class RolePermission {
        id?: number;
        roleId?: number;
        accessPoint?: string;
        createdDate?: Date;
        createdBy?: string;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        view?: boolean;
        create?: boolean;
        edit?: boolean;
        deleted?: boolean;
        isDisabled?:boolean;
        moduleName?:string;
        supplierAccess?:boolean;
    }

    export class RoleMasterModel {
        id?: number;
        name?: string;
        subsidiaryId?: number;
        selectedAccess?: string;
        createdDate?: Date;
        createdBy?: string;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        restrictedDepartments: RestrictedDepartment[]=[];
        rolePermissions: RolePermission[]=[];
        deleted?: boolean;
        inactive?: boolean;
        subsidiaryName?:string;
        active:boolean=true;
        accountId?:any;
        self?:boolean;
        accesstype?:any;
    }

