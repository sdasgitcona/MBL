import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch, SubsidiaryEntry, Supplier, BaseSearchPdf } from '../../supplier/model/supplier-model';
import { RoleMasterModel } from '../model/role-model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-role-list',
  templateUrl: './role-list.component.html',
  styleUrls: ['./role-list.component.scss']
})

export class RoleListComponent implements OnInit {
  columns: any[];
  departments: any[] = [];
  roleList: RoleMasterModel[] = [];
  selectedRole: RoleMasterModel = new RoleMasterModel();
  Subsidiarylist: SubsidiaryEntry[] = [];
  roleNameList: RoleMasterModel[] = [];
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  role: RoleMasterModel = new RoleMasterModel();
  vendorTypeOptions:any;
  newevent:any;
  status:any;
  SubIdList:any=[];
  SubsideryObject:any=[];
  RetloginDetails:any;
  RetRoleDetails:any;
  pagePermission: boolean=false;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  roleNameListPrint: any[] = [];
  showloader:boolean=false;
  issubsidiaryhidden:boolean=false;
  issubsidiarydisabled:boolean=false;
  accesstype:any;  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  // For Role Base Access
  constructor(
    private router: Router,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService
  ) {
    this.status = [{id:'Active',value:'active'},{id:'Inactive',value:'inactive'}];
  }


  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    // For Role Base Access
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
    {
      if(role_Dtls[0].rolePermissions[i].accessPoint == "Role")
      {
        this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
        this.isEditable=role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable=role_Dtls[0].rolePermissions[i].view;
      }

      if(role_Dtls[0].rolePermissions[i].accessPoint == "Subsidiary" ){
        if(role_Dtls[0].rolePermissions[i].create==false && role_Dtls[0].rolePermissions[i].edit==false && role_Dtls[0].rolePermissions[i].view== false){
          this.pagePermission=false;
        }else{
          this.pagePermission=true;
        }
      }
    }
    
 // End For Role Base Access

    
    this.GetSubsideryList();
    this.primengConfig.ripple = true;
    this.columns = [
      //  { field: 'id', header: 'Internal ID' },
      { field: 'id', header: 'Role Id' },
      { field: 'subsidiaryName', header: 'Subsidiary' },
      { field: 'name', header: 'Role Name' },
      { field: "active", header: 'Status'},
      //  { field: 'active', header: 'Status' },
     ];
     this.accesstype = ['VENDOR', 'ADMIN'];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
    this.vendorTypeOptions = ['Company','Individual']
  }



  resetBaseSearch() {
    if(this.RetloginDetails.userType=='ROOTADMIN') {
      this.baseSearch.filters = {roleId:this.RetRoleDetails[0].id};
      this.baseSearch.pageNumber = 0;
      this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
      this.baseSearch.sortColumn = GlobalConstants.ROLE_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
      this.loadRole(this.newevent);
    }else{
      this.baseSearch.filters = {subsidiaryId: this.SubIdList};
      this.baseSearch.pageNumber = 0;
      this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
      this.baseSearch.sortColumn = GlobalConstants.ROLE_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
      this.loadRole(this.newevent);
    }
  }

  /* Start Fetch Subsidery list from api */
  GetSubsideryList_old() {
    this.HttpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
      (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      this.SubsideryObject=res.list;
      }
      },
      (error) => {
      }
    );
  }
  GetSubsideryList() {
    this.SubsideryObject=[];
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
     if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.SubsideryObject=res;
        for(let x=0;x<this.SubsideryObject.length;x++)
       { 
        this.SubIdList.push(this.SubsideryObject[x].id);
      }
      this.issubsidiaryhidden=false;
      this.issubsidiarydisabled=false;
      //this.resetBaseSearch();
      }
      },
      (error) => {
        alert(error);
       },
       () => {
        if(localStorage.getItem("RoleFilters") != null)
        {const LocDetails:any =localStorage.getItem("RoleFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.role.subsidiaryId=searcheData.filters.subsidiaryId[0];
        this.role.name=searcheData.filters.roleName;
        this.role.active=searcheData.filters.status=="active"?true:false;
        this.loadRole(this.newevent);
        localStorage.removeItem("RoleFilters");
        }
        else
       { this.resetBaseSearch();}
      }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.SubsideryObject.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });

      this.issubsidiaryhidden=true;
      this.issubsidiarydisabled=true;
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.role.subsidiaryId= this.SubsideryObject[0].id
      this.GetAllRoleList(this.SubsideryObject[0].id);
      if(localStorage.getItem("RoleFilters") != null)
      {const LocDetails:any =localStorage.getItem("RoleFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.role.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.role.name=searcheData.filters.roleName;
      this.role.active=searcheData.filters.status=="active"?true:false;
      this.loadRole(this.newevent);
      localStorage.removeItem("RoleFilters");
      }
      else
     { this.resetBaseSearch();}

      
    }
    else if (this.RetloginDetails.userType=='ROOTADMIN'){
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.resetBaseSearch();
    }
  }

  GetAllRoleList(SubsidiaryId: any) {
    try {
      this.HttpService.GetAll(`/masters-ws/roles/get-roles-by-subsidiary?subsidiaryId=${SubsidiaryId}&accessType=` + "APPROVER", this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.length > 0) {
              this.roleNameList = res;
            } else {
              this.roleNameList = [];
            }
          }
        },
        (error) => {
        }
      );
    } catch (err) {
    }
  }

  loadRole(event: any) {
    try {
      this.newevent=event
      this.loading = true;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;    
      this.baseSearch.sortColumn = event.sortField
      ?  event.sortField
      : GlobalConstants.ROLE_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
          if(this.SubIdList.length==0)
         {
          return;
         }
      this.HttpService.Insert('/masters-ws/roles/get/all',this.baseSearch,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
          { 
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { 
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
          {
            if (res && res.list.length > 0) {
            this.roleList = res.list;
            this.totalRecords = res.totalRecords;
            } else {
              this.roleList = [];
            }
            this.loading = false;
          }
        },
        (error) => {
         this.loading = false;
        }
      );
    } catch (err) {
     }
  }

  navigateToAdd() {
    this.router.navigate(['/main/role/update']);
  }
  navigateToAddViewEdit(
    action: string,
    selectedRole: RoleMasterModel = new RoleMasterModel()
  ) {
    let roleId = null;
    if (selectedRole?.id) {
      roleId = selectedRole.id;
      this.router.navigate(['/main/role/action', action, roleId]);
    } else {
      this.router.navigate(['/main/role/action', action]);
    }
   }
//   exportPdf() {
//     import("jspdf").then(jsPDF => {
//         import("jspdf-autotable").then(x => {
//             const doc = new jsPDF.default();
//             (doc as any).autoTable(this.exportColumns, this.roleList);
//             doc.save('roles.pdf');
//         })
//     })
// }



  /* Start fetch filter list of supplier from api */
  findby(event: any){
    let subsidyList:any=[];
    subsidyList.push(this.role.subsidiaryId);
    this.baseSearch.filters={
      subsidiaryId: subsidyList,
      roleName: this.role.name,
      status: this.role.active?"active":"inactive",
      access:this.role.accesstype
  }
  this.baseSearch.pageNumber=-1;
    this.loadRole(this.newevent);
  }
  /* End filter list of supplier from api */
    GetAllRoles() {
      try {
        var obj={
          filters: {
        },
          pageNumber: 0,
          pageSize: 1000,
          sortColumn: "subsidiary_id",
          sortOrder: "asc"
      }
        this.HttpService.Insert('/masters-ws/roles/get/all',obj,this.RetloginDetails.token).subscribe(
          (res) => {

            if(res.status == 401)
            { 
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { 
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else
            {
              if (res && res.list.length > 0) {
                  this.roleNameList = res.list;
                } else {
                  this.roleNameList = [];
                }
            }
          },
          (error) => {
          }
        );
      } catch (err) {
       }
    }
    Reset()
    {
      if(this.RetloginDetails.userType=='SUPERADMIN')
      {
        this.role.subsidiaryId =undefined;
      }
   
      this.role.name=undefined;
      this.roleNameList=[];
      this.role.active=true;
      this.resetBaseSearch();
      this.baseSearch.pageNumber=-1;
      this.loadRole(this.newevent);
    }

    showAlert(AlertMSG:string) {
      this.toastService.addSingle(
        'error',
        'Alert',
        AlertMSG
      );
    }


    //List Export option Start

    //Start PDF
    generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.ROLE_TABLE_SORT_COLUMN;
      this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};

      this.HttpService.Insert('/masters-ws/roles/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.roleNameListPrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {
                  if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){   
                  this.roleNameListPrint.push({
                    'id': RetData[i].id,    
                    'subsidiaryName':RetData[i].subsidiaryName, 
                    'name': RetData[i].name,
                    'active': RetData[i].active,
                });
              }
                else{
                  this.roleNameListPrint.push({
                    'Role ID': RetData[i].id,
                    'Subsidiary':RetData[i].subsidiaryName,
                    'Role Name': RetData[i].name,
                    'Status': RetData[i].active,
                  });
                }

              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    exportPdf() {
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          //this.= this.employeeExport;
          //this.employeelist=[];
          (doc as any).autoTable(this.exportColumns, this.roleNameListPrint);
          doc.save('role.pdf');
        })
      })
    }

  //End PDF

  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');

   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.roleNameListPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.roleNameListPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'role');
           this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
  //End Excel 
    //List Export option End

    editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("RoleFilters") != null)
    {
      localStorage.removeItem("RoleFilters");
    }
    localStorage.setItem("RoleFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/role/action', actionType, mainId]);
   }


   onRowSelect(event: any) {
    let roleId = event.data.id;
    
    this.router.navigate(['/main/role/action/view',roleId]);
  }


}
