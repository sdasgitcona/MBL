import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { AddressComponent } from 'src/app/shared/shared-components/address/address.component';
import { CountryModel } from 'src/app/shared/shared-components/address/model/address.model';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { Subsidiary } from '../../subsidiary/Model/subsidiary-model';
import { SubsidiaryAddress, SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { RestrictedDepartment, RoleMasterModel, RolePermission } from '../model/role-model';
@Component({
  selector: 'app-role-add-edit',
  templateUrl: './role-add-edit.component.html',
  styleUrls: ['./role-add-edit.component.scss']
})
export class RoleAddEditComponent implements OnInit {
  role: RoleMasterModel = new RoleMasterModel();
  selectedrolePermissions: RolePermission = new RolePermission();
  totalpermisions: number = 0;
  roleId: number;
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  roleHistoryList: HistoryModel[] = [];
  Subsidiarylist: any[] = [];
  accessPointOptions: any;
  //departmentOptions:any;
  departmentOptions: RestrictedDepartment[] = [];
  restrictedDepartmentsCopy: RestrictedDepartment[] = [];
  checked: boolean;
  selectedIndex: any
  isReloadSub: boolean;
  adminrole: boolean;
  approverrole: boolean;
  venderrole: boolean=false;
  department: any;
  showloader:boolean=false;
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   isviewEditable:boolean=true;
   RoleAccessPoint:RolePermission[]=[];
   disableSelf:boolean;
   disableApprover:boolean;
   disableSupplier:boolean;
   disableAdminaccess:boolean;
   uniqueModules:any=[];
   MODULE_Master:boolean;
   MODULE_Setup:boolean;
   MODULE_Transaction:boolean;
   MODULE_Approval:boolean;
   ShowHistory:boolean;
   loggedAccountId:any;
   RetloginDetails:any;
   RetRoleDetails:any;
   // For Role Base Access
  constructor(
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
  ) {
    //this.accessPointOptions = ['AP Invoice', 'Payment', 'Vendor Report', 'Mail Dashboard'];
    //this.departmentOptions = ['ABC', 'BCA'];
    this.accessPointOptions = [{id:'Company Information', value:'Company Information'},{id:'Subsidiary', value:'Subsidiary'},
    {id:'Fiscal Calendar', value:'Fiscal Calendar'}, {id:'Item', value:'Item'}, {id:'Tax Rate Rule', value:'Tax Rate Rule'},
    {id:'Tax Group', value:'Tax Group'}, {id:'Supplier', value:'Supplier'}, {id:'Employee', value:'Employee'}, 
    {id:'Account Code', value:'Account Code'}, {id:'Bank', value:'Bank'}, {id:'Role', value:'Role'},
    {id:'Approval Preference', value:'Approval Preference'}, {id:'Document Sequencing', value:'Document Sequencing'},
    {id:'Project', value:'Project'}, {id:'Location', value:'Location'}, {id:'Currency', value:'Currency'},
    {id:'General Preference', value:'General Preference'}, {id:'Purchase Requisition', value:'Purchase Requisition'},
    {id:'Auto Create PO & RFQ', value:'Auto Create PO & RFQ'}, {id:'Request For Quotation', value:'Request For Quotation'},
    {id:'Quotation Analysis', value:'Quotation Analysis'}, {id:'Purchase Order', value:'Purchase Order'},
    {id:'Goods Received Note', value:'Goods Received Note'}, {id:'AP Invoice', value:'AP Invoice'},
    {id:'AP Invoice by Supplier', value:'AP Invoice by Supplier'}, {id:'PR Approval', value:'PR Approval'}, {id:'PO Approval', value:'PO Approval'},
    {id:'AP Invoice Approval', value:'AP Invoice Approval'}, {id:'RTV Approval', value:'RTV Approval'},
    {id:'Debit Note Approval', value:'Debit Note Approval'}, {id:'Supplier Approval', value:'Supplier Approval'},
    {id:'Advance Payment Approval', value:'Advance Payment Approval'}, {id:'Return to Supplier', value:'Return to Supplier'},
    {id:'Debit Note', value:'Debit Note'}, {id:'Advance Payment', value:'Advance Payment'}, {id:'Make Payment', value:'Make Payment'},
    {id:'Make Payment Approval', value:'Make Payment Approval'},
    {id:'Report', value:'Report'}, {id:'Manage Integration', value:'Manage Integration'}, {id:'Template Mapping', value:'Template Mapping'},
    {id:'Department', value:'Department'},
  ]
    let department1 = new RestrictedDepartment();
    department1.departmentId = 1;
    department1.departmentName = 'Admin';
    let department2 = new RestrictedDepartment();
    department2.departmentId = 2;
    department2.departmentName = 'Finance';
    let department3 = new RestrictedDepartment();
    department3.departmentId = 3;
    department3.departmentName = 'Purchase';
    let department4 = new RestrictedDepartment();
    department4.departmentId = 3;
    department4.departmentName = 'HR';
    //this.departmentOptions.push(department1, department2, department3, department4);
  }
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
const LDetails:any=localStorage.getItem("LoggerDTLS");
this.RetloginDetails = JSON.parse(LDetails);
 // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;

 this.loggedAccountId=role_Dtls[0].accountId;
 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Role")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access
    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.roleId = +params['id']; // (+) converts string 'id' to a number
            this.GetRolebyId();
          }
          this.assignMode(params['action']);
          this.GetSubsideryList();
        } else {
        }
      },
      (error) => {
      }
    );
    this.totalpermisions = this.role.rolePermissions.length;
    if(this.addMode){
      this.GetAccessPointList('ADMIN');
    }
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        //this.role.inactive=false;
       // this.role.rolePermissions.push(new RolePermission());
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;
      default:
        break;
    }
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  GetRolebyId() {
    this.showloader=true;
    this.httpService
      .GetById('/masters-ws/roles/get?id=' + this.roleId, this.roleId,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        this.GetDepartmentList(res.subsidiaryId);
        setTimeout(() => {
          for(let k=0;k<res.rolePermissions.length;k++)
          {
            res.rolePermissions[k].isDisabled=true;
          }
          this.RoleAccessPoint=[];
          this.RoleAccessPoint=res.rolePermissions;
          this.uniqueModules = this.RoleAccessPoint.map(item => item.moduleName).filter((value, index, self) => self.indexOf(value) === index);
          this.MODULE_Setup =false;
          this.MODULE_Master =false;
          this.MODULE_Transaction =false;
          this.MODULE_Approval =false;
         for(let x=0;x<this.uniqueModules.length;x++)
          {
            if(this.uniqueModules[x] == "Setup")
             { this.MODULE_Setup =true}
             if(this.uniqueModules[x] == "Master")
             { this.MODULE_Master=true}
             if(this.uniqueModules[x] == "Transaction")
             { this.MODULE_Transaction=true}
             if(this.uniqueModules[x] == "Approval")
             { this.MODULE_Approval=true}
          }
          this.role = res;
        
          this.venderrole = this.role.selectedAccess == "VENDOR" ? true : false;
          this.adminrole = this.role.selectedAccess == "ADMIN" || this.role.selectedAccess == "ADMIN_APPROVER" ? true : false;
          this.approverrole = this.role.selectedAccess == "APPROVER" || this.role.selectedAccess == "ADMIN_APPROVER"? true : false;
          if (
            this.role.restrictedDepartments &&
            this.role.restrictedDepartments.length > 0
          ) {
            if (this.viewMode) {
              var rolelist = this.role.restrictedDepartments.map(
                (x) => x.departmentName
              );
              this.department = rolelist.join(',');
            } else {
              let copiedValue = JSON.parse(
                JSON.stringify(this.role.restrictedDepartments)
              );
              //this.role.restrictedDepartments = [];
              this.restrictedDepartmentsCopy = [];
              copiedValue.forEach((element: any) => {
                let item = this.departmentOptions.find(
                  (o) => o.departmentId == element.departmentId
                );
                if (item) {
                  let role1 = new RestrictedDepartment();
                  role1.departmentId = item.departmentId;
                  role1.departmentName = item.departmentName;
                  this.restrictedDepartmentsCopy?.push(role1);
                }
              });
            }
          }
          this.ShowHistory=true;
          this.disableApprover=true;
          this.disableSupplier=true;
          this.disableAdminaccess=true;
          this.disableSelf=true;
          this.showloader=false;
        }, 250);
        
        //For disbaled Delete button
       
      }
      });
  }
  //--Department List
  GetDepartmentList(subsidiaryId:any) {
    subsidiaryId=Number(subsidiaryId);
    this.httpService.GetAll('/masters-ws/department/get-department-by-subsidiary?subsidiaryId='+subsidiaryId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      if(res)
  {   this.departmentOptions=[];
    for(let x=0;x<res.length;x++)
    { this.departmentOptions.push({
      departmentId:  res[x].id,
      departmentName: res[x].departmentName
    })
  }
  }
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}
//--Access Point
giveAllAccessPoint()
{
  for (let i = 0; i < this.accessPointOptions.length; i++) {
    this.role.rolePermissions.push({
      accessPoint:this.accessPointOptions[i].value,
      create:true,
      edit:true,
      view:true
    })
  }
}
  /* End Fetch Subsidery list from api */
  /* Start fetching History details */
  LoadHistory() {
    this.showloader=true;
    if (this.roleHistoryList.length == 0)
      this.httpService
        .GetById(
          `/masters-ws/roles/get/history?id=${this.roleId}&pageSize=100`,
          this.roleId,this.RetloginDetails.token
        )
        .subscribe((res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
        this.showloader=false;
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
        this.showloader=false;
      }
      else
      {
          this.roleHistoryList = res;
          this.showloader=false;
        }
        });
  }
  /* End fetching History details */
  handleTabChange(event: any) {
    //alert(event.originalEvent.currentTarget.innerText == "History")
    //alert(event.originalEvent.target.innerText)
    //Fetch History if the selected tab index is History Tab index
    if (event.originalEvent.target.innerText == "History") {
      this.LoadHistory();
    }
  }
  handleToggleEvent(event: any) {
    event.originalEvent.cancelBubble = true;
  }
  saveRole() {
    var isvalidate=true;
    this.role.selectedAccess = this.adminrole && this.approverrole ?"ADMIN_APPROVER" :this.venderrole ? "VENDOR" : this.adminrole ? "ADMIN" : this.approverrole ? "APPROVER" : ""
    if (this.role.name == undefined || this.role.name == "")
    {
      this.showAlert('Please enter Role Name !');
      return false;
    }
    if (this.role.restrictedDepartments.length > 0) {
      var output = this.role.restrictedDepartments.filter(
        (val, i) => {
          var t = !this.restrictedDepartmentsCopy.find(NewArrayobj => NewArrayobj.departmentId == val.departmentId)
           if (t == false) {
            val.deleted = false;
          } else {
            val.deleted = true;
            if (!val.id) {
              this.role.restrictedDepartments.splice(i, 1);
            }
          }
        }
      );
      var output1 = this.restrictedDepartmentsCopy.filter(
        val => !this.role.restrictedDepartments.find(myArrayobj => myArrayobj.departmentId == val.departmentId));
        output1.map(x => {
        this.role.restrictedDepartments.push({ departmentId: x.departmentId, departmentName: x.departmentName })
      })
    } 
    else {
      this.restrictedDepartmentsCopy.map((x, i) => {
        this.role.restrictedDepartments.push({ departmentId: x.departmentId, departmentName: x.departmentName })
      })
    }
    if(!this.role.subsidiaryId){
      this.toastService.addSingle(
        'error',
        'Error',
        'Please select Accessible Subsidiary'
      );
      return
    }
    this.role.rolePermissions=this.RoleAccessPoint;
     if(this.role.rolePermissions.length>0){
      var isvalidate=true;
      if(this.addMode){
      this.role.rolePermissions.map((data,index:any)=>{
        data.id=undefined
      });
    }
       }
       else{
        this.showAlert("No Role persmission list found")
       }
     if(this.addMode){
      this.role.createdBy=this.RetloginDetails.username;this.role.lastModifiedBy=this.RetloginDetails.username
      }
     else if(!this.addMode){
      this.role.lastModifiedBy=this.RetloginDetails.username
      }
      if(localStorage.getItem("LoggerDTLS") == null){ //Logout from one tab then forcefully page will logout.
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }else {
        this.role.accountId=this.loggedAccountId;
      if(isvalidate){
        this.showloader=true;
        this.httpService.Insert('/masters-ws/roles/save', this.role,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

       if (res && res.id > 0) {
          //this.saveAddress();
          this.showloader=false;
          this.showSuccess();
          if(this.addMode){
            this.router.navigate(['/main/role/action', 'view',res.id]);
          }else{
            this.router.navigate(['/main/role/list']);
          }
        } else {
          this.showloader=false;
          this.showError();
        }
      }
      },
      (error) => {
        this.showloader=false;
       this.showAlert(error);
      },
      () => { }
    );
    }
      }
     
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Role Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving role!'
    );
  }
  clearRoleData() {
      this.router.navigate(['/main/role/list']);
  }
  checked2: boolean = true;
  // inactive:boolean = true;
  /* Start Reload Subsidery */
  reloadSubsidary() {
    this.isReloadSub = true;
    this.role.subsidiaryId=0;
    this.GetSubsideryList();
    this.isReloadSub = false;
  }
  /* End Reload Subsidery */
  /* Start Fetch Subsidery list from api */
  GetSubsideryList() {
    this.Subsidiarylist=[];
  
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist=res;
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
       //this.loadSuppliers('');
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
    }
  }

  /* End Fetch Subsidery list from api */
  onVanderroleChange() {
    if( this.venderrole == true){
      if(this.addMode)
      {
        this.role.self=true;
      }
      
    this.adminrole = false;
    this.approverrole = false;
    this.disableApprover=true;
    }
    else
    {
      if(this.addMode)
      {
        this.role.self=false;
      }
      this.disableApprover=false;
    }
    this.GetAccessPointList();
  }
  onAdminroleChange() {
    if( this.adminrole == true){
    this.venderrole = false;
    //this.approverrole = false;
    this.disableApprover=false;
    }
    this.GetAccessPointList();
  }
  onApproverroleChange() {
    this.venderrole = false;
    //this.adminrole = false;
    this.GetAccessPointList();
    if(this.approverrole == false)
    {this.chkApprovarAccess();}
  }
  addpermissons() {
    let newpermisions=new RolePermission();
    newpermisions.view=true;
    this.role.rolePermissions.push(newpermisions);
    this.totalpermisions = this.role.rolePermissions.length;
  }
  deletepermissons(index: number,Data:any) {
    if(this.editMode && Data == true){
      this.showAlert("You cannot delete this Access Point !");
      //this.role.rolePermissions[index].deleted=true;
      }else{
        if (index >= 0) {
          this.role.rolePermissions.splice(index, 1);
        }
      }
  }
  onasscepointchange(access: string, index: number) {
    for (let i = 0; i < this.role.rolePermissions.length; i++) {
      debugger;
      if (i !== index) {
        if (this.role.rolePermissions[i].accessPoint == access) {
          //this.role.rolePermissions[index].accessPoint="";
          this.role.rolePermissions[index] = new RolePermission();
          this.toastService.addSingle(
            'error',
            'Error',
            'Please choose different access point'
          );
          return
        }

      }
    }
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  GetAccessPointList_bak(Default:any="") {
    //this.role.selectedAccess; 
    //let accessBy:string= this.venderrole ? "SUPPLIER":'';

    let accessBy:string= this.venderrole ? "SUPPLIER" : this.adminrole ? "ADMIN" : this.approverrole ? "APPROVER" : this.adminrole && this.approverrole ?"ADMIN_APPROVER":Default? Default:"ADMIN"; 
    if(accessBy !=""){
    this.showloader=true;
    this.httpService
    .GetById('/masters-ws/roles/get-access-point-by-selected-access?selectedAccess=' + accessBy, accessBy,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

      
      if(!this.venderrole)
      {this.RoleAccessPoint=[];this.RoleAccessPoint = res;}
      this.RoleAccessPoint.map((data,index:any)=>{
        
        this.RoleAccessPoint[index].create=this.adminrole == true ? true:false;
        this.RoleAccessPoint[index].edit=this.adminrole == true ? true:false;
        this.RoleAccessPoint[index].view=this.adminrole == true ? true:false;
        // if(data.create)
        // {
        //   this.RoleAccessPoint[index].create=this.adminrole == true ? true:false;
        // }
        // if(data.edit)
        // {
        //   this.RoleAccessPoint[index].edit=this.adminrole == true ? true:false;
        // }
        // if(data.view)
        // {
        //   this.RoleAccessPoint[index].view=this.adminrole == true ? true:false;
        // }
      });
      this.uniqueModules = this.RoleAccessPoint.map(item => item.moduleName).filter((value, index, self) => self.indexOf(value) === index);
      this.MODULE_Setup =false;
      this.MODULE_Master =false;
      this.MODULE_Transaction =false;
      this.MODULE_Approval =false;
     for(let x=0;x<this.uniqueModules.length;x++)
      {
        if(this.uniqueModules[x] == "Setup")
         { this.MODULE_Setup =true}
         if(this.uniqueModules[x] == "Master")
         { this.MODULE_Master=true}
         if(this.uniqueModules[x] == "Transaction")
         { this.MODULE_Transaction=true}
         if(this.uniqueModules[x] == "Approval")
         { this.MODULE_Approval=true}
      }
      this.showloader=false;
    }
      },
      (error) => {
      this.showAlert(error);
      this.showloader=false;
      }
    );
    }
    else
  { this.RoleAccessPoint =[]}
    
  }

  GetAccessPointList(Default: any = "") {
    //this.role.selectedAccess; 
    //let accessBy:string= this.venderrole ? "SUPPLIER":'';

    let accessBy: string = this.venderrole ? "SUPPLIER" : this.adminrole ? "ADMIN" : this.approverrole ? "APPROVER" : this.adminrole && this.approverrole ? "ADMIN_APPROVER" : Default ? Default : "ADMIN";
    if (accessBy != "") {
      this.showloader = true;
      this.httpService
        .GetById('/masters-ws/roles/get-access-point-by-selected-access?selectedAccess=' + accessBy, accessBy, this.RetloginDetails.token)
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {

            if (!this.venderrole) { this.RoleAccessPoint = []; this.RoleAccessPoint = res; }
            this.RoleAccessPoint.map((data, mainIndex: any) => {
              res.map((vendorData: any, index: any) => {
                //if ((this.venderrole == true && this.RoleAccessPoint[index].accessPoint =='Purchase Order') || (this.venderrole == true && this.RoleAccessPoint[index].accessPoint =='AP invoice'))
                if (this.venderrole == true && data.accessPoint == vendorData.accessPoint) 
                {
                  this.RoleAccessPoint[mainIndex].create = false;
                  this.RoleAccessPoint[mainIndex].edit = false;
                  this.RoleAccessPoint[mainIndex].view = true;
                }

                else if (this.venderrole == false) {
                  this.RoleAccessPoint[mainIndex].create = this.adminrole == true ? true : false;
                  this.RoleAccessPoint[mainIndex].edit = this.adminrole == true ? true : false;
                  this.RoleAccessPoint[mainIndex].view = this.adminrole == true ? true : false;
                }
              });
            });

            // if (!this.venderrole) { this.RoleAccessPoint = []; this.RoleAccessPoint = res; }
            // this.RoleAccessPoint.map((data, index: any) => {
            //   res.map((vendorData: any, index: any) => {
            //     if (this.venderrole == true && this.RoleAccessPoint[index].accessPoint == res[index].accessPoint) {
            //       this.RoleAccessPoint[index].create = false;
            //       this.RoleAccessPoint[index].edit = false;
            //       this.RoleAccessPoint[index].view = true;
            //     }

            //     else if (this.venderrole == false) {
            //       this.RoleAccessPoint[index].create = this.adminrole == true ? true : false;
            //       this.RoleAccessPoint[index].edit = this.adminrole == true ? true : false;
            //       this.RoleAccessPoint[index].view = this.adminrole == true ? true : false;
            //     }
            //   });
            // });

            this.uniqueModules = this.RoleAccessPoint.map(item => item.moduleName).filter((value, index, self) => self.indexOf(value) === index);
            this.MODULE_Setup = false;
            this.MODULE_Master = false;
            this.MODULE_Transaction = false;
            this.MODULE_Approval = false;
            for (let x = 0; x < this.uniqueModules.length; x++) {
              if (this.uniqueModules[x] == "Setup") { this.MODULE_Setup = true }
              if (this.uniqueModules[x] == "Master") { this.MODULE_Master = true }
              if (this.uniqueModules[x] == "Transaction") { this.MODULE_Transaction = true }
              if (this.uniqueModules[x] == "Approval") { this.MODULE_Approval = true }
            }
            this.showloader = false;
          }
        },
          (error) => {
            this.showAlert(error);
            this.showloader = false;
          }
        );
    }
    else { this.RoleAccessPoint = [] }

  }
  
  saveRoleData()
  {
    console.log(this.RoleAccessPoint);
  }
  chkApprovarAccess()
  {
    let isapproverrole:boolean=false;
    this.RoleAccessPoint.map((data,index:any)=>{
      if(data.create && data.moduleName== "Approval")
      {
        isapproverrole=true;
      }
    });
    if(isapproverrole)
    {
      this.approverrole=true;
    }
    else{
      this.approverrole=false;
    }
  }
  checkOthers(Module:any,RowIndex:number)
  {
    this.RoleAccessPoint.map((data,index:any)=>{
      if(data.moduleName == Module && index == RowIndex)
      {
        data.edit=true;
        data.view=true;
      }
    });
  }
}
