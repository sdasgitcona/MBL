export class dashboardModel {
    subsidiaryId?: number;
    subsidiaryName?: string;
    Active_Supplier?:number;
    InActive_Supplier?:number;

}

export class Active_Supplier{
    name?:string;
    count?:number;
    category?:string;
    value?:number;
}