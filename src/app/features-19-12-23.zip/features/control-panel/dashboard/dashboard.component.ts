import { Component, OnInit, Inject, PLATFORM_ID, NgZone } from '@angular/core';

import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import * as am5radar from "@amcharts/amcharts5/radar";
import * as am5percent from "@amcharts/amcharts5/percent";
import am5themes_Animated from '@amcharts/amcharts5/themes/Animated';

import {MenuItem} from 'primeng/api';
import {MessageService} from 'primeng/api';
import { PrimeNGConfig } from 'primeng/api';
import { isPlatformBrowser } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

am5.addLicense("AM5C367311118");

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

 
  items1: MenuItem[];
  isFullscreen: any = false;

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private router: Router,
    private zone: NgZone,
    private messageService: MessageService,
    private primengConfig: PrimeNGConfig
  ) { }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    this.primengConfig.ripple = true;
      this.items1 = [
        {
            label: 'Options',
            items: [{
                label: 'Update',
                icon: 'pi pi-refresh',
                command: () => {
                    this.update();
                }
            },
            {
                label: 'Delete',
                icon: 'pi pi-times',
                command: () => {
                    this.delete();
                }
            },
            {
              label: 'Maximize',
              icon: 'pi pi-times',
              
          }
        ]},
        {
            label: 'Navigate',
            items: [{
                label: 'Angular Website',
                icon: 'pi pi-external-link',
                url: 'http://angular.io'
            },
            {
                label: 'Router',
                icon: 'pi pi-upload',
                routerLink: '/fileupload'
            }
        ]}
      ];

      this.initAPIGuage();
      this.initbarSort();
  }

  update() {
    this.messageService.add({severity:'success', summary:'Success', detail:'Data Updated'});
  }

  delete() {
    this.messageService.add({severity:'warn', summary:'Delete', detail:'Data Deleted'});
  }

  toggleFullscreen(){
    let div = document.querySelector('.fullscreenDiv');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }
  toggleFullscreen2(){
    let div = document.querySelector('.fullscreenDiv2');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }
  toggleFullscreen3(){
    let div = document.querySelector('.fullscreenDiv3');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }
  toggleFullscreen4(){
    let div = document.querySelector('.fullscreenDiv4');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }




  initAPIGuage(){
    let root = am5.Root.new("totalBills");
  // Set themes
// https://www.amcharts.com/docs/v5/concepts/themes/
root.setThemes([
  am5themes_Animated.new(root)
]);


// Create chart
// https://www.amcharts.com/docs/v5/charts/radar-chart/
let chart = root.container.children.push(am5radar.RadarChart.new(root, {
  panX: false,
  panY: false,
  startAngle: 160,
  endAngle: 380,
  innerRadius: -20
}));


// Create axis and its renderer
// https://www.amcharts.com/docs/v5/charts/radar-chart/gauge-charts/#Axes
let axisRenderer = am5radar.AxisRendererCircular.new(root, {
  innerRadius: 0
});

axisRenderer.grid.template.setAll({
  stroke: root.interfaceColors.get("background"),
  visible: true,
  strokeOpacity: 0.8
});

let xAxis = chart.xAxes.push(am5xy.ValueAxis.new(root, {
  maxDeviation: 0,
  min: 0,
  max: 100,
  strictMinMax: true,
  renderer: axisRenderer
}));


// Add clock hand
// https://www.amcharts.com/docs/v5/charts/radar-chart/gauge-charts/#Clock_hands
let axisDataItem = xAxis.makeDataItem({});

let clockHand = am5radar.ClockHand.new(root, {
  pinRadius: am5.percent(5),
  radius: am5.percent(100),
  bottomWidth: 10
})

let bullet = axisDataItem.set("bullet", am5xy.AxisBullet.new(root, {
  sprite: clockHand
}));

xAxis.createAxisRange(axisDataItem);

let label = chart.radarContainer.children.push(am5.Label.new(root, {
  fill: am5.color(0xffffff),
  centerX: am5.percent(50),
  textAlign: "center",
  centerY: am5.percent(50),
  fontSize: "1em"
}));

axisDataItem.set("value", 50);
bullet.get("sprite").on("rotation", function () {
  let value = axisDataItem.get("value");  
//   let text = Math.round(axisDataItem.get("value")).toString();
//   let fill = am5.color(0x000000);
//   xAxis.axisRanges.each(function (axisRange) {
//     if (value >= axisRange.get("value") && value <= axisRange.get("endValue")) {
//       fill = axisRange.get("axisFill").get("fill");
//     }
//   })

//   label.set("text", Math.round(value).toString());

//   clockHand.pin.animate({ key: "fill", to: fill, duration: 500, easing: am5.ease.out(am5.ease.cubic) })
//   clockHand.hand.animate({ key: "fill", to: fill, duration: 500, easing: am5.ease.out(am5.ease.cubic) })
 });

setInterval(function () {
  axisDataItem.animate({
    key: "value",
    to: Math.round(Math.random() * 140 - 40),
    duration: 5000,
    easing: am5.ease.out(am5.ease.cubic)
  });
}, 2000)

chart.bulletsContainer.set("mask", undefined);


// Create axis ranges bands
// https://www.amcharts.com/docs/v5/charts/radar-chart/gauge-charts/#Bands
let bandsData = [ {
  title: "Foundational",
  color: "#fdae19",
  lowScore: 0,
  highScore: 20
}, {
  title: "Developing",
  color: "#f3eb0c",
  lowScore: 20,
  highScore: 40
}, {
  title: "Maturing",
  color: "#b0d136",
  lowScore: 40,
  highScore: 60
}, {
  title: "Sustainable",
  color: "#54b947",
  lowScore: 60,
  highScore: 80
}, {
  title: "High Performing",
  color: "#0f9747",
  lowScore: 80,
  highScore: 100
}];

am5.array.each(bandsData, function (data) {
  let axisRange = xAxis.createAxisRange(xAxis.makeDataItem({}));

  axisRange.setAll({
    value: data.lowScore,
    endValue: data.highScore
  });

  axisRange.get("axisFill")?.setAll({
    visible: true,
    fill: am5.color(data.color),
    fillOpacity: 0.8
  });

  // axisRange.get("axisFill").setAll({
  //   visible: true,
  //   fill: am5.color(data.color),
  //   fillOpacity: 0.8
  // });

  // axisRange.get("label").setAll({
  //   text: data.title,
  //   inside: true,
  //   radius: 15,
  //   fontSize: "0.9em",
  //   fill: root.interfaceColors.get("background")
  // });
});


// Make stuff animate on load
chart.appear(1000, 100);
  }

  initbarSort(){
    let root = am5.Root.new("chartbarSort");


// Set themes
// https://www.amcharts.com/docs/v5/concepts/themes/
root.setThemes([
  am5themes_Animated.new(root)
]);


// Create chart
// https://www.amcharts.com/docs/v5/charts/xy-chart/
let chart = root.container.children.push(am5xy.XYChart.new(root, {
  panX: false,
  panY: false,
  wheelX: "panX",
  wheelY: "zoomX",
  layout: root.verticalLayout
}));


// Data
let colors = chart.get("colors");

let data = [{
  country: "Mar 22",
  visits: 725,
  columnSettings: { fill: colors?.next() }
}, {
  country: "Apr 22",
  visits: 625,
  columnSettings: { fill: colors?.next() }
}, {
  country: "May 22",
  visits: 602,
  columnSettings: { fill: colors?.next() }
}, {
  country: "Jun 22",
  visits: 509,
  columnSettings: { fill: colors?.next() }
}, {
  country: "Jul 22",
  visits: 322,
  columnSettings: { fill: colors?.next() }
}, {
  country: "Aug 22",
  visits: 214,
  columnSettings: { fill: colors?.next() }
}, {
  country: "Sep 22",
  visits: 204,
  columnSettings: { fill: colors?.next() }
}, {
  country: "Oct 22",
  visits: 198,
  columnSettings: { fill: colors?.next() }
}, {
  country: "Nov 22",
  visits: 165,
  columnSettings: { fill: colors?.next() }
}, {
  country: "Dec 22",
  visits: 93,
  columnSettings: { fill: colors?.next() }
}, {
  country: "Jan 23",
  visits: 41,
  columnSettings: { fill: colors?.next() }
}, {
  country: "Feb 23",
  visits: 41,
  columnSettings: { fill: colors?.next() }
}
];


// Create axes
// https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
let xRenderer = am5xy.AxisRendererX.new(root, {
  minGridDistance: 30
})

let xAxis = chart.xAxes.push(am5xy.CategoryAxis.new(root, {
  categoryField: "country",
  renderer: xRenderer,
  bullet: function(root, axis, dataItem) {
    return am5xy.AxisBullet.new(root, {
      location: 0.5,
      sprite: am5.Picture.new(root, {
        width: 24,
        height: 24,
        centerY: am5.p50,
        centerX: am5.p50,
      })
    });
  }
}));

xRenderer.grid.template.setAll({
  location: 1
})

xRenderer.labels.template.setAll({
  paddingTop: 20
});

xAxis.data.setAll(data);

let yAxis = chart.yAxes.push(am5xy.ValueAxis.new(root, {
  renderer: am5xy.AxisRendererY.new(root, {
    strokeOpacity: 0.1
  })
}));


// Add series
// https://www.amcharts.com/docs/v5/charts/xy-chart/series/
let series = chart.series.push(am5xy.ColumnSeries.new(root, {
  xAxis: xAxis,
  yAxis: yAxis,
  valueYField: "visits",
  categoryXField: "country"
}));

series.columns.template.setAll({
  tooltipText: "{categoryX}: {valueY}",
  tooltipY: 0,
  strokeOpacity: 0,
  templateField: "columnSettings"
});

series.data.setAll(data);


// Make stuff animate on load
// https://www.amcharts.com/docs/v5/concepts/animations/
series.appear();
chart.appear(1000, 100);

  };


}
