import { Component, OnInit, Inject, NgZone, PLATFORM_ID,VERSION } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { dashboardModel, Active_Supplier } from '../model/dashboard-model';
import { CommonHttpService } from 'src/app/core/services/common-http.service';

//amCharts imports
import * as am5 from '@amcharts/amcharts5';
import * as am5xy from '@amcharts/amcharts5/xy';
import am5themes_Animated from '@amcharts/amcharts5/themes/Animated';
import * as am5percent from "@amcharts/amcharts5/percent";
// import * as am5 from '@amcharts/amcharts5';
// import * as am5xy from '@amcharts/amcharts5/xy';
// import * as am5percent from "@amcharts/amcharts5/percent";
// import * as am5radar from "@amcharts/amcharts5/radar";
// import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";

// Amchart License Part
am5.addLicense("AM5C367311118");
// End Amchart License Part


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  private root!: am5.Root;

  Subsidiarylist: any;
  dashboard: dashboardModel = new dashboardModel();
  active_supplier: Active_Supplier[] = [];
  router: any;

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private zone: NgZone,
    private httpService: CommonHttpService,
  ) { }

  ngOnInit(): void {
    this.GetSubsideryList();
  }


  // Run the function only in the browser
  browserOnly(f: () => void) {
    if (isPlatformBrowser(this.platformId)) {
      this.zone.runOutsideAngular(() => {
        f();
      });
    }
  }

  ngAfterViewInit() {
    // BarChart1 code goes in here
    this.browserOnly(() => {
      let root = am5.Root.new("BarChart1");

      root.setThemes([am5themes_Animated.new(root)]);
      let chart = root.container.children.push(
        am5xy.XYChart.new(root, {
          panY: false,
          layout: root.verticalLayout
        })
      );
      // Define data
      let data = [
        {
          category: "Research",
          value1: 1000,
          value2: 588
        },
        {
          category: "Marketing",
          value1: 1200,
          value2: 1800
        },
        {
          category: "Sales",
          value1: 850,
          value2: 1230
        }
      ];
      // Create Y-axis
      let yAxis = chart.yAxes.push(
        am5xy.ValueAxis.new(root, {
          renderer: am5xy.AxisRendererY.new(root, {})
        })
      );
      // Create X-Axis
      let xAxis = chart.xAxes.push(
        am5xy.CategoryAxis.new(root, {
          renderer: am5xy.AxisRendererX.new(root, {}),
          categoryField: "category"
        })
      );
      xAxis.data.setAll(data);

      // Create series
      let series1 = chart.series.push(
        am5xy.ColumnSeries.new(root, {
          name: "Series",
          xAxis: xAxis,
          yAxis: yAxis,
          valueYField: "value1",
          categoryXField: "category"
        })
      );
      series1.data.setAll(data);

      let series2 = chart.series.push(
        am5xy.ColumnSeries.new(root, {
          name: "Series",
          xAxis: xAxis,
          yAxis: yAxis,
          valueYField: "value2",
          categoryXField: "category"
        })
      );
      series2.data.setAll(data);

      // Add legend
      let legend = chart.children.push(am5.Legend.new(root, {}));
      legend.data.setAll(chart.series.values);

      // Add cursor
      chart.set("cursor", am5xy.XYCursor.new(root, {}));

      this.root = root;
    });
   // End BarChart1


   // Donut Chart 1 chart
  //  https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/

    this.browserOnly(() => {

      let root2 = am5.Root.new("DonutChart1");
      let chart2 = root2.container.children.push(am5percent.PieChart.new(root2, {
        radius: am5.percent(90),
        innerRadius: am5.percent(50),
        layout: root2.horizontalLayout
      }));

      // Create series
      // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Series
      let series = chart2.series.push(am5percent.PieSeries.new(root2, {
        name: "Series",
        valueField: "value",
        categoryField: "category"
      }));
      // Set data
      // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Setting_data
      // series.data.setAll(
      //   this.active_supplier);

      series.data.setAll([
        //this.Subsidiarylist

        {
          category: "Inactive Supplier",
          value: 501.9
        },
        {
          category: "Active Supplier",
          value: 301.9
        },
      ]);

      // Disabling labels and ticks
      series.labels.template.set("visible", false);
      series.ticks.template.set("visible", false);

      // Adding gradients
      series.slices.template.set("strokeOpacity", 0);
      series.slices.template.set("fillGradient", am5.RadialGradient.new(root2, {
        stops: [{
          brighten: -0.8
        }, 
        {
          brighten: -0.8
        },
        {
          brighten: -0.5
        },
        {
          brighten: 0
        },
        {
          brighten: -0.5
        }]
      }));

      // Create legend
      // https://www.amcharts.com/docs/v5/charts/percent-charts/legend-percent-series/
      let legend = chart2.children.push(am5.Legend.new(root2, {
        centerY: am5.percent(50),
        y: am5.percent(50),
        layout: root2.verticalLayout
      }));
      // set value labels align to right
      legend.valueLabels.template.setAll({ textAlign: "right" })
      // set width and max width of labels
      legend.labels.template.setAll({ 
        maxWidth: 140,
        width: 140,
        oversizedBehavior: "wrap"
      });

      legend.data.setAll(series.dataItems);

      // Play initial series animation
      // https://www.amcharts.com/docs/v5/concepts/animations/#Animation_of_series
      series.appear(1000, 100);
    });

  //  End Donut Chart 1 chart


  //  DonutCreate2 chart
    this.browserOnly(() => {

      let root3 = am5.Root.new("DonutChart2");
      let chart3 = root3.container.children.push(am5percent.PieChart.new(root3, {
        radius: am5.percent(90),
        innerRadius: am5.percent(50),
        layout: root3.horizontalLayout
      }));

      // Create series
      // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Series
      let series = chart3.series.push(am5percent.PieSeries.new(root3, {
        name: "Series",
        valueField: "Approval",
        categoryField: "Subsidiary"
      }));

      // Set data
      // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Setting_data
      series.data.setAll([
        {
          Subsidiary: "Pending Approval",
          Approval: 501.9
        },
        {
          Subsidiary: "Approved",
          Approval: 30
        },
      ]);

      // Disabling labels and ticks
      series.labels.template.set("visible", false);
      series.ticks.template.set("visible", false);

      // Adding gradients
      series.slices.template.set("strokeOpacity", 0);
      series.slices.template.set("fillGradient", am5.RadialGradient.new(root3, {
        stops: [
          {
            brighten: -0.8
          },
          {
            brighten: -0.8
          },
          {
            brighten: -0.5
          },
          {
            brighten: 0
          },
          {
            brighten: -0.5
          }
        ]
      }));

      // Create legend
      // https://www.amcharts.com/docs/v5/charts/percent-charts/legend-percent-series/
      let legend = chart3.children.push(am5.Legend.new(root3, {
        centerY: am5.percent(50),
        y: am5.percent(50),
        layout: root3.verticalLayout
      }));
      // set value labels align to right
      legend.valueLabels.template.setAll({ textAlign: "right" })
      // set width and max width of labels
      legend.labels.template.setAll({
        maxWidth: 140,
        width: 140,
        oversizedBehavior: "wrap"
      });
      legend.data.setAll(series.dataItems);

      // Play initial series animation
      // https://www.amcharts.com/docs/v5/concepts/animations/#Animation_of_series
      series.appear(1000, 100);
    });
   // End DonutCreate2 chart


   // Active Item Pie Chart 1
    this.browserOnly(() => {
      // Create root and chart
      let root4 = am5.Root.new("PieChart1");
      let chart4 = root4.container.children.push(am5percent.PieChart.new(root4, {
        // startAngle: -180,
        // endAngle: 0,
        layout: root4.verticalLayout
      })
      );
      // Define data
      let data = [{
        Iteam: "Inactive",
        sales: 100000
      }, {
        Iteam: "Active",
        sales: 160000
      }
      ];
      // Create series
      let series = chart4.series.push(
        am5percent.PieSeries.new(root4, {
          name: "Series",
          valueField: "sales",
          categoryField: "Iteam",
          // startAngle: -180,
          // endAngle: 0
        })
      );
      series.data.setAll(data);

      // Add legend
      let legend = chart4.children.push(am5.Legend.new(root4, {
        centerX: am5.percent(50),
        x: am5.percent(50),
        layout: root4.horizontalLayout
      }));

      legend.data.setAll(series.dataItems);
      // Play initial series animation
      // https://www.amcharts.com/docs/v5/concepts/animations/#Animation_of_series
      series.appear(1000, 100);
    })
   // End Active Item Pie Chart 1


   // Item Type Pie Chart 2
    this.browserOnly(() => {
      // Create root and chart
      let root5 = am5.Root.new("PieChart2");
      let chart5 = root5.container.children.push(am5percent.PieChart.new(root5, {
        // startAngle: -180,
        // endAngle: 0,
        layout: root5.verticalLayout
      })
      );
      // Define data
      let data = [{
        Iteam: "Inventory Non-Stockable",
        sales: 100000
      }, {
        Iteam: "Stockable",
        sales: 160000
      },
      {
        Iteam: "Expense Non-Stockable",
        sales: 160000
      }
      ];
      // Create series
      let series = chart5.series.push(
        am5percent.PieSeries.new(root5, {
          name: "Series",
          valueField: "sales",
          categoryField: "Iteam",
          // startAngle: -180,
          // endAngle: 0
        })
      );
      series.data.setAll(data);

      // Add legend
      let legend = chart5.children.push(am5.Legend.new(root5, {
        centerX: am5.percent(50),
        x: am5.percent(50),
        layout: root5.horizontalLayout
      }));


      legend.data.setAll(series.dataItems);
      // Play initial series animation
      // https://www.amcharts.com/docs/v5/concepts/animations/#Animation_of_series
      series.appear(1000, 100);
    })

    // End Item Type Pie Chart 2
    this.root.dispose();
  }

  ngOnDestroy() {
    //Clean up chart when the component is removed
    this.browserOnly(() => {
      if (this.root) {
        this.root.dispose();
      }
    });
  }


  handleSubsidiaryChange(event: any) {
   
     let root2:any;
      let legend:any;

    this.httpService
      .GetById('/masters-ws/supplier/get-dashboard-by-status?subsidiaryId=' + this.dashboard.subsidiaryId, this.dashboard.subsidiaryId)
      .subscribe((res) => {
        console.log(res);
        if (res) {
          this.active_supplier = [];
          for (let i = 0; i < res.length; i++) {
            this.active_supplier.push({
              category: res[i].category,
              value: res[i].value
            });
          }

         // this.browserOnly(() => {
         
        
           
          root2 = am5.Root.new("DonutChart1");
          
          let chart2 = root2.container.children.push(am5percent.PieChart.new(root2, {
            radius: am5.percent(90),
            innerRadius: am5.percent(50),
            layout: root2.horizontalLayout
          }));

          // Create series
          // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Series
          let series = chart2.series.push(am5percent.PieSeries.new(root2, {
            name: "Series",
            valueField: "value",
            categoryField: "category"
          }));

       
          // Set dataseries
          // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Setting_data
          
          series.data.setAll(
            this.active_supplier);
             legend = chart2.children.push(am5.Legend.new(root2, {
              centerY: am5.percent(50),
              y: am5.percent(50),
              layout: root2.verticalLayout
            }));
           
            // set value labels align to right
            legend.valueLabels.template.setAll({ textAlign: "right" })
            // set width and max width of labels
            legend.labels.template.setAll({
              maxWidth: 140,
              width: 140,
              oversizedBehavior: "wrap"
            });
  
            legend.data.setAll(series.dataItems);

          // Disabling labels and ticks
          series.labels.template.set("visible", false);
          series.ticks.template.set("visible", false);

          // Adding gradients
          series.slices.template.set("strokeOpacity", 0);
          series.slices.template.set("fillGradient", am5.RadialGradient.new(root2, {
            stops: [{
              brighten: -0.8
            },
            {
              brighten: -0.8
            },
            {
              brighten: -0.5
            },
            {
              brighten: 0
            },
            {
              brighten: -0.5
            }]
          }));

          // Create legend
          // https://www.amcharts.com/docs/v5/charts/percent-charts/legend-percent-series/
         
        
          // Play initial series animation
          // https://www.amcharts.com/docs/v5/concepts/animations/#Animation_of_series
          series.appear(1000, 100);

       // });
          //legend.dispose();
          // legend.events.on("datavalidated", function() {
          //   legend.valueLabels.getIndex(0).set("active", true);
          // });
 
          //});


          //this.ngAfterViewInit();
          //   for(var key in res) {

          //     this.active_supplier.push({
          //        name:key,
          //        count:res[key]
          //     });
          //  }
        }
        else {

        }

      },
        (error) => {
        alert(error);

        },
        ()=>{
         // this.root.dispose();
             setTimeout(() => {
              root2.dispose();
          }, 5000);
          //root2.dispose();
          //legend.dispose();
        }
        );
    

  }

  getAllSubsidiaryReloadList() {
    this.Subsidiarylist = [];
    this.GetSubsideryList();
  }

  GetSubsideryList() {
    this.httpService.GetAll("/setup-ws/subsidiary/get/all").subscribe(
      (res) => {
        console.log(res);
        this.Subsidiarylist = res.list;
        //this.SubsideryObject=res;
      },
      (error) => {

        console.log(error);
      }
    );
  }



  addNewItem() {
    //this.=false;
    const url = this.router.serializeUrl(
      this.router.createUrlTree(["http://43.205.33.156:8080/Birt-Report/Dev/indexPDF.html"])
    );
    window.open(decodeURIComponent(url))
  }

  initGraphComb(){
    let data = [{
      category: "Criticalss",
      value: 89,
      sliceSettings: {
        fill: am5.color(0xdc4534),
      },
      breakdown: [{
        category: "Sales inquiries",
        value: 29
      }, {
        category: "Support requests",
        value: 40
      }, {
        category: "Bug reports",
        value: 11
      }, {
        category: "Other",
        value: 9
      }]
    }, {
      category: "Acceptable",
      value: 71,
      sliceSettings: {
        fill: am5.color(0xd7a700),
      },
      breakdown: [{
        category: "Sales inquiries",
        value: 22
      }, {
        category: "Support requests",
        value: 30
      }, {
        category: "Bug reports",
        value: 11
      }, {
        category: "Other",
        value: 10
      }]
    }, {
      category: "Good",
      value: 120,
      sliceSettings: {
        fill: am5.color(0x68ad5c),
      },
      breakdown: [{
        category: "Sales inquiries",
        value: 60
      }, {
        category: "Support requests",
        value: 35
      }, {
        category: "Bug reports",
        value: 15
      }, {
        category: "Other",
        value: 10
      }]
    }]
    let root = am5.Root.new("DonutChart1");
    
    
    root.setThemes([
      am5themes_Animated.new(root)
    ]);
    
    // Create wrapper container
    let container = root.container.children.push(am5.Container.new(root, {
      width: am5.p100,
      height: am5.p100,
      layout: root.horizontalLayout
    }));
    
    
    // ==============================================
    // Column chart
    // ==============================================
    
    // Create chart
    // https://www.amcharts.com/docs/v5/charts/xy-chart/
    let columnChart = container.children.push(am5xy.XYChart.new(root, {
      width: am5.p50,
      panX: false,
      panY: false,
      wheelX: "none",
      wheelY: "none",
      layout: root.verticalLayout
    }));
    
    // Create axes
    // https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
    let yAxis :any = columnChart.yAxes.push(am5xy.CategoryAxis.new(root, {
      categoryField: "category",
      renderer: am5xy.AxisRendererY.new(root, {})
    }));
    
    //xAxis.data.setAll(data);
    
    let xAxis :any = columnChart.xAxes.push(am5xy.ValueAxis.new(root, {
      renderer: am5xy.AxisRendererX.new(root, {})
    }));
    
    
    // Add series
    // https://www.amcharts.com/docs/v5/charts/xy-chart/series/
    let columnSeries :any = columnChart.series.push(am5xy.ColumnSeries.new(root, {
      name: "", // change '' was name
      xAxis: xAxis,
      yAxis: yAxis,
      valueXField: "value",
      categoryYField: "category"
    }));
    
    columnSeries.columns.template.setAll({
      tooltipText: "{categoryY}: {valueX}"
    });
    
    //series.data.setAll(data);
    
    // Make stuff animate on load
    // https://www.amcharts.com/docs/v5/concepts/animations/
    columnChart.appear(1000, 100);
    
    
    // ==============================================
    // Column chart
    // ==============================================
    
    let pieChart = container.children.push( 
      am5percent.PieChart.new(root, {
        width: am5.p50,
        innerRadius: am5.percent(50)
      }) 
    );
    
    // Create series
    let pieSeries = pieChart.series.push(
      am5percent.PieSeries.new(root, {
        valueField: "value",
        categoryField: "category"
      })
    );
    
    pieSeries.slices.template.setAll({
      templateField: "sliceSettings",
      strokeOpacity: 0
    });
    
    let currentSlice: am5.Slice | undefined;
    pieSeries.slices.template.on("active", function(active:boolean | undefined, slice:am5.Slice | undefined) {
      if (currentSlice && currentSlice != slice && active) {
        currentSlice.set("active", false)
      }
      
      let color = slice?.get("fill");
    
      label1.setAll({
        fill: color,
        // text: root.numberFormatter.format(slice.dataItem.get("valuePercentTotal"), "#.'%'")
      });
      
      // label2.set("text", slice.dataItem.get("category"));
      
      columnSeries.columns.template.setAll({
        fill: slice?.get("fill"),
        stroke: slice?.get("fill")
      });
      
      // columnSeries.data.setAll (slice.dataItem.dataContext.breakdown);
      // yAxis.data.setAll(slice.dataItem.dataContext.breakdown);
      
      currentSlice = slice;
    });
    
    pieSeries.labels.template.set("forceHidden", true);
    pieSeries.ticks.template.set("forceHidden", true);
    
    //pieSeries.data.setAll(this.active_supplier);
    pieSeries.data.setAll(this.active_supplier);
    
    // Add label
    let label1 = pieChart.seriesContainer.children.push(am5.Label.new(root, {
      text: "",
      fontSize: 35,
      // fontweight: "bold",
      centerX: am5.p50,
      centerY: am5.p50
    }));
    
    let label2 = pieChart.seriesContainer.children.push(am5.Label.new(root, {
      text: "",
      fontSize: 12,
      centerX: am5.p50,
      centerY: am5.p50,
      dy: 30
    }));
    
    // Pre-select first slice
    // pieSeries.events.on("datavalidated", function() {
    //   pieSeries.slices?.getIndex(0).set("active", true);
    // });
    

  }


}
