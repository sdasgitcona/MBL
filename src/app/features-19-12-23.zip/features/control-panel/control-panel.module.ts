import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ControlPanelRoutingModule } from './control-panel-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';


import { Button, ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { TabMenuModule } from 'primeng/tabmenu';
import { DialogModule } from 'primeng/dialog';
import { TabViewModule } from 'primeng/tabview';
import { SharedComponentsModule } from 'src/app/shared/shared-components/shared-components.module';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { MultiSelectModule } from 'primeng/multiselect';

import { PasswordModule } from "primeng/password";
import { DividerModule } from "primeng/divider";
import { TagModule } from "primeng/tag";
import { FieldsetModule, } from 'primeng/fieldset';
import {InputSwitchModule} from 'primeng/inputswitch';


import { CardModule } from 'primeng/card';
import { ChartModule } from 'primeng/chart';
import { MenuModule } from 'primeng/menu';


@NgModule({
  declarations: [
    DashboardComponent
  ],
  imports: [
    CommonModule,
    ControlPanelRoutingModule,
   
    ButtonModule,
    InputTextModule,
    PanelModule,
    TableModule,
    TabMenuModule,
    DialogModule,
    TabViewModule,
    SharedComponentsModule,
    DropdownModule,
    FormsModule, 
    ReactiveFormsModule,
    CheckboxModule,
    ToggleButtonModule,
    MultiSelectModule,
    DividerModule,
    TagModule,
    FieldsetModule,
    MenuModule,
    CardModule,
  ]
})
export class ControlPanelModule { }
