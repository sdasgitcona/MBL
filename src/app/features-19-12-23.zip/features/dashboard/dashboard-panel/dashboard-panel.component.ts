import { Component, OnInit, Inject, PLATFORM_ID, NgZone } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import { DashboardDataUpdateService } from 'src/app/core/services/dashboard-data-update.service';

// pr
import { PartiallyApprovedDirective } from 'src/app/dashboard_features/pr/reminders/partially-approved.directive';
import { PendingApprovalDirective } from 'src/app/dashboard_features/pr/reminders/pending-approval.directive';
import { RejectedPrDirective } from 'src/app/dashboard_features/pr/reminders/rejected-pr.directive';
import { AwatingForApprovalPrDirective } from 'src/app/dashboard_features/pr/reminders/awating-for-approval-pr.directive';
import { OpenandApprovedPRComponent } from 'src/app/dashboard_features/pr/indicators/openand-approved-pr/openand-approved-pr.component';
import { PrOnPriorityComponent } from 'src/app/dashboard_features/pr/indicators/pr-on-priority/pr-on-priority.component';
import { ProjectWisePRComponent } from 'src/app/dashboard_features/pr/charts/project-wise-pr/project-wise-pr.component';
import { PrToRfqAndPoComponent } from 'src/app/dashboard_features/pr/charts/pr-to-rfq-and-po/pr-to-rfq-and-po.component';
import { PrAgingComponent } from 'src/app/dashboard_features/pr/charts/pr-aging/pr-aging.component';
import { TotalPrKPIComponent } from 'src/app/dashboard_features/pr/charts/total-pr-kpi/total-pr-kpi.component';
import { RecentlyCreatedPrComponent } from 'src/app/dashboard_features/pr/indicators/recently-created-pr/recently-created-pr.component';

// po
import { PartiallyApprovedPODirective } from 'src/app/dashboard_features/po/reminders/partially-approved-po.directive';
import { PendingApprovalPODirective } from 'src/app/dashboard_features/po/reminders/pending-approval-po.directive';
import { RejectedPODirective } from 'src/app/dashboard_features/po/reminders/rejected-po.directive';
import { AwatingForApprovalPoDirective } from 'src/app/dashboard_features/po/reminders/awating-for-approval-po.directive';
import { OpenPoComponent } from 'src/app/dashboard_features/po/indicators/open-po/open-po.component';
import { RecentlyCreatedPOComponent } from 'src/app/dashboard_features/po/indicators/recently-created-po/recently-created-po.component';
import { TotalSupplierComponent } from 'src/app/dashboard_features/po/indicators/total-supplier/total-supplier.component';
import { LocationBasedPOComponent } from 'src/app/dashboard_features/po/charts/location-based-po/location-based-po.component';
import { PoApprovedBuildKPIComponent } from 'src/app/dashboard_features/po/charts/po-approved-build-kpi/po-approved-build-kpi.component';
import { PoApprovalAgingComponent } from 'src/app/dashboard_features/po/charts/po-approval-aging/po-approval-aging.component';

// Advance Paymeny
import { AdvanceApprovedDirective } from 'src/app/dashboard_features/advanced-payment/reminders/advance-approved.directive';
import { AdvancePendingApprovalDirective } from 'src/app/dashboard_features/advanced-payment/reminders/advance-pending-approval.directive';
import { AppliedAdvanceDirective } from 'src/app/dashboard_features/advanced-payment/reminders/applied-advance.directive';
import { PartiallyAppliedDirective } from 'src/app/dashboard_features/advanced-payment/reminders/partially-applied.directive';
import { RejectedAdvanceDirective } from 'src/app/dashboard_features/advanced-payment/reminders/rejected-advance.directive';
import { AwatingForApprovalAdvancePaymentDirective } from 'src/app/dashboard_features/advanced-payment/reminders/awating-for-approval-advance-payment.directive';
import { TotalOpenApComponent } from 'src/app/dashboard_features/advanced-payment/indicators/total-open-ap/total-open-ap.component';
import { RecentlyCreatedComponent } from 'src/app/dashboard_features/advanced-payment/indicators/recently-created/recently-created.component';
import { MonthlyAdvanceTrendBarComponent } from 'src/app/dashboard_features/advanced-payment/charts/monthly-advance-trend-bar/monthly-advance-trend-bar.component';
import { TotalVsApprovedPaymentComponent } from 'src/app/dashboard_features/advanced-payment/charts/total-vs-approved-payment/total-vs-approved-payment.component';

// Make Paymeny
import { PaymentApprovedDirective } from 'src/app/dashboard_features/make-payment/reminders/payment-approved.directive';
import { PaymentPendingApprovalDirective } from 'src/app/dashboard_features/make-payment/reminders/payment-pending-approval.directive';
import { PaymentVoidedDirective } from 'src/app/dashboard_features/make-payment/reminders/payment-voided.directive';
import { RejectedPaymentDirective } from 'src/app/dashboard_features/make-payment/reminders/rejected-payment.directive';
import { AwatingForApprovalMakePaymentDirective } from 'src/app/dashboard_features/make-payment/reminders/awating-for-approval-make-payment.directive';
import { RecentlyCreatedPaymentComponent } from 'src/app/dashboard_features/make-payment/indicators/recently-created-payment/recently-created-payment.component';
import { TotalOpenMpComponent } from 'src/app/dashboard_features/make-payment/indicators/total-open-mp/total-open-mp.component';
import { LocalForexCurrencyComponent } from 'src/app/dashboard_features/make-payment/charts/local-forex-currency/local-forex-currency.component';
import { PaymentApprovalAgingComponent } from 'src/app/dashboard_features/make-payment/charts/payment-approval-aging/payment-approval-aging.component';

// Invoice
import { BillsPendingApprovalApDirective } from 'src/app/dashboard_features/ap-invoice/reminders/bills-pending-approval-ap.directive';
import { BillsApprovedApDirective } from 'src/app/dashboard_features/ap-invoice/reminders/bills-approved-ap.directive';
import { PartiallyPaidBillsDirective } from 'src/app/dashboard_features/ap-invoice/reminders/partially-paid-bills.directive';
import { PartiallyApprovedBillsDirective } from 'src/app/dashboard_features/ap-invoice/reminders/partially-approved-bills.directive';
import { RejectedBillsApDirective } from 'src/app/dashboard_features/ap-invoice/reminders/rejected-bills-ap.directive';
import { AwatingForApprovalApDirective } from 'src/app/dashboard_features/ap-invoice/reminders/awating-for-approval-ap.directive';
import { RecentlyCreatedBillsApComponent } from 'src/app/dashboard_features/ap-invoice/indicators/recently-created-bills-ap/recently-created-bills-ap.component';
import { TotalBillsOpenBillsComponent } from 'src/app/dashboard_features/ap-invoice/indicators/total-bills-open-bills/total-bills-open-bills.component';
import { TotalApprovedVsTotalPaidBillsKpiComponent } from 'src/app/dashboard_features/ap-invoice/charts/total-approved-vs-total-paid-bills-kpi/total-approved-vs-total-paid-bills-kpi.component';
import { ApInvoiceAgingSummaryBarComponent } from 'src/app/dashboard_features/ap-invoice/charts/ap-invoice-aging-summary-bar/ap-invoice-aging-summary-bar.component';

//GRN
import { PartiallyReceivedPoDirective } from 'src/app/dashboard_features/store/reminders/partially-received-po.directive';
import { ApprovedPoGrnDirective } from 'src/app/dashboard_features/store/reminders/approved-po-grn.directive';
import { RecentlyCreatedGrnComponent } from 'src/app/dashboard_features/store/indicators/recently-created-grn/recently-created-grn.component';
import { TotalReceivedTotalReturnGrnComponent } from 'src/app/dashboard_features/store/indicators/total-received-total-return-grn/total-received-total-return-grn.component';
import { GrnVsBillKpiComponent } from 'src/app/dashboard_features/store/charts/grn-vs-bill-kpi/grn-vs-bill-kpi.component';
import { ShipmentDetailsPieComponent } from 'src/app/dashboard_features/store/charts/shipment-details-pie/shipment-details-pie.component';
import { TotalReceivedAndReturnSupplierBarComponent } from 'src/app/dashboard_features/store/charts/total-received-and-return-supplier-bar/total-received-and-return-supplier-bar.component';
import { ItemWiseReceivedBarComponent } from 'src/app/dashboard_features/store/charts/item-wise-received-bar/item-wise-received-bar.component';
import { LocationWiseReceivedBarComponent } from 'src/app/dashboard_features/store/charts/location-wise-received-bar/location-wise-received-bar.component';
import { ItemWiseHoldingValuePieComponent } from 'src/app/dashboard_features/store/charts/item-wise-holding-value-pie/item-wise-holding-value-pie.component';

//Supplier or Vendor
import { RejectedSupplierDirective } from 'src/app/dashboard_features/vendor-master/reminders/rejected-supplier.directive';
import { SupplierPartiallyApprovalDirective } from 'src/app/dashboard_features/vendor-master/reminders/supplier-partially-approval.directive';
import { SupplierPendingApprovalDirective } from 'src/app/dashboard_features/vendor-master/reminders/supplier-pending-approval.directive';
import { CategoryWiseSupplierBarComponent } from 'src/app/dashboard_features/vendor-master/charts/category-wise-supplier-bar/category-wise-supplier-bar.component';
import { CountryWiseSupplierPieComponent } from 'src/app/dashboard_features/vendor-master/charts/country-wise-supplier-pie/country-wise-supplier-pie.component';
import { DeliveryPerformanceBarComponent } from 'src/app/dashboard_features/vendor-master/charts/delivery-performance-bar/delivery-performance-bar.component';
import { SupplierApprovalAgingBarComponent } from 'src/app/dashboard_features/vendor-master/charts/supplier-approval-aging-bar/supplier-approval-aging-bar.component';
import { TotalReceivedAndReturnBarComponent } from 'src/app/dashboard_features/vendor-master/charts/total-received-and-return-bar/total-received-and-return-bar.component';
import { TotalSupplierVsApproveSupplierKpiComponent } from 'src/app/dashboard_features/vendor-master/charts/total-supplier-vs-approve-supplier-kpi/total-supplier-vs-approve-supplier-kpi.component';
import { RecentlyCreatedSupplierComponent } from 'src/app/dashboard_features/vendor-master/indicators/recently-created-supplier/recently-created-supplier.component';
import { RegisteredUnregisteredSupplierComponent } from 'src/app/dashboard_features/vendor-master/indicators/registered-unregistered-supplier/registered-unregistered-supplier.component';
import { TotalHavingAccessSupplierComponent } from 'src/app/dashboard_features/vendor-master/indicators/total-having-access-supplier/total-having-access-supplier.component';

// Make Paymeny
import { AwatingForApprovalDebitNoteDirective } from 'src/app/dashboard_features/debit-note/reminders/awating-for-approval-debit-note.directive';

// rtv
import { AwatingForApprovalRtvDirective } from 'src/app/dashboard_features/rtv/reminders/awating-for-approval-rtv.directive';

@Component({
  selector: 'app-dashboard-panel',
  templateUrl: './dashboard-panel.component.html',
  styleUrls: ['./dashboard-panel.component.scss']
})
export class DashboardPanelComponent implements OnInit {

  allCards: any[] = [];
  apAgingIndicators: any[] = [];
  billsIndicators: any[] = [];
  exportToNetsuiteIndicators: any[] = [];
  incomingInvoicesIndicators: any[] = [];
  recentlyCreatedBillsIndicators: any[] = [];
  SubsidiaryId: any;
  selectedSubsidiaryId: any;
  RetloginDetails: any;
  isFullscreen: any = false;
  chartsComponents: any[] = [];
  indicatorsComponents: any[] = [];
  Subsidiarylist: any[] = [];

  constructor(
    private httpService: CommonHttpService,
    private router: Router,
    private toastService: ToastService,
    private dashboardDataUpdate: DashboardDataUpdateService,

    // pr
    private PartiallyApproved: PartiallyApprovedDirective,
    private PendingApproval: PendingApprovalDirective,
    private RejectedPr: RejectedPrDirective,
    private AwatingForApprovalPr: AwatingForApprovalPrDirective,

    // po
    private PartiallyAppprovedPo: PartiallyApprovedPODirective,
    private PendingAppprovalPo: PendingApprovalPODirective,
    private RejectedPo: RejectedPODirective,
    private AwatingForApprovalPo: AwatingForApprovalPoDirective,

    // Advance Payment
    private AdvanceApproved: AdvanceApprovedDirective,
    private AdvancePendingApproval: AdvancePendingApprovalDirective,
    private AppliedAdvance: AppliedAdvanceDirective,
    private PartiallyApplied: PartiallyAppliedDirective,
    private RejectedAdvance: RejectedAdvanceDirective,
    private AwatingForApprovalAdvancePayment: AwatingForApprovalAdvancePaymentDirective,

    // Make Payment
    private PaymentApproved: PaymentApprovedDirective,
    private PaymentPendingApproval: PaymentPendingApprovalDirective,
    private PaymentVoided: PaymentVoidedDirective,
    private RejectedPayment: RejectedPaymentDirective,
    private AwatingForApprovalMakePayment: AwatingForApprovalMakePaymentDirective,

    // Invoice
    private BillsPendingApprovalAp: BillsPendingApprovalApDirective,
    private BillsApprovedAp: BillsApprovedApDirective,
    private PartiallyPaidBills: PartiallyPaidBillsDirective,
    private PartiallyApprovedBills: PartiallyApprovedBillsDirective,
    private RejectedBillsAp: RejectedBillsApDirective,
    private AwatingForApprovalAp: AwatingForApprovalApDirective,

    //GRN
    private PartiallyReceivedPo: PartiallyReceivedPoDirective,
    private ApprovedPoGrn: ApprovedPoGrnDirective,

     // Vendor or Supplier
     private RejectedSupplier: RejectedSupplierDirective,
     private SupplierPartiallyApproval: SupplierPartiallyApprovalDirective,
     private SupplierPendingApproval: SupplierPendingApprovalDirective,

    // Make Paymeny
    private AwatingForApprovalDebitNote: AwatingForApprovalDebitNoteDirective,

    // rtv 
    private AwatingForApprovalRtv: AwatingForApprovalRtvDirective,
  ) { }

  ngOnInit(): void {

    const RDetails: any = localStorage.getItem("RoleDTLS");
    this.SubsidiaryId = JSON.parse(RDetails);

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.selectedSubsidiaryId = this.SubsidiaryId[0].subsidiaryId;

    this.getData(); // Reminders
    this.Loadlov(); // Subsidiary
  }

  getData() {

    //Clear Array
    this.chartsComponents = [];
    this.indicatorsComponents = [];
    this.allCards = [];

    for (let x = 0; x < this.SubsidiaryId[0].rolePermissions.length; x++) //--Loop on accesspoint name
    {
      // PR Component
      if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'Purchase Requisition' && this.SubsidiaryId[0].rolePermissions[x].view == true) {
        // Indicator
        this.indicatorsComponents.push(OpenandApprovedPRComponent, RecentlyCreatedPrComponent, PrOnPriorityComponent) //ProjectWisePrComponent,
        // Chart
        this.chartsComponents.push(TotalPrKPIComponent,PrToRfqAndPoComponent, PrAgingComponent, ); //ProjectWisePRComponent

        // Reminder
        // Pr Pending Approved - reminders
        this.PartiallyApproved.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.PartiallyApproved.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Pr Partially Approved - reminders
        this.PendingApproval.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.PendingApproval.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Rejected Pr - reminders
        this.RejectedPr.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.RejectedPr.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });
       
        // End Reminder
      }
      // End PR Component

      // PO Component
      if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'Purchase Order' && this.SubsidiaryId[0].rolePermissions[x].view == true) {
        // Indicator
        this.indicatorsComponents.push(OpenPoComponent, RecentlyCreatedPOComponent,TotalSupplierComponent, ); //
        // Chart
        this.chartsComponents.push(PoApprovedBuildKPIComponent, PoApprovalAgingComponent, LocationBasedPOComponent,);

         // Reminder

        // Partially Approved
        this.PartiallyAppprovedPo.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.PartiallyAppprovedPo.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Pend Approval
        this.PendingAppprovalPo.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.PendingAppprovalPo.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Rejected
        this.RejectedPo.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.RejectedPo.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });
        // End Reminder
      }
      // End PO Component

      // Make Payment Component
      if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'Make Payment' && this.SubsidiaryId[0].rolePermissions[x].view == true) {
        // Indicator
        this.indicatorsComponents.push(TotalOpenMpComponent, RecentlyCreatedPaymentComponent,);
        // Chart
        this.chartsComponents.push(LocalForexCurrencyComponent, PaymentApprovalAgingComponent,);

         // Reminder

         // Make Payment Approved
          this.PaymentApproved.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
          this.PaymentApproved.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
              this.allCards.push(...Card);
            }
          });

        // Make Payment - Payment Pending Approval
        this.PaymentPendingApproval.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.PaymentPendingApproval.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Make Payment - Payment Voided
        this.PaymentVoided.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.PaymentVoided.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Make Payment - Rejected Payment
        this.RejectedPayment.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.RejectedPayment.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });
         // End Reminder
      }
      // End Make Payment Component

      // Advance Payment Component
      if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'Advance Payment' && this.SubsidiaryId[0].rolePermissions[x].view == true) {
         // Indicator
         this.indicatorsComponents.push(TotalOpenApComponent, RecentlyCreatedComponent,);
         // Chart
         this.chartsComponents.push(MonthlyAdvanceTrendBarComponent, TotalVsApprovedPaymentComponent);
 
          // Reminder
          // Advance Payment - Advance Approved
        this.AdvanceApproved.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.AdvanceApproved.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Advance Payment - Advance Pending Approval
        this.AdvancePendingApproval.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.AdvancePendingApproval.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Advance Payment - Applied Advance
        this.AppliedAdvance.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.AppliedAdvance.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Advance Payment - Partially Applied
        this.PartiallyApplied.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.PartiallyApplied.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Advance Payment - Rejected Advance
        this.RejectedAdvance.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.RejectedAdvance.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });
      // End Reminder
 
      }
      // End Advance Payment Component

      // Invoice Component
      if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'AP invoice' && this.SubsidiaryId[0].rolePermissions[x].view == true) {
         // Indicator
         this.indicatorsComponents.push(TotalBillsOpenBillsComponent, RecentlyCreatedBillsApComponent);
         // Chart
         this.chartsComponents.push(TotalApprovedVsTotalPaidBillsKpiComponent, ApInvoiceAgingSummaryBarComponent);

         // Ap Invoice - Bills Pending Approval - reminders
        this.BillsPendingApprovalAp.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.BillsPendingApprovalAp.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Ap Invoice - Bills Approved - reminders
        this.BillsApprovedAp.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.BillsApprovedAp.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Ap Invoice - Partially Paid Bills - reminders
        this.PartiallyPaidBills.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.PartiallyPaidBills.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Ap Invoice - Partially Approved Bills - reminders
        this.PartiallyApprovedBills.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.PartiallyApprovedBills.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Ap Invoice - Rejected Bills - reminders
        this.RejectedBillsAp.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.RejectedBillsAp.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });
      }
      // End Invoice Component

      //GRN
      if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'Goods Received Notes' && this.SubsidiaryId[0].rolePermissions[x].view == true) {
        // Indicator
        this.indicatorsComponents.push(TotalReceivedTotalReturnGrnComponent, RecentlyCreatedGrnComponent,);
        // Chart
        this.chartsComponents.push(ShipmentDetailsPieComponent, GrnVsBillKpiComponent, LocationWiseReceivedBarComponent, ItemWiseReceivedBarComponent, TotalReceivedAndReturnSupplierBarComponent, ItemWiseHoldingValuePieComponent,); // 

        // store - Partially Received Po - reminders
    this.PartiallyReceivedPo.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
    this.PartiallyReceivedPo.CardsReady.subscribe(Card => {
      if (!this.checkExistingCard(Card[0], this.allCards)) {
        this.allCards.push(...Card);
      }
    });

     // store - Approved PO - reminders
     this.ApprovedPoGrn.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
     this.ApprovedPoGrn.CardsReady.subscribe(Card => {
       if (!this.checkExistingCard(Card[0], this.allCards)) {
         this.allCards.push(...Card);
       }
     });
     }
      //END GRN

      // Vendor or Supplier Component
      if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'Supplier_OFF' && this.SubsidiaryId[0].rolePermissions[x].view == true) {
        // Indicator
        this.indicatorsComponents.push(RecentlyCreatedSupplierComponent, RegisteredUnregisteredSupplierComponent, TotalHavingAccessSupplierComponent,);
        // Chart
        this.chartsComponents.push(CategoryWiseSupplierBarComponent, CountryWiseSupplierPieComponent, DeliveryPerformanceBarComponent, SupplierApprovalAgingBarComponent, TotalReceivedAndReturnBarComponent, TotalSupplierVsApproveSupplierKpiComponent);

         // Reminder

        // Partially Approved
        this.SupplierPartiallyApproval.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.SupplierPartiallyApproval.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Pend Approval
        this.SupplierPendingApproval.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.SupplierPendingApproval.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });

        // Rejected
        this.RejectedSupplier.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
        this.RejectedSupplier.CardsReady.subscribe(Card => {
          if (!this.checkExistingCard(Card[0], this.allCards)) {
            this.allCards.push(...Card);
          }
        });
        // End Reminder
      }
      // End Vendor or Supplier Component

       // For APPROVER Access
       if(this.SubsidiaryId[0].selectedAccess == 'APPROVER'){
        // PR Approval
        if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'PR Approval' && this.SubsidiaryId[0].rolePermissions[x].create == true) {
          // Awating For Approval Pr - reminders
          this.AwatingForApprovalPr.getApiData(this.RetloginDetails.employeeId,this.RetloginDetails.token, this.selectedSubsidiaryId);
          this.AwatingForApprovalPr.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
              if(Card[0].value > 0){
                this.allCards.push(...Card);
              }
            }
          });
        }
        // End PR Approval
  
        // PO Approval
        if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'PO Approval' && this.SubsidiaryId[0].rolePermissions[x].create == true) {
          // Awating For Approval Pr - reminders
          this.AwatingForApprovalPo.getApiData(this.RetloginDetails.employeeId,this.RetloginDetails.token, this.selectedSubsidiaryId);
          this.AwatingForApprovalPo.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
              if(Card[0].value > 0){
                this.allCards.push(...Card);
              }
            }
          });
        }
        // End PO Approval

        // Advance Payment Approval
        if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'Advance Payment Approval' && this.SubsidiaryId[0].rolePermissions[x].create == true) {
          // Awating For Approval Pr - reminders
          this.AwatingForApprovalAdvancePayment.getApiData(this.RetloginDetails.employeeId,this.RetloginDetails.token, this.selectedSubsidiaryId);
          this.AwatingForApprovalAdvancePayment.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
              if(Card[0].value > 0){
                this.allCards.push(...Card);
              }
            }
          });
        }
        // End Advance Payment Approval

        // Make Payment Approval
        if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'Make Payment Approval' && this.SubsidiaryId[0].rolePermissions[x].create == true) {
          // Awating For Approval Pr - reminders
          this.AwatingForApprovalMakePayment.getApiData(this.RetloginDetails.employeeId,this.RetloginDetails.token, this.selectedSubsidiaryId);
          this.AwatingForApprovalMakePayment.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
              if(Card[0].value > 0){
                this.allCards.push(...Card);
              }
            }
          });
        }
        // End Make Payment Approval

        // AP Invoice Approval
        if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'Debit Note Approval' && this.SubsidiaryId[0].rolePermissions[x].create == true) {
          // Awating For Approval Pr - reminders
          this.AwatingForApprovalAp.getApiData(this.RetloginDetails.employeeId,this.RetloginDetails.token, this.selectedSubsidiaryId);
          this.AwatingForApprovalAp.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
              if(Card[0].value > 0){
                this.allCards.push(...Card);
              }
            }
          });
        }
        // End AP Invoice Approval

        // Debit Note Approval
        if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'Debit Note Approval' && this.SubsidiaryId[0].rolePermissions[x].create == true) {
          // Awating For Approval Pr - reminders
          this.AwatingForApprovalDebitNote.getApiData(this.RetloginDetails.employeeId,this.RetloginDetails.token, this.selectedSubsidiaryId);
          this.AwatingForApprovalDebitNote.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
              if(Card[0].value > 0){
                this.allCards.push(...Card);
              }
            }
          });
        }
        // End Debit Note Approval

        // RTV Approval
        if (this.SubsidiaryId[0].rolePermissions[x].accessPoint == 'RTV Approval' && this.SubsidiaryId[0].rolePermissions[x].create == true) {
          // Awating For Approval Pr - reminders
          this.AwatingForApprovalRtv.getApiData(this.RetloginDetails.employeeId,this.RetloginDetails.token, this.selectedSubsidiaryId);
          this.AwatingForApprovalRtv.CardsReady.subscribe(Card => {
            if (!this.checkExistingCard(Card[0], this.allCards)) {
              if(Card[0].value > 0){
                this.allCards.push(...Card);
              }
            }
          });
        }
        // End RTV Approval
      }
      // END For APPROVER Access

    }

  }

  checkExistingCard(card: any, allCards: any[]): boolean {
    // Check if card data already exists in allCards array
    return allCards.some(c => c.category === card.category && c.value === card.value && c.link === card.link);
  }

  // Load Subsidiary List
  Loadlov() {
    if (this.SubsidiaryId[0].accountId !== null && this.SubsidiaryId[0].subsidiaryId == null) {
      this.allCards = [];
      this.httpService
        .GetAll(`/setup-ws/subsidiary/get/all/lov?accountId=` + this.SubsidiaryId[0].accountId, this.RetloginDetails.token)
        .subscribe((res) => {
          console.log(res)
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.Subsidiarylist = res;
            this.dashboardDataUpdate.sendSubsidiaryId(this.selectedSubsidiaryId);
          }
        });
    }
  }

  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  toggleFullscreen() {
    let div = document.querySelector('.fullscreenDiv');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }

  toggleFullscreenRightDiv() {
    let div = document.querySelector('.fullscreenRightDiv');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }



}
