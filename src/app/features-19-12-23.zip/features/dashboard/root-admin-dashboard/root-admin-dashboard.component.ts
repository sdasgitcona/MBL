import { Component, OnInit, Inject, PLATFORM_ID, NgZone } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';

import { PendingAccessDirective } from 'src/app/dashboard_features/product/reminders/pending-access.directive';
import { PendingCompanyCreationDirective } from 'src/app/dashboard_features/product/reminders/pending-company-creation.directive';
import { TotalCreatedRecentelyCreatedCompanyComponent } from 'src/app/dashboard_features/product/indicators/total-created-recentely-created-company/total-created-recentely-created-company.component';
import { UpcomingCompanyExpirationInactivatedCompanyComponent } from 'src/app/dashboard_features/product/indicators/upcoming-company-expiration-inactivated-company/upcoming-company-expiration-inactivated-company.component';
import { PackageUpdateDetailsBarComponent } from 'src/app/dashboard_features/product/charts/package-update-details-bar/package-update-details-bar.component';
import { YearWiseRegistrationBarComponent } from 'src/app/dashboard_features/product/charts/year-wise-registration-bar/year-wise-registration-bar.component';
import { ActiveInactiveRegistrationBarComponent } from 'src/app/dashboard_features/product/charts/active-inactive-registration-bar/active-inactive-registration-bar.component';
import { TotalActiveVsDeactivatedProductPieComponent } from 'src/app/dashboard_features/product/charts/total-active-vs-deactivated-product-pie/total-active-vs-deactivated-product-pie.component';


@Component({
  selector: 'app-root-admin-dashboard',
  templateUrl: './root-admin-dashboard.component.html',
  styleUrls: ['./root-admin-dashboard.component.scss']
})
export class RootAdminDashboardComponent implements OnInit {

  allCards: any[] = [];
  allCardsWithoutLink: any[] = [];
  apAgingIndicators: any[] = [];
  billsIndicators: any[] = [];
  exportToNetsuiteIndicators: any[] = [];
  incomingInvoicesIndicators: any[] = [];
  recentlyCreatedBillsIndicators: any[] = [];
  SubsidiaryId: any;
  selectedSubsidiaryId: any;
  RetloginDetails: any;
  isFullscreen: any = false;
  chartsComponents: any[] = [];
  indicatorsComponents: any[] = [];
  Subsidiarylist: any[] = [];

  constructor(
    private PendingCompanyCreation: PendingCompanyCreationDirective,
    private PendingAccess: PendingAccessDirective,
  ) { }

  ngOnInit(): void {

    const RDetails: any = localStorage.getItem("AllRoleList");
    this.SubsidiaryId = JSON.parse(RDetails);

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.selectedSubsidiaryId = this.SubsidiaryId[0].subsidiaryId;

    this.reminders();
    this.indicators();
    this.charts();
  }

  reminders() {
    // Pending Company Creation
    this.PendingCompanyCreation.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
    this.PendingCompanyCreation.CardsReady.subscribe(Card => {
      if (!this.checkExistingCard(Card[0], this.allCardsWithoutLink)) {
        this.allCardsWithoutLink.push(...Card);
      }
    });

    // Pending Access
    this.PendingAccess.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
    this.PendingAccess.CardsReady.subscribe(Card => {
      if (!this.checkExistingCard(Card[0], this.allCards)) {
        this.allCards.push(...Card);
      }
    });
  }

  indicators() {
    this.indicatorsComponents.push(TotalCreatedRecentelyCreatedCompanyComponent, UpcomingCompanyExpirationInactivatedCompanyComponent,);
  }

  charts() {
    this.chartsComponents.push(TotalActiveVsDeactivatedProductPieComponent, PackageUpdateDetailsBarComponent, YearWiseRegistrationBarComponent, ActiveInactiveRegistrationBarComponent,);
  }

  checkExistingCard(card: any, allCards: any[]): boolean {
    // Check if card data already exists in allCards array
    return allCards.some(c => c.category === card.category && c.value === card.value && c.link === card.link);
  }

  toggleFullscreen() {
    let div = document.querySelector('.fullscreenDiv');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }

  toggleFullscreenRightDiv() {
    let div = document.querySelector('.fullscreenRightDiv');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }

}
