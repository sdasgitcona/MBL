import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardPanelComponent } from './dashboard-panel/dashboard-panel.component';


import { SharedComponentsModule } from 'src/app/shared/shared-components/shared-components.module';
import { MessageModule } from 'primeng/message';
import { CardModule } from 'primeng/card';
import { ChartModule } from 'primeng/chart';
import { MessagesModule } from 'primeng/messages';

import { PanelModule } from 'primeng/panel';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { TableModule } from 'primeng/table';
import { TabMenuModule } from 'primeng/tabmenu';
import { DialogModule } from 'primeng/dialog';
import { TabViewModule } from 'primeng/tabview';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { MultiSelectModule } from 'primeng/multiselect';
import { DividerModule } from "primeng/divider";
import { TagModule } from "primeng/tag";
import { FieldsetModule, } from 'primeng/fieldset';
import { SupplierModule } from '../supplier/supplier.module';
import { MenuModule } from 'primeng/menu';

// pr
import { PartiallyApprovedDirective } from 'src/app/dashboard_features/pr/reminders/partially-approved.directive';
import { PendingApprovalDirective } from 'src/app/dashboard_features/pr/reminders/pending-approval.directive';
import { RejectedPrDirective } from 'src/app/dashboard_features/pr/reminders/rejected-pr.directive';
import { AwatingForApprovalPrDirective } from 'src/app/dashboard_features/pr/reminders/awating-for-approval-pr.directive';
import { OpenandApprovedPRComponent } from 'src/app/dashboard_features/pr/indicators/openand-approved-pr/openand-approved-pr.component';
import { ProjectWisePrComponent } from 'src/app/dashboard_features/pr/indicators/project-wise-pr/project-wise-pr.component';
import { PrOnPriorityComponent } from 'src/app/dashboard_features/pr/indicators/pr-on-priority/pr-on-priority.component';
import { PrToRfqAndPoComponent } from 'src/app/dashboard_features/pr/charts/pr-to-rfq-and-po/pr-to-rfq-and-po.component';
import { PrAgingComponent } from 'src/app/dashboard_features/pr/charts/pr-aging/pr-aging.component';
import { TotalPrKPIComponent } from 'src/app/dashboard_features/pr/charts/total-pr-kpi/total-pr-kpi.component';
import { RecentlyCreatedPrComponent } from 'src/app/dashboard_features/pr/indicators/recently-created-pr/recently-created-pr.component';
import { ProjectWisePRComponent } from 'src/app/dashboard_features/pr/charts/project-wise-pr/project-wise-pr.component';

//PO
import { PartiallyApprovedPODirective } from 'src/app/dashboard_features/po/reminders/partially-approved-po.directive';
import { PendingApprovalPODirective } from 'src/app/dashboard_features/po/reminders/pending-approval-po.directive';
import { RejectedPODirective } from 'src/app/dashboard_features/po/reminders/rejected-po.directive';
import { AwatingForApprovalPoDirective } from 'src/app/dashboard_features/po/reminders/awating-for-approval-po.directive';
import { OpenPoComponent } from 'src/app/dashboard_features/po/indicators/open-po/open-po.component';
import { RecentlyCreatedPOComponent } from 'src/app/dashboard_features/po/indicators/recently-created-po/recently-created-po.component';
import { TotalSupplierComponent } from 'src/app/dashboard_features/po/indicators/total-supplier/total-supplier.component';
import { LocationBasedPOComponent } from 'src/app/dashboard_features/po/charts/location-based-po/location-based-po.component';
import { PoApprovedBuildKPIComponent } from 'src/app/dashboard_features/po/charts/po-approved-build-kpi/po-approved-build-kpi.component';
import { PoApprovalAgingComponent } from 'src/app/dashboard_features/po/charts/po-approval-aging/po-approval-aging.component';

// Advance Paymeny
import { AdvanceApprovedDirective } from 'src/app/dashboard_features/advanced-payment/reminders/advance-approved.directive';
import { AdvancePendingApprovalDirective } from 'src/app/dashboard_features/advanced-payment/reminders/advance-pending-approval.directive';
import { AppliedAdvanceDirective } from 'src/app/dashboard_features/advanced-payment/reminders/applied-advance.directive';
import { PartiallyAppliedDirective } from 'src/app/dashboard_features/advanced-payment/reminders/partially-applied.directive';
import { RejectedAdvanceDirective } from 'src/app/dashboard_features/advanced-payment/reminders/rejected-advance.directive';
import { AwatingForApprovalAdvancePaymentDirective } from 'src/app/dashboard_features/advanced-payment/reminders/awating-for-approval-advance-payment.directive';
import { TotalOpenApComponent } from 'src/app/dashboard_features/advanced-payment/indicators/total-open-ap/total-open-ap.component';
import { RecentlyCreatedComponent } from 'src/app/dashboard_features/advanced-payment/indicators/recently-created/recently-created.component';
import { MonthlyAdvanceTrendBarComponent } from 'src/app/dashboard_features/advanced-payment/charts/monthly-advance-trend-bar/monthly-advance-trend-bar.component';
import { TotalVsApprovedPaymentComponent } from 'src/app/dashboard_features/advanced-payment/charts/total-vs-approved-payment/total-vs-approved-payment.component';

// Make Paymeny
import { PaymentApprovedDirective } from 'src/app/dashboard_features/make-payment/reminders/payment-approved.directive';
import { PaymentPendingApprovalDirective } from 'src/app/dashboard_features/make-payment/reminders/payment-pending-approval.directive';
import { PaymentVoidedDirective } from 'src/app/dashboard_features/make-payment/reminders/payment-voided.directive';
import { RejectedPaymentDirective } from 'src/app/dashboard_features/make-payment/reminders/rejected-payment.directive';
import { AwatingForApprovalMakePaymentDirective } from 'src/app/dashboard_features/make-payment/reminders/awating-for-approval-make-payment.directive';
import { RecentlyCreatedPaymentComponent } from 'src/app/dashboard_features/make-payment/indicators/recently-created-payment/recently-created-payment.component';
import { TotalOpenMpComponent } from 'src/app/dashboard_features/make-payment/indicators/total-open-mp/total-open-mp.component';
import { LocalForexCurrencyComponent } from 'src/app/dashboard_features/make-payment/charts/local-forex-currency/local-forex-currency.component';
import { PaymentApprovalAgingComponent } from 'src/app/dashboard_features/make-payment/charts/payment-approval-aging/payment-approval-aging.component';

//Invoice
import { BillsPendingApprovalApDirective } from 'src/app/dashboard_features/ap-invoice/reminders/bills-pending-approval-ap.directive';
import { BillsApprovedApDirective } from 'src/app/dashboard_features/ap-invoice/reminders/bills-approved-ap.directive';
import { PartiallyPaidBillsDirective } from 'src/app/dashboard_features/ap-invoice/reminders/partially-paid-bills.directive';
import { PartiallyApprovedBillsDirective } from 'src/app/dashboard_features/ap-invoice/reminders/partially-approved-bills.directive';
import { RejectedBillsApDirective } from 'src/app/dashboard_features/ap-invoice/reminders/rejected-bills-ap.directive';
import { AwatingForApprovalApDirective } from 'src/app/dashboard_features/ap-invoice/reminders/awating-for-approval-ap.directive';
import { RecentlyCreatedBillsApComponent } from 'src/app/dashboard_features/ap-invoice/indicators/recently-created-bills-ap/recently-created-bills-ap.component';
import { TotalBillsOpenBillsComponent } from 'src/app/dashboard_features/ap-invoice/indicators/total-bills-open-bills/total-bills-open-bills.component';
import { TotalApprovedVsTotalPaidBillsKpiComponent } from 'src/app/dashboard_features/ap-invoice/charts/total-approved-vs-total-paid-bills-kpi/total-approved-vs-total-paid-bills-kpi.component';
import { ApInvoiceAgingSummaryBarComponent } from 'src/app/dashboard_features/ap-invoice/charts/ap-invoice-aging-summary-bar/ap-invoice-aging-summary-bar.component';
import { CfoDashboardComponent } from './cfo-dashboard/cfo-dashboard.component';

//GRN
import { PartiallyReceivedPoDirective } from 'src/app/dashboard_features/store/reminders/partially-received-po.directive';
import { ApprovedPoGrnDirective } from 'src/app/dashboard_features/store/reminders/approved-po-grn.directive';
import { RecentlyCreatedGrnComponent } from 'src/app/dashboard_features/store/indicators/recently-created-grn/recently-created-grn.component';
import { TotalReceivedTotalReturnGrnComponent } from 'src/app/dashboard_features/store/indicators/total-received-total-return-grn/total-received-total-return-grn.component';
import { GrnVsBillKpiComponent } from 'src/app/dashboard_features/store/charts/grn-vs-bill-kpi/grn-vs-bill-kpi.component';
import { ShipmentDetailsPieComponent } from 'src/app/dashboard_features/store/charts/shipment-details-pie/shipment-details-pie.component';
import { TotalReceivedAndReturnSupplierBarComponent } from 'src/app/dashboard_features/store/charts/total-received-and-return-supplier-bar/total-received-and-return-supplier-bar.component';
import { ItemWiseReceivedBarComponent } from 'src/app/dashboard_features/store/charts/item-wise-received-bar/item-wise-received-bar.component';
import { LocationWiseReceivedBarComponent } from 'src/app/dashboard_features/store/charts/location-wise-received-bar/location-wise-received-bar.component';
import { ItemWiseHoldingValuePieComponent } from 'src/app/dashboard_features/store/charts/item-wise-holding-value-pie/item-wise-holding-value-pie.component';

//Supplier or Vendor
import { RejectedSupplierDirective } from 'src/app/dashboard_features/vendor-master/reminders/rejected-supplier.directive';
import { SupplierPartiallyApprovalDirective } from 'src/app/dashboard_features/vendor-master/reminders/supplier-partially-approval.directive';
import { SupplierPendingApprovalDirective } from 'src/app/dashboard_features/vendor-master/reminders/supplier-pending-approval.directive';
import { CategoryWiseSupplierBarComponent } from 'src/app/dashboard_features/vendor-master/charts/category-wise-supplier-bar/category-wise-supplier-bar.component';
import { CountryWiseSupplierPieComponent } from 'src/app/dashboard_features/vendor-master/charts/country-wise-supplier-pie/country-wise-supplier-pie.component';
import { DeliveryPerformanceBarComponent } from 'src/app/dashboard_features/vendor-master/charts/delivery-performance-bar/delivery-performance-bar.component';
import { SupplierApprovalAgingBarComponent } from 'src/app/dashboard_features/vendor-master/charts/supplier-approval-aging-bar/supplier-approval-aging-bar.component';
import { TotalReceivedAndReturnBarComponent } from 'src/app/dashboard_features/vendor-master/charts/total-received-and-return-bar/total-received-and-return-bar.component';
import { TotalSupplierVsApproveSupplierKpiComponent } from 'src/app/dashboard_features/vendor-master/charts/total-supplier-vs-approve-supplier-kpi/total-supplier-vs-approve-supplier-kpi.component';
import { RecentlyCreatedSupplierComponent } from 'src/app/dashboard_features/vendor-master/indicators/recently-created-supplier/recently-created-supplier.component';
import { RegisteredUnregisteredSupplierComponent } from 'src/app/dashboard_features/vendor-master/indicators/registered-unregistered-supplier/registered-unregistered-supplier.component';
import { TotalHavingAccessSupplierComponent } from 'src/app/dashboard_features/vendor-master/indicators/total-having-access-supplier/total-having-access-supplier.component';
import { RootAdminDashboardComponent } from './root-admin-dashboard/root-admin-dashboard.component';

// Make Paymeny
import { AwatingForApprovalDebitNoteDirective } from 'src/app/dashboard_features/debit-note/reminders/awating-for-approval-debit-note.directive';

// rtv
import { AwatingForApprovalRtvDirective } from 'src/app/dashboard_features/rtv/reminders/awating-for-approval-rtv.directive';

//Product Dashboard for ROOT ADMIN (ROOT-ADMIN-DASHBOARD)
import { PendingAccessDirective } from 'src/app/dashboard_features/product/reminders/pending-access.directive';
import { PendingCompanyCreationDirective } from 'src/app/dashboard_features/product/reminders/pending-company-creation.directive';
import { TotalCreatedRecentelyCreatedCompanyComponent } from 'src/app/dashboard_features/product/indicators/total-created-recentely-created-company/total-created-recentely-created-company.component';
import { UpcomingCompanyExpirationInactivatedCompanyComponent } from 'src/app/dashboard_features/product/indicators/upcoming-company-expiration-inactivated-company/upcoming-company-expiration-inactivated-company.component';
import { PackageUpdateDetailsBarComponent } from 'src/app/dashboard_features/product/charts/package-update-details-bar/package-update-details-bar.component';
import { YearWiseRegistrationBarComponent } from 'src/app/dashboard_features/product/charts/year-wise-registration-bar/year-wise-registration-bar.component';
import { ActiveInactiveRegistrationBarComponent } from 'src/app/dashboard_features/product/charts/active-inactive-registration-bar/active-inactive-registration-bar.component';
import { TotalActiveVsDeactivatedProductPieComponent } from 'src/app/dashboard_features/product/charts/total-active-vs-deactivated-product-pie/total-active-vs-deactivated-product-pie.component';

//CFO
import { CfoDraftPrDirective } from 'src/app/dashboard_features/cfo-dashboard/reminders/cfo-draft-pr.directive';
import { CfoPrApprovalAgingComponent } from 'src/app/dashboard_features/cfo-dashboard/indicators/cfo-pr-approval-aging/cfo-pr-approval-aging.component';
import { CfoMonthlyPaymentTrendBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-monthly-payment-trend-bar/cfo-monthly-payment-trend-bar.component';
import { CfoTotalPayebleAmountCurrencyWiseBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-total-payeble-amount-currency-wise-bar/cfo-total-payeble-amount-currency-wise-bar.component';
import { CfoTotalOverDuesBillPieComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-total-over-dues-bill-pie/cfo-total-over-dues-bill-pie.component';
import { CfoTotalPayeblePaymentCurrencyWiseBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-total-payeble-payment-currency-wise-bar/cfo-total-payeble-payment-currency-wise-bar.component';
import { CfoTotalPoAndUnapprovedComponent } from 'src/app/dashboard_features/cfo-dashboard/indicators/cfo-total-po-and-unapproved/cfo-total-po-and-unapproved.component';
import { CfoTotalInvoiceAndUnapprovedComponent } from 'src/app/dashboard_features/cfo-dashboard/indicators/cfo-total-invoice-and-unapproved/cfo-total-invoice-and-unapproved.component';
import { CfoRecentlyCreatedSupplierAndUnapprovedComponent } from 'src/app/dashboard_features/cfo-dashboard/indicators/cfo-recently-created-supplier-and-unapproved/cfo-recently-created-supplier-and-unapproved.component';
import { CfoTotalAdvanceAndTotalPaidAmountCurrencywiseBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-total-advance-and-total-paid-amount-currencywise-bar/cfo-total-advance-and-total-paid-amount-currencywise-bar.component';
import { CfoTotalOutstandingBySubsidiaryBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-total-outstanding-by-subsidiary-bar/cfo-total-outstanding-by-subsidiary-bar.component';
import { CfoInvoiceAgingForSubsidiaryidsBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-invoice-aging-for-subsidiaryids-bar/cfo-invoice-aging-for-subsidiaryids-bar.component';

@NgModule({
  declarations: [
    DashboardPanelComponent,
    // pr
    OpenandApprovedPRComponent,
    ProjectWisePrComponent,
    PrOnPriorityComponent,
    PrToRfqAndPoComponent,
    PrAgingComponent,
    TotalPrKPIComponent,
    RecentlyCreatedPrComponent,
    ProjectWisePRComponent,
    //PO
    OpenPoComponent,
    RecentlyCreatedPOComponent,
    TotalSupplierComponent,
    LocationBasedPOComponent,
    PoApprovedBuildKPIComponent,
    PoApprovalAgingComponent,
    // Advance Paymeny
    TotalOpenApComponent,
    RecentlyCreatedComponent,
    MonthlyAdvanceTrendBarComponent,
    TotalVsApprovedPaymentComponent,
    // Make Paymeny
    RecentlyCreatedPaymentComponent,
    TotalOpenMpComponent,
    LocalForexCurrencyComponent,
    PaymentApprovalAgingComponent,
    //Invoice
    RecentlyCreatedBillsApComponent,
    TotalBillsOpenBillsComponent,
    TotalApprovedVsTotalPaidBillsKpiComponent,
    ApInvoiceAgingSummaryBarComponent,
    CfoDashboardComponent,
    //GRN
    RecentlyCreatedGrnComponent,
    TotalReceivedTotalReturnGrnComponent,
    GrnVsBillKpiComponent,
    ShipmentDetailsPieComponent,
    TotalReceivedAndReturnSupplierBarComponent,
    ItemWiseReceivedBarComponent,
    LocationWiseReceivedBarComponent,
    ItemWiseHoldingValuePieComponent,
    //CFO
    CfoPrApprovalAgingComponent,
    CfoMonthlyPaymentTrendBarComponent,
    CfoTotalPayebleAmountCurrencyWiseBarComponent,
    CfoTotalOverDuesBillPieComponent,
    CfoTotalPayeblePaymentCurrencyWiseBarComponent,
    CfoTotalPoAndUnapprovedComponent,
    CfoTotalInvoiceAndUnapprovedComponent,
    CfoRecentlyCreatedSupplierAndUnapprovedComponent,
    CfoTotalAdvanceAndTotalPaidAmountCurrencywiseBarComponent,
    CfoTotalOutstandingBySubsidiaryBarComponent,
    CfoInvoiceAgingForSubsidiaryidsBarComponent,
    //Supplier or Vendor
    TotalHavingAccessSupplierComponent,
    RegisteredUnregisteredSupplierComponent,
    RecentlyCreatedSupplierComponent,
    CategoryWiseSupplierBarComponent,
    CountryWiseSupplierPieComponent,
    DeliveryPerformanceBarComponent,
    SupplierApprovalAgingBarComponent,
    TotalReceivedAndReturnBarComponent,
    TotalSupplierVsApproveSupplierKpiComponent,
    RootAdminDashboardComponent,

    //Dashboard for ROOT ADMIN product (ROOT-ADMIN-DASHBOARD)
    TotalCreatedRecentelyCreatedCompanyComponent,
    UpcomingCompanyExpirationInactivatedCompanyComponent,
    PackageUpdateDetailsBarComponent,
    YearWiseRegistrationBarComponent,
    ActiveInactiveRegistrationBarComponent,
    TotalActiveVsDeactivatedProductPieComponent,

  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    MessageModule,
    MessagesModule,
    CardModule,
    ChartModule,
    InputTextModule,
    TableModule,
    TabMenuModule,
    DialogModule,
    TabViewModule,
    SharedComponentsModule,
    DropdownModule,
    ReactiveFormsModule,
    CheckboxModule,
    ToggleButtonModule,
    MultiSelectModule,
    DividerModule,
    TagModule,
    FieldsetModule,
    SupplierModule,
    PanelModule,
    MenuModule,
    FormsModule,
    ButtonModule,
  ],
  providers: [
    // pr - reminders
    PartiallyApprovedDirective,
    PendingApprovalDirective,
    RejectedPrDirective,
    AwatingForApprovalPrDirective,
    // po - reminders
    PartiallyApprovedPODirective,
    PendingApprovalPODirective,
    RejectedPODirective,
    AwatingForApprovalPoDirective,
    // Advance Paymeny
    AdvanceApprovedDirective,
    AdvancePendingApprovalDirective,
    AppliedAdvanceDirective,
    PartiallyAppliedDirective,
    RejectedAdvanceDirective,
    AwatingForApprovalAdvancePaymentDirective,
    // Make Paymeny
    PaymentApprovedDirective,
    PaymentPendingApprovalDirective,
    PaymentVoidedDirective,
    RejectedPaymentDirective,
    AwatingForApprovalMakePaymentDirective,
    //Invoice
    BillsPendingApprovalApDirective,
    BillsApprovedApDirective,
    PartiallyPaidBillsDirective,
    PartiallyApprovedBillsDirective,
    RejectedBillsApDirective,
    AwatingForApprovalApDirective,
    //GRN
    PartiallyReceivedPoDirective,
    ApprovedPoGrnDirective,
    //Vendor or Supplier
    SupplierPendingApprovalDirective,
    SupplierPartiallyApprovalDirective,
    RejectedSupplierDirective,
    // Make Paymeny
    AwatingForApprovalDebitNoteDirective,
    // rtv
    AwatingForApprovalRtvDirective,
    //CFO
    CfoDraftPrDirective,
    //Dashboard for ROOT ADMIN product (ROOT-ADMIN-DASHBOARD)
    PendingAccessDirective,
    PendingCompanyCreationDirective,
  ]
})
export class DashboardModule { }
