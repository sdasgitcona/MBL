import { Component, OnInit, Inject, PLATFORM_ID, NgZone } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import { DashboardDataUpdateService } from 'src/app/core/services/dashboard-data-update.service';

import { CfoDraftPrDirective } from 'src/app/dashboard_features/cfo-dashboard/reminders/cfo-draft-pr.directive';
import { CfoPrApprovalAgingComponent } from 'src/app/dashboard_features/cfo-dashboard/indicators/cfo-pr-approval-aging/cfo-pr-approval-aging.component';
import { CfoMonthlyPaymentTrendBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-monthly-payment-trend-bar/cfo-monthly-payment-trend-bar.component';
import { CfoTotalPayebleAmountCurrencyWiseBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-total-payeble-amount-currency-wise-bar/cfo-total-payeble-amount-currency-wise-bar.component';
import { CfoTotalOverDuesBillPieComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-total-over-dues-bill-pie/cfo-total-over-dues-bill-pie.component';
import { CfoTotalPayeblePaymentCurrencyWiseBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-total-payeble-payment-currency-wise-bar/cfo-total-payeble-payment-currency-wise-bar.component';
import { CfoTotalPoAndUnapprovedComponent } from 'src/app/dashboard_features/cfo-dashboard/indicators/cfo-total-po-and-unapproved/cfo-total-po-and-unapproved.component';
import { CfoTotalInvoiceAndUnapprovedComponent } from 'src/app/dashboard_features/cfo-dashboard/indicators/cfo-total-invoice-and-unapproved/cfo-total-invoice-and-unapproved.component';
import { CfoRecentlyCreatedSupplierAndUnapprovedComponent } from 'src/app/dashboard_features/cfo-dashboard/indicators/cfo-recently-created-supplier-and-unapproved/cfo-recently-created-supplier-and-unapproved.component';
import { CfoTotalAdvanceAndTotalPaidAmountCurrencywiseBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-total-advance-and-total-paid-amount-currencywise-bar/cfo-total-advance-and-total-paid-amount-currencywise-bar.component';
import { CfoTotalOutstandingBySubsidiaryBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-total-outstanding-by-subsidiary-bar/cfo-total-outstanding-by-subsidiary-bar.component';
import { CfoInvoiceAgingForSubsidiaryidsBarComponent } from 'src/app/dashboard_features/cfo-dashboard/charts/cfo-invoice-aging-for-subsidiaryids-bar/cfo-invoice-aging-for-subsidiaryids-bar.component';

@Component({
  selector: 'app-cfo-dashboard',
  templateUrl: './cfo-dashboard.component.html',
  styleUrls: ['./cfo-dashboard.component.scss']
})
export class CfoDashboardComponent implements OnInit {


  allCards: any[] = [];
  selectedSubsidiaryId: any;
  RetloginDetails: any;
  isFullscreen: any = false;
  chartsComponents: any[] = [];
  indicatorsComponents: any[] = [];
  Subsidiarylist: any[] = [];
  RetRoleDetails: any;
  Subsidiaries: any;
  refreshRow: boolean = true;

  constructor(
    private dashboardDataUpdate: DashboardDataUpdateService,
    private httpService: CommonHttpService,
    private router: Router,
    private toastService: ToastService,
    private CfoDraftPr: CfoDraftPrDirective,
  ) { }

  ngOnInit(): void {
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails = role_Dtls;

    this.GetSubsideryList(); // For Getting Subsidery List

    // subscribe to changes to the selected subsidiary id of reminders
    this.dashboardDataUpdate.getSubsidiaryId().subscribe((id: any) => {
      this.selectedSubsidiaryId = id;
      this.reminders();
    });

    setTimeout(() => {
      // Get Subsidiary Id for CFO Dashboard from LocalStorage
      const GetCfoSubsidiaryId: any = localStorage.getItem("CFOSelectedSubId");
      this.selectedSubsidiaryId = JSON.parse(GetCfoSubsidiaryId);
      this.reminders();
      this.indicators();
      this.charts();
    }, 200); // Delay of 1 second (1000 milliseconds)
  }

  // For Getting Subsidery List
  GetSubsideryList() {
    if (this.RetloginDetails.userType == 'SUPERADMIN') {
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId=' + this.RetRoleDetails[0].accountId, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.Subsidiaries = res;
            this.Subsidiarylist = this.Subsidiaries.map((obj: { id: any; }) => obj.id);
            localStorage.setItem('CFOSelectedSubId', JSON.stringify(this.Subsidiarylist));
          }
        })
    }
  }

  // For Getting Reminders
  reminders() {
    // CFO Draft PR
    this.CfoDraftPr.getApiData(this.RetloginDetails.token, this.selectedSubsidiaryId);
    this.CfoDraftPr.CardsReady.subscribe(cards => {
      cards.forEach((Card: { category: any; value: any; param2: any; }) => {
        if (!this.checkExistingCard(Card, this.allCards)) {
          const index = this.allCards.findIndex(c => c.category === Card.category);
          if (index !== -1) {
            this.allCards[index].value = Card.value; // Update existing card value
            this.allCards[index].param2 = Card.param2; // Update existing card param2
          } else {
            this.allCards.push(Card); // Add new card
          }
        }
      })
    });
  }

  checkExistingCard(card: any, allCards: any[]): boolean {
    // Check if card data already exists in allCards array
    return allCards.some(c => c.category === card.category && c.value === card.value && c.link === card.link && c.param2 === card.param2);
  }

  // For Getting Indicators
  indicators() {
    this.indicatorsComponents.push(CfoPrApprovalAgingComponent,CfoTotalPoAndUnapprovedComponent,CfoTotalInvoiceAndUnapprovedComponent,CfoRecentlyCreatedSupplierAndUnapprovedComponent,)
  }

  // For Getting Charts
  charts() {
    this.chartsComponents.push(CfoMonthlyPaymentTrendBarComponent, CfoTotalPayebleAmountCurrencyWiseBarComponent, CfoTotalOverDuesBillPieComponent, CfoTotalPayeblePaymentCurrencyWiseBarComponent,CfoTotalAdvanceAndTotalPaidAmountCurrencywiseBarComponent,CfoTotalOutstandingBySubsidiaryBarComponent,CfoInvoiceAgingForSubsidiaryidsBarComponent,)
  }

  // Function that will run after Changing Subsidery and Update Subsidery in all CFO Component
  changeSubsidery() {
    // Store selected subsidiary in local storage
    localStorage.setItem('CFOSelectedSubId', JSON.stringify(this.selectedSubsidiaryId));
    this.dashboardDataUpdate.sendSubsidiaryId(this.selectedSubsidiaryId);
    this.refreshDiv();
  }

  // For Pushing all Subsidery List in All CFO Component 
  allSubsidery(): void {
    // Store selected subsidiary in local storage
    localStorage.setItem('CFOSelectedSubId', JSON.stringify(this.Subsidiarylist));
    this.selectedSubsidiaryId = this.Subsidiarylist;
    this.dashboardDataUpdate.sendSubsidiaryId(this.selectedSubsidiaryId);
    this.refreshDiv();
  }

  // For Refresh Div
  refreshDiv(): void {
    // Toggle the refreshRow variable to refresh the <div class="row"> element
    this.refreshRow = false;
    setTimeout(() => {
      this.refreshRow = true;
    }, 100);
  }

  showAlert(AlertMSG: any) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }

  toggleFullscreen() {
    let div = document.querySelector('.fullscreenDiv');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }

  toggleFullscreenRightDiv() {
    let div = document.querySelector('.fullscreenRightDiv');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }

}
