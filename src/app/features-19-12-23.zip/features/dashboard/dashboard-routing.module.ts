import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {DashboardPanelComponent} from './dashboard-panel/dashboard-panel.component'
import { CfoDashboardComponent } from './cfo-dashboard/cfo-dashboard.component';
import { RootAdminDashboardComponent } from './root-admin-dashboard/root-admin-dashboard.component';

const routes: Routes = [
  { path: '', component: DashboardPanelComponent,},
  { path : 'cfo_dashboard', component : CfoDashboardComponent },
  { path : 'product_dashboard', component : RootAdminDashboardComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
