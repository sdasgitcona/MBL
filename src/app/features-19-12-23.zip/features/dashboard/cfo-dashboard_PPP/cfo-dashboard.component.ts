import { Component, OnInit, Inject, PLATFORM_ID, NgZone } from '@angular/core';

import * as am5 from "@amcharts/amcharts5";
import * as am5xy from "@amcharts/amcharts5/xy";
import * as am5radar from "@amcharts/amcharts5/radar";
import * as am5percent from "@amcharts/amcharts5/percent";
import am5themes_Animated from '@amcharts/amcharts5/themes/Animated';

import { MenuItem } from 'primeng/api';
import { MessageService } from 'primeng/api';
import { PrimeNGConfig } from 'primeng/api';
import { isPlatformBrowser } from '@angular/common';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { any } from '@amcharts/amcharts5/.internal/core/util/Array';

am5.addLicense("AM5C367311118");

@Component({
  selector: 'app-cfo-dashboard',
  templateUrl: './cfo-dashboard.component.html',
  styleUrls: ['./cfo-dashboard.component.scss']
})
export class CfoDashboardComponent implements OnInit {

  
  data2: any;
  seriesColumn: any;
  xAxisColumn: any

  selectColumn = [
    "NORTH AMERICA",
    "ASIA",
    "EUROPE"
  ];
  selectedColumn: any;


  items1: MenuItem[];
  isFullscreen: any = false;
  httpService: any;
  RetloginDetails: any;



  chart3: any;
  series2: any;
  selectedColumn2: string;

 

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,

    private zone: NgZone,
    private messageService: MessageService,
    private primengConfig: PrimeNGConfig,
    private CommonHttpService: CommonHttpService
  ) { }

  ngOnInit(): void {

    //----------------------------------------------------------------------- TOKEN     --------/////////////////////////
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    //----------------------------------------------------------------------- TOKEN     -------///////////////////////////

    this.initbarSort();



    this.Pie_Chart();    ////------------------------- PIE  CHART     ---------------------/////////////////////////////

    this.DONUT_Chart();   ////--------------------      DONUT    CHART    -----------------/////////////////////////////

    this.DONUT_Chart_2();   /////--------------------   DONUT  CHART  WITH  EMPTY SPACE   -----------------///////////////////////////

    this.testingStack();
    this.primengConfig.ripple = true;
    this.items1 = [
      {
        label: 'Options',
        items: [{
          label: 'Update',
          icon: 'pi pi-refresh',
          command: () => {
            this.update();
          }
        },
        {
          label: 'Delete',
          icon: 'pi pi-times',
          command: () => {
            this.delete();
          }
        },
        {
          label: 'Maximize',
          icon: 'pi pi-times',

        }
        ]
      },
      {
        label: 'Navigate',
        items: [{
          label: 'Angular Website',
          icon: 'pi pi-external-link',
          url: 'http://angular.io'
        },
        {
          label: 'Router',
          icon: 'pi pi-upload',
          routerLink: '/fileupload'
        }
        ]
      }
    ];

    this.initAPIGuage();

  }

  update() {
    this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Data Updated' });
  }

  delete() {
    this.messageService.add({ severity: 'warn', summary: 'Delete', detail: 'Data Deleted' });
  }

  toggleFullscreen() {
    let div = document.querySelector('.fullscreenDiv');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }
  toggleFullscreen2() {
    let div = document.querySelector('.fullscreenDiv2');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }
  toggleFullscreen3() {
    let div = document.querySelector('.fullscreenDiv3');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }
  toggleFullscreen4() {
    let div = document.querySelector('.fullscreenDiv4');
    div?.classList.toggle('fullscreen');
    this.isFullscreen = !this.isFullscreen;
  }



  initAPIGuage() {
    let root = am5.Root.new("totalBills");
    // Set themes
    // https://www.amcharts.com/docs/v5/concepts/themes/
    root.setThemes([
      am5themes_Animated.new(root)
    ]);


    // Create chart
    // https://www.amcharts.com/docs/v5/charts/radar-chart/
    let chart = root.container.children.push(am5radar.RadarChart.new(root, {
      panX: false,
      panY: false,
      startAngle: 160,
      endAngle: 380,
      innerRadius: -20
    }));


    // Create axis and its renderer
    // https://www.amcharts.com/docs/v5/charts/radar-chart/gauge-charts/#Axes
    let axisRenderer = am5radar.AxisRendererCircular.new(root, {
      innerRadius: -30
    });

    axisRenderer.grid.template.setAll({
      stroke: root.interfaceColors.get("background"),
      visible: true,
      strokeOpacity: 0.0
    });

    let xAxis = chart.xAxes.push(am5xy.ValueAxis.new(root, {
      maxDeviation: 0,
      min: 0,
      max: 100,
      strictMinMax: true,
      renderer: axisRenderer
    }));


    // Add clock hand
    // https://www.amcharts.com/docs/v5/charts/radar-chart/gauge-charts/#Clock_hands
    let axisDataItem = xAxis.makeDataItem({});

    let clockHand = am5radar.ClockHand.new(root, {
      pinRadius: am5.percent(10),
      radius: am5.percent(130),
      bottomWidth: 15
    })

    let bullet = axisDataItem.set("bullet", am5xy.AxisBullet.new(root, {
      sprite: clockHand
    }));

    xAxis.createAxisRange(axisDataItem);

    let label = chart.radarContainer.children.push(am5.Label.new(root, {
      fill: am5.color(0xffffff),
      centerX: am5.percent(50),
      textAlign: "center",
      centerY: am5.percent(50),
      fontSize: "1em"
    }));

    axisDataItem.set("value", 50);
    bullet.get("sprite").on("rotation", function () {
      let value = axisDataItem.get("value");
      //   let text = Math.round(axisDataItem.get("value")).toString();
      //   let fill = am5.color(0x000000);
      //   xAxis.axisRanges.each(function (axisRange) {
      //     if (value >= axisRange.get("value") && value <= axisRange.get("endValue")) {
      //       fill = axisRange.get("axisFill").get("fill");
      //     }
      //   })

      //   label.set("text", Math.round(value).toString());

      //   clockHand.pin.animate({ key: "fill", to: fill, duration: 500, easing: am5.ease.out(am5.ease.cubic) })
      //   clockHand.hand.animate({ key: "fill", to: fill, duration: 500, easing: am5.ease.out(am5.ease.cubic) })
    });

    setInterval(function () {
      axisDataItem.animate({
        key: "value",
        to: Math.round(Math.random() * 140 - 40),
        duration: 5000,
        easing: am5.ease.out(am5.ease.cubic)
      });
    }, 2000)

    chart.bulletsContainer.set("mask", undefined);


    // Create axis ranges bands
    // https://www.amcharts.com/docs/v5/charts/radar-chart/gauge-charts/#Bands
    let bandsData = [{
      title: "Foundational",
      color: "#fdae19",
      lowScore: 0,
      highScore: 20
    }, {
      title: "Developing",
      color: "#f3eb0c",
      lowScore: 20,
      highScore: 40
    }, {
      title: "Maturing",
      color: "#b0d136",
      lowScore: 40,
      highScore: 60
    }, {
      title: "Sustainable",
      color: "#54b947",
      lowScore: 60,
      highScore: 80
    }, {
      title: "High Performing",
      color: "#0f9747",
      lowScore: 80,
      highScore: 100
    }];

    am5.array.each(bandsData, function (data) {
      let axisRange = xAxis.createAxisRange(xAxis.makeDataItem({}));

      axisRange.setAll({
        value: data.lowScore,
        endValue: data.highScore
      });

      axisRange.get("axisFill")?.setAll({
        visible: true,
        fill: am5.color(data.color),
        fillOpacity: 0.8
      });

      // axisRange.get("axisFill").setAll({
      //   visible: true,
      //   fill: am5.color(data.color),
      //   fillOpacity: 0.8
      // });

      // axisRange.get("label").setAll({
      //   text: data.title,
      //   inside: true,
      //   radius: 15,
      //   fontSize: "0.9em",
      //   fill: root.interfaceColors.get("background")
      // });
    });


    // Make stuff animate on load
    chart.appear(1000, 100);
  }

  initbarSort() {
    let root = am5.Root.new("chartbarSort");


    // Set themes
    // https://www.amcharts.com/docs/v5/concepts/themes/
    root.setThemes([
      am5themes_Animated.new(root)
    ]);


    // Create chart
    // https://www.amcharts.com/docs/v5/charts/xy-chart/
    let chart = root.container.children.push(am5xy.XYChart.new(root, {
      panX: false,
      panY: false,
      wheelX: "panX",
      wheelY: "zoomX",
      layout: root.verticalLayout
    }));


    // Data
    let colors = chart.get("colors");

    let data = [{
      country: "Mar 22",
      visits: 725,
      columnSettings: { fill: colors?.next() }
    }, {
      country: "Apr 22",
      visits: 625,
      columnSettings: { fill: colors?.next() }
    }, {
      country: "May 22",
      visits: 602,
      columnSettings: { fill: colors?.next() }
    }, {
      country: "Jun 22",
      visits: 509,
      columnSettings: { fill: colors?.next() }
    }, {
      country: "Jul 22",
      visits: 322,
      columnSettings: { fill: colors?.next() }
    }, {
      country: "Aug 22",
      visits: 214,
      columnSettings: { fill: colors?.next() }
    }, {
      country: "Sep 22",
      visits: 204,
      columnSettings: { fill: colors?.next() }
    }, {
      country: "Oct 22",
      visits: 198,
      columnSettings: { fill: colors?.next() }
    }, {
      country: "Nov 22",
      visits: 165,
      columnSettings: { fill: colors?.next() }
    }, {
      country: "Dec 22",
      visits: 93,
      columnSettings: { fill: colors?.next() }
    }, {
      country: "Jan 23",
      visits: 41,
      columnSettings: { fill: colors?.next() }
    }, {
      country: "Feb 23",
      visits: 41,
      columnSettings: { fill: colors?.next() }
    }
    ];


    // Create axes
    // https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
    let xRenderer = am5xy.AxisRendererX.new(root, {
      minGridDistance: 30
    })

    let xAxis = chart.xAxes.push(am5xy.CategoryAxis.new(root, {
      categoryField: "country",
      renderer: xRenderer,
      bullet: function (root, axis, dataItem) {
        return am5xy.AxisBullet.new(root, {
          location: 0.5,
          sprite: am5.Picture.new(root, {
            width: 24,
            height: 24,
            centerY: am5.p50,
            centerX: am5.p50,
          })
        });
      }
    }));

    xRenderer.grid.template.setAll({
      location: 1
    })

    xRenderer.labels.template.setAll({
      paddingTop: 20
    });

    xAxis.data.setAll(data);

    let yAxis = chart.yAxes.push(am5xy.ValueAxis.new(root, {
      renderer: am5xy.AxisRendererY.new(root, {
        strokeOpacity: 0.1
      })
    }));


    // Add series
    // https://www.amcharts.com/docs/v5/charts/xy-chart/series/
    let series = chart.series.push(am5xy.ColumnSeries.new(root, {
      xAxis: xAxis,
      yAxis: yAxis,
      valueYField: "visits",
      categoryXField: "country"
    }));
   
    series.columns.template.setAll({
      tooltipText: "{categoryX}: {valueY}",
      tooltipY: 0,
      strokeOpacity: 0,
      templateField: "columnSettings"
    });

    series.data.setAll(data);


    // Make stuff animate on load
    // https://www.amcharts.com/docs/v5/concepts/animations/
    series.appear();
    chart.appear(1000, 100);

  };


   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ////////-------------------------------------------      NEW  ADDED   PROGRAMS      ---------------------------/////////////////////
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


  Pie_Chart() {
    let root = am5.Root.new("chartdiv");

    // Set themes
    // https://www.amcharts.com/docs/v5/concepts/themes/
    root.setThemes([
      am5themes_Animated.new(root)
    ]);

    // Create chart
    // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/
    let chart = root.container.children.push(
      am5percent.PieChart.new(root, {
        endAngle: 270
      })
    );

    // Create series
    // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Series
    let series = chart.series.push(
      am5percent.PieSeries.new(root, {
        valueField: "value",
        categoryField: "category",
        endAngle: 270
      })
    );

    series.states.create("hidden", {
      endAngle: -90
    });

    //////------- Set data in API
    this.CommonHttpService.GetById(`/masters-ws/supplier/get-supplier-dashboard-by-approval-status?SubsidiaryId=19`, this.RetloginDetails.token, this.RetloginDetails.token)
      .subscribe((res) => {

        console.log(res)
        series.data.setAll(res)
        series.appear(1000, 100);

      })



      

  }

  DONUT_Chart() {
    let root = am5.Root.new("chartdivs");

    // Set themes
    // https://www.amcharts.com/docs/v5/concepts/themes/
    root.setThemes([
      am5themes_Animated.new(root)
    ]);

    // Create chart
    // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/
    let chart = root.container.children.push(am5percent.PieChart.new(root, {
      radius: am5.percent(90),
      innerRadius: am5.percent(50),
      layout: root.horizontalLayout
    }));

    // Create series
    // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Series
    let series2 = chart.series.push(am5percent.PieSeries.new(root, {
      name: "Series",
      valueField: "value",
      categoryField: "category"
    }));

    // Set data
    https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Setting_data

    this.CommonHttpService.GetById(`/masters-ws/employee/get-active-inactive-employee-count?subsidiaryId=4`, this.RetloginDetails.token, this.RetloginDetails.token)
      .subscribe((res) => {
        console.log(res)
        series2.data.setAll(res)
        series2.appear(1000, 100);
        // Disabling labels and ticks
        series2.labels.template.set("visible", false);
        series2.ticks.template.set("visible", false);

        // Adding gradients
        series2.slices.template.set("strokeOpacity", 0);
        series2.slices.template.set("fillGradient", am5.RadialGradient.new(root, {
          stops: [{
            brighten: -0.8
          }, {
            brighten: -0.8
          }, {
            brighten: -0.5
          }, {
            brighten: 0
          }, {
            brighten: -0.5
          }]
        }));

        // Create legend
        // https://www.amcharts.com/docs/v5/charts/percent-charts/legend-percent-series/
        let legend = chart.children.push(am5.Legend.new(root, {
          centerY: am5.percent(50),
          y: am5.percent(50),
          layout: root.verticalLayout
        }));
        // set value labels align to right
        legend.valueLabels.template.setAll({ textAlign: "right" })
        // set width and max width of labels
        legend.labels.template.setAll({
          maxWidth: 140,
          width: 140,
          oversizedBehavior: "wrap"
        });

        legend.data.setAll(series2.dataItems);


        // Play initial series animation
        // https://www.amcharts.com/docs/v5/concepts/animations/#Animation_of_series
        series2.appear(1000, 100);
      })

    //  series2.data.setAll([{
    //   country: "Lithuania",
    //   sales: 501.9
    // }, {
    //   country: "Czechia",
    //   sales: 301.9
    // }, {
    //   country: "Ireland",
    //   sales: 201.1
    // }, {
    //   country: "Germany",
    //   sales: 165.8
    // }, {
    //   country: "Australia",
    //   sales: 139.9
    // }, {
    //   country: "Austria",
    //   sales: 128.3
    // }, {
    //   country: "UK",
    //   sales: 99
    // }, {
    //   country: "Belgium",
    //   sales: 60
    // }, {
    //   country: "The Netherlands",
    //   sales: 50
    // }]);  


  }



  DONUT_Chart_2() {
    let root = am5.Root.new("chartdivrs");


    // Set themes
    // https://www.amcharts.com/docs/v5/concepts/themes/
    root.setThemes([
      am5themes_Animated.new(root)
    ]);


    // Create chart
    // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/
    let chart = root.container.children.push(am5percent.PieChart.new(root, {
      layout: root.verticalLayout,
      innerRadius: am5.percent(50)
    }));


    // Create series
    // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Series
    let series3 = chart.series.push(am5percent.PieSeries.new(root, {
      valueField: "value",
      categoryField: "category",
      alignLabels: false
    }));

    series3.labels.template.setAll({
      textType: "circular",
      centerX: 0,
      centerY: 0
    });


    // Set data

    this.CommonHttpService.GetById(`/masters-ws/employee/get-active-inactive-employee-count?subsidiaryId=4`, this.RetloginDetails.token, this.RetloginDetails.token)
      .subscribe((res) => {
        console.log(res)
        series3.data.setAll(res)
        series3.appear(1000, 100);

      })


    // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart/#Setting_data
    // series.data.setAll([
    //   { value: 10, category: "One" },
    //   { value: 9, category: "Two" },
    //   { value: 6, category: "Three" },
    //   { value: 5, category: "Four" },
    //   { value: 4, category: "Five" },
    //   { value: 3, category: "Six" },
    //   { value: 1, category: "Seven" },
    // ]);


    // Create legend
    // https://www.amcharts.com/docs/v5/charts/percent-charts/legend-percent-series/
    let legend = chart.children.push(am5.Legend.new(root, {
      centerX: am5.percent(50),
      x: am5.percent(50),
      marginTop: 15,
      marginBottom: 15,
    }));

    legend.data.setAll(series3.dataItems);


    // Play initial series animation
    // https://www.amcharts.com/docs/v5/concepts/animations/#Animation_of_series
    // series.appear(1000, 100);
  }



  testingStack(){
    /* Chart code */
    // Create root element
    // https://www.amcharts.com/docs/v5/getting-started/#Root_element
    let root = am5.Root.new("chartbarSort9");


    // Set themes
    // https://www.amcharts.com/docs/v5/concepts/themes/
    root.setThemes([
      am5themes_Animated.new(root)
    ]);


    // Create chart
    // https://www.amcharts.com/docs/v5/charts/xy-chart/
    let chart = root.container.children.push(am5xy.XYChart.new(root, {
      panX: false,
      panY: false,
      // wheelX: "panX",
      // wheelY: "zoomX",
      layout: root.verticalLayout
    }));

    // Add scrollbar
    // https://www.amcharts.com/docs/v5/charts/xy-chart/scrollbars/
    // chart.set("scrollbarX", am5.Scrollbar.new(root, {
    //   orientation: "horizontal"
    // }));

    let data = [{
      "year": "2021",
      "europe": 2.5,
      "namerica": 2.5,
      "asia": 2.1,
      "lamerica": 1,
    }, {
      "year": "2022",
      "europe": 2.6,
      // "namerica": 0,
      "asia": 2.2,
      "lamerica": 0.5,
    }, {
      "year": "2023",
      "europe": 2.8,
      "namerica": 2.9,
      "asia": 2.4,
      "lamerica": 0.3,
    }]


    // Create axes
    // https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
    let xRenderer = am5xy.AxisRendererX.new(root, {});
    let xAxis = chart.xAxes.push(am5xy.CategoryAxis.new(root, {
      categoryField: "year",
      renderer: xRenderer,
      tooltip: am5.Tooltip.new(root, {})
    }));

    xRenderer.grid.template.setAll({
      location: 1
    })

    xAxis.data.setAll(data);

    let yAxis = chart.yAxes.push(am5xy.ValueAxis.new(root, {
      min: 0,
      renderer: am5xy.AxisRendererY.new(root, {
        strokeOpacity: 0.1
      })
    }));


    // Add legend
    // https://www.amcharts.com/docs/v5/charts/xy-chart/legend-xy-series/
    let legend = chart.children.push(am5.Legend.new(root, {
      centerX: am5.p50,
      x: am5.p50
    }));


    // Add series
    // https://www.amcharts.com/docs/v5/charts/xy-chart/series/
    function makeSeries(name:any, fieldName:any) {
      let series = chart.series.push(am5xy.ColumnSeries.new(root, {
        name: name,
        stacked: true,
        xAxis: xAxis,
        yAxis: yAxis,
        valueYField: fieldName,
        categoryXField: "year"
      }));

      series.columns.template.setAll({
        tooltipText: "{name}, {categoryX}: {valueY}",
        tooltipY: am5.percent(10)
      });
      series.data.setAll(data);

      // Make stuff animate on load
      // https://www.amcharts.com/docs/v5/concepts/animations/
      series.appear();

      series.bullets.push(function () {
        return am5.Bullet.new(root, {
          sprite: am5.Label.new(root, {
            text: "{valueY}",
            fill: root.interfaceColors.get("alternativeText"),
            centerY: am5.p50,
            centerX: am5.p50,
            populateText: true
          })
        });
      });

      legend.data.push(series);
    }

    makeSeries("Europe", "europe");
    makeSeries("North America", "namerica");
    makeSeries("Asia", "asia");
    makeSeries("Latin America", "lamerica");


    // Make stuff animate on load
    // https://www.amcharts.com/docs/v5/concepts/animations/
    chart.appear(1000, 100);
  }
  

}
