import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubsidiaryAddEditComponent } from './subsidiary-add-edit.component';

describe('SubsidiaryAddEditComponent', () => {
  let component: SubsidiaryAddEditComponent;
  let fixture: ComponentFixture<SubsidiaryAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubsidiaryAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SubsidiaryAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
