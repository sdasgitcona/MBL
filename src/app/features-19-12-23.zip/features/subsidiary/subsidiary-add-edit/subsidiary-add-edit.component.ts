import { formatDate } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { AddressComponent } from 'src/app/shared/shared-components/address/address.component';
import { CountryModel } from 'src/app/shared/shared-components/address/model/address.model';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { SubsidiaryAddress, Subsidiary,parentcompany,subsidiaryGeneralInfo } from '../Model/subsidiary-model';
let $:any;
@Component({
  selector: 'app-subsidiary-add-edit',
  templateUrl: './subsidiary-add-edit.component.html',
  styleUrls: ['./subsidiary-add-edit.component.scss']
})
export class SubsidiaryAddEditComponent implements OnInit {

  subsidiary:Subsidiary=new Subsidiary();
  selectedSubsidiaryAddress: SubsidiaryAddress = new SubsidiaryAddress();
  totalSubsidiaryAddresses: number = 0;
  SubsidiaryId: number = 0;
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  addressData: any;
  displayAddressDialog: boolean = false;
  SubsidiaryHistoryList: HistoryModel[] = [];
  selectedGeneralInfo: subsidiaryGeneralInfo = new subsidiaryGeneralInfo();
  isvisibleactive:boolean=true;
  isvisibleinactive:boolean=true;
  languageOptions: any;
  invoicemailId:any[];
  //fiscalCalanderption: any;
  registrationTypeOptions: any;
  checked: boolean;
  currency: [{ id?: number; name?: string; code?: string; }];
  selectedIndex:any
  //ParentCompanyList:any;
  ParentCompanyList:parentcompany[]=[];
  countries: CountryModel[] = [];
  fiscalCal: [{ id?: number; name?: string; yearName?:string }];
  isReloadSub:boolean;
  isReloadCurrency:boolean;
  isReloadCompany:boolean;
  isLogoShow: boolean;
  showloader: boolean=false;
  url1:any;
  RetRoleDetails:any;
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   isviewEditable:boolean=true;
   isAvailableReceiveMail:boolean;
   // For Role Base Access
   RetloginDetails:any;

  @ViewChild(AddressComponent) addressComponent: AddressComponent;
  constructor(
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService
  )
 
  {
   
    this.languageOptions = ['Bengali', 'Hindi', 'English', 'Tamil','Talegue'];


    this.registrationTypeOptions = [{id:'Registered',value:'Registered'},{id:'Unregistered',value:'Unregistered'},{id:'Overseas',value:'Overseas'}];

  }

 

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;
 this.subsidiary.accountId=role_Dtls[0].accountId;

const LDetails:any=localStorage.getItem("LoggerDTLS");
this.RetloginDetails = JSON.parse(LDetails);

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Subsidiary")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
   if( this.isCreatetable == false && this.isEditable== false &&  this.isViewtable == false){
    {
      if (this.RetloginDetails.userType=='SUPERADMIN' || this.RetloginDetails.userType=='ROOTADMIN'){
        this.router.navigate(['/main/dashboard/cfo_dashboard']);
      }
      else {
        this.router.navigate(['/main/dashboard']);
      }
   }
  }
 }
// End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.SubsidiaryId = +params['id']; // (+) converts string 'id' to a number
            this.GetSubsidiarybyId();
            this.InvoicereceivemailId(); 
          }
          this.url1="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAyVBMVEX////7+/u2MS78/Pz+/v79/f34nyr6+vqzMS7znCq1LSr47++xEQq8SUezHxuwCwC0JSHSkI/kwMDiurnBXlz4mxjz5OTUmJf4nSSyGhW0KCX4mhKvHhr+9+20KSb3mAD4qUf+8ODt0dD4pDPs1NTcpqW5ODXCXFr816/9+vX5tWX7y5rGcG67Qj/frKvoxsXPgoHHamj95Mr5r1b6vnz8377958/80qX4pz/5rFC9R0X26OjLgX/MeHe+VFL56tf5uXD2voX4xo/Js7uSAAAec0lEQVR4nM1dC1viOhMOtBUEZEEsFhAQvIIXvK+7ruL6/3/U12SSNPemBfd8POc5y7rTZCaZybxzSUUBIp+gEsGXSiUkf4aVCvwgqqgkASXxodVIQkayZVoHm3lP1hwCIhttbatMRx5ra52a/dh/V3x2UJtFFzB/MQxTl2Az9GbaYwetu1KEttwOOqbOmcW+9w4VtdtVTdvB/KkLqah5bbd0yJSywXwVLWWDsqL5KHetgCF47HYRActMLdOWU+4SdgU72P99ijY6+ouz+c9skDBy2x4OzlAurcEG/b2Zyua/tMHofdCo1wfXNTftZjuo0X7LLJWaabf7vzvVer1e7dyceiKZzQQU5Cuz96kqFXQTt4MJEbBabbRuUVTKTSALrYNNXwE3VtHgblClAqYfqqmebmIjROmexeRgykG1/kdbELBe76RnqlvAUm5CZzNwP7mJmxBoI9TrTCQB69VG++wboZrE5ve7CRTdtRpUwM55h0k6uG4iqw16KI8vm9/vJkBDYeMG3eZhu0q3kmrqtnbQRvvdUC1AvcmECjhp99IfrYZDqquNzplZwM2hmkD7zVAtrNy1mOm195qYFtUuYE+xpt7XUCnlKcCm8uSWI3rUJ9JgARuDu5CNe9hu0FOHeH+gLRUu5R8VeUuz2SxovzGkAoKGMtpVfQK2WG0cndmm3sxNMNryAubrCQq7gwYImO5VX6RFTXL6kH8i3n/LUE2gRU4V3chNoLdMivadQks0lRpj5zyLqAq5CU9E+V1QDa2qE3ZmEg1VOVpVh9QYG4Nb+swWInqNdsPUltUG0eFRgyE0oqE6bfOgzTBO+70mC7jFxMM3uYnmxRHjfvAemGmj8JDYKYmoUk3dKlTLaL8Hqs2H9KysN45uHbTz6tAQUW3HTXBay9JsZIOHdAOrLIaw0qaayiOq92bu1GXYVJ4sBdWUiL52f0SZ5nGgAxQctjR73Z4NcgG3GtGnGlpn3vw2hxb7qzlBBQSY/zhz+7YCbHJamWnP81eiVZk+y2IHhshy0hvN+zaPqN5ZRLUFNwEkyLj35SP62v0gy1Q0LbTacIctbVW2mHjYavHl9Dzz4vl50cxWVg0eUbVvc5gu6s22CtXOBnrM4FV8od6f6Co+nUpBNQvtFt1E7XpQpQIO7pvISYu0iD49U6kxChHVNhDl9iL605sOFbDROkQFBGQR1YSfwZ3bvKmLsCkvTXmodpsiMBBweD5HkW3cILANx3Eqjqjua1tLPMjilrbB2nuLxkJEQ60cNZs1eTgBi6aaOpAiqq0gSvlvpW3w9HeHstYYHKLIRru63jv/fb2yH+BCRNVhZ/GGiFL6W+niy217QgUcDufW+mDzfjBpNBpDYZO1gJfHJNX60XUkT12KzYqBkcJQjWgoCNi+aFoFXE2G9CQZTlY2pkPQVMh8VE+3gih9lsapov29DhWwMega3A+lPRxUeVK/ignN8WC6EudDpvHtM34ylUeUG/bJBKg3nFABJ8NVlhNUaIUoiXi99kXfGtGLERWrUW2AKDcrvqDojobpKdMfTSttisokAdPl6PQYxtartjRHRyKqU8vU3mxu5CZSDaUJ31SjuvZZuj8Y2Bny0KraugvMAqbjEk2lpY7bDRGlZRl9bDCAohkREGuoTU9w3puhuev++4BtZWfv1Dp182AgRFThJukN+uMSNhhGfxiz1fbem5W21xhyNHcWQrUbuJ+kPi+yMd1tqTWqUmyGMtNFbJBpKDka/1hpSe2QIuoUp2AS6FiAEIvFkDrTaFXnEVXrrCybUOUuE9EjtN9hCd/JsGedhVa3iTSptlHL+8Pd+vBmbhZQiajS2L9Mw0JIPX4ZN9Fts+Ouvde30CJwJdS33XI0F2YGnEa8h/apDwc8oko1tWxUVyr72vxgCd/qgByJRrwU3mVI+qaf1SZSkrc93rnQPmha67QrIat1li2cL5uqgOqT9vN31eYJ307PRksCRgp22u+RWnzp8gN2ONm3TS1FVMRmiyf/yriJ7oCZUYdoqGkZoxSOMyyAvbu0g7BM9CRJSVrd0LK2UkR1c1rkqJCr3EVsUID/rbuaZZYUjmdgJ12GUNlBnFzAPo+RXLxZp54PeUTVZjWqQjUi6W8eyr2aZOXbWwttQDWUgJ3BXWTrsjjjeQFcIo4sUzcP+JJSnFqkRmQT0Krch0xDq1RDDbNE4VmLhUCTSc8c0ZPhTs87GYhTon++KyFUUyGiwjWqIjWi0Pxjq3Jj2E85GrzXFAF55qd5nYGdj76WVUPC+dakIK7KQJwpokeQ+adu9RZK1y42BQErZgFtxZf5OQticTHMJmC6MUzAVjcyCsjhV3ogtXj0hVNslqxa84Ln0tssovJsqTOdv9YgVoeKup4IxSSI5fOS6jiC5sCcp1k1D8VqyikOqp462RR3UBIwT7mbYklCW0ZGm1IxtWsfvCHk0dJcuePeh4E4fVcCnKXih9etp4oGph/b9n5+09FKEvosENhhRqqQFvZoD0jBXZuDODK2OWVBvAvw0H6vhZ4COvra5JUWShLnp8hGSw+9lJHJZC6RuGr0AcQpAoiz2JVgJoyJ/ODYeopKT2Ld4yWJGrLQCo7rCAoX/jdfunwFh0OaiTM4b6YiOKK6NQoolyb5J89NzLOSBA5aGdMKLWugyfS4SDslNTPSvUFAnDG9IdWomj4XdBQBzTZ41uYlieo8S+YqtF22gaRwYRHQHqWjNwbi6gTE2WgPf4g1KtWk9XPTIqC497hoxgw81dDATPv2wdsTju5VLOCZsTwkIA4PMxn0UGBhel7nERU78uw76NPXRhAmDWKzkoTK/X6noQZyJW6+zM873CH94d38soDpYt7LXX9OAaMcG0QQA0FJojoXYjyJNrrjrpKXN0s1OjK8x0GcaTFINZX1jafTBQ4BgxwbJPd4WDsvLkmYad/2jrT2BEO45JFMSEHcDx5V4ljJQrvCERXNLDPnbAuQXCoqRemp/66ZVbTHD/pJhzcZlmsNicRMnADitIhejKju5YhKvcdpV9EAs04FHFZXyHJJGWMuhgX2NCxQ6OYLTF1LVZ4dyhTEGdIboRBR3ZxaVZR/DCoaUrgIIXjTxhFGI1TA1ntNHa5Q1z2v2vYGWWfqmZk2HW6VRVQks+wpYBalY22pUqDbtXKEa6P2KL1kOyW/ocFAnJm2ecFqVA0eCtgE1GwwYuuYDjFsrKSjX6AVqvc41FU3eYNLygKI6zAQp9MKERXgVMNdavlvPIitCSUJjC9Ml5RDsXrfugtCdaVLCchoMwjIQJzh8GI4ld2jMh0VyGSDtKxLo/TQbAgpmOuwhDbW0EATcKObL+jtQkiFWOs+zQtWNSDeX9+HyGzp7awksY8sS1MjoS7YyofVVlBRGxRcSpYpnbR6WblbTTy0GZriEVVeX1uqobwkcdG3CTg/l6v3mjPapIOFDpcF3RmIMyTgedBNe/6VhdP2/o2XJOqtbmAWMKKhLnGVjX204Q5aUY8E4swN/ziiuuBuDScA1XFVjvYbvCQx6Fk4Ij2vzFWmGooM3raEiuqoJwNxdQBxloi+m9UoU++vYgz5b39a7ATrfJBF08/fiHWDsur9hh2E7j4ZyMTxdjILMBIiqh9nRgHp3r/xkkQV5+KR0YNGWU/P8Hxl2pWt3nypiXHL3DKcVKMiPf9mAYUbZXCPJ6/eleINk4BbuqTMuM+OdiinmiL6UI2o5L42Km5XK0kYdlDoVx4cGpne+s0XekUMOo0OsnK3ArbnPKKidX8+HJ2leZHdkniPFAG5DXaF2xFzZNrkbV5S5rRdXu7OQJwWLqURFetKYnEXGZfOsjpXO3QNO9jP7mJBn7PfyVjkFLUsxj4/SqptAHGGrFrlMOvVIakGUUARGfTVZWRD9Krck4AebMsGPW6+qCDOpM4RmreHVJ1JZwQZTo1D2teBsjRsllDwJJCMKeTbitigoUYkXskkmThzPEi6/uRuejzLPLsl0cnqyIqA/SxdSG8LGvIGxSP6fBvkw4mVkz9aOoh9ob6MlHlYyuHQcEtCO2R6DfU2k2sHt3NJWaXlIA7fiesb2VTwCOEUbh3ByvBbEuosoeB2z/tGkq1BNTttSMupVQbiTLRiRNXA1dR51VCSUKFa/zcH+Ud/mCfZyE2UbackkWsG4rSIHmgP+X4cHaB3voO4W4XNIiv3LX9BQGPYs630plDN015rd8ItsLnCA1+MFQNnwz6q/aZuYthE5mWsvPN04dGe1ZN8l5vQD6TeEfdZAOIMWZheh2IXbIinNH4c/kGMe2kHT/EJRu30j9VWvueSsvFQZvf8WZrTkKToU7/WwTLhvC+sSIuBbUnAW37hatLo8TXYKKu2+V3qbnYDabLK2sVZorC2B7vc2CMeP0TvNB8x0VMWzWvejIzThZvArxJQzV4AFUDcUVehDdAdzaMdgUdJ/7uBrO7kI1I4gutokC7s1kIb099vg+rb0QQQVycvhRHDJUUp8ac/ZB0OSNrBsx+sYomVIfDOdRZROwNU82jlqoQMxNUBxHEzqYTUCOtsc8mnR0P7VvZ+igA6Y1h/xJvWtLFZVm0LL7IlWJMegXesYlKJajeQgWh8kMdhjIqiuUTtSLoQYHrrkKyazEgpqFYmA2dp5RIjWpaJwyTvUG6ptt9gOPbkb2gum+zV6I9pOpbY4FwPq/+9mzCUu8M/LDVfJyAOk9zSzGJrnw8HD7wN4fztvBMBIQUJAg7eHGr3T6CaRCIgStTk76ACEFdBp1TAdpcPx57sUSiXooAK7W2hWt5qRhvt4BagmimiJ0dFK2OTgLjKOaRXhwcRZ5NvOWuHGfTpxSr2ZKupnaIbFUC3+CLbZitjE3fVn10z1/6WDceeDKIPCEyqNwftqiBgKqFpcPjyz6CaJaJvCQJiG6Otqi2p65M/2QT56w3eJ0gdZ1OZ5d9E9B4CphLSBiMG4kBAYoTy21vgyf2BuCL1zscNnErNnJX+V1BNT1lgCTH8zJL6JBN/gPQdhCG6R8KWD67RHlmaVtMyy3YF1FXU+CJbiTaVkABsdrEBchfVpjgceZLv5wFvDyQpjj0S+LaappX+jteOGWlNboJ9AW+RShiR7kJaYZtLwyFxV6Jmg9ZcoDNmjwTHrab7kPG3wS1ANZGHIOAShlmHKK41yGxKs6x+gOkBzttr0LN0S9HENqCauBiIS4g/tWvcadQ5UDVeWRr8dlFWeOIS6k0I/7WboLTg8amEpLmnca4F/eqT98OjD4piuYQ8di5jg9txE+aWOvD4ICG0i7fmGpvqk81JN2CMcC2VSbZ9ipayQUJLPD5oKdDWehmtXCPNngyb2SxEQubx/4OsmkOdgZb5Q9Ni2ASU9GSvkXn8f1B8KWaDVEJ6ltqnds4ievz/H6gm0PKz1JH8k59UOMo8/rcVX8rbIBI9vsP8jT9mswgef0uHDMqjLeRSAskfWqd2YCt+lv4/QTWxD1WW0AKiHJaeefwtRfQoj7aIDWJayePbvJn1rA51j1/KBr/zV9OIHt86tUtPJH/4fwPVBFrB4zvM3zGL6A//C6img22FNvP4jhqRmSOYhfhDKmGRIHajj4+bYFNzj5+7gxZL3yOFNSJhERtEp71yn1MYF1nG1TWjSXozsT/UdpCzKcmtMp15/ELFF9T90cafo6N2O+eL9IMf3SI2iPODzY/zdmeSSug2f7shcI9f7He+oC67qZHl+aQvdcOX9H+dbjEBMW3t9PBicIPUHZQsye6MuLcICxZfup0yAmIJC9hgthh99W3F6m8ls+5K5vELuolup4yARELkGtcydagKKLPpULtsD3MFlI/zbqeMgFhCKqALquWiRJVN+9IEisf3x6Jd6C8adnw/Q0lChw0ybdJfg2rHIw4BZY9foPjSJS8sGb4f+n7eSamLSujCuLP1w3P6eXhZj+XFsKNEJ9Oyx/eHal2yJ23WzJv/WZFGNJDQcndp8XC1PInjEfnE6Zf4+OlyXcuxQWR7ews1BMHjF4FqTMJ9S5MV0uxqn7SeEQl1AaMwWF/9mo7iZHcHPrvkS5LEo+TzcozciNLMNB1c9PgFAl7qD1MJfXHrPmng7XRNAoazr+NUOibXjvwlGcXLy0XoPgvtiJd7/GIRPZXwSHuDl/Xo3z9SPT6nfVjGWDyLgGQv492vcSEBs8Ibjw8LRvTg8amEHhF9KiE9S1U38fA6SsxyZV/SP+Pp08yKKO27Inh8fwHJLODx2/sWWg2dYDsECWUVfXkcCWIQw4PPFFslFx2TxPHXODKzaRewpuS8/ZNO4PHb+2ZaPXakEg6ZxwfaxdMoyQRMRtOTz6vLh/UYf9bPP78e42mqv7uMJN69NLNpFbASKR7fP6IHj48l9Iz+ZQmB9jnlmXGfxDtPz+TQZMc12a/Zz8ckzrR4tByb2FSYlkJlyeMXiOjB4+Oz1DOiJxIyj09oo6dpQgVM4pO/L5ap0eLyMY6ZUSbxMzdGm4DySosevwgg5N7CN6u2Tzw+vKmE8DD7FVP9S0bHP8dONmd/45ht9vQrUGnNT1IPKnh8Hxvkl5RBwsG+noq25G9Ij0TnPmK0LzvMwEYnl+wZK5to/HfKdDVehgqtk+nM4xfKVmd7mEfLhsMef/IRMNrnKRUwia+QvSErawoOx0viVbDjeB2rtKYqJH2Se/yCWTXZ43uEQKnHbwybjKPLKfUBo+VMtytLVu35JKbGmIoo0brqUqrH9y2ASh7fI7ONPT60MWHayxEImEwvi1hHuo0U47yOI5HW6CbgSdXjexdfRI/vkyROtZTcKwAVZQKerJ14RJs6vJpS33K8EGm1vc9guuLx/Ysvgsf3Kr6g/dYF4+iFqmj8uChcFnlOwBiTY4nWsTSSxy9QfMk8vmfxZf8He0PmLIFDZrQ00eZF9GtyBqf45tMuoBQqix6/SAG0O6Qe37f40usyR/+LCvjpFNBap51Rzzj6yZPEzqUx9bV52JUQAeerKCFZsTchPIGjj907aI/o0ZoC8tELCxnJk7YCqKuvzbErmT/0sEEpmniewiHzaBTQdFSo44YvMaDU10VGYl8aR1+bq1Cj+EP/AuhiJ4FT1HjI6FMHi5eZNi51NvETpzXU6Jly2/va3AVQyR86br6o3D9BNDH1dBPB4ng6etJohVHI1KEdQOt9bZ41etEfFqgPvkC8OzI6ep3NVMAE4x72L5z2GLDNL7oYhkOGcWTta8srgBJ/SCUsUKN/JAFvsnTaoCDgIzG5eBnJtOlpA4fNJUSTjvPX1teW2yfTJTcWiYQ+ArKcDGxhMva0wV/0TCEHr1THuBoREV/FCNHsQc19bfk1+szjF6nnv4KOXnkKeByz/A0WUaZ9JcnH0aUgoHlXpL62AjdfuMcv0ifzQIBzcuKIJkw7CIq6kI+KB+J10rG4gJajX/D4RW6+ZB6/QJ9MuCTWM3r2CWSYDfIs1FJZjGNi0tNnirutNXpTX5tHn0zm8fNVlG/lLIawoGYXsGbeQQjtZVqqEI/M49t2Rahy+6topHl8jx0Mwi84GC+jIjaYvJ6w0H4p0kbBL6IR8QwHfvaqht7X5tknI3t8HwErxLft7JxoSSeTm/jFBRzPaDSRihgKvy+MIJv0hz+Rawf1vjbflmbJ4/sIWENrwlHypArochMJXo8Z09V4mRlQhMZAQgCuA1+qVW7fawWix/e4+YLHvSJJz1jNi+pRnaCisOHr3YTa4pPI5ifZ23gmeHwD02qV2wnVgBEynODxPdwEGfcXlM8UAY1QLVNRQhuuWWnqRKQF/JC5RPOuKFVuS0Svc5R5fC8bTMddkNwFKKkTbI9/KQJGiyUcNrs4sM8WY7yzK6i97egv29fGPb7hQNJtMCIrTgoPz8bhrDZIhltCUn83ScbiPoSPCcm7hU6mpSq3P/wSYny/HUSpGRIPrSVzVQFVFRUE3JlJbEbEssmQjl0RqtxF2imtVW57n8wS1+gxynJF9JKbQFRFmYAnsoAVrBb4hH1wCShWuf3cBCGp2arcjlauE2I0n55Qje9gqOygeFSMp+SAvXTBr8xbFGxpVj0+ctDCFwA0V4ZkgqcNygISNmMSWl25dkXra/OwQaGvjXp8uagJA9On2ZcAQGkashazwUeLDQKbBH2neuHT14ZyBTT1tXVu3/p5H/Jmh0oAiGb0oCYTLFANGW1QPSo+iW0/brmvDWahfW2dVqs1GLTgY/zy4x4Jp8Jo7djBXBXVjoq/BAm8Ktsjq53s8T1VFLEqt9h2aOlM7HRhalyN2dkdje0CHmsCPuYIGIK7OHHuiqnKbYVqwizdoZ+A1c4hjAv1JpDQC6pFodVNMDapQ9x1CWjpa1N30NbX5tFbiiXE4z4DpBmLO6hn1YRDZuFwE4xNQULr0V+sry17jVG34ycg6fNCREICk8fmpHoJG8RsQriy62Raq3J72CAm6bYnE/xb1BuTCXyZmL80jugb1B7iXUBYxja5om6CsvlFHOKJ62Q09bWpAhozcGcXB36fC9ojBOWU6dp0SQ7NRgXdBMvuJ1Asdahdkb42DbcW+ITBOqZ5NlMyAQ5aO1SzIcol8fhLx28lK9LXVvr2GTA9plkVlkyQkn+fSQGoJkx9QmoET86XzKl9bZTprVxSlmkhlfilCohJwlfQNqqimQ3a3ARD1dNdlotCVrVT+tqctBsJCGl4UhjVcmMz0icTQ3Cca4OZgBQJPitMy6ok5LyL2KC9+OI+FXZiaQ2o2l1CaT55caqo5s2iZ3Z6mQWEWTJ/6OcmirgUeTFAjOnMcHB8QgN7MnoJPd0EGTd8gohsgYy7kvW1VW19baXfZWGkXY+o0WgCLk5Y6n70gnKhmjD1K8nTPIZOpoUq9yYq6nEg1UgckBqidvSDOUG68DEfqvFxSci5iw8vhyr59LUVyd9YFyMd/xNEHMs2mP7Tz5gLuJPkuQlh3J8E0YweMo4MK61WuQvYVaEdxCSkzkCyKkDLI4RlwgXc8bVB/OWRtB5hJ+pY6eJ9beUExMONyZJTfyGq3UgTMMdNwNTrEaH9ROxj7pPx7WvzKr64dhABxoI6gyTgy1QRMHZEE8K4X6TlhHpDIyNF+to8iy9OAam/iP8qdvUzzgRMkniaPLmhGh13Ae20yYIJaFE76e0tZdxEgQuSC1ojG8uBDK3YYOni18/LmXk4DVFCDj3+QrbfSlamr628DZIvrAj8FIpqtwDUHU9PPi/X7D2z+RhjAThoOkMb9LUVeu1YnoriGcdgcdOZSPsySpLRaPlzvUD6L+2yJx6+CA5KIycytQN+OfraHMtYzE1kJE9wnC5F2q/pr6uH0Htq+mUGQG+6JpfQHX0yBfraNrNB2OQxnA7k/GO060WYN5y+trRxJfkMpb42w97797WVdvT0C5B8xdAzJLR9BVaNtyf/aJfCTryGaoQmYIG+tnIRvZVkzFoOHC+ezq8RASLFjofXRSQBJaY9+9o228FsbSO6+KMr63rl22C4eAUd3WEKLi+N/KRfX9uGbkK0DlqSnz6baX0O8OATtjCDMxIjRfratgHV1KkBnZKA3qmi9vx0+JcaIWtRqNgEJH+43te2SURvSt0DyfMUUhZp+JCzGOapwy8QMKGN7EBiZzrra9tuRO84GQHZ7CTxuoCb4H3Q4RdcDNpNRNxgP389+tq24yayqYNgGVMeX/IWQz9kAqqi1JAdAlKOMn/IHCJnhK0B81d6w79OW7HSikyHr/TuEomGvW4/sAkWn0zAnyKJw66ohAPt7S1FmC4mID5tXmm3Iblo4G/+aPZKtz/+kmhdT4I/rA9+/IvPHeMhFZG6/uM1X6Zc60gDzMQoIDItIxtir2Go+ZV6uY6ThL6+v8d+Jc74mOVmEvD9HjY4W7KM1dQsoKuv7d8IWK122G+Kj6CoTdIQr89iqc0G1RZf/A0Lsg0i5e0taqi81/h3AtbrjUafM/05YpfVp8cPTA9tbC6u+ItdkuRZppXf3qLt/V7jHwpYrU7O3/jUP/kbMXZGx+QdNNas2lfCr+PHr1L8zCTJ62tzyiV88SDJoR3eNNkvaEdrdjLiV2LsfD6PeaTAJY1C/N6IUcwzVaOnhUkSR6B1M2AvxDO9Ik/5F/1LcdpBnf5et9SbLp6mCXtzScr87uPVA9lKLun6+ek1Ft79Ee8wsC3vtquNBP1XH0Ay618jIVOaxKNpfPz59yr9fD0tT6YjeDUPf3vGX5Y6VHRxk3rDlqCaHbdeHo/kpH6Cs4rpJxHe6wIH0uc6tAxnnWXbxRf/KD1bjGhxeTK1vSIqEzCeLtehtYHSxvS3R/T2HZRpnx/j2CVgMkq+Zii0Tm0T8JvCpULvWma06YEZjxLTVibJ6OTzeeGcOm+W74zofWnTH8wun16nxP7osZOQg+fxC85XF5s5TPuoaJRHu5mAnGT8cHn1+fh6gsuCx8unn888meqc+n++Nsgd59CCVQAAAABJRU5ErkJggg==";
          this.assignMode(params['action']);
          this.GetParentCompany();
          this.GetCurrencyList();
          this.GetFiscalCalenderList();
          var addedAddress = new SubsidiaryAddress();
         // addedAddress.isdisablecountry=true;
          this.subsidiary.subsidiaryAddresses.push(addedAddress);
          this.subsidiary.subsidiaryAddresses[0].isdisablecountry=true;
          this.subsidiary.subsidiaryAddresses[0].active=true;
          this.changeswitch();
          
          setTimeout(() => {
           // console.log("Delayed for 1 second.");
            this.countries=this.addressComponent.countries;
          }, 2000)
         
        } 
        // else {
        //   console.log('cannot get params');
        // }
      },
      // (error) => {
      //   console.log('add');
      // }
    );
    this.totalSubsidiaryAddresses = this.subsidiary.subsidiaryAddresses.length;

  }

  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        this.isLogoShow=true;
        var addedAddress = new SubsidiaryAddress();
        //this.subsidiary.subsidiaryAddresses.push(addedAddress);
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.isLogoShow=false;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.isLogoShow=false;
        break;

      default:
        break;
    }
  }

   //--Show Hide Upload Logo
  showHideLogo()
  {
    if(this.editMode)
    this.isLogoShow=true;
  }


  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  GetSubsidiarybyId() {
    this.httpService
      .GetById('/setup-ws/subsidiary/get?id=' + this.SubsidiaryId, this.SubsidiaryId,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { 
        
        this.subsidiary = res;
       
        if(!this.subsidiary.subsidiaryGeneralInfo && this.editMode)
        {
          this.subsidiary.subsidiaryGeneralInfo=[];
       
        }
     
        this.subsidiary.activeDate = this.subsidiary.activeDate ? new Date(this.subsidiary.activeDate) : this.subsidiary.activeDate;
        this.subsidiary.inactiveDate = this.subsidiary.inactiveDate ? new Date(this.subsidiary.inactiveDate) : this.subsidiary.inactiveDate;

        if(this.subsidiary.invoiceMail)
        {
          this.isAvailableReceiveMail=true
        }
        for(let i=0;i<this.subsidiary.subsidiaryAddresses.length;i++)
        {
          this.subsidiary.subsidiaryAddresses[i].isdisablecountry=true;
        }
        this.url=this.subsidiary.logoMetadata+","+this.subsidiary.logo;
        if(this.url=="null,null")
        {
          if(this.editMode)
          {
          this.isLogoShow=true;
          }
          else{
          this.subsidiary.logoMetadata="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKYAAAAlCAIAAABHzgVWAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAR8SURBVHhe7Zu9auswFMdz72uYQOnsBwiBLHkAb4GSpXOXbN46ZvOWpXOXUsiWB8gSKHkAz6UQ8h5XtqUj2dbHObLS9mL9ljrEH5L+58tH6Z/T6TSJjIm//G9kNETJR0eUfHREyUdHlHx0RMlHR5R8dETJR4ezFXPdPz3sSv4hK075jB/3gDOtZ1Wci0V+4McS52UG4G79G7QGP0k37y+rhH9w0LrSfaF6On0e7WEKLE/VL2Ab4zCcXn75UsZyyIszP/SCzW3B0A/3kFffPe2v/HMAWoOflLst8ubX/VaVoPy68CMD14+jPP1wwq8R046h0ZtR7h6qLxf9Jb9ePvmRD9TAPkB0Nj2YG7NgFl4Uiqz5op7oMLuyUB4/MJqf37QaGGkpztboFWNZtfkL4++th7Iih9zoBprLAGOkQUuepmlzgJtQFzZBPr16mL2INcvZKMUsLZP0I91smlujND+fmpFmmw2fsx2heJplzfnupyihXL8efEUU5YOB9/LlI1+AcvdG9UIZKLPCkhVn+bv/M+zMF1xz542v+1eu+GJe/3UhYkK6XK+XKM3PhdCbJVxHlVAp7ziFCCGwT1eP4IW00AuBMischU0in+EVTMzMuOauVAsuu1njajARE9LlPEnmCM3BptzLcRNIuXy2FpGOJIhYFOY37hmCNMi8iwYGbx27dNk5zrNUxZnJujUH+0cbVWBo5VuyeobIi61+aYqrmrvqZCIYF4Q0/oiMpd0L5EMMGUSuBvYRoaFJrkZebLqFN4r0btocOJjeNYs2+bwEdXM5dpPmShpH+h8oDheA5voMQl6N8FAlZ16YQ2GNiu7wbnw/JVp1aDeXEURvruQ0rjURpRzRaO6/GsGgS65kRUJ0J5BM7/lReGxFHDmNw+t4JyhYHmJzct6n0mAslkW3pov1HddHco/o/mswF3HkNG5S3G5YPoTNcF6Ss0kRozuF26Y7QxFHT+NmxVXNO6sDEUyTtJLVS918AUSTwoyp+2Z9kfeUXHEXV3S/WTXmibamJqdxq+KK5sa3g59bDW/J0dHdZthaRIWDzqlENPUVOY3Lt2u+G9QFdo46mktbCF6bYvGXHB3diW4OL663q2m7uVY8kqC4GKSbjuawGoHyPJ0hkreiu9nRnd0JFaUbiU2qHrRyrUzj6OYIKJ4VPHtqgP2CluZKjBm4E+3LMMnZBEQ77pBvj/VBH6U74ar1vqsbKW31uIUdH7SNScVtl5hMHZ79Q6IPlFy12rLk2a2H2qd9MM9S3WB9vnE3UurBR02wMcgDjksUU28FcVaay23i2/04wMRgyVWrNdOeZb9VULch5I5i2N1CLdJUa/BpHPKA+xKT5mzNYJu4Xg9N70T9QUlYAkiuOLGNWS5fNHtdI5hdlRy/aUcREjoDn8bh5QxjJGbNKyfo/BaojfyxmCXkmbpvFcYOXAjJ6/HD6C0dFN5skKcq8K7Cd24gS80JpSLtFdKieYX1ly+iz9IPecNa0vGfjUdHGC+P/EdEyUdHlHx0RMlHR5R8ZEwm/wAtHTGcfoNZrwAAAABJRU5ErkJggg==";
          this.url="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKYAAAAlCAIAAABHzgVWAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAR8SURBVHhe7Zu9auswFMdz72uYQOnsBwiBLHkAb4GSpXOXbN46ZvOWpXOXUsiWB8gSKHkAz6UQ8h5XtqUj2dbHObLS9mL9ljrEH5L+58tH6Z/T6TSJjIm//G9kNETJR0eUfHREyUdHlHx0RMlHR5R8dETJR4ezFXPdPz3sSv4hK075jB/3gDOtZ1Wci0V+4McS52UG4G79G7QGP0k37y+rhH9w0LrSfaF6On0e7WEKLE/VL2Ab4zCcXn75UsZyyIszP/SCzW3B0A/3kFffPe2v/HMAWoOflLst8ubX/VaVoPy68CMD14+jPP1wwq8R046h0ZtR7h6qLxf9Jb9ePvmRD9TAPkB0Nj2YG7NgFl4Uiqz5op7oMLuyUB4/MJqf37QaGGkpztboFWNZtfkL4++th7Iih9zoBprLAGOkQUuepmlzgJtQFzZBPr16mL2INcvZKMUsLZP0I91smlujND+fmpFmmw2fsx2heJplzfnupyihXL8efEUU5YOB9/LlI1+AcvdG9UIZKLPCkhVn+bv/M+zMF1xz542v+1eu+GJe/3UhYkK6XK+XKM3PhdCbJVxHlVAp7ziFCCGwT1eP4IW00AuBMischU0in+EVTMzMuOauVAsuu1njajARE9LlPEnmCM3BptzLcRNIuXy2FpGOJIhYFOY37hmCNMi8iwYGbx27dNk5zrNUxZnJujUH+0cbVWBo5VuyeobIi61+aYqrmrvqZCIYF4Q0/oiMpd0L5EMMGUSuBvYRoaFJrkZebLqFN4r0btocOJjeNYs2+bwEdXM5dpPmShpH+h8oDheA5voMQl6N8FAlZ16YQ2GNiu7wbnw/JVp1aDeXEURvruQ0rjURpRzRaO6/GsGgS65kRUJ0J5BM7/lReGxFHDmNw+t4JyhYHmJzct6n0mAslkW3pov1HddHco/o/mswF3HkNG5S3G5YPoTNcF6Ss0kRozuF26Y7QxFHT+NmxVXNO6sDEUyTtJLVS918AUSTwoyp+2Z9kfeUXHEXV3S/WTXmibamJqdxq+KK5sa3g59bDW/J0dHdZthaRIWDzqlENPUVOY3Lt2u+G9QFdo46mktbCF6bYvGXHB3diW4OL663q2m7uVY8kqC4GKSbjuawGoHyPJ0hkreiu9nRnd0JFaUbiU2qHrRyrUzj6OYIKJ4VPHtqgP2CluZKjBm4E+3LMMnZBEQ77pBvj/VBH6U74ar1vqsbKW31uIUdH7SNScVtl5hMHZ79Q6IPlFy12rLk2a2H2qd9MM9S3WB9vnE3UurBR02wMcgDjksUU28FcVaay23i2/04wMRgyVWrNdOeZb9VULch5I5i2N1CLdJUa/BpHPKA+xKT5mzNYJu4Xg9N70T9QUlYAkiuOLGNWS5fNHtdI5hdlRy/aUcREjoDn8bh5QxjJGbNKyfo/BaojfyxmCXkmbpvFcYOXAjJ6/HD6C0dFN5skKcq8K7Cd24gS80JpSLtFdKieYX1ly+iz9IPecNa0vGfjUdHGC+P/EdEyUdHlHx0RMlHR5R8ZEwm/wAtHTGcfoNZrwAAAABJRU5ErkJggg==";
        }
      }

        for(let i=0;i<this.subsidiary.subsidiaryAddresses.length;i++)
        {
            this.subsidiary.subsidiaryAddresses[i].pin=res.subsidiaryAddresses[i].zipcode;
        
        }
       }
      });

 

      this.changeswitch();
  }

  GetParentCompany(){
    this.httpService.GetAll("/setup-ws/subsidiary/get/parent/lov?accountId="+this.RetRoleDetails[0].accountId,this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else if(res){
          this.ParentCompanyList=res;
      }
      this.isReloadCompany=false;
      });
   }

  /* End Fetch Subsidery list from api */

  /* Start fetching History details */
  LoadHistory() {
    if (this.SubsidiaryHistoryList.length == 0)
      this.httpService
        .GetById(
          `/setup-ws/subsidiary/get/history?subsidiaryId=${this.SubsidiaryId}&pageSize=100`,
          this.SubsidiaryId,this.RetloginDetails.token
        )
        .subscribe((res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
          {this.SubsidiaryHistoryList = res;}
        });
  }
  /* End fetching History details */

  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 2) {
      this.LoadHistory();
      this.displayAddressDialog = false;
    }
  }


  handleToggleEvent(event: any) {
    event.originalEvent.cancelBubble = true;
  }

  openSubsidiaryAddressDialog() {
    this.selectedIndex=-1;
    this.selectedSubsidiaryAddress = new SubsidiaryAddress();
    this.selectedSubsidiaryAddress.country=this.subsidiary.country;
    this.selectedSubsidiaryAddress.isdisablecountry=true;
    this.addressComponent.GetStateListByString(this.selectedSubsidiaryAddress.country);
    this.displayAddressDialog = true;
  }

  editSubsidiaryAddressDialog(addressToEdit: SubsidiaryAddress) {
    if (addressToEdit.country && addressToEdit.state) {
      this.selectedSubsidiaryAddress = addressToEdit;
      this.addressComponent.GetStateListByString(addressToEdit.country);
      this.addressComponent.GetCityListByString(addressToEdit.state);
      this.displayAddressDialog = true;
    }
  }

  deleteSubsidiaryAddress(addressToDelete: SubsidiaryAddress) {
    let addressIndexToDelete = this.subsidiary.subsidiaryAddresses.findIndex(
      (o) =>
        o.address1 == addressToDelete.address1 &&
        o.address2 == addressToDelete.address2 &&
        o.city == addressToDelete.city &&
        o.state == addressToDelete.state &&
        o.country == addressToDelete.country &&
        o.zipcode == addressToDelete.zipcode
    );
    if (addressIndexToDelete >= 0) {
      this.subsidiary.subsidiaryAddresses.splice(addressIndexToDelete, 1);
    }
  }

  onAddressSave(addedAddress: SubsidiaryAddress) {
    addedAddress.zipcode = addedAddress.pin;
    if (addedAddress.country && addedAddress.state  && addedAddress.city && addedAddress.address1) {
    if(this.selectedIndex !=-1){

    }else{
      this.subsidiary.subsidiaryAddresses.push(addedAddress);
    }
    this.displayAddressDialog = false;
   }
  }

  onAddressCancel(event: any) {
    // if(this.selectedIndex !=-1){
    //   if (this.subsidiary.subsidiaryAddresses[this.selectedIndex].country &&this.subsidiary.subsidiaryAddresses[this.selectedIndex].state && this.subsidiary.subsidiaryAddresses[this.selectedIndex].city ) {
    //     this.displayAddressDialog = false;
    //   }
    // }else{
      this.displayAddressDialog = false;
   // }
  }

  saveSubsidiary() {
    debugger
    let  registrationnumber=true;
    
    if(!this.subsidiary.name){
      this.toastService.addSingle(
        'error',
        'Error',
        'Please enter Name'
      );
      return;
    }
   else  if(!this.subsidiary.country){
      this.toastService.addSingle(
        'error',
        'Error',
        'Please select Country'
      );
      return;
    }
   else  if(!this.subsidiary.currency){
      this.toastService.addSingle(
        'error',
        'Error',
        'Please select Currency'
      );
      return;
    }
  else if(!this.subsidiary.fiscalCalender){
      this.toastService.addSingle(
        'error',
        'Error',
        'Please select Fiscal Calendar'
      );
      return;
    }

    if(this.subsidiary.active)
    {
      if (this.subsidiary.activeDate == undefined || this.subsidiary.activeDate == "" || JSON.stringify(this.subsidiary.activeDate) === '{}') {
        this.showAlert('Please input Active Date !');
        this.subsidiary.activeDate={};
        this.showloader = false;
        return false;
      }
    }
    else
    {
      if (this.subsidiary.inactiveDate == undefined || this.subsidiary.inactiveDate == "" || JSON.stringify(this.subsidiary.inactiveDate) === '{}') {
        this.showAlert('Please input Inactive Date !');
        this.subsidiary.inactiveDate={};
        this.showloader = false;
        return false;
      }
    }

    let active = this.subsidiary.subsidiaryAddresses.find((x) => x.active);
    if (typeof active ==='undefined') {
      registrationnumber=false;
      this.toastService.addSingle(
        'error',
        'Error',
        'Atleast one active Address'
      );
      return true;
    }
    this.subsidiary.subsidiaryAddresses.map((address:SubsidiaryAddress,index:any)=>{
      if(!address.registrationType){
        registrationnumber=false;
        this.toastService.addSingle(
          'error',
          'Error',
          'Please select Registration Type'
        );
        return true;
      }
      if(this.subsidiary.subsidiaryAddresses.length ==1 && !address.country && !address.state && !address.city && !address.address1 ){
        registrationnumber=false;
        return true;
      }
      if(address.registrationType==='Registered' && (address.registrationCode===null || address.registrationCode==="" || typeof address.registrationCode ==='undefined')  ){
        registrationnumber=false;
        this.toastService.addSingle(
          'error',
          'Error',
          'Please enter Registration Number'
        );
       //alert('Please enter Registration Number')
        return true;
      }
    });

   
    if(registrationnumber){
      if(this.addMode){
        this.subsidiary.createdBy=this.RetloginDetails.username;this.subsidiary.lastModifiedBy=this.RetloginDetails.username
        }
       else if(!this.addMode){
        this.subsidiary.lastModifiedBy=this.RetloginDetails.username
        }

      this.showloader=true;
    this.httpService.Insert('/setup-ws/subsidiary/save', this.subsidiary,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
        else if (res && res.id > 0) {
          //this.saveAddress();
          this.showloader=false;
          this.showSuccess();
          // alert('Data saved successfully');

          if(this.addMode){
            this.router.navigate(['/main/subsidiary/action', 'view',res.id]);
          } else {
            this.router.navigate(['/main/subsidiary/list']);
          }


          
        } else {
          this.showloader=false;
          this.showError();
          // alert('!! Something went wrong');
        }
      },
      (error) => {
        this.showloader=false;
        //console.log('error-' + error);
        this.showAlert(error);
      },
      () => {}
    );
    }
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Subsidiary Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Subsidiary!'
    );
  }
  clearsubsidiaryData() {

    this.router.navigate(['/main/subsidiary/list']);
   /* if(this.editMode){
     
    }
    else{
    this.subsidiary = new Subsidiary();
    }*/
  }
  checked2: boolean = true;
  // inactive:boolean = true;
    /* Start Reload Currency */
    reloadCurrency(){
      //$('.refsubsidery').addClass('fa-spin');
      this.isReloadCurrency=true;
      this.subsidiary.currency='';
      this.GetCurrencyList();
    }
    /* End Reload Currency */

 /* Start Fetch Currency list from api */
 GetCurrencyList(): any {
  this.httpService.GetAll("/setup-ws/currency/get/all",this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
     { this.currency = res;}
    },
      // error => {
      //   console.log(error);
      // },
      () => {
        this.isReloadCurrency=false;
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
}
/* End Fetch Currency list from api */

  /* Start Reload fiscal */
  reloadFiscalCalender(){
    //$('.refsubsidery').addClass('fa-spin');
    this.isReloadSub=true;
    this.subsidiary.fiscalCalender='';
    this.GetFiscalCalenderList();
  }
  /* End Reload fiscal */

 /* Start Fetch fiscal list from api */
 GetFiscalCalenderList(): any {

  this.httpService.GetAll("/setup-ws/fiscal-calender/get-by-account-id?accountId="+this.RetRoleDetails[0].accountId,this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
    {  //res.list = [...new Map(res.list.map((m:any) => [m.name, m])).values()];
      this.fiscalCal = res;}
    },
      // error => {
      //   console.log(error);
      // },
      () => {
        this.isReloadSub=false;

        // 'onCompleted' callback.
        // No errors, route to new page here
      });
}
/* End Fetch fiscal list from api */

deleteSubsidiaryAddressrowlevel(index: number) {
  if(this.editMode){
    this.subsidiary.subsidiaryAddresses[index].deleted=true;
    }else{
      if (index >= 0) {
        this.subsidiary.subsidiaryAddresses.splice(index, 1);
      }
    }
  // if (index >= 0) {
  //   this.subsidiary.subsidiaryAddresses.splice(index, 1);
  // }
}
editSubsidiaryAddressDialogrowlevel(index:any) {
  this.selectedIndex=index;
  this.selectedSubsidiaryAddress=this.subsidiary.subsidiaryAddresses[index];
  if (this.subsidiary.subsidiaryAddresses[index].country ) {
    this.addressComponent.GetStateListByString(this.selectedSubsidiaryAddress.country as string);
  }
  if (this.subsidiary.subsidiaryAddresses[index].state) {
    this.addressComponent.GetCityListByString(this.selectedSubsidiaryAddress.state as string);
  }
  this.displayAddressDialog = true;
}

handleToggleRegtype(event: any,index:any) {
  if(event.target.value=="Unregistered"){
    this.subsidiary.subsidiaryAddresses[index].registrationCode="";
  }
}
    //input type image show
    url: any;
    msg = "";
    selectFile(event: any) {
      if(!event.target.files[0] || event.target.files[0].length == 0) {
        this.msg = 'You must select an image';
        this.toastService.addSingle(
          'error',
          'Error',
          'You must select an image'
        );
        return;
      }
      
      var mimeType = event.target.files[0].type;
      
      if (mimeType.match(/image\/*/) == null) {
        this.msg = "Only images are supported";
        this.toastService.addSingle(
          'error',
          'Error',
          'Only images are supported'
        );
        return;
      }
      
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      
      reader.onload = (_event) => {
        this.msg = "";
        this.url = reader.result; 
        if(reader.result !=null){
          var splitres=reader.result.toString()?.split(",")
          this.subsidiary.logo=splitres[1];
          this.subsidiary.logoMetadata=splitres[0];
    
          }
      }
      
    }
validatePan(event: any){
  var regex = /[A-Z]{5}[0-9]{4}[A-Z]{1}$/;    
  if(!regex.test(event.target.value)){      
    this.subsidiary.pan=""   ;
    this.toastService.addSingle(
      'error',
      'Error',
      'Invalid Registration Number'
    );
    return regex.test(event.target.value); 
}
}
validateWeb(event: any){
  var url_validate = /((ftp|http|https):\/\/)?(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
  if(!url_validate.test(event.target.value)){
  this.toastService.addSingle(
    'error',
    'Error',
    'Please enter valid website'
  );
  this.subsidiary.website=""

  }
}
validateEmail(event: any){
  var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
  if (testEmail.test(event.target.value)){
      // Do whatever if it passes.
     // alert('success')
  }
  else{
    this.subsidiary.email="";
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter valid Email'
    );
   //this.subsidiary.email.focus()
  // $("#txtEmail").foucs();
  }
}
validateBidEmail(event: any){
  var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
  if (testEmail.test(event.target.value)){
      // Do whatever if it passes.
     // alert('success')
  }
  else{
    this.subsidiary.bidMail="";
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter valid Email'
    );
   //this.subsidiary.email.focus()
  // $("#txtEmail").foucs();
  }
}
validateAdminEmail(event: any){
  var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
  if (testEmail.test(event.target.value)){
      // Do whatever if it passes.
     // alert('success')
  }
  else{
    this.subsidiary.adminMail="";
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter valid Email'
    );
   //this.subsidiary.email.focus()
  // $("#txtEmail").foucs();
  }
}
handleToggleAdressActive(event: any,index:any) {
  event.originalEvent.cancelBubble = true;
  this.subsidiary.subsidiaryAddresses.map(function (val:any,i:any){
    if(event.checked && index!=i){
      val.active=false;
    }
  })
}
reloadParentCompany(){
  this.isReloadCompany=true;
  this.subsidiary.parentCompany='';
  this.GetParentCompany();
}

showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}
/* Create Email */
CreateEmail(): any {
  if(this.subsidiary.invoiceMail){
    var formData=new FormData();
    formData.append("userName",this.subsidiary.invoiceMail)
    this.showloader=true;
  this.httpService.uploadFile("/setup-ws/subsidiary/createUser",formData,this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else if(res){
        this.toastService.addSingle(
          'success',
          'Success',
          'Invoice Receiving Mail ID created Successfully!'
        );
      this.subsidiary.invoiceMail=res.primaryEmail
      //--After create mail Id FIre Save Function
      this.saveSubsidiary();
      this.showloader=false;
      }
      else{
        this.toastService.addSingle(
          'error',
          'Alert',
          res
        );
        this.showloader=false;
      }
    },
      error => {
        this.toastService.addSingle(
          'error',
          'Alert',
          error
        );
        this.showloader=false;
      },
      () => {

        // 'onCompleted' callback.
        // No errors, route to new page here
      });
    }
}
/* End Create Email */

getcountry(){

  for(let i=0;i<this.subsidiary.subsidiaryAddresses.length;i++)
  {
      this.subsidiary.subsidiaryAddresses[i].country=this.subsidiary.country;
  
  }

}

changeswitch()
{
 if(this.subsidiary.active)
 {
  this.isvisibleactive=false;
  this.isvisibleinactive=true;
 }
 else
 {
  this.isvisibleactive=true;
  this.isvisibleinactive=false;
 }
}

addGeneralInfo()
{
 
  if (this.subsidiary.subsidiaryGeneralInfo.length > 0 && this.subsidiary.subsidiaryGeneralInfo[length - 1] == new subsidiaryGeneralInfo() ) 
  
  {
    
    return;
  }

  this.subsidiary.subsidiaryGeneralInfo.push(new subsidiaryGeneralInfo());

}

deleteGeneralinfo(index: number)
{
  if(this.editMode){
    let oldRowItems=this.subsidiary.subsidiaryGeneralInfo.filter(x=>x.id != null && x.deleted==false).length;
    let newRowItems=this.subsidiary.subsidiaryGeneralInfo.filter(x=>x.id == null).length;
    if(oldRowItems + newRowItems>1)
    {
    if( this.subsidiary.subsidiaryGeneralInfo[index].id != null)
    {
    this.subsidiary.subsidiaryGeneralInfo[index].deleted=true;
    }
    else
    {
      this.subsidiary.subsidiaryGeneralInfo.splice(index, 1);
    }
    }
    else
    {
      this.showAlert("Minimum 1 row is required !");
    }
    }else{
  if (index >= 0) this.subsidiary.subsidiaryGeneralInfo.splice(index, 1);
  }
}

InvoicereceivemailId() {
  //this.subsidiary.accountId
  this.httpService.GetAll("/setup-ws/inv-email/lov-by-account-id?accountId="+this.subsidiary.accountId, this.RetloginDetails.token)
    .subscribe(res => {
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        //Success:Do your code 
        this.invoicemailId = res;
      }
    });
}


}
