import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SubsidiaryAddEditComponent } from './subsidiary-add-edit/subsidiary-add-edit.component';
import { SubsidiaryListComponent } from './subsidiary-list/subsidiary-list.component';

const routes: Routes = [
  {
    path: '',
    component: SubsidiaryListComponent,
  },
  {
    path: 'list',
    component: SubsidiaryListComponent,
  },
  {
    path: 'action/:action/:id',
    component: SubsidiaryAddEditComponent,
  },
  {
    path: 'action/:action',
    component: SubsidiaryAddEditComponent,
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SubsidiaryRoutingModule { }
