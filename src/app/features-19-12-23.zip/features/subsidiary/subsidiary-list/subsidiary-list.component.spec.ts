import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubsidiaryListComponent } from './subsidiary-list.component';

describe('SubsidiaryListComponent', () => {
  let component: SubsidiaryListComponent;
  let fixture: ComponentFixture<SubsidiaryListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubsidiaryListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SubsidiaryListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
