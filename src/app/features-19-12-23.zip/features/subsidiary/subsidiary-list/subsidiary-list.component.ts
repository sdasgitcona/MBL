import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch, SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { ToastService } from 'src/app/core/services/toast.service';

const datepipe: DatePipe = new DatePipe('en-US')
@Component({
  selector: 'app-subsidiary-list',
  templateUrl: './subsidiary-list.component.html',
  styleUrls: ['./subsidiary-list.component.scss']
})

export class SubsidiaryListComponent implements OnInit {

  columns: any[];
  Subsidiarylist: SubsidiaryEntry[] = [];
  selectedSubsidiary: SubsidiaryEntry = new SubsidiaryEntry();
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  newevent:any;
  startdate:any;
  enddate:any;
  startdatenew:any;
  enddatenew:any;
url:any;
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   // For Role Base Access
   RetloginDetails:any;
   RetRoleDetails:any;
  constructor(
    private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService
  ) {
   
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }

   // For Role Base Access
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
    {
      if(role_Dtls[0].rolePermissions[i].accessPoint == "Subsidiary")
      {
        this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
        this.isEditable=role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable=role_Dtls[0].rolePermissions[i].view;
      }
    }
// End For Role Base Access

    this.resetBaseSearch();
    this.primengConfig.ripple = true;
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
       { field: 'name', header: 'Name' },
       { field: 'parentCompany', header: 'Parent Subsidiary' },
     
     ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }


  // resetBaseSearch() {
  //  if(this.RetloginDetails.userType=='ENDUSER') {
  //    this.baseSearch.filters = {roleId:this.RetRoleDetails[0].id,accountId:this.RetRoleDetails[0].accountId};
  //    this.baseSearch.pageNumber = 0;
  //    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
  //    this.baseSearch.sortColumn = GlobalConstants.SUBSIDIARY_TABLE_SORT_COLUMN;
  //    this.baseSearch.sortOrder = GlobalConstants.DESCENDING;
  //    this.loadSubsidiary(this.newevent);
  //   }
  //  else if(this.RetloginDetails.userType=='ROOTADMIN') {
  //   this.router.navigate(['/main/subsidiary/action/view/',this.RetRoleDetails[0].subsidiaryId]);
  //   }
  //   else {
  //     this.baseSearch.filters = {roleId:this.RetRoleDetails[0].id,accountId:this.RetRoleDetails[0].accountId};
  //     this.baseSearch.pageNumber = 0;
  //     this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
  //     this.baseSearch.sortColumn = GlobalConstants.SUBSIDIARY_TABLE_SORT_COLUMN;
  //     this.baseSearch.sortOrder = GlobalConstants.DESCENDING;
  //     this.loadSubsidiary(this.newevent);
  //   }
  // }

  resetBaseSearch() {
    if(this.RetloginDetails.userType=='ENDUSER') {
       this.baseSearch.filters = {roleId:this.RetRoleDetails[0].id,accountId:this.RetRoleDetails[0].accountId,name:this.RetRoleDetails[0].subsidiaryName};
       this.baseSearch.pageNumber = 0;
       this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
       this.baseSearch.sortColumn = GlobalConstants.SUBSIDIARY_TABLE_SORT_COLUMN;
       this.baseSearch.sortOrder = GlobalConstants.DESCENDING;
       this.loadSubsidiary(this.newevent);
      }
      else if(this.RetloginDetails.userType=='ROOTADMIN') {
        this.router.navigate(['/main/subsidiary/action/view/',this.RetRoleDetails[0].subsidiaryId]);
      }
      else {
        this.baseSearch.filters = {roleId:this.RetRoleDetails[0].id,accountId:this.RetRoleDetails[0].accountId};
        this.baseSearch.pageNumber = 0;
        this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
        this.baseSearch.sortColumn = GlobalConstants.SUBSIDIARY_TABLE_SORT_COLUMN;
        this.baseSearch.sortOrder = GlobalConstants.DESCENDING;
        this.loadSubsidiary(this.newevent);
      }
    }
 
 /* Start Fetch Subsidery list from api */

  /* End Fetch Subsidery list from api */
  // loadSubsidiary(event: any) {
  //   try {
  //     this.newevent=event
  //     this.loading = true;
     
  //     if(this.RetloginDetails.userType=='ROOTADMIN')
  //     {   
  //       this.HttpService.GetAll('/setup-ws/subsidiary/get/all?roleId='+this.RetRoleDetails[0].id,this.RetloginDetails.token).subscribe(     
  //         (res) => {
  //             if(res.status == 401)
  //             { this.showAlert("Unauthorized Access !");
  //               this.router.navigate(['/login']);
  //             }
  //             else if(res.status == 404)
  //             { this.showAlert("Wrong/Invalid Token!");
  //                this.router.navigate(['/login']);
  //              }
  //             else {
  //               this.Subsidiarylist = [];
  //               this.Subsidiarylist = res.list;
  //             }
  //             this.loading = false;
              
  //           },
  //           (error) => {
  //             this.loading = false;
  //           }
  //         );
  //     }
  //     else
  //     {
  //  this.HttpService.GetAll('/setup-ws/subsidiary/get/all?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(    
  //     (res) => {
  //         if(res.status == 401)
  //         { this.showAlert("Unauthorized Access !");
  //           this.router.navigate(['/login']);
  //         }
  //         else if(res.status == 404)
  //         { this.showAlert("Wrong/Invalid Token!");
  //            this.router.navigate(['/login']);
  //          }
  //         else {
  //           this.Subsidiarylist = [];
  //           this.Subsidiarylist = res.list;
  //         }
  //         this.loading = false;
          
  //       },
  //       (error) => {

  //         this.loading = false;
  //       }
  //     );
  //     }
  //   } catch (err) {
  //   }
  // }

  loadSubsidiary(event: any) {
    try {
      this.newevent=event
      this.loading = true;
     
      if(this.RetloginDetails.userType=='ROOTADMIN')
      {
            //this.HttpService.GetAll('/setup-ws/subsidiary/get/all?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(    
        this.HttpService.Insert('/setup-ws/subsidiary/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(     
          (res) => {
              if(res.status == 401)
              { this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if(res.status == 404)
              { this.showAlert("Wrong/Invalid Token!");
                 this.router.navigate(['/login']);
               }
               else if (res && res.list.length > 0) {
                this.Subsidiarylist = [];
                this.Subsidiarylist = res.list;
                this.totalRecords = res.totalRecords;
               } 
              else {
                this.totalRecords = 0;
              }
              this.loading = false;
              
            },
            (error) => {
              // console.log(error);
              this.loading = false;
            }
          );
      }
      else
      {
   this.HttpService.Insert('/setup-ws/subsidiary/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(    
   // this.HttpService.GetAll('/setup-ws/subsidiary/get/all?roleId='+this.RetRoleDetails[0].id,this.RetloginDetails.token).subscribe(     
      (res) => {
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
             this.router.navigate(['/login']);
           }
           else if (res && res.list.length > 0) {
            this.Subsidiarylist = [];
            this.Subsidiarylist = res.list;
            this.totalRecords = res.totalRecords;
           } 
          else {
            this.totalRecords = 0;
          }
          this.loading = false;
          
        },
        (error) => {
          // console.log(error);
          this.loading = false;
        }
      );
      }
      // console.log('PrimeNg Event is' + event);
   
    } catch (err) {
      // console.log(err);
    }
  }

  navigateToAdd() {
    this.router.navigate(['/main/subsidiary/update']);
  }
  navigateToAddViewEdit(
    action: string,
    selectedSubsidiary: SubsidiaryEntry = new SubsidiaryEntry()
  ) {
    let supplierId = null;
    if (selectedSubsidiary?.id) {
      supplierId = selectedSubsidiary.id;
      this.router.navigate(['/main/subsidiary/action', action, supplierId]);
    } else {
      this.router.navigate(['/main/subsidiary/action', action]);
    }
    // console.log('Action is ' + action);
  }
  exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.Subsidiarylist);
            doc.save('subsidiary.pdf');
        })
    })
}

  /* Start fetch filter list of Subsidiary from api */
  findby(event: any){
    this.startdatenew=this.startdate?datepipe.transform(this.startdate, 'YYYY-MM-dd'):"",
    this.enddatenew=this.enddate?datepipe.transform(this.enddate, 'YYYY-MM-dd'):"",

    this.loadSubsidiary(this.newevent);
  }
  /* End filter list of Subsidiary from api */
 
// Reset Filter
  Reset(){
    this.startdate ={};
    this.enddate={};
    location.reload();
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  onRowSelect(event: any) {
    let subId = event.data.id;
    
    this.router.navigate(['/main/subsidiary/action/view', subId]);
  }
}
