export class Subsidiary {
  id: number;
  name: string;
  legalName:string;
  parentCompany:string;
  country:string;
  email:string;
  website:string;
  language:string;
  currency:string;
  fiscalCalender:string
  pan:string;
  cin:string;
  tan:string;
  isActive:boolean=true;
  integratedId:string;
  createdBy:string;
  lastModifiedBy:string;
  //subsidiaryAddress: Array<SubsidiaryAddress> ;
  //subsidiaryAddress: [SubsidiaryAddress]=[] ;
  subsidiaryAddresses: SubsidiaryAddress[] = [];
  subsidiaryGeneralInfo:subsidiaryGeneralInfo[]=[];
  logo:string;
  logoMetadata:string;
  inactive:boolean;
  active:boolean=true;
  bidMail?:string;
  invoiceMail?:string;
  adminMail?:string;
  accountId?:string;
  activeDate?:any;
  inactiveDate?:any;
  parentSubsidiary?:boolean=false;
  parent?:boolean=false;
  invoiceMailForView:any;
}
export class SubsidiaryAddress{
  subsidiaryId?:number;
  country?:string;
  attention?:string;
  address?:string;
  phone?:number;
  address1?:string;
  address2?:string;
  city?:string;
  state?:string;
  zipcode?:string;
  registrationType?:string;
  registrationCode?:string;
  inactive?:boolean=false;
  pin?:string;
  active?:boolean;
  deleted?:boolean;
  isdisablecountry?:boolean=false;

}
export class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}
export class test {
  id: number;
  name: string;
}
export class parentcompany{
  id: number;
  name: string;
}

export class subsidiaryGeneralInfo
  {
      id?:number;
      serialNumber?:number;
      remarks?:string;
      subsidiaryId?:number;
      createdDate?: Date;
      createdBy?: string;
      lastModifiedDate?: Date;
      lastModifiedBy?: string;
      deleted?:boolean;
  }
