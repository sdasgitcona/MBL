import { Component, Inject, OnInit,LOCALE_ID} from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { PrimeNGConfig } from 'primeng/api';
import { quotation,BaseSearch,quotationItems,itemline,quotationVendors,generalinfo,BaseSearchPdf } from '../../requist-quatation/model/rfq-model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as FileSaver from 'file-saver';
import {formatDate } from '@angular/common';
@Component({
  selector: 'app-request-quatation-list',
  templateUrl: './request-quatation-list.component.html',
  styleUrls: ['./request-quatation-list.component.scss']
})
export class RequestQuatationListComponent implements OnInit {
  columns: any[];
  RFQList: quotation[]=[];
  Subsidiarylist:any[]=[];
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  RFQPrint: any[] = [];
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  newevent:any;
  quotation: quotation = new quotation();
  selectedRFQ: quotation = new quotation();
  Bidstatus:any;
  RetloginDetails:any;
  showloader:boolean = false;
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  // For Role Base Access
  RetRoleDetails:any;
  SubIdList:any=[];
  status:any[]=[];

  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,  private toastService: ToastService,@Inject(LOCALE_ID) public locale: string) {

      this.Bidstatus = [{id:'Open',value:'open'},{id:'Close',value:'close'}]; 
      this.status = ['QA Created', 'Draft', 'Submitted'];
     }

  ngOnInit(): void {
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    // For Role Base Access
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
  this.RetRoleDetails=role_Dtls;

    for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
    {
      if(role_Dtls[0].rolePermissions[i].accessPoint == "Request For Quotation")
      {
        this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
        this.isEditable=role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable=role_Dtls[0].rolePermissions[i].view;
      }
    }
// End For Role Base Access
   // this.resetBaseSearch();
    this.GetSubsideryList();
    this.columns = [
                { field: 'id', header: 'Internal ID' },
                { field: 'Subsidiary', header: 'Subsidiary' },
                { field: 'RFQ Date', header: 'RFQ Date' },
                { field: 'RFQ Number', header: 'RFQ Number' },
                { field: 'Bid Open Date', header: 'Bid Open Date & Time' },
                { field: 'Bid Close Date', header: 'Bid Close Date & Time' },
                { field: 'Bidding Type', header: 'RFQ Type' },
                { field: 'Creator', header: 'Creator' },
                { field: 'RFQ Status', header: 'status' },
                { field: 'Currency', header: 'currency' },
                { field: 'PR Number', header: 'prNumber' },

    ];
   this.exportColumns = this.columns.map(col => ({
     title: col.header,
     dataKey: col.field
   }));

  }

  navigateToAddViewEdit(
    action: string,
  ) {
    let locationId = null;
    this.router.navigate(['/main/request-quatation/action', action]);
    console.log('Action is ' + action);
  }

  loadselectedRFQList(event:any) {
    try {
      this.newevent=event
      this.loading = true;
   this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      this.baseSearch.pageSize = event.rows;
      this.baseSearch.sortColumn = event.sortField
      ?  event.sortField
      : GlobalConstants.RFQ_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
          if(this.SubIdList.length==0)
          {
           return;
          }
      this.HttpService.Insert('/procure-ws/quotation/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
          if (res && res.list.length > 0) {
            this.RFQList = res.list;
            this.totalRecords = res.totalRecords;
          } else {
            this.RFQList = [];
            this.totalRecords=0;
          }
          this.loading = false;
        }
        },
        (error) => {
          this.showAlert(error);
          this.loading = false;
        }
      );
    } catch (err) {
    }
  }


  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.RFQ_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadselectedRFQList(this.newevent);
  }



  /* Start Fetch project list All from api */
  loadrfqAll() {
    var obj={
      pageNumber: 0,
      pageSize: 1000,
      sortColumn: "bidType",
      sortOrder: "asc"
  }
    this.HttpService.Insert("/procure-ws/quotation/get/all",obj,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        this.RFQList=res.list;
        this.showAlert(res);
      }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  }
  /* End Fetch project list All from api */



  /*exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.RFQList);
            doc.save('RFQ.pdf');
        })
    })
}*/

GetSubsideryList() {
  if(this.RetloginDetails.userType=='SUPERADMIN')
  //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    
  //this.HttpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
     this.Subsidiarylist = res;
    
     for (let x = 0; x < this.Subsidiarylist.length; x++) {
      this.SubIdList.push(this.Subsidiarylist[x].id);
    }
    }
    },
    (error) => {
     this.showAlert(error);
    },
    () => {
      if(localStorage.getItem("RFQFilters") != null)
      {const LocDetails:any =localStorage.getItem("RFQFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.quotation.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.quotation.bidType=searcheData.filters.type;
      this.quotation.bidOpenDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;;
      this.quotation.bidCloseDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.quotation.rfqNumber=searcheData.filters.rfqNumber;
      this.quotation.status=searcheData.filters.status;
      this.quotation.creator=searcheData.filters.creator;
      this.loadselectedRFQList(this.newevent);
      localStorage.removeItem("RFQFilters");
      }
      else
     { this.resetBaseSearch();}
    }
  );
}else if(this.RetloginDetails.userType=='ENDUSER'){
  this.Subsidiarylist.push({
    "id":this.RetRoleDetails[0].subsidiaryId,
    "name":this.RetRoleDetails[0].subsidiaryName
  });
  this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
  this.quotation.subsidiaryId=this.RetRoleDetails[0].subsidiaryId
  if(localStorage.getItem("RFQFilters") != null)
  {const LocDetails:any =localStorage.getItem("RFQFilters");
  let RetLocDetails = JSON.parse(LocDetails);
  this.baseSearch=RetLocDetails;
  let searcheData:any = RetLocDetails;
  this.quotation.subsidiaryId=searcheData.filters.subsidiaryId[0];
  this.quotation.bidType=searcheData.filters.type;
  this.quotation.bidOpenDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;;
  this.quotation.bidCloseDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
  this.quotation.rfqNumber=searcheData.filters.rfqNumber;
  this.quotation.status=searcheData.filters.status;
  this.quotation.creator=searcheData.filters.creator;  this.loadselectedRFQList(this.newevent);
  localStorage.removeItem("RFQFilters");
  }
  else
 { this.resetBaseSearch();}
}
}
findby(event: any){
  let subsidyList:any=[];
  subsidyList.push(this.quotation.subsidiaryId);

  let days:any;
  let months:any;
  let year:any;
  let daysclosedate:any;
  let monthsclosedate:any;
  let yearclosedate:any;
 if(this.quotation.bidOpenDate!=undefined)
 {
    
    days = new Date(this.quotation.bidOpenDate).getUTCDate();
    months = new Date(this.quotation.bidOpenDate).getUTCMonth()+1;
    year = new Date(this.quotation.bidOpenDate).getUTCFullYear();
   // fromdate=year+"-"+months+"-"+days;

 }

 if(this.quotation.bidCloseDate!=undefined)
 {
    daysclosedate = new Date(this.quotation.bidCloseDate).getUTCDate();
    monthsclosedate = new Date(this.quotation.bidCloseDate).getUTCMonth()+1;
    yearclosedate = new Date(this.quotation.bidCloseDate).getUTCFullYear();
  //  closedate=yearclosedate+"-"+monthsclosedate+"-"+daysclosedate;

 }

  this.baseSearch.filters={
    subsidiaryId:subsidyList,
    type:this.quotation.bidType,
    fromDate:this.quotation.bidOpenDate !== undefined ? (year + '-' + (months.toString().length == 1 ? "0" + months : months) + '-' + (days.toString().length == 1 ? "0" + days : days)) : null,
    toDate:this.quotation.bidCloseDate !== undefined ? (yearclosedate + '-' + (monthsclosedate.toString().length == 1 ? "0" + monthsclosedate : monthsclosedate) + '-' + (daysclosedate.toString().length == 1 ? "0" + daysclosedate : daysclosedate)) : null,
    rfqNumber:this.quotation.rfqNumber,
    status:this.quotation.status,
    creator:this.quotation.creator
}
this.baseSearch.pageNumber=-1;
 this.loadselectedRFQList(this.newevent);
}
Reset(){
  //this.quotation.subsidiaryId =undefined;
  if(this.RetloginDetails.userType=='SUPERADMIN')
  {
    this.quotation.subsidiaryId=undefined;
  }
 
  this.quotation.status='';
  this.quotation.locationId=undefined;
  this.quotation.creator=undefined;
  this.quotation.bidOpenDate=undefined;
  this.quotation.bidCloseDate=undefined;
  this.quotation.bidType=undefined;
  this.resetBaseSearch();
  this.baseSearch.pageNumber=-1;
  this.loadselectedRFQList(this.newevent);
}
showAlert(AlertMSG:any) {
  this.toastService.addSingle(
    'error',
    'Error',
    AlertMSG
  );
}


editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("RFQFilters") != null)
    {
      localStorage.removeItem("RFQFilters");
    }
    localStorage.setItem("RFQFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/request-quatation/action', actionType, mainId]);
   }

   
    //List Export option Start

    //Start PDF
    generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.RFQ_TABLE_SORT_COLUMN;
      this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};

      this.HttpService.Insert('/procure-ws/quotation/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.RFQPrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {
                  if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }

               
                if(exportType == 'PDF'){   
                  this.RFQPrint.push({
                    'id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'RFQ Date': formatDate(RetData[i].rfqDate, 'dd-MM-yyyy' ,this.locale),
                    'RFQ Number': RetData[i].rfqNumber,
                    'Bid Open Date': formatDate(RetData[i].bidOpenDate, 'dd-MM-yyyy' ,this.locale),
                    'Bid Close Date':formatDate(RetData[i].bidCloseDate, 'dd-MM-yyyy' ,this.locale), 
                    'Bidding Type': RetData[i].bidType,
                    'Creator': RetData[i].creator,
                    'RFQ Status': RetData[i].status,
                    'Currency': RetData[i].currency,
                    'PR Number': RetData[i].prNumber,
                });
              }
                else{
                  this.RFQPrint.push({
                    'Internal Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'RFQ Date': formatDate(RetData[i].rfqDate, 'dd-MM-yyyy' ,this.locale),
                    'RFQ Number': RetData[i].rfqNumber,
                    'Bid Open Date': formatDate(RetData[i].bidOpenDate, 'dd-MM-yyyy' ,this.locale),
                    'Bid Close Date':formatDate(RetData[i].bidCloseDate, 'dd-MM-yyyy' ,this.locale), 
                    'Bidding Type': RetData[i].bidType,
                    'Creator': RetData[i].creator,
                    'RFQ Status': RetData[i].status,
                    'Currency': RetData[i].currency,
                    'PR Number': RetData[i].prNumber,
                  });
                }

              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    exportPdf() {
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          //this.= this.employeeExport;
          //this.employeelist=[];
          (doc as any).autoTable(this.exportColumns, this.RFQPrint);
          doc.save('RFQ.pdf');
        })
      })
    }

  //End PDF

  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');

   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.RFQPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.RFQPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'RFQ');
           this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
  //End Excel 

  onRowSelect(event: any) {
    let rqId = event.data.id;
    
    this.router.navigate(['/main/request-quatation/action/view', rqId]);
  }
}
