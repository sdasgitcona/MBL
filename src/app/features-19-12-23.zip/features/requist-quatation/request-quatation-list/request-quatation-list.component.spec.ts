import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestQuatationListComponent } from './request-quatation-list.component';

describe('RequestQuatationListComponent', () => {
  let component: RequestQuatationListComponent;
  let fixture: ComponentFixture<RequestQuatationListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestQuatationListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RequestQuatationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
