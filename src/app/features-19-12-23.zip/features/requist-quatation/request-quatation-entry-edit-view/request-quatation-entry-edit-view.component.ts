import { Component, OnInit } from '@angular/core';
import { quotation,BaseSearch,quotationItems,quotationPrs,itemline,quotationVendors,quotationInfos,itemVendors } from '../../requist-quatation/model/rfq-model';
import { SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { PurchasesRequisition, RequesterList } from '../../purchases-requisition/model/purchases-requisition.model'
import { ActivatedRoute, Router } from '@angular/router';
import { ToastService } from 'src/app/core/services/toast.service';
import { DatePipe } from '@angular/common';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { RfqReportComponent } from '../../reports/rfq-report/rfq-report.component';
import { RfqCloseComponent } from '../../reports/rfq-close/rfq-close.component';
@Component({
  selector: 'app-request-quatation-entry-edit-view',
  templateUrl: './request-quatation-entry-edit-view.component.html',
  styleUrls: ['./request-quatation-entry-edit-view.component.scss']
})
export class RequestQuatationEntryEditViewComponent implements OnInit {

  quotationId:number;
  quotation: quotation = new quotation();
  quotationcopy: quotation = new quotation();
  Subsidiarylist: any[] = [];
  PRList: quotationPrs[]=[];
  itemlines: itemline[]=[];
  quotationVendors:quotationVendors[]=[];
  lstCurrencyList: any[] = [];
  supplierlistid: any[] = [];
  vendorlist: itemVendors[] = [];
  quotationprCopy:quotationPrs[]=[];
  supplierCopy:itemVendors[]=[];
  quotationprCall:any;
  employeelist: any[] = [];
  Bidtype:any;
  Bidstatus:any;
  remarks:string;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  enadissendnotification:boolean=true;
  enadissendmail:boolean=true;
  enadisclose:boolean=true;
  enadiscreateQA:boolean=true;
  enadissubmit:boolean=true;
  dissupplier:boolean=true;
  isReloadSub:boolean;
  baseSearch: BaseSearch = new BaseSearch();
  selectedGeneralInfo: quotationInfos = new quotationInfos();
  private subscription: any;
  Selectedvendors: itemVendors[] = [];
  Testvendors: itemVendors[] = [];
  testPrs:quotationPrs[]=[];
  QuotationHistoryList: HistoryModel[] = [];
  isdisableaftersubmit:boolean=false;
  EmployeeList:RequesterList[]; // add by Aftab
  loginId:number;  // add by Aftab
  ishiddenafterQA:boolean=false;
  prNumberafterSubmit:string="";
  checkforlines:boolean=false;
  RetloginDetails:any;
  ProjectList:any[];
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   isviewEditable:boolean=true;
   // For Role Base Access
   showloader:boolean = false;
   fiscalCalenderDTLS: any;
   isdisablebidtype:boolean=false;
   RetRoleDetails:any;
   url:any;
  constructor(
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
    private datepipe:DatePipe,
    private rfqOpenReport:RfqReportComponent,
    private rfqClose:RfqCloseComponent,
  ) {

    this.Bidtype = [{id:'Open Bid',value:'Open'},{id:'Closed Bid',value:'Close'}];
    
    this.Bidstatus = [{id:'QA Created',value:'QA Created'},{id:'Closed',value:'Closed'},{id:'Draft',value:'Draft'},{id:'Open',value:'Open'},{id:'Submitted',value:'Submitted'}]; 
  }

  ngOnInit(): void {
    
const LDetails:any=localStorage.getItem("LoggerDTLS");
this.RetloginDetails = JSON.parse(LDetails);
     // For Role Base Access
     const logDetails:any = localStorage.getItem("LoggerDTLS");
const LoggerId=JSON.parse(logDetails);
this.loginId= LoggerId.employeeId;
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Request For Quotation")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access
    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.quotationId = +params['id']; // (+) converts string 'id' to a number
            this.GetQuotationbyId();
            
          }
          this.assignMode(params['action']);       
          this.GetSubsideryList();
             
          this.All_CurrencyList();

          if(this.addMode)
          {
            this.loadrequestor();
          }
          
        } else {
          this.showAlert('cannot get params');
        }
      },
      (error) => {
        this.showAlert('add');
      }
    );
  }




  // Mode Creation Start
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;

      default:
        break;
    }
  }
  // Mode Creation End

  /* Fetch Subsidery list from api */
GetSubsideryList() {
  if(this.RetloginDetails.userType=='SUPERADMIN')
  //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
  {
    this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(

  //this.httpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
     this.Subsidiarylist = res;
     this.isReloadSub=false;
    }
    },
    (error) => {
      this.isReloadSub=false;
      this.showAlert(error);
    }
  );
}
else if(this.RetloginDetails.userType=='ENDUSER'){
  this.Subsidiarylist.push({
    "id":this.RetRoleDetails[0].subsidiaryId,
    "name":this.RetRoleDetails[0].subsidiaryName
  });

}
}
  /* End Fetch Subsidery list from api */
  /* Start reload Subsidery list from api */
reloadSubidery(){
  location.reload();
 /* this.isReloadSub=true;
  this.quotation.subsidiaryId=0;
  this.Subsidiarylist=[];
  this.quotationprCopy=[];
  this.itemlines=[];
  this.quotation.quotationVendors=[];
  this.quotation.subsidiaryAddress=undefined;
  this.quotation.bidRecieveEmail=undefined;
  this.quotation.creator=undefined;
  this.quotation.currency=undefined;
  this.GetSubsideryList();*/
}

reloadPRnumber()
{
  this.quotationprCopy=[];
  this.itemlines=[];
  this.quotation.quotationVendors=[];
  this.PRList=[];
  this.GetPRList();
}

GetPRList() {

  if(this.quotation.projectId!=null)
  {
    this.url="/procure-ws/pr/get-prs-by-subsidiary?subsidiaryId="+this.quotation.subsidiaryId+"&projectId="+this.quotation.projectId;
  }
  else{
    this.url="/procure-ws/pr/get-prs-by-subsidiary?subsidiaryId="+this.quotation.subsidiaryId;
  }

//status--approved, partially processed
  this.httpService.GetAll(this.url,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      this.testPrs=[];
      this.PRList=[];
      for(let k=0;k<res.length;k++)
      {
          this.testPrs.push({
            prNumber:res[k].toString(),
            deleted:false,
            
           
          });
          // this.PRList.push({
          //   id:res[k].prId,
          //   name:res[k].name,
          //   //isDisabled:true
          // });
      }  
    // this.PRList=this.testPrs;

     this.PRList=res;  // Edited by Aftab
     this.isReloadSub=false;
     //this.SubsideryObject=res;
    }
    },
    (error) => {
      this.isReloadSub=false;
     this.showAlert(error);
    }
  );
}
/* End reload Subsidery list from api */
All_CurrencyList() {
  this.httpService.GetAll("/setup-ws/currency/get/all",this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      this.lstCurrencyList = res;
    }
    });
}

getAllCurrencyReloadList()
{
  this.lstCurrencyList=[];
  this.All_CurrencyList();
}

loaddetails()
{
  this.getFiscalDateRanges();

  this.quotationprCopy=[];
  this.itemlines=[];
  //this.quotation.quotationVendors=[];
  this.GetPRList();
  this.GetAllProjectList(this.quotation.subsidiaryId);

  this.httpService.GetAll('/setup-ws/subsidiary/get?id='+this.quotation.subsidiaryId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      this.quotation.currency=res.currency;
      for(let i=0;i<res.subsidiaryAddresses.length;i++)
      {
        if(res.subsidiaryAddresses[i].active==true)
        {
          this.quotation.subsidiaryAddress=undefined;
          //this.quotation.subsidiaryAddress=res.subsidiaryAddresses[i].address1!=null?res.subsidiaryAddresses[i].address1:""+ " ," + res.subsidiaryAddresses[i].address2!=null?res.subsidiaryAddresses[i].address2:""+ " ," +res.subsidiaryAddresses[i].city!=null?res.subsidiaryAddresses[i].city:"" + " ," +res.subsidiaryAddresses[i].state!=null?res.subsidiaryAddresses[i].state:""+ " ," +res.subsidiaryAddresses[i].zipcode!=null?res.subsidiaryAddresses[i].zipcode:"";
          if(res.subsidiaryAddresses[i].address1!=null)
          {
            this.quotation.subsidiaryAddress=res.subsidiaryAddresses[i].address1;
          }
          if(res.subsidiaryAddresses[i].address2!=null)
          {
            this.quotation.subsidiaryAddress=this.quotation.subsidiaryAddress+","+ res.subsidiaryAddresses[i].address2;
          }
          if(res.subsidiaryAddresses[i].city!=null)
          {
            this.quotation.subsidiaryAddress=this.quotation.subsidiaryAddress+","+ res.subsidiaryAddresses[i].city;
          }
          if(res.subsidiaryAddresses[i].state!=null)
          {
            this.quotation.subsidiaryAddress=this.quotation.subsidiaryAddress+","+ res.subsidiaryAddresses[i].state;
          }
          if(res.subsidiaryAddresses[i].zipcode!=null)
          {
            this.quotation.subsidiaryAddress=this.quotation.subsidiaryAddress+","+ res.subsidiaryAddresses[i].zipcode;
          }
          this.quotation.bidRecieveEmail=undefined;
          if(res.bidMail!=null)
          {
            this.quotation.bidRecieveEmail=res.bidMail;
          }
        
         
        }
      }
    }
    },
    (error) => {
      this.showAlert(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    }
  );

  this.httpService.GetAll('/masters-ws/employee/get-employee-by-subsidiary?subsidiaryId='+this.quotation.subsidiaryId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      this.employeelist=res;
    }
    },
    (error) => {
      this.showAlert(error);
    },
    () => {
     
    }
  );

}

loaditem(event:any)
{

 
  const PRarray = [];
  let isPrChcked:boolean;
  let PrCheckedId=0;
  if(this.addMode)
  {
    for(let i=0;i<this.quotationprCopy.length;i++)
    {
     //PRarray.push(this.quotationprCopy[i].prNumber) // old
     PRarray.push(this.quotationprCopy[i].id)  // new
    }
  }
  else{
  PrCheckedId=event.itemValue.id;
  if (this.quotationprCopy.find((a:any) => a.id == PrCheckedId)) {
    isPrChcked=true;
    }
    else
    {
      isPrChcked=false;
    }
 
  PRarray.push(PrCheckedId);
  }
 


  //this.httpService.Insert('/pr/get-unprocessed-items-by-pr-numbers', PRarray).subscribe(
    this.httpService.Insert('/procure-ws/pr/get-unprocessed-items-by-pr-ids?formName=Request For Quotation', PRarray,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      if(this.addMode)
      {
        
     this.itemlines=res;
     for(let i=0;i<this.itemlines.length;i++)
     {
      this.itemlines[i].receivedDate=this.itemlines[i].receivedDate!=null?new Date(this.itemlines[i].receivedDate):"";
     }
     this.LoadsupplierbySubsidiaryId();
     this.departmentchecking();
    
    }
    else //Edit Mode
    {
      
     // this.quotation.quotationVendors=[];
      //this.itemlines=[];
      for(let i=0;i<res.length;i++)
      {
        //let obj1 = this.itemlines.find(o=>o.prId!=res[i].prId);
        //if(obj1 != undefined)
        if(isPrChcked)
        {
          debugger
          this.itemlines.push({
            id:res[i].id,
            itemId:res[i].itemId,
            quantity:res[i].quantity,
            remainedQuantity:res[i].remainedQuantity,
            receivedDate:res[i].receivedDate!=null?new Date(res[i].receivedDate):"",
            Remarks:res[i].remarks,
            prNumber:res[i].prNumber,
            prLocationId:res[i].prLocationId,
            itemName:res[i].itemName,
            itemDescription:res[i].itemDescription,
            itemUom:res[i].itemUom,
            supplier:[],
            Suppliers:[],
            prLocationName:res[i].prLocationName,
            prId:res[i].prId,
            deleted:false,
            departmentName:res[i].departmentName,
            departmentId:res[i].departmentId
          });
        }
        // else
        // {
        //   this.itemlines.splice(i,1);
        // }
      }
       if(isPrChcked == false){
      
      //   this.itemlines.forEach((element,index)=>{
      //     if(element.prId==PrCheckedId && element.id==null) this.itemlines.splice(index,1);
      //  });

      for(let x=0;x<this.quotationprCopy.length;x++)
      {
        if( this.quotationprCopy[x].id==PrCheckedId)
        this.quotationprCopy[x].deleted=true;
      }
      for(let x=0;x<this.itemlines.length;x++)
      {
         if(this.itemlines[x].prId == PrCheckedId && this.itemlines[x].id == null)
         {
          this.itemlines.splice(x,1);
          x--;
         }
         else if(this.itemlines[x].prId == PrCheckedId && this.itemlines[x].id != null)
         {
          this.itemlines[x].deleted=true;

          for(let i=0;i<this.itemlines[x].supplier.length;i++)
          {
              for(let j=0;j<this.quotation.quotationVendors.length;j++)
              {
                if(this.quotation.quotationVendors[j].vendorId==this.itemlines[x].supplier[i].vendorId)
                {
                  this.quotation.quotationVendors[j].deleted=true;
                }
              }
          }   
         }
      }
        //if(this.itemlines[i].prId == PrCheckedId)
        //{
          //this.itemlines.(o => o.id == this.itemlines[x].prId);
          // if(this.itemlines[i].id == null)
          // {
          //   this.itemlines.map(o => o.id === this.itemlines[i].prId);
          //   //this.itemlines.splice(i,1);
          // }
          // else
          // {
          //   this.itemlines[i].deleted=true;
          // }
        //}
      
        // let obj = this.quotationprCopy.find(o => o.id === this.itemlines[i].prId);
        //           if(!obj)
        //           {
        //             this.itemlines[i].deleted=true;
        //           }
    }
   this.departmentchecking();

    }
  }
    },
    (error) => {
      this.showAlert(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    }
  );




}
/*
handleTabChange(event: any) {
  //Fetch History if the selected tab index is History Tab index

  if (event.index == 1) {
    let check=0;
   // this.quotationVendors=[];
if(this.quotation.quotationVendors.length>0)
{
  for(let m=0;m<this.quotation.quotationVendors.length;m++)
  {
    for(let i=0;i<this.itemlines.length;i++)
     {
        if(this.itemlines[i].Suppliers!=undefined)
           {
             for(let j=0;j<this.itemlines[i].Suppliers.length;j++)
                {
                    if(this.quotation.quotationVendors[m].vendorId==this.itemlines[i].Suppliers[j].vendorId)
                    {
                     check=1;
                    }

                }
            }
     }

     if(check==0)
     {
      this.quotation.quotationVendors.splice(m,1);
     }
     check=0;

  }
}

for(let i=0;i<this.itemlines.length;i++)
{
  if(this.itemlines[i].Suppliers!=undefined)
  {
  for(let j=0;j<this.itemlines[i].Suppliers.length;j++)
  {

       this.httpService.GetAll('/masters-ws/supplier/get?id='+this.itemlines[i].Suppliers[j].vendorId,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
          for(let k=0;k<res.supplierContacts.length;k++)
          {
            if(res.supplierContacts[k].primaryContact==true)
            {
                 let flag=0;
              for(let l=0;l<this.quotation.quotationVendors.length;l++)
              {
                if(this.quotation.quotationVendors[l].vendorName==res.name && this.quotation.quotationVendors[l].contactName==res.supplierContacts[k].name)
                {
                  if(this.quotation.quotationVendors[l].deleted==true)
                  {
                    for(let k1=0;k1<this.itemlines.length;k1++)
                    {
                      let supp_=(this.itemlines[k1].Suppliers.filter(x=>x.vendorId==this.quotation.quotationVendors[l].vendorId))
                      if(supp_.length>0)
                      {
                        if(this.itemlines[k1].deleted!=true)
                        {
                          this.quotation.quotationVendors[l].deleted=false;
                        }
                      }
                    }
                   
                  }
                       flag=1;
                }
              }
              if(flag==0)
              {
              this.quotation.quotationVendors.push({
                vendorName:res.name,
                vendorId:res.id,
                contactName:res.supplierContacts[k].name,
                email:res.supplierContacts[k].email,
                memo:"",
                deleted:res.supplierContacts[k].deleted
   
              });
             }
             flag=0;
            }
          }

        }
     
        },
        (error) => {
         this.showAlert(error);
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        }
      );
  }
}
 
}

   
      
  //  this.LoadHistory();
   // this.displayAddressDialog = false;
  }
  else if(event.index==4)
  {
    
    this.LoadHistory();
  }
}
*/
handleTabChange(event: any) {
  //Fetch History if the selected tab index is History Tab index

  if (event.index == 1) {
    let check=0;
   // this.quotationVendors=[];
if(this.quotation.quotationVendors.length>0)
{
  for(let m=0;m<this.quotation.quotationVendors.length;m++)
  {
    for(let i=0;i<this.itemlines.length;i++)
     {
        if(this.itemlines[i].Suppliers!=undefined)
           {
             for(let j=0;j<this.itemlines[i].Suppliers.length;j++)
                {
                    if(this.quotation.quotationVendors[m].vendorId==this.itemlines[i].Suppliers[j].vendorId)
                    {
                     check=1;
                    }

                }
            }
     }

     if(check==0)
     {
      this.quotation.quotationVendors.splice(m,1);
     }
     check=0;

  }
}

for(let i=0;i<this.itemlines.length;i++)
{
  if(this.itemlines[i].Suppliers!=undefined)
  {
  for(let j=0;j<this.itemlines[i].Suppliers.length;j++)
  {

       this.httpService.GetAll('/masters-ws/supplier/get?id='+this.itemlines[i].Suppliers[j].vendorId,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
          for(let k=0;k<res.supplierContacts.length;k++)
          {
            if(res.supplierContacts[k].primaryContact==true)
            {
                 let flag=0;
              for(let l=0;l<this.quotation.quotationVendors.length;l++)
              {
                if(/*this.quotation.quotationVendors[l].vendorName==res.name && this.quotation.quotationVendors[l].contactName==res.supplierContacts[k].name &&*/ this.quotation.quotationVendors[l].vendorId==res.supplierContacts[k].supplierId)
                {
                  if(this.quotation.quotationVendors[l].deleted==true)
                  {
                    for(let k1=0;k1<this.itemlines.length;k1++)
                    {
                      let supp_=(this.itemlines[k1].Suppliers.filter(x=>x.vendorId==this.quotation.quotationVendors[l].vendorId))
                      if(supp_.length>0)
                      {
                        if(this.itemlines[k1].deleted!=true)
                        {
                          this.quotation.quotationVendors[l].deleted=false;
                        }
                      }
                    }
                   
                  }
                  for(let i=0;i<this.quotation.quotationVendors.length;i++)
                  {
                    if(this.quotation.quotationVendors[i].vendorId==res.supplierContacts[k].supplierId)
                    {
                      this.quotation.quotationVendors[i].vendorName=res.name;
                      this.quotation.quotationVendors[i].contactName=res.supplierContacts[k].name;
                      this.quotation.quotationVendors[i].email=res.supplierContacts[k].email;

                    }
                  }
                       flag=1;
                }
              }
              if(flag==0)
              {

             
             
              this.quotation.quotationVendors.push({
                vendorName:res.name,
                vendorId:res.id,
                contactName:res.supplierContacts[k].name,
                email:res.supplierContacts[k].email,
                memo:"",
                deleted:res.supplierContacts[k].deleted
   
              });
             }
             
             flag=0;
            }
          }

        }
     
        },
        (error) => {
         this.showAlert(error);
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        }
      );
  }
}
 
}

   
      
  //  this.LoadHistory();
   // this.displayAddressDialog = false;
  }
  else if(event.index==4)
  {
    
    this.LoadHistory();
  }
}
LoadsupplierbySubsidiaryId()
{
  this.httpService.GetAll('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId='+this.quotation.subsidiaryId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      this.vendorlist=[];
      for(let i=0;i<res.length;i++)
      {
        this.vendorlist.push({
          vendorId:res[i].id,
          vendorName:res[i].name
        });
      }
    }
    },
    (error) => {
      this.showAlert(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    }
  );
}

deleteGeneralinfo(index: number)
{
  if(this.editMode){
    let oldRowItems=this.quotation.quotationInfos.filter(x=>x.id != null && x.deleted==false).length;
    let newRowItems=this.quotation.quotationInfos.filter(x=>x.id == null).length;
    if(oldRowItems + newRowItems>1)
    {
    if( this.quotation.quotationInfos[index].id != null)
    {
    this.quotation.quotationInfos[index].deleted=true;
    }
    else
    {
      this.quotation.quotationInfos.splice(index, 1);
    }
    }
    else
    {
      this.showAlert("Minimum 1 row is required !");
    }
    }else{
  if (index >= 0) this.quotation.quotationInfos.splice(index, 1);
  }
}

deleteItemLine(index: number)
{
  if (index >= 0) {
    //this.itemlines.splice(index, 1);
    this.itemlines[index].deleted=true;
  }
}
addGeneralInfo()
{
 
  if (this.quotation.quotationInfos.length > 0 && this.quotation.quotationInfos[length - 1] == new quotationInfos() ) 
  
  {
    
    return;
  }

  this.quotation.quotationInfos.push(new quotationInfos());

}

saveQuotation(type:string) {

  if(this.editMode || this.viewMode)
  {
    this.Selectedvendors=[];
    
    for(let i=0;i<this.quotation.quotationItems.length;i++)
    {
        if(this.quotation.quotationItems[i].itemVendors!=undefined)
        {
                for(let j=0;j<this.quotation.quotationItems[i].itemVendors.length;j++)
              {
                
                        this.Selectedvendors.push({
                                id:this.quotation.quotationItems[i].itemVendors[j].id,  
                                vendorId:this.quotation.quotationItems[i].itemVendors[j].vendorId,
                                vendorName:this.quotation.quotationItems[i].itemVendors[j].vendorName,
                          });
               }
        }
      }  
      this.quotation.quotationItems=[];
  }
  this.quotation.quotationItems=[];
  if(this.quotation.subsidiaryId==undefined)
  {
    this.showErrorSubsidiary();
    return;
  }
  
  if(this.quotation.rfqDate==undefined || this.quotation.rfqDate=="[object Object]")
  {
    this.showErrorrfqDate();
    return;
  }
  
  if(this.quotationprCopy.length==0)
  {
    this.showErrorquotationPrs();
    return;
  }
  if(this.quotation.bidType==undefined)
  {
    this.showErrorbidtype();
    return;
  }
  if(this.quotation.bidOpenDate==undefined)
  {
    this.showErrorbidopen();
    return;
  }
  if(this.quotation.bidCloseDate==undefined)
  {
    this.showErrorbidclose();
    return;
  }
  if(new Date(this.quotation.bidOpenDate) <= new Date(this.quotation.rfqDate))
  {
    this.showErrordatevalidationRFQ();
    return;
  }
  if(new Date(this.quotation.bidOpenDate) == new Date(this.quotation.bidCloseDate))
  {

    this.showErrordateequal();
    return;
  }
  if(new Date(this.quotation.bidOpenDate) >= new Date(this.quotation.bidCloseDate))
  {
    this.showErrordatevalidation();
    return;
  }
  
  if(this.quotation.creator==undefined)
  {
    this.showErrorcreator();
    return;
  }

  //---Start PR List
 if(this.editMode || this.viewMode)
 {
        let _copiedValue = JSON.parse(
          JSON.stringify(this.quotationprCopy)
        );
        this.testPrs=[];
          _copiedValue.forEach((element: any) => {
            let item = this.quotation.quotationPrs.find(
              (o) => o.prId == element.id
            );
            if (item) {
           
              this.testPrs.push({
                id:item.id,
                quotationId:item.quotationId,
                quotationNumber:element.quotationNumber,
                prNumber:item.prNumber,
                prId:item.prId,
                prLocationId:item.prLocationId,
                createdDate:item.createdDate,
                createdBy:item.createdBy,
                lastModifiedDate:item.lastModifiedDate,
                lastModifiedBy:item.lastModifiedBy,
                deleted:item.deleted
              });
            }
            else
            {
              this.testPrs.push({
                prId:element.id,
                //prNumber:this.quotationprCopy[k].name,
                deleted:false
              });
            }
          });

   

  }
  else
  {
        this.testPrs=[];
        for(let k=0;k<this.quotationprCopy.length;k++)
        {
            // this.testPrs.push({
            //   id:this.quotationprCopy[k].id,
            //   prNumber:this.quotationprCopy[k].prNumber.toString(),
            //   deleted:this.quotationprCopy[k].deleted
            // });
            this.testPrs.push({
              prId:this.quotationprCopy[k].id,
              //prNumber:this.quotationprCopy[k].name,
              deleted:false
            });
            // edited by Aftab
        }  
  }

 //---End PR List

for(let i=0;i<this.itemlines.length;i++)
{
  this.Testvendors=[];

  if(this.itemlines[i].Suppliers!=undefined)
  {
    for(let j=0;j<this.itemlines[i].Suppliers.length;j++)  ///////
   {
    if(this.editMode || this.viewMode)
    {
      
      let vendorline=this.Selectedvendors.find(o=>o.vendorId==this.itemlines[i].Suppliers[j].vendorId); ///////

    if(vendorline)
      {
      this.Testvendors.push({
        id:vendorline.id,
        vendorId:this.itemlines[i].Suppliers[j].vendorId,
        itemId:this.itemlines[i].itemId,
        deleted:this.itemlines[i].Suppliers[j].deleted,
        quotationId:this.quotation.id,
        rfqNumber:this.quotation.rfqNumber
  
       
       });
      }
      else
      {
          this.Testvendors.push({
            //id:this.itemlines[i].Suppliers[j].id,
            vendorId:this.itemlines[i].Suppliers[j].vendorId,
            itemId:this.itemlines[i].itemId,
            deleted:this.itemlines[i].Suppliers[j].deleted,
            quotationId:this.quotation.id,
            rfqNumber:this.quotation.rfqNumber

          
          });
      }
    }
    else //Add
    {
            this.Testvendors.push({
              //id:this.itemlines[i].Suppliers[j].id,
              vendorId:this.itemlines[i].Suppliers[j].vendorId,
              itemId:this.itemlines[i].itemId,
              deleted:this.itemlines[i].Suppliers[j].deleted,
              quotationId:this.quotation.id,
              rfqNumber:this.quotation.rfqNumber
        
            
            });
    }

    
   }
  }
if(this.addMode)
{
  if(this.itemlines[i].deleted!=true)
  {
  this.quotation.quotationItems.push({
    id:this.itemlines[i].id,
    itemId:this.itemlines[i].itemId,
    quantity:this.itemlines[i].quantity,
    receivedDate:this.itemlines[i].receivedDate,
    remarks:this.itemlines[i].Remarks,
    prNumber:this.itemlines[i].prNumber,
    prLocation:this.itemlines[i].prLocationId,
    prLocationName:this.itemlines[i].prLocationName,
    itemName:this.itemlines[i].itemName,
    itemDescription:this.itemlines[i].itemDescription,
    itemUom:this.itemlines[i].itemUom,
    deleted:this.itemlines[i].deleted,
    quotationId:this.quotation.id,
    rfqNumber:this.quotation.rfqNumber,
    currency:this.quotation.currency,
    itemNameToDisplay:"",
    itemVendors:this.Testvendors,
    createdDate:this.itemlines[i].createdDate,
    createdBy:this.itemlines[i].createdBy,
    lastModifiedDate:this.itemlines[i].lastModifiedDate,
    lastModifiedBy:this.itemlines[i].lastModifiedBy,
    prId:this.itemlines[i].prId ,// add by Aftab
    department:this.itemlines[i].departmentName,
    departmentId:this.itemlines[i].departmentId
   
    })
  }
}
else
{
  this.quotation.quotationItems.push({
    id:this.itemlines[i].id,
    itemId:this.itemlines[i].itemId,
    quantity:this.itemlines[i].quantity,
    receivedDate:this.itemlines[i].receivedDate,
    remarks:this.itemlines[i].Remarks,
    prNumber:this.itemlines[i].prNumber,
    prLocation:this.itemlines[i].prLocationId,
    prLocationName:this.itemlines[i].prLocationName,
    itemName:this.itemlines[i].itemName,
    itemDescription:this.itemlines[i].itemDescription,
    itemUom:this.itemlines[i].itemUom,
    deleted:this.itemlines[i].deleted,
    quotationId:this.quotation.id,
    rfqNumber:this.quotation.rfqNumber,
    currency:this.quotation.currency,
    itemNameToDisplay:"",
    itemVendors:this.Testvendors,
    createdDate:this.itemlines[i].createdDate,
    createdBy:this.itemlines[i].createdBy,
    lastModifiedDate:this.itemlines[i].lastModifiedDate,
    lastModifiedBy:this.itemlines[i].lastModifiedBy,
    prId:this.itemlines[i].prId ,// add by Aftab
    department:this.itemlines[i].departmentName,
    departmentId:this.itemlines[i].departmentId
   
    })
}



    //this.quotation.quotationItems[i].itemVendors[i]=new itemVendors()
   // this.itemlines[i].supplier.map((data:any,index,any)=>{
    //  this.quotation.quotationItems[i].itemVendors[index].vendorId=10;
    //  this.quotation.quotationItems[i].itemVendors[index].itemId=100;

  //  })
}
this.checkforlines=false;

for(let p=0;p<this.quotation.quotationItems.length;p++)
{

  this.checkforlines=true;
  if(this.quotation.quotationItems[p].quantity==undefined || this.quotation.quotationItems[p].quantity<=0)
  {
    this.showErrorquantity();
    return;
  }

  let rfq_days:any = new Date(this.quotation.rfqDate).getDate();
  let rfq_months:any = new Date(this.quotation.rfqDate).getMonth()+1;
  let rfq_year:any = new Date(this.quotation.rfqDate).getFullYear();
  if(rfq_months<10)
  {
    rfq_months="0".toString()+rfq_months.toString();
  }
  if(rfq_days<10)
  {
    rfq_days="0".toString()+rfq_days.toString();
  }
  this.quotation.rfqDate=rfq_year+"-"+rfq_months+"-"+rfq_days;

  let ReceivedDT:any=this.quotation.quotationItems[p].receivedDate;
  let Rdays: any = new Date(ReceivedDT).getDate();
  let Rmonths: any = new Date(ReceivedDT).getMonth() + 1;
  let Ryear: any = new Date(ReceivedDT).getFullYear();
  let OnlyReceivedDT: any = ReceivedDT !== undefined ? (Ryear + '-' + (Rmonths.toString().length == 1 ? "0" + Rmonths : Rmonths) + '-' + (Rdays.toString().length == 1 ? "0" + Rdays : Rdays)) : ""

  let BidCloseDT:any=this.quotation.bidCloseDate;
  let BCdays: any = new Date(BidCloseDT).getDate();
  let BCmonths: any = new Date(BidCloseDT).getMonth() + 1;
  let BCyear: any = new Date(BidCloseDT).getFullYear();
  let OnlyBidCloseDT: any = BidCloseDT !== undefined ? (BCyear + '-' + (BCmonths.toString().length == 1 ? "0" + BCmonths : BCmonths) + '-' + (BCdays.toString().length == 1 ? "0" + BCdays : BCdays)) : ""
 if(OnlyReceivedDT < OnlyBidCloseDT && this.quotation.quotationItems[p].deleted==undefined )
  {
    this.showErrorReceivedate();
    return;
  }
}

if(this.checkforlines==false)
{
  this.showErrorlineitems();
  return;
}
this.checkforlines=false
if(this.editMode)
{
  for(let i=0;i<this.quotation.quotationPrs.length;i++)
  {
    let prs=this.testPrs.filter(x=>x.prId==this.quotation.quotationPrs[i].prId);
    if(prs.length==0)
    {
      this.testPrs.push({
        id:this.quotation.quotationPrs[i].id,
        quotationId:this.quotation.quotationPrs[i].quotationId,
        quotationNumber:this.quotation.quotationPrs[i].quotationNumber,
        prNumber:this.quotation.quotationPrs[i].prNumber,
        prId:this.quotation.quotationPrs[i].prId,
        prLocationId:this.quotation.quotationPrs[i].prLocationId,
        createdDate:this.quotation.quotationPrs[i].createdDate,
        createdBy:this.quotation.quotationPrs[i].createdBy,
        lastModifiedDate:this.quotation.quotationPrs[i].lastModifiedDate,
        lastModifiedBy:this.quotation.quotationPrs[i].lastModifiedBy,
        deleted:true
      });
    }
  }
}
this.quotation.quotationPrs=this.testPrs;
this.quotation.locationId=3;
if(type=='save')
{
  this.quotation.submitted=false;
}
else if(type=='submit')
{
  this.quotation.submitted=true;
  
}
else if(type=='qa')
{
  this.quotation.createQa=true;
  
}
if(this.quotation.bidType=="Close")
{
  if(this.quotation.quotationItems.length>0)
  {
    for(let m=0;m<this.quotation.quotationItems.length;m++)
    {
     if(this.quotation.quotationItems[m].deleted!=true)
     {
     if(this.quotation.quotationItems[m].itemVendors.length==0)
     {
      this.showErrorSupplier();
        return;
     }
    }
    }
  }
}


if(this.addMode){
  this.quotation.createdBy=this.RetloginDetails.username;this.quotation.lastModifiedBy=this.RetloginDetails.username
  }
 else if(!this.addMode){
  this.quotation.lastModifiedBy=this.RetloginDetails.username
  }
 

  this.showloader=true;
  this.httpService.Insert('/procure-ws/quotation/save', this.quotation,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      if (res!=undefined && res.id>0) {
      if(type=='qa')
      {
      this.showloader=false;
      this.showSuccessQA();
      if(this.addMode)
       this.router.navigate(['/main/quotation-analysis/action', 'view',res.id]);
       else
      this.router.navigate(['/main/quotation-analysis/list']);
      }
      else
      {
       this.showloader=false;
       this.showSuccess();
       if(this.addMode)
       this.router.navigate(['/main/request-quatation/action', 'view',res.id]);
       else
       this.router.navigate(['/main/request-quatation/list']);
      }
       
      } else {
       this.showloader=false;
       this.showAlert(res.errorMessage);
        //alert(res.errorMessage);
      }
    }
    },
    (error) => {
      this.showloader=false;
      this.showAlert(error);
    },
    () => {}
  );
}
showSuccess() {
  this.toastService.addSingle(
    'success',
    'Success',
    'RFQ save successfully!'
  );
}
showSuccessQA() {
  this.toastService.addSingle(
    'success',
    'Success',
    'QA save successfully!'
  );
}
showError() {
  this.toastService.addSingle(
    'error',
    'Error',
    'Error occured while saving Quotation!'
  );
}
showAlert(AlertMSG: string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}
showErrorSubsidiary()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please select Subsidiary!'
  );
}
showErrorrfqDate()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please enter RFQ Date!'
  );
}
showErrorquotationPrs()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please select PR Number!'
  );
}

showErrorcurrency()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please select Currency!'
  );
}
showErrorexchangeRate()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please enter Exchange Rate!'
  );
}

showErrorcreator()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please select Creator!'
  );
}
showErrordateequal()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Bid Open and Bid Close Date & Time must be different!'
  );
}

showErrordatevalidation()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Bid Open Date & Time must be smaller than Bid Close Date & Time!'
  );
}

showErrordatevalidationRFQ()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Bid Open Date & Time must be greater than RFQ Date & Time!'
  );
}

showErrorbidopen()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please enter Bid Open Date & Time!'
  );
}
showErrorbidclose()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please enter Bid Close Date & Time!'
  );
}

showErrorquantity()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please enter Item Quantity!'
  );
}

showErrorlineitems()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please add atleast one Item!'
  );
}

showErrorReceivedate()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Receive Date must be greater than Bid Close Date & Time!'
  );
}


showErrorReceivedateblank()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please input Receive Date in line'
  );
}
showErrorSupplier()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please select Supplier!'
  );
}
SentMailError()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Mail Not Sent!'
  );
}

SentMail() {
  this.toastService.addSingle(
    'success',
    'Success',
    'Mail Sent Successfully!'
  );
}

showErrorbidtype()
{
  this.toastService.addSingle(
    'error',
    'Error',
    'Please select Bid Type!'
  );
}


clearQuotation()
{
  this.router.navigate(['/main/request-quatation/list']);
  // if(this.editMode){
  //   this.router.navigate(['/main/request-quatation/list']);
  // }
  // if(this.viewMode){
  //   this.router.navigate(['/main/request-quatation/list']);
  // }
  // else{
  //   location.reload();
  // }
}

GetQuotationbyId() {
  this.quotationprCopy=[];
  this.itemlines=[];
  this.quotation.quotationVendors=[];
  this.httpService
    .GetById('/procure-ws/quotation/get?id=' + this.quotationId, this.quotationId,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
     
      if(res.errorMessage!="")
      {
        this.showAlert(res.errorMessage);
      }

      this.GetSubsideryList();
      this.All_CurrencyList();

      this.enadissubmit=false;
      this.quotation = res;
      this.GetDepartmentList_edit_header(this.quotation.departmentId);
     // this.GetDepartmentList_edit_line();
      this.quotation.quotationItems.sort((a:any,b:any) => a.id - b.id);
      if(this.quotation.bidType=="Close")
      {
          this.isdisablebidtype=true;
      }
      
     
      //this.quotation.submitted=true;
      if(this.quotation.status=='Submitted')
      {

        this.isdisableaftersubmit=true;
        this.enadisclose=false;
        this.enadiscreateQA=false;
        if(this.quotation.bidType=="Open")
        {
          
         this.enadissendnotification=false;
         this.enadissendmail=true;
         
        }
        else if(this.quotation.bidType=="Close")
        {
         
         this.enadissendnotification=true;
         this.enadissendmail=false;
   
        }
      }
      else if(this.quotation.status=='QA Created')
      {
     
        this.enadiscreateQA=true;
        this.isdisableaftersubmit=false;
        this.enadissubmit=true;

      }
      else
      {
        this.isdisableaftersubmit=false;
      }

      if(this.quotation.bidType=="Close")
      {
        this.dissupplier=false;
      }
      else
      {
        this.dissupplier=true;
      }
      this.enadisbutton();
      this.quotation.rfqDate=this.quotation.rfqDate!=null?new Date(this.quotation.rfqDate):"";
      this.quotation.bidOpenDate=this.quotation.bidOpenDate!=null?new Date(this.quotation.bidOpenDate):"";
      this.quotation.bidCloseDate=this.quotation.bidCloseDate!=null?new Date(this.quotation.bidCloseDate):"";
      
      

      this.loaddetails();
      //this.LoadsupplierbySubsidiaryId();

  
      setTimeout(() => {this.SelectPRS()},600);
    

      setTimeout(() => {this.LoadsupplierbySubsidiaryId()},700);

      // setTimeout(() => {
      //   this.GetPRList();
       
      //   this.LoadsupplierbySubsidiaryId();
       
      // }, 200);
      // setTimeout(() => {
      //   this.SelectPRS();
        
      // }, 1000);

      setTimeout(() => {
          this.loadsupplier();
      }, 1000);

       this.LoadHistory();


      if(this.quotation.bidOpenDate=="" && this.quotation.bidCloseDate=="")
      {

      for(let i=0;i<this.quotation.quotationPrs.length;i++)
      {
        this.quotationprCopy.push({
          "id":this.quotation.quotationPrs[i].prId})
      }
        this.loaditem(0);
      }
      /// this.quotation.creator=Number(this.quotation.creator);
    }
    });
    //this.LoadsupplierbySubsidiaryId();


   
   
}

SelectPRS()
{

  if(this.quotation.status=="Submitted" || this.quotation.status=="QA Created" )
  {
    for(let i=0;i<this.quotation.quotationPrs.length;i++)
        {
          this.PRList.push({id:this.quotation.quotationPrs[i].prId,name:this.quotation.quotationPrs[i].prNumber});
          this.prNumberafterSubmit=this.prNumberafterSubmit+this.quotation.quotationPrs[i].prNumber + ",";
        }
        this.prNumberafterSubmit = this.prNumberafterSubmit.substring(0, this.prNumberafterSubmit.length-1);
        this.quotation.prNumberafterSubmit=this.prNumberafterSubmit;
  }
  

       
        


 
  if (
    this.quotation.quotationPrs &&
    this.quotation.quotationPrs.length > 0
  ) {
  //  if (this.viewMode) {
    //  var rolelist = this.quotation.quotationPrs.map(
    //    (x) => x.prNumber
    //  );
    // // this.role = rolelist.join(',');
    //} else {
      let copiedValue = JSON.parse(
        JSON.stringify(this.quotation.quotationPrs)
      );
      //this.supplier.supplierAccess.supplierRoles = [];
      this.quotationprCopy=[];
      copiedValue.forEach((element: any) => {
        let item = this.PRList.find(
          (o) => o.id == element.prId
        );
        if (item) {
          let role = new quotationPrs();
          role.id=element.prId;
          role.name = item.name;
          //role.deleted=element.deleted;
          
          
          //role.roleName = item.roleName;
          //this.supplier.supplierAccess.supplierRoles?.push(role);
          this.quotationprCopy?.push(role);
        }
      });
   // }
  }
}

SelectSuppliers()
{
for(let i=0;i<this.quotation.quotationItems.length;i++)
{
  if(this.quotation.quotationItems[i].itemVendors!=undefined)
  {
  for(let j=0;j<this.quotation.quotationItems[i].itemVendors.length;j++)
  {
    if (
      this.quotation.quotationItems[i].itemVendors &&
      this.quotation.quotationItems[i].itemVendors.length > 0
    ) {
      if (this.viewMode) {
        var rolelist = this.quotation.quotationItems[i].itemVendors.map(
          (x) => x.vendorId
        );
       // this.role = rolelist.join(',');
      } else {
        let copiedValue = JSON.parse(
          JSON.stringify(this.quotation.quotationItems[i].itemVendors[j])
        );
        //this.supplier.supplierAccess.supplierRoles = [];
        this.supplierCopy=[];
        copiedValue.forEach((element: any) => {
          let item = this.vendorlist.find(
            (o) => o.vendorId == element.vendorId
          );
          if (item) {
            let role = new itemVendors();
           // role.vendorId = item.vendorId;
            role.deleted=item.deleted;
            role.vendorName = item.vendorName;
            //this.supplier.supplierAccess.supplierRoles?.push(role);
            this.supplierCopy?.push(role);
          }
        });
      }
    } 
  }
}
 
}

}
loadsupplier()
{
  for(let i=0;i<this.quotation.quotationItems.length;i++)
      {
        this.Testvendors=[];

        if(this.quotation.quotationItems[i].itemVendors!=undefined)
        {
          for(let j=0;j<this.quotation.quotationItems[i].itemVendors.length;j++)
        {
          for(let k=0;k<this.vendorlist.length;k++)
          {
            if(this.vendorlist[k].vendorId==this.quotation.quotationItems[i].itemVendors[j].vendorId)
         {
            this.Testvendors.push({
            //id:this.quotation.quotationItems[i].itemVendors[j].id,  
            vendorId:this.vendorlist[k].vendorId,
            vendorName:this.vendorlist[k].vendorName,
            
            //itemId:this.itemlines[i].itemId,
            //deleted:this.quotation.quotationItems[i].itemVendors[j].deleted,
           // vendorName:this.quotation.quotationItems[i].itemVendors[j].vendorName

          });
        }
        }
        }
        }
        

      this.itemlines.push({
          id:this.quotation.quotationItems[i].id,
          itemId:this.quotation.quotationItems[i].itemId,
          quantity:this.quotation.quotationItems[i].quantity,
          remainedQuantity:this.quotation.quotationItems[i].remainedQuantity,
          receivedDate:this.quotation.quotationItems[i].receivedDate!=null?new Date(this.quotation.quotationItems[i].receivedDate):"",
          Remarks:this.quotation.quotationItems[i].remarks,
          prNumber:this.quotation.quotationItems[i].prNumber,
          prLocationId:this.quotation.quotationItems[i].prLocation,
          itemName:this.quotation.quotationItems[i].itemName,
          itemDescription:this.quotation.quotationItems[i].itemDescription,
          itemUom:this.quotation.quotationItems[i].itemUom,
          supplier:this.Testvendors,
          Suppliers:this.Testvendors,
          prLocationName:this.quotation.quotationItems[i].prLocationName,
          prId:this.quotation.quotationItems[i].prId,
          departmentName:this.quotation.quotationItems[i].departmentName,
          departmentId:this.quotation.quotationItems[i].departmentId
          //prLocationName:this.quotation.quotationItems[i].prLocation.toString
        
          })
          //this.quotation.quotationItems[i].itemVendors[i]=new itemVendors()
        // this.itemlines[i].supplier.map((data:any,index,any)=>{
          //  this.quotation.quotationItems[i].itemVendors[index].vendorId=10;
          //  this.quotation.quotationItems[i].itemVendors[index].itemId=100;

        //  })
      }
}
LoadHistory() {
  if (this.QuotationHistoryList.length == 0)
    this.httpService.GetAll('/procure-ws/quotation/get/history?rfqNumber='+this.quotation.rfqNumber+'&pageSize=100',this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        this.QuotationHistoryList = res;
      }
      });
}
enadisbutton()
{
  if(this.addMode)
  {
     if(this.quotation.bidType=="Open")
     {
      for(let i=0;i<this.itemlines.length;i++)
      {
        this.itemlines[i].Suppliers=[];
      }
     
      if(this.quotation.status=='Submitted')
      {
       this.enadissendnotification=false;
       this.enadissendmail=true;
      }
      this.dissupplier=true;
     }
     else if(this.quotation.bidType=="Close")
     {
      if(this.quotation.status=='Submitted')
      {
       this.enadissendnotification=true;
       this.enadissendmail=false;
      }
      this.dissupplier=false;
     }
  }
  else if(this.editMode)
  {
    if(this.quotation.bidType=="Open")
    {
     for(let i=0;i<this.itemlines.length;i++)
     {
       this.itemlines[i].deleted=true;
       
     }
     for(let i=0;i<this.itemlines.length;i++)
     {
        if(this.itemlines[i].Suppliers!=undefined)
           {
             for(let j=0;j<this.itemlines[i].Suppliers.length;j++)
                {
                   this.itemlines[i].Suppliers[j].deleted=true;
                                        
                    
                }
            }
     }
     for(let j=0;j<this.quotation.quotationVendors.length;j++)
     {
      this.quotation.quotationVendors[j].deleted=true;
     }
    
     this.quotationprCopy=[];
     if(this.quotation.status=='Submitted')
     {
      this.enadissendnotification=false;
      this.enadissendmail=true;
     }
     this.dissupplier=true;
    } 
    else if(this.quotation.bidType=="Close")
    {
      for(let i=0;i<this.itemlines.length;i++)
     {
       this.itemlines[i].deleted=true;
       
     }
     this.quotationprCopy=[];
     if(this.quotation.status=='Submitted')
     {
      this.enadissendnotification=true;
      this.enadissendmail=false;
     }
     this.dissupplier=false;
    }
  }

    

}
SendMail()
{
  this.httpService
  .GetById('/procure-ws/quotation/send-mail?id=' + this.quotation.id, this.quotation.id,this.RetloginDetails.token)
  .subscribe((res) => {
    if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
   if(res)
   {
      this.SentMail();
   }
   else
   {
    this.SentMailError();
   }
  }
  },
  (error) => {
   this.showAlert(error);
   
  });


}

//Added by Aftab
// fnRequesterList(SubID:any)
// {
//   this.httpService.GetById('/employee/get-employee-by-subsidiary?subsidiaryId=' + SubID, SubID)
//     .subscribe((res) => {
//       if (res != undefined) {
//         this.EmployeeList=[];
//       this.EmployeeList = res;
//       }
//     },
//     (error) => {
//       this.showAlert(error);
//     },
//     ()=>{
//       if(this.addMode)
//       this.quotation.creator=this.loginId;
//     }
//     );
// }

Sendindividualmail(index:number)
{
    if(this.quotation.quotationVendors[index].email!=null)
    {
      this.httpService
      .GetById('/procure-ws/quotation/send-mail-to-rfq-supplier?mailId=' + this.quotation.quotationVendors[index].email, this.quotation.quotationVendors[index].email,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
       if(res)
       {
          this.SentMail();
       }
       else
       {
        this.SentMailError();
       }
      }
      },
      (error) => {
       this.showAlert(error);
       
      });
    }
    else
    {
      this.SentMailError();
    }

}
getFiscalDateRanges() {
  let Subsidiary=this.quotation.subsidiaryId;
  let InputDate=this.quotation.rfqDate;
  if((Subsidiary != undefined || Subsidiary != "") && (InputDate!= undefined || InputDate!= null)) {

  this.httpService
  .GetById('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId=' + Subsidiary, Subsidiary,this.RetloginDetails.token)
  .subscribe((res) => {
    if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
    if (res) {
      this.fiscalCalenderDTLS=res;
      if(this.fiscalCalenderDTLS != null && this.fiscalCalenderDTLS.fiscalCalanderAccounting.length >0)
      {
      let AllowMonths: any = "Allow Months: ";
      let IsDateAvailable:boolean = false;
    
      var Dummymonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    
      let PRdays: any = new Date(InputDate).getDate();
      let PRmonths: any = new Date(InputDate).getMonth() + 1;
      let PRyear: any = new Date(InputDate).getFullYear();
      let CompareDate: any = InputDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""
    
      for (let x = 0; x < this.fiscalCalenderDTLS.fiscalCalanderAccounting.length; x++) {
        AllowMonths += this.fiscalCalenderDTLS.fiscalCalanderAccounting.length == (x + 1) ? this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month : this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month + " , "
    
        if (CompareDate >= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].fromDate && CompareDate <= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].toDate && this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month == Dummymonths[PRmonths - 1] + "-" + PRyear) {
          IsDateAvailable = true;
        }
      }
    
      if (IsDateAvailable == false) {
        this.showAlert("Selected Date is Not available in Fiscal Calendar ! " + AllowMonths);
        this.quotation.rfqDate = {};
      }
    }
    else
          {
            this.showAlert("Selected Date is Not available in Fiscal Calendar !");
            this.quotation.rfqDate = {};
          }
    } else {
      this.showAlert("No Data Found");
    }
  }
  },
    (error) => {
      this.toastService.addSingle(
        'error',
        'Error',
         error
      );
    }

  );

}
}

DownloadReport(rfqNumber:any){
  this.showloader=true;
  //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
this.rfqOpenReport.exportPdf(rfqNumber);  
this.showloader=false;
}
DownloadCloseBidReport(rfqNumber:any,supId:any){
  //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
this.rfqClose.exportPdf(rfqNumber,supId);  

}
loadrequestor()
{

  this.httpService.GetAll('/masters-ws/employee/get?id='+this.loginId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.quotation.creator=res.fullName
     
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}

GetAllProjectList(subsidiaryId:any)
{
  this.httpService.GetById('/masters-ws/project/get-by-subsidiary-id?subsidiaryId=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.ProjectList=[];
      for(let x=0;x<res.length;x++)
      {
        this.ProjectList.push({
          "id":res[x].id,
          "name":res[x].name
        })
      }
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );
//  var obj={
//    filters:{   
//    },
//    pageNumber: 0,
//    pageSize: 1000,
//    sortColumn: "p.id",
//    sortOrder: "asc"
// }
// this.httpService.Insert("/project/get/all",obj)
// .subscribe(res => {
//  this.ProjectList=res.list;
//  });
}
Loadpr()
{

  this.PRList=[];
  this.quotationprCopy=[];
  this.GetPRList();
  this.chklineasdelete();

}
reloadProjectList()
{
  this.ProjectList=[];
  this.GetAllProjectList(this.quotation.subsidiaryId);
  this.PRList=[];
  this.quotationprCopy=[];
  this.chklineasdelete();
}

departmentchecking()
{
  let department:any;
  let isdepartment:boolean=false;
  debugger
  department=this.itemlines[0].departmentName;
  for(let i=0;i<this.itemlines.length;i++)
  { 
    if(department==this.itemlines[i].departmentName)
    {
       isdepartment=false;
    }
    else
    {
       isdepartment=true;
       break;
    }
  }
  if(isdepartment)
  {
    this.quotation.department="All";
    this.quotation.departmentId=0;
  }
  else
  {
    this.quotation.department=this.itemlines[0].departmentName;
    this.quotation.departmentId=this.itemlines[0].departmentId;
  }
  isdepartment=false;
}

chklineasdelete()
{
  for(let x=0;x<this.quotationprCopy.length;x++)
  {
    this.quotationprCopy[x].deleted=true;
  }
  for(let x=0;x<this.itemlines.length;x++)
  {
      this.itemlines[x].deleted=true;

      for(let i=0;i<this.itemlines[x].supplier.length;i++)
      {
          for(let j=0;j<this.quotation.quotationVendors.length;j++)
          {
            if(this.quotation.quotationVendors[j].vendorId==this.itemlines[x].supplier[i].vendorId)
            {
              this.quotation.quotationVendors[j].deleted=true;
            }
          }
      }   
     
  }
}
GetDepartmentList_edit_header(id:any) {

  if(id==0)
  {
    this.quotation.department= "All";
  }
  else
  {
    this.httpService.GetById("/masters-ws/department/get?id="+id, id, this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
       else if(res.errorMessage){
        this.showAlert(res.errorMessage)
       }else{
       
        this.quotation.department= res.departmentName;
      }
    },
    error => {
     this.showAlert(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    });
  }
  
  
  
  }
  GetDepartmentList_edit_line() {
    for(let i=0;i<this.quotation.quotationItems.length;i++)
    {
      
      this.httpService.GetById("/masters-ws/department/get?id="+this.quotation.quotationItems[i].departmentId, this.quotation.quotationItems[i].departmentId, this.RetloginDetails.token)
      .subscribe(res => {
        if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
         else if(res.errorMessage){
          this.showAlert(res.errorMessage)
         }else{
         
          this.quotation.quotationItems[i].departmentName= res.departmentName;
        }
      },
      error => {
       this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
    }
  
  
  
  }



  
}
