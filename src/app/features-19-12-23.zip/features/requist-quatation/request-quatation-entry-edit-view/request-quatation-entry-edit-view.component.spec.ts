import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestQuatationEntryEditViewComponent } from './request-quatation-entry-edit-view.component';

describe('RequestQuatationEntryEditViewComponent', () => {
  let component: RequestQuatationEntryEditViewComponent;
  let fixture: ComponentFixture<RequestQuatationEntryEditViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestQuatationEntryEditViewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RequestQuatationEntryEditViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
