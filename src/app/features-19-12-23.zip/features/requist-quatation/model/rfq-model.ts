export class quotation {
    id?: number;
   /* rfqNumber?: any;
    bidOpenDate?: any;
    bidCloseDate?: any;
    bidType?: string;
    currency?:string;
    quotationPrs?: number;
    subsidiaryId?: number;
    rfqDate?: any;*/
    rfqNumber?:string;
    subsidiaryId?:number;
    rfqDate?:any;
    memoNotes?:string;
    bidType?:string;
    bidOpenDate?:any;
    bidCloseDate?:any;
    locationId?:number;
    status?:string;
    netSuiteId?:string;
    createdDate?: Date;
    createdBy?: string;
    creator?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    currency?:string;
    quotationPrs:quotationPrs[]=[];
    exchangeRate?:string;
    department?:string;
    departmentId?:number;
    subsidiaryAddress?:string;
    bidRecieveEmail?:string;
    subsidiaryName?:string;
    quotationVendors:quotationVendors[]=[];
    quotationItems:quotationItems[]=[];
    quotationInfos:quotationInfos[]=[];
    deleted?:boolean;
    submitted:boolean;
    createQa:boolean=false;
    prNumberafterSubmit:string;
    projectId?:number;
}
export class BaseSearch {
    filters?: Filter | {} = {};
    pageNumber?: number = 0;
    pageSize?: number = 0;
    sortColumn?: string = '';
    sortOrder?: string = '';
  }
  
  //this class holds the custom filter values at component level.
  export class Filter {
    subsidiary?: string = '';
    vendorname?: string = '';
    vendornumber?: string = '';
    vendortype?: string = '';
    pan?: string = '';
    active?: string = '';
  }

  export class itemVendors{

    id?: number;
    quotationId?: number;
    rfqNumber?: string;
    itemId?:number;
    vendorId?:any;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    vendorName?: string;
    deleted?: boolean;


  }

  export class quotationItems{
    id?:number;
    itemId:number;
    quantity:number;
    remainedQuantity?:number;
    receivedDate:any;
    remarks:string;
    prNumber?:any;
    prLocation?:number;
    prLocationName?:string;
    itemVendors:itemVendors[] = [];
    itemName?: string;
    itemDescription?:string;
    itemUom?:string;
    deleted?:boolean=false;
    quotationId?:number;
    rfqNumber?:string;
    currency?:string;
    itemNameToDisplay?:string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    prId?:any; // add by Aftab
    department?:string;
    departmentId?:number;
    departmentName?:number;
  }
  export class itemline{
    id?:number;
    prId?:number;
    prNumber:string;
    itemId:number;
    itemDescription?:string;
    quantity:number;
    remainedQuantity?:number;
    rate?:number;
    memo?:string;
    integratedId?:number;
    estimatedAmount?:number;
    receivedDate?:any;
    poNumber?:number;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    itemName?:string;
    itemUom?:string;
    departmentName?:any;
    departmentId?:number;
    accountId?:number;
    deleted?:boolean;
    supplier:itemVendors[]=[];
    Suppliers:any[]=[];
    prLocationName?:string;
    Remarks:string;
    prLocationId?:number;
  
  }


  export class quotationVendors{
        id?:number;
        quotationId?:number;
        rfqNumber?:string;
        vendorId?:number;
        contactName?:string;
        email?:string;
        memo?:string;
        createdDate?: Date;
        createdBy?: string;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        vendorName?:string;
        deleted?:boolean;
  }

  export class quotationPrs{
            id?: number;            
            quotationId?:number;
            quotationNumber?:string;
            prNumber?:any;
            prLocationId?:number;
            createdDate?: Date;
            createdBy?: string;
            lastModifiedDate?: Date;
            lastModifiedBy?: string;
            deleted?:boolean;
            name?:any;
            prId?:any;
            //isDisabled?: boolean;

  }

 
  export class suppliers{
    id?: number;            
    supplier?:string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted?:boolean;
}
export class generalinfo{
  remarks:string;
  deleted:boolean;
}

export class quotationInfos{
  id?:number;
  remarks:string;
  deleted=false;
}

  // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: requestquotation | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class requestquotation {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}
