import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RequestQuatationListComponent } from './request-quatation-list/request-quatation-list.component';
import { RequestQuatationEntryEditViewComponent } from './request-quatation-entry-edit-view/request-quatation-entry-edit-view.component';


const routes: Routes = [
  {
    path: '',
    component: RequestQuatationListComponent,
  },
  {
    path: 'list',
    component: RequestQuatationListComponent,
  },
  {
    path:'action/:action/:id',
    component: RequestQuatationEntryEditViewComponent,
  },
  {
    path: 'action/:action',
    component: RequestQuatationEntryEditViewComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RequistQuatationRoutingModule { }
