export class manageIntegration{
    name:string;
    intigrationWith:string;
    subsidiaryId?:number;
    accountId:string;
    description:string;
    startDate:any;
    endDate:any;
    connection:string;
    tbaTokenSecret:string;
    tbaTokenId:string;
    tbaConsumerSecret:string;
    tbaConsumerKey:string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    subsidiaryName: string;
    deleted:boolean;
    taxCode:boolean;
    item:boolean;
    employeeCode:boolean;
    advancePayment:boolean;
    companyMaster:boolean;
    supplierMaster:boolean;
    apInvoice:boolean;
    makePayment:boolean;
    debitNote:boolean;
    manageIntegrationSubsidiaries:manageIntegrationSubsidiaries[]=[];
    wsUrl:string;
    systemId:any;
}

export class BaseSearch {
    filters?: Filter | {} = {};
    pageNumber?: number = 0;
    pageSize?: number = 0;
    sortColumn?: string = '';
    sortOrder?: string = '';
  }
  
  //this class holds the custom filter values at component level.
  export class Filter {
    subsidiary?: string = '';
    vendorname?: string = '';
    vendornumber?: string = '';
    vendortype?: string = '';
    pan?: string = '';
    active?: string = '';
  }

  export class manageIntegrationSubsidiaries
    {
        subsidiaryId?:number
        subsidiaryName?:string
        isDeleted?:boolean;
    }

    // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: manageintegrationFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class manageintegrationFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}