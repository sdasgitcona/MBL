import { Component, OnInit,LOCALE_ID, Inject } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { PrimeNGConfig } from 'primeng/api';
import { ThemeService } from 'src/app/core/services/theme.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ActivatedRoute,Router } from '@angular/router';
import { manageIntegration,BaseSearch,BaseSearchPdf } from '../model/manage-integration-module';
import * as FileSaver from 'file-saver';
import {formatDate } from '@angular/common';
@Component({
  selector: 'app-manage-integration-list',
  templateUrl: './manage-integration-list.component.html',
  styleUrls: ['./manage-integration-list.component.scss']
})
export class ManageIntegrationListComponent implements OnInit {
  manageIntegration:manageIntegration= new manageIntegration();
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  RetRoleDetails:any;
  columns: any[];
  ManageIntegrationList: manageIntegration[]=[];
  IntegrationWith:any;
  totalRecords: number = 0;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  MIPrint: any[] = [];
  loading: boolean = false;
  newevent:any;
  RetloginDetails:any;
  selectedManageIntegration: manageIntegration = new manageIntegration();
  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private activatedRoute: ActivatedRoute,
    private toastService: ToastService,@Inject(LOCALE_ID) public locale: string) {

      this.IntegrationWith = [{id:'NetSuite',value:'NetSuite'},{id:'Oracle EBS',value:'Oracle EBS'},{id:'SAP',value:'SAP'} ];
   }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;

   
    this.resetBaseSearch();
    this.Getfilterlist();
    this.columns = [
     
      { field: 'Id', header: 'Internal ID' },
      { field: 'Integration with', header: 'Integration with' },
      { field: 'Description', header: 'Description' },
      { field: 'Account ID', header: 'Account ID' },
      { field: 'Start Date', header: 'Start Date' },
      { field: 'End Date', header: 'End Date' },

    ];
   this.exportColumns = this.columns.map(col => ({
     title: col.header,
     dataKey: col.field
   }));
  }
  navigateToAddViewEdit(
    action: string,
  ) {
    let locationId = null;
    this.router.navigate(['/main/manage-integration/action', action]);
    console.log('Action is ' + action);
  }

  resetBaseSearch() {
    this.baseSearch.filters = {systemId:this.RetRoleDetails[0].accountId};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.MI_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
  }
  /*exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.manageIntegration);
            doc.save('RFQ.pdf');
        })
    })
}*/
findby(event: any){
  let startDate:any;
  let endDate:any;
 if(this.manageIntegration.startDate!=undefined)
 {
    let days:any = new Date(this.manageIntegration.startDate).getDate();
    let months:any = new Date(this.manageIntegration.startDate).getMonth()+1;
    let year:any = new Date(this.manageIntegration.startDate).getFullYear();
    startDate=year+"-"+months+"-"+days;

 }
 if(this.manageIntegration.endDate!=undefined)
 {
    let days_:any = new Date(this.manageIntegration.endDate).getDate();
    let months_:any = new Date(this.manageIntegration.endDate).getMonth()+1;
    let year_:any = new Date(this.manageIntegration.endDate).getFullYear();
    endDate=year_+"-"+months_+"-"+days_;

 }

  this.baseSearch.filters={
    intigrationWith:this.manageIntegration.intigrationWith,
    startDate:startDate,
    endDate:endDate,
    systemId:this.manageIntegration.accountId
    
}
 this.loadselectedMIList(this.newevent);
}

loadselectedMIList(event:any)
{
  try {
    this.newevent=event
    this.loading = true;
    this.baseSearch.pageNumber = event.first / event.rows;
    this.baseSearch.pageSize = event.rows;
    this.baseSearch.sortColumn = event.sortField
    ?  event.sortField
    : GlobalConstants.MI_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder =
      event.sortOrder == -1
        ? GlobalConstants.ASCENDING
        : GlobalConstants.DESCENDING;
       this.HttpService.Insert('/integration-ws/intigration/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { 
         this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { 
         this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
       {
        debugger
        if (res && res.list!=null) {
          this.ManageIntegrationList = res.list;
          this.totalRecords = res.totalRecords;
        } else {
          this.ManageIntegrationList = [];
          this.totalRecords = 0;
         }
        this.loading = false;
      }
      },
      (error) => {
        console.log(error);
        this.loading = false;
      }
    );
  } catch (err) {
    console.log(err);
  }
}

showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}

Reset()
{
  this.manageIntegration.intigrationWith ="";
  this.manageIntegration.startDate="";
  this.manageIntegration.endDate="";
  this.baseSearch.filters = {};
  this.loadselectedMIList(this.newevent);
}
    /***((Export Excel)) */
    generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.MI_TABLE_SORT_COLUMN;
     // this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
  
      this.HttpService.Insert('/integration-ws/intigration/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.MIPrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {

                if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){ 

                  this.MIPrint.push({
                    'Id': RetData[i].id,    
                    'Integration with':RetData[i].intigrationWith, 
                    'Description':  RetData[i].description,
                    'Account ID': RetData[i].accountId,
                    'Start Date': formatDate(RetData[i].startDate, 'dd-MM-yyyy' ,this.locale),
                    'End Date':  formatDate(RetData[i].endDate, 'dd-MM-yyyy' ,this.locale),  
               
                    // 
                    
                });
              }
                else{
                  this.MIPrint.push({
                    'Internal Id': RetData[i].id,    
                    'Integration with':RetData[i].intigrationWith, 
                    'Description':  RetData[i].description,
                    'Account ID': RetData[i].accountId,
                    'Start Date': formatDate(RetData[i].startDate, 'dd-MM-yyyy' ,this.locale),
                    'End Date':  formatDate(RetData[i].endDate, 'dd-MM-yyyy' ,this.locale),  
                  });
                }
  
              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    exportPdf() {
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          //this.= this.employeeExport;
          //this.employeelist=[];
          (doc as any).autoTable(this.exportColumns, this.MIPrint);
          doc.save('manage-integration.pdf');
        })
      })
    }
  
  //End PDF
  
  //Start Excel
  exportExcel() {
   
    this.generatePDFData('');
  
   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.MIPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.MIPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'manage-integration');
         //  this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
  //End Excel 
    //List Export option End
  
     /********Export excel */

     Getfilterlist() {
      if(this.RetloginDetails.userType=='SUPERADMIN')
     // if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
      {
        if(localStorage.getItem("MIFilters") != null)
        {const LocDetails:any =localStorage.getItem("MIFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.manageIntegration.intigrationWith=searcheData.filters.intigrationWith;
        this.manageIntegration.startDate=searcheData.filters.startDate != undefined ? new Date(searcheData.filters.startDate ):undefined;
        this.manageIntegration.endDate=searcheData.filters.endDate != undefined ? new Date(searcheData.filters.endDate ):undefined;
        this.manageIntegration.accountId=searcheData.filters.accountId;
        this.loadselectedMIList(this.newevent);
        localStorage.removeItem("MIFilters");
        }
        else
       { this.resetBaseSearch();}
      }else if(this.RetloginDetails.userType=='ENDUSER'){
        if(localStorage.getItem("MIFilters") != null)
        {const LocDetails:any =localStorage.getItem("MIFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.manageIntegration.intigrationWith=searcheData.filters.intigrationWith;
        this.manageIntegration.startDate=searcheData.filters.startDate != undefined ? new Date(searcheData.filters.startDate ):undefined;
        this.manageIntegration.endDate=searcheData.filters.endDate != undefined ? new Date(searcheData.filters.endDate ):undefined;
        this.manageIntegration.accountId=searcheData.filters.accountId;
        this.loadselectedMIList(this.newevent);
        localStorage.removeItem("MIFilters");
        }
        else
       { this.resetBaseSearch();}
      }
    }
    editview(actionType:any,mainId:any)
    {
     if (localStorage.getItem("MIFilters") != null)
     {
       localStorage.removeItem("MIFilters");
     }
     localStorage.setItem("MIFilters", JSON.stringify(this.baseSearch));
     this.router.navigate(['/main/manage-integration/action', actionType, mainId]);
    }
    onRowSelect(event: any) {
      let miId = event.data.id;
      
      this.router.navigate(['/main/manage-integration/action/view', miId]);
    }
  
}
