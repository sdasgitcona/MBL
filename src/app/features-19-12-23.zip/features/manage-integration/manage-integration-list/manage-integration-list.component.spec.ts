import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageIntegrationListComponent } from './manage-integration-list.component';

describe('ManageIntegrationListComponent', () => {
  let component: ManageIntegrationListComponent;
  let fixture: ComponentFixture<ManageIntegrationListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageIntegrationListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManageIntegrationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
