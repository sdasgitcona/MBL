import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {  ManageIntegrationComponent } from './manage-integration/manage-integration.component';
import {  ManageIntegrationListComponent } from './manage-integration-list/manage-integration-list.component';
const routes: Routes = [
  {
    path: '',
    component: ManageIntegrationListComponent,
  },
  {
    path: 'list',
    component: ManageIntegrationListComponent,
  },
  {
    path: 'action/:action/:id',
    component: ManageIntegrationComponent,
  },
  {
    path: 'action/:action',
    component: ManageIntegrationComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageIntegrationRoutingModule { }
