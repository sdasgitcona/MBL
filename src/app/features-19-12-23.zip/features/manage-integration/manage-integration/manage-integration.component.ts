import { Component, OnInit } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { PrimeNGConfig } from 'primeng/api';
import { ThemeService } from 'src/app/core/services/theme.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ActivatedRoute,Router } from '@angular/router';
import { manageIntegration,BaseSearch,manageIntegrationSubsidiaries } from '../model/manage-integration-module';
import { accountSubsidiaries } from '../../accountcode/model/accountcode-model';
@Component({
  selector: 'app-manage-integration',
  templateUrl: './manage-integration.component.html',
  styleUrls: ['./manage-integration.component.scss']
})
export class ManageIntegrationComponent implements OnInit {
  totalpermisions: number = 0;
  manageIntegrationId: number;
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  AvailableOptions: any;
  checked: boolean;
  selectedIndex: any
  isReloadSub: boolean;
  adminrole: boolean;
  approverrole: boolean;
  venderrole: boolean;
  RetloginDetails:any;
  manageIntegration:manageIntegration= new manageIntegration();
  manageIntegrationlist:manageIntegration[]=[];
  department: any;
  IntegrationWith:any;
  Subsidiarylist:any;
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   isviewEditable:boolean=true;
   // For Role Base Access
   displaySetupDialog:boolean=false;
   subsidiriesCopy: accountSubsidiaries[] = [];
   RetRoleDetails:any;
  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private activatedRoute: ActivatedRoute,
    private toastService: ToastService,) { 

    this.IntegrationWith = [{id:'NetSuite',value:'NetSuite'},{id:'Oracle EBS',value:'Oracle EBS'},{id:'SAP',value:'SAP'} ];
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
  
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
   

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.manageIntegrationId = +params['id']; // (+) converts string 'id' to a number
            this.GetMIbyId();
            
          }
          this.assignMode(params['action']);       
          this.GetAllSubsidiaryList();
        } else {
          console.log('cannot get params');
        }
      },
      (error) => {
        console.log('add');
      }
    );
  }

  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;

      default:
        break;
    }
  }

  GetAllSubsidiaryList(){
    this.Subsidiarylist=[];

    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { 
        this.Subsidiarylist=res;
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({ "id": this.RetRoleDetails[0].subsidiaryId, "name": this.RetRoleDetails[0].subsidiaryName })
    }

    // this.HttpService.GetSendAll("/setup-ws/subsidiary/get/all",this.Subsidiarylist,this.RetloginDetails.token)
    // .subscribe(res => {
    //   if(res.status == 401)
    //    { 
    //      this.showAlert("Unauthorized Access !");
    //      this.router.navigate(['/login']);
    //    }
    //    else if(res.status == 404)
    //    { 
    //      this.showAlert("Wrong/Invalid Token!");
    //      this.router.navigate(['/login']);
    //    }
    //    else
    //    {
    //   this.Subsidiarylist=[];
    //   res.list.map((x: any, i: any) => {
    //     this.Subsidiarylist.push({ "subsidiaryId": x.id, "subsidiaryName": x.name })
    //   });
    // }
    // });
    // this.HttpService.GetAll("/setup-ws/subsidiary/get/all")
    // .subscribe(res => {
    //   this.Subsidiarylist=res.list;
    //   });
   }

   OpenDialogSetup()
   {
    this.displaySetupDialog=true;
   }
   oncancel()
   {
    this.displaySetupDialog=false;
   }
   onsavedialog()
   {
       if(this.manageIntegration.accountId==undefined || this.manageIntegration.accountId=="")
       {
       
        this.showAlert("Please input Account Id !");
        return;
       }
       if(this.manageIntegration.tbaTokenSecret==undefined || this.manageIntegration.tbaTokenSecret=="")
       {
        this.showAlert("Please input Token Serect !");
        return;
       }
       if(this.manageIntegration.tbaTokenId==undefined || this.manageIntegration.tbaTokenId=="")
       {
        this.showAlert("Please input Token Id !");
        return;
       }
       if(this.manageIntegration.tbaConsumerSecret==undefined || this.manageIntegration.tbaConsumerSecret=="")
       {
        this.showAlert("Please input Consumer Secret !");
        return;
       }
       if(this.manageIntegration.tbaConsumerKey==undefined || this.manageIntegration.tbaConsumerKey=="")
       {
        this.showAlert("Please input Consumer Key !");
        return;
       }
       if(this.manageIntegration.wsUrl==undefined || this.manageIntegration.wsUrl=="")
       {
        this.showAlert("Please input Soap Url!");
        return;
       }
       this.displaySetupDialog=false;

   }

   showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  onsave()
  {
    if(this.manageIntegration.intigrationWith==undefined)
       {
       
        this.showAlert("Please select Integration with!");
        return;
       }
       if(this.manageIntegration.startDate==undefined)
       {
       
        this.showAlert("Please input Start Date!");
        return;
       }
      debugger
       if(this.manageIntegration.subsidiaryId==undefined)
       {
       
        this.showAlert("Please input Subsidiary!");
        return;
       }
       this.manageIntegration.manageIntegrationSubsidiaries=[];
      // for(let i=0;i<this.subsidiriesCopy.length;i++)
       //{
        this.manageIntegration.manageIntegrationSubsidiaries.push({
          subsidiaryId:this.manageIntegration.subsidiaryId,
          isDeleted:false
          
        })
      // }

   /*   if (this.manageIntegration.manageIntegrationSubsidiaries && this.manageIntegration.manageIntegrationSubsidiaries.length > 0) {
        var output = this.manageIntegration.manageIntegrationSubsidiaries?.filter(
          (val, i) => {
            var t = !this.subsidiriesCopy.find(NewArrayobj => NewArrayobj.subsidiaryId == val.subsidiaryId)
            if (t == false) {
              val.deleted = false;
            } else {
              val.deleted = true;
              if (!val.subsidiaryId) {
                this.manageIntegration.manageIntegrationSubsidiaries?.splice(i, 1);
              }
            }
          }
        );
        var output1 = this.subsidiriesCopy.filter(
          val => !this.manageIntegration.manageIntegrationSubsidiaries?.find(myArrayobj => myArrayobj.subsidiaryId == val.subsidiaryId));
          output1.map(x => {
          this.manageIntegration.manageIntegrationSubsidiaries?.push({ subsidiaryId: x.subsidiaryId, subsidiaryName: x.subsidiaryName,deleted:x.deleted })
        })
      } 
      else {
        this.subsidiriesCopy.map((x, i) => {
          if(this.manageIntegration.manageIntegrationSubsidiaries){
            this.manageIntegration.manageIntegrationSubsidiaries.push({ subsidiaryId: x.subsidiaryId, subsidiaryName: x.subsidiaryName,deleted:x.deleted })
          }else{
            this.manageIntegration.manageIntegrationSubsidiaries=[];
            this.manageIntegration.manageIntegrationSubsidiaries.push({ subsidiaryId: x.subsidiaryId, subsidiaryName: x.subsidiaryName,deleted:x.deleted })
          }
        })
      }*/

      if(this.addMode){this.RetloginDetails
        this.manageIntegration.createdBy=this.RetloginDetails.username;this.manageIntegration.lastModifiedBy=this.RetloginDetails.username
        }
       else if(!this.addMode){
        this.manageIntegration.lastModifiedBy=this.RetloginDetails.username
        }
        
        this.manageIntegration.systemId=this.RetRoleDetails[0].accountId;

  this.manageIntegrationlist.push(this.manageIntegration);
    this.HttpService.Insert('/integration-ws/intigration/save', this.manageIntegrationlist,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { 
         this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { 
         this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
       {
        console.log(res);
        if (res && res[0].id > 0) {
          this.showSuccess();

          
          if(this.addMode){
            this.router.navigate(['/main/manage-integration/action', 'view',res[0].id]);
          } else {
            this.router.navigate(['/main/manage-integration/list']);
          }
          
         } else {
          this.showError();
         }
        }
      },
      (error) => {
        console.log('error-' + error);
      },
      () => {}
    );
  }

  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Manage Integration Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Manage Integration!'
    );
  }

  onconnect()
  {

  }

  GetMIbyId() {

    this.HttpService
      .GetById('/integration-ws/intigration/get?id=' + this.manageIntegrationId, this.manageIntegrationId,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
       { 
         this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { 
         this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
       {
        this.manageIntegration=res;

        this.manageIntegration.startDate=this.manageIntegration.startDate!=null?new Date(this.manageIntegration.startDate):"";
        this.manageIntegration.endDate=this.manageIntegration.endDate!=null?new Date(this.manageIntegration.endDate):"";
        this.GetAllSubsidiaryList();
        this.manageIntegration.subsidiaryId=this.manageIntegration.manageIntegrationSubsidiaries[0].subsidiaryId;


      //  setTimeout(() => {this.SelectSubsidiary();},1000);
        
       }


      });
      //this.LoadsupplierbySubsidiaryId();
      
     
  }

/* SelectSubsidiary()
{

 if (
    this.manageIntegration.manageIntegrationSubsidiaries &&
    this.manageIntegration.manageIntegrationSubsidiaries.length > 0
  ) {
  //  if (this.viewMode) {
    //  var rolelist = this.quotation.quotationPrs.map(
    //    (x) => x.prNumber
    //  );
    // // this.role = rolelist.join(',');
    //} else {
      let copiedValue = JSON.parse(
        JSON.stringify(this.manageIntegration.manageIntegrationSubsidiaries)
      );
      //this.supplier.supplierAccess.supplierRoles = [];
      this.subsidiriesCopy=[];
      copiedValue.forEach((element: any) => {
        let item = this.Subsidiarylist.find(
          (o:any) => o.subsidiaryId == element.subsidiaryId
        );
       if (item) {
           let role = new manageIntegrationSubsidiaries();
          role.subsidiaryId=element.subsidiaryId;
          role.subsidiaryName=element.subsidiaryName;
          //role.isDeleted = false;
          //role.deleted=element.deleted;
          
          
          //role.roleName = item.roleName;
          //this.supplier.supplierAccess.supplierRoles?.push(role);
          this.subsidiriesCopy?.push(role);
        }
      });
   // }
  }
}*/
loadmodule()
{
  this.displaySetupDialog=true;
}
funcancel()
{
  this.router.navigate(['/main/manage-integration/list']);
}

}
