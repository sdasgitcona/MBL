import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportFromNsComponent } from './import-from-ns.component';

describe('ImportFromNsComponent', () => {
  let component: ImportFromNsComponent;
  let fixture: ComponentFixture<ImportFromNsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImportFromNsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImportFromNsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
