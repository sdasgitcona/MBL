import { Component, OnInit } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { Router } from '@angular/router';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { importFromNS } from '../model/netsuite-module'; // Import model
import { ToastService } from 'src/app/core/services/toast.service';
import { BaseSearch } from '../../supplier/model/supplier-model';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';

@Component({
  selector: 'app-import-from-ns',
  templateUrl: './import-from-ns.component.html',
  styleUrls: ['./import-from-ns.component.scss']
})
export class ImportFromNsComponent implements OnInit {
  Subsidiarylist: any[] = [];
  subsidiaryId: any;
  ImportFromNS: importFromNS = new importFromNS();
  typelist: any;
  type: any;
  startDate: Date;
  endDate: Date;
  startDateimport: Date;
  endDateimport: Date;
  RetloginDetails:any;
  columns: any[];
  departments: any[] = [];
  RetRoleDetails:any;
  LoadimportNS: [] = [];
  importFromNSselection: []
  totalRecords: number = 0;
  loading: boolean = false;
   AllSelected: boolean = false;
   SubIdList:any=[];
   baseSearch: BaseSearch = new BaseSearch();
   newevent:any;
  // isRejectPressed: boolean = false;
  // approvalRoutingActive: boolean = false;
  // userRoleId: number;
  // empID: number;
  // approverRoleList: [{ id?: number; name?: string; }];
  // IsLoggerAdmin: string;
  // LoggerRoleName: string;




  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,private toastService: ToastService) {
    this.typelist = ['Make Payment'];//['Item', 'Employee', 'Supplier', 'AP Invoice'];
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);

    this.RetRoleDetails=role_Dtls;
    this.GetSubsideryList();
  }
  GetSubsideryList() {
    this.Subsidiarylist=[];
    if(this.RetloginDetails.userType=='SUPERADMIN')
   // if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist=res;
        for(let x=0;x<this.Subsidiarylist.length;x++)
       { 
        this.SubIdList.push(this.Subsidiarylist[x].id);
      }
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
        //this.resetBaseSearch();
       //this.loadSuppliers('');
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.ImportFromNS.subsidiaryId = this.RetRoleDetails[0].subsidiaryId;
     // this.resetBaseSearch();
    }
  }

  searchByData() {
    try {
      if(this.ImportFromNS.type == undefined || this.ImportFromNS.type == "")
      {
      this.showAlert("please select Type");
      return false;
      }

      let PRdays: any = new Date(this.ImportFromNS.startDate).getDate();
      let PRmonths: any = new Date(this.ImportFromNS.startDate).getMonth() + 1;
      let PRyear: any = new Date(this.ImportFromNS.startDate).getFullYear();
      let startDate: any = this.ImportFromNS.startDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""
    
      let enddays: any = new Date(this.ImportFromNS.endDate).getDate();
      let endmonths: any = new Date(this.ImportFromNS.endDate).getMonth() + 1;
      let endyear: any = new Date(this.ImportFromNS.endDate).getFullYear();
      let endDate: any = this.ImportFromNS.endDate !== undefined ? (endyear + '-' + (endmonths.toString().length == 1 ? "0" + endmonths : endmonths) + '-' + (enddays.toString().length == 1 ? "0" + enddays : enddays)) : ""
    

      this.loading = true;
      this.HttpService.GetAll('/integration-ws/netsuite/get-object?type=' + this.ImportFromNS.type + '&startDate=' + startDate + '&endDate=' + endDate + '&subsidiaryId=' + this.ImportFromNS.subsidiaryId,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
       { 
         this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { 
         this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
       {
          if (res && res.length > 0) {
            this.LoadimportNS = res;
            this.totalRecords = res.length;
          } else {
            this.totalRecords = res.length;
          }
          this.loading = false;
        }
        },
        (error) => {
          this.showAlert(error);
          this.loading = false;
        }
      );
    } catch (err) {
      this.showAlert(err);
      this.loading = false;
    }
  }
  importNS(event: any) {
    try {
      // For populating the lsit  : {{localurl}}/netsuite/get-object?type=Item&startDate=2015-01-01&endDate=2024-03-01&subsidiaryId=3
      let PRdays: any = new Date(this.ImportFromNS.startDate).getDate();
      let PRmonths: any = new Date(this.ImportFromNS.startDate).getMonth() + 1;
      let PRyear: any = new Date(this.ImportFromNS.startDate).getFullYear();
      let startDateimport: any = this.ImportFromNS.startDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""
    
      let enddays: any = new Date(this.ImportFromNS.endDate).getDate();
      let endmonths: any = new Date(this.ImportFromNS.endDate).getMonth() + 1;
      let endyear: any = new Date(this.ImportFromNS.endDate).getFullYear();
      let endDateimport: any = this.ImportFromNS.endDate !== undefined ? (endyear + '-' + (endmonths.toString().length == 1 ? "0" + endmonths : endmonths) + '-' + (enddays.toString().length == 1 ? "0" + enddays : enddays)) : ""

      
      this.loading = true;
      this.HttpService.Insert('/integration-ws/netsuite/get-object?type=' + this.ImportFromNS.type + '&startDate=' + this.startDateimport + '&endDate=' + this.endDateimport + '&subsidiaryId=' + this.ImportFromNS.subsidiaryId,this.ImportFromNS,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
          { 
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { 
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
       else
       {

          // console.log(res);
          if (res && res.length > 0) {
            this.LoadimportNS = res;
            this.totalRecords = res.length;
          } else {
            this.totalRecords = res.length;
          }
          this.loading = false;
        }
        },
        (error) => {
          this.showAlert(error);
          this.loading = false;
        }
      );
    } catch (err) {
      this.showAlert(err);
    }
  }
  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = "";
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.importNS(this.newevent);
  }
  onSelectChange(event:any,routingStatus:any){
    if(!event.checked && this.AllSelected){
    this.AllSelected=false;
    }
   // this.isRejectPressed=false

  }
  onAllSelectChange(event:any){
    if(event.checked){
      this.LoadimportNS.map((data:importFromNS)=>{
        data.selected=true;
      })
    }
    else{
      this.LoadimportNS.map((data:importFromNS)=>{
        data.selected=false;
      })
    }
  }
  Reset()
  {
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.ImportFromNS.subsidiaryId=undefined;
    }
    this.ImportFromNS.type=undefined;
    this.ImportFromNS.startDate=undefined;
    this.ImportFromNS.endDate=undefined;
  }
  showAlert(AlertMSG:any) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }
}
