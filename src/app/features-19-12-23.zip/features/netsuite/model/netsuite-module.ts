export class exportToNS {
        type: any;
        startDate: any;
        endDate: any;
        subsidiaryId: any;
        selected:boolean;
        nsStatus:boolean;
}

export class importFromNS {
        type: any;
        startDate: any;
        endDate: any;
        subsidiaryId: any;
        selected:boolean;
}

export class LoadExportedNS{
        createddate?:any;
        exportedStatus?:any;
        mblId?:number;
        name?: string;
        referenceNumber?:  string;
        remarks?: string;
        type?:  string;
        selected?:boolean;
        }