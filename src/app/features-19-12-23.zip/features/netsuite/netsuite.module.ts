import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NetsuiteRoutingModule } from './netsuite-routing.module';
import { ImportFromNsComponent } from './import-from-ns/import-from-ns.component';
import { ExportedToNsComponent } from './exported-to-ns/exported-to-ns.component';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { CalendarModule } from 'primeng/calendar';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { TabMenuModule } from 'primeng/tabmenu';
import { DialogModule } from 'primeng/dialog';
import { TabViewModule } from 'primeng/tabview';
import { SharedComponentsModule } from 'src/app/shared/shared-components/shared-components.module';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { MultiSelectModule } from 'primeng/multiselect';
import { FieldsetModule } from 'primeng/fieldset';
import { InputSwitchModule } from 'primeng/inputswitch';
import { CardModule } from 'primeng/card';
import { OverlayPanelModule } from 'primeng/overlaypanel';


@NgModule({
  declarations: [
    ImportFromNsComponent,
    ExportedToNsComponent
  ],
  imports: [
    CommonModule,
    NetsuiteRoutingModule,
    PanelModule,
    TableModule,
    TabMenuModule,
    TabViewModule,
    SharedComponentsModule,
    DialogModule,
    ButtonModule,
    DropdownModule,
    InputTextModule,
    FormsModule,
    CheckboxModule,
    ReactiveFormsModule,
    ToggleButtonModule,
    MultiSelectModule,
    CalendarModule,
    FieldsetModule,
    InputSwitchModule,
    InputTextareaModule,
    ProgressSpinnerModule,
    CardModule,
    OverlayPanelModule,
  ]
})
export class NetsuiteModule { }
