import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportedToNsComponent } from './exported-to-ns.component';

describe('ExportedToNsComponent', () => {
  let component: ExportedToNsComponent;
  let fixture: ComponentFixture<ExportedToNsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExportedToNsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ExportedToNsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
