import { Component, OnInit } from '@angular/core';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { Router } from '@angular/router';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { exportToNS, LoadExportedNS } from '../model/netsuite-module'; // Import model
import { ToastService } from 'src/app/core/services/toast.service';

@Component({
  selector: 'app-exported-to-ns',
  templateUrl: './exported-to-ns.component.html',
  styleUrls: ['./exported-to-ns.component.scss']
})
export class ExportedToNsComponent implements OnInit {
  Subsidiarylist: any[] = [];
  subsidiaryId: any;
  ExportToNS: exportToNS = new exportToNS();
  typelist: any;
  type: any;
  startDate: Date;
  endDate: Date;
  itemlist: any[] = [];
  columns: any[];
  url:any;
  tabIndex:number;
  itemexported: any[] = [];
  departments: any[] = [];
  LoadExportedNS: LoadExportedNS[] = [];
  LoadNotExportedNS: LoadExportedNS[] = [];
  exportFromNSSelectedApproval: []
  totalRecords: number = 0;
  loading: boolean = false;
  AllSelected: boolean;
  showloader: boolean;
  RetloginDetails:any;
  RetRoleDetails:any;
  SubIdList:any=[];
  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService, private toastService: ToastService) {
    //this.typelist = ['Item', 'Employee', 'Supplier', 'AP Invoice'];
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.RetloginDetails = JSON.parse(LDetails);
    const retDetails:any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;

    this.GetSubsideryList();
    //this.GetTypeList();
    //this.loadExportedNS();
  }

  GetTypeList() {
    this.HttpService.GetAll("/integration-ws/intigration/get/lov?subsidiaryId="+this.ExportToNS.subsidiaryId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { 
         this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { 
         this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
       {
        this.typelist = res;
       }

      },
      (error) => {
        this.showAlert(error);

      }
    );
  }


  GetSubsideryList_old() {
    this.HttpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { 
         this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { 
         this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
       {
        this.Subsidiarylist = res.list;
       }

      },
      (error) => {
        this.showAlert(error);

      }
    );
  }

  GetSubsideryList() {
       this.Subsidiarylist=[];
    if(this.RetloginDetails.userType=='SUPERADMIN')
  //  if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist=res;
        for(let x=0;x<this.Subsidiarylist.length;x++)
       { 
        this.SubIdList.push(this.Subsidiarylist[x].id);
      }
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
        //this.resetBaseSearch();
       //this.loadSuppliers('');
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.ExportToNS.subsidiaryId = this.RetRoleDetails[0].subsidiaryId;
      this.GetTypeList();
     // this.resetBaseSearch();
    }
  }

  exportNS() {
    this.itemlist = [];

    
    for (let i = 0; i < this.LoadNotExportedNS.length; i++) {
      if (this.LoadNotExportedNS[i].selected == true) {
        this.itemlist.push(this.LoadNotExportedNS[i].mblId);
      }
    }
    if (this.ExportToNS.type == 'Item') {
      this.showloader = true;
      this.HttpService.GetAll('/integration-ws/netsuite/send-item?subsidiaryId=' + this.ExportToNS.subsidiaryId + '&itemIds=' + this.itemlist,this.RetloginDetails.token).subscribe(
        (res) => {
          if (res) {
            if(res.status == 401)
            { 
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { 
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            
            else
            {
              this.showSuccessExport("Item exported to Netsuite Successfully");
              this.showloader = false;
              setTimeout(() => {
                window.location.reload();
              }, 3000);
          
          /*  this.itemexported = [];
            //this.returnfromns=res;
            for (let i = 0; i < res.length; i++) {
              if (res[i].nsStatus == "Exported") {
                this.itemexported.push(res[i].id);
              }

            }
            this.showSuccessExport("Item Id " + this.itemexported + " exported to Netsuite Successfully");
            this.showloader = false;
            setTimeout(() => {
              window.location.reload();
            }, 3000);*/
   
          }
            // this.showSuccess();
          }
          else {
            this.showAlert("Export failed !");
            this.showloader = false;
          }
        },
        (error) => {
          this.showAlert(error);
          this.showloader = false;
        }
      );
    } else if (this.ExportToNS.type == 'Employee') {
      this.showloader = true;
      this.HttpService.GetAll('/integration-ws/netsuite/send-employee?subsidiaryId=' + this.ExportToNS.subsidiaryId + '&employeeIds=' + this.itemlist,this.RetloginDetails.token).subscribe(
        (res) => {
          if (res) {
            if(res.status == 401)
            { 
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { 
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else
            {
              this.showSuccessExport("Employee exported to Netsuite Successfully");
              this.showloader = false;
              setTimeout(() => {
                window.location.reload();
              }, 3000);


           /* this.itemexported = [];
            //this.returnfromns=res;
            for (let i = 0; i < res.length; i++) {
              if (res[i].nsStatus == "Exported") {
                this.itemexported.push(res[i].id);
              }

            }
            this.showSuccessExport("Employee Id " + this.itemexported + " exported to Netsuite Successfully");
            this.showloader = false;
            setTimeout(() => {
              window.location.reload();
            }, 3000);*/
            // this.showSuccess();
          }
          }
          else {
            this.showAlert("Export failed !");
            this.showloader = false;
          }
        },
        (error) => {
          this.showAlert(error);
          this.showloader = false;
        }
      );
    } else if (this.ExportToNS.type == 'Supplier') {
      this.showloader = true;
      this.HttpService.GetAll('/integration-ws/netsuite/send-supplier?subsidiaryId=' + this.ExportToNS.subsidiaryId + '&supplierIds=' + this.itemlist,this.RetloginDetails.token).subscribe(
        (res) => {

          if (res) {
            if(res.status == 401)
              { 
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if(res.status == 404)
              { 
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else
              {
                this.showSuccessExport("Supplier exported to Netsuite Successfully");
                this.showloader = false;
                setTimeout(() => {
                  window.location.reload();
                }, 3000);

                 /* this.itemexported = [];
                  //this.returnfromns=res;
                  for (let i = 0; i < res.length; i++) {
                    if (res[i].nsStatus == "Exported") {
                      this.itemexported.push(res[i].id);
                    }

                  }
                  this.showSuccessExport("Supplier Id " + this.itemexported + " exported to Netsuite Successfully");
                  this.showloader = false;
                  setTimeout(() => {
                    window.location.reload();
                  }, 3000);
             */
                

            // this.showSuccess();
          }
          }
          else {
            this.showAlert("Export failed !");
            this.showloader = false;
          }


        },
        (error) => {
          this.showAlert(error);
          this.showloader = false;
        }
      );
    } else if (this.ExportToNS.type == 'AP Invoice') {
      this.showloader = true;
      this.HttpService.GetAll('/integration-ws/netsuite/send-invoice?subsidiaryId=' + this.ExportToNS.subsidiaryId + '&invoiceIds=' + this.itemlist,this.RetloginDetails.token).subscribe(
        (res) => {
          if (res) {
            if(res.status == 401)
            { 
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { 
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else
            {
            this.showSuccessExport("AP Invoice exported to Netsuite Successfully");
            this.showloader = false;
            setTimeout(() => {
              window.location.reload();
            }, 3000);
            /*  this.itemexported = [];
            //this.returnfromns=res;
            for (let i = 0; i < res.length; i++) {
              if (res[i].nsStatus == "Exported") {
                this.itemexported.push(res[i].id);
              }

            }
            this.showSuccessExport("AP Invoice Id " + this.itemexported + " exported to Netsuite Successfully");
            this.showloader = false;
            setTimeout(() => {
              window.location.reload();
            }, 3000);*/
          }
          }
          else {
            this.showAlert("Export failed !");
            this.showloader = false;
          }
        },
        (error) => {
          this.showAlert(error);
          this.showloader = false;
        }
      );
    }
  }

  searchByData() {
    try {


      if (this.ExportToNS.subsidiaryId == undefined || this.ExportToNS.subsidiaryId == "") {
        this.showAlert("please select Subsidiary");
        return false;
      }
      else if (this.ExportToNS.type == undefined || this.ExportToNS.type == "") {
        this.showAlert("please select Type");
        return false;
      }
      else if (this.ExportToNS.startDate == undefined || this.ExportToNS.startDate == "") {
        this.showAlert("please select Start Date");
        return false;
      }
      else if (this.ExportToNS.endDate == undefined || this.ExportToNS.endDate == "") {
        this.showAlert("please select End Date");
        return false;
      }

     

      let PRdays: any = new Date(this.ExportToNS.startDate).getDate();
      let PRmonths: any = new Date(this.ExportToNS.startDate).getMonth() + 1;
      let PRyear: any = new Date(this.ExportToNS.startDate).getFullYear();
      let startDate: any = this.ExportToNS.startDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""

      let enddays: any = new Date(this.ExportToNS.endDate).getDate();
      let endmonths: any = new Date(this.ExportToNS.endDate).getMonth() + 1;
      let endyear: any = new Date(this.ExportToNS.endDate).getFullYear();
      let endDate: any = this.ExportToNS.endDate !== undefined ? (endyear + '-' + (endmonths.toString().length == 1 ? "0" + endmonths : endmonths) + '-' + (enddays.toString().length == 1 ? "0" + enddays : enddays)) : ""
    
     
      if(this.ExportToNS.nsStatus==true)
      {
          this.url='/integration-ws/netsuite/get-object?type=' + this.ExportToNS.type + '&startDate=' + startDate + '&endDate=' + endDate + '&subsidiaryId=' + this.ExportToNS.subsidiaryId+'&nsStatus=Exported';
      }
      else
      {
           this.url='/integration-ws/netsuite/get-object?type=' + this.ExportToNS.type + '&startDate=' + startDate + '&endDate=' + endDate + '&subsidiaryId=' + this.ExportToNS.subsidiaryId+'&nsStatus=Not Exported';
      }

      this.loading = true;
      this.HttpService.GetAll(this.url,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
          { 
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { 
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
          {
   
          // console.log(res);
          if (res && res.length > 0) {
            this.LoadExportedNS=[];
            this.LoadNotExportedNS=[];

            if(this.ExportToNS.nsStatus==true)
            {
              this.tabIndex=1;
              this.LoadExportedNS = res;
            }
            else
            {
              this.tabIndex=0;
              this.LoadNotExportedNS = res;
            }

          
            this.totalRecords = res.length;
          } else {
            this.LoadExportedNS=[];
            this.LoadNotExportedNS=[];
            if(this.ExportToNS.nsStatus==true)
            {
              this.tabIndex=0;
            }
            else
            {
              this.tabIndex=1;
            }

            this.totalRecords = res.length;
          }
          this.loading = false;
        }
        },
        (error) => {
          this.showAlert(error);
          this.loading = false;
        }
      );
    } catch (err) {
      this.showAlert(err);
      this.loading = false;
    }
  }
  onSelectChange(event: any, routingStatus: any) {
    if (!event.checked && this.AllSelected) {
      this.AllSelected = false;
    }
    // this.isRejectPressed=false

  }
  // onAllSelectChange(event:any){
  //   if(event.checked){
  //     this.LoadExportedNS.map((data:exportToNS)=>{
  //       data.selected=true;
  //     })
  //   }
  //   else{
  //     this.LoadExportedNS.map((data:exportToNS)=>{
  //       data.selected=false;
  //     })
  //   }
  // }

  onAllSelectChange(event: any) {
    if (event.checked) {
      for (let i = 0; i < this.LoadNotExportedNS.length; i++) {
        this.LoadNotExportedNS[i].selected = true;
      }
      // this.LoadExportedNS.map((data:exportToNS)=>{
      // data.selected=true;
      //  })
    }
    else {
      //this.LoadExportedNS.map((data:exportToNS)=>{
      // data.selected=false;
      // })

      for (let i = 0; i < this.LoadNotExportedNS.length; i++) {
        this.LoadNotExportedNS[i].selected = false;
      }
    }
  }
  Reset()
  {
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.ExportToNS.subsidiaryId=undefined;
    }
    this.LoadExportedNS=[];
    this.LoadNotExportedNS=[];
    this.ExportToNS.type=undefined;
    this.ExportToNS.startDate=undefined;
    this.ExportToNS.endDate=undefined;
  }
  showAlert(AlertMSG: any) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }

  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Export to NS done successfully!'
    );
  }
  showSuccessExport(AlertMSG: any) {
    this.toastService.addSingle(
      'success',
      'Success',
      AlertMSG
    );
  }
  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 0) {
    
      this.ExportToNS.nsStatus=false;
      this.searchByData();
     // this.displayAddressDialog = false;
    }
    else if(event.index == 1)
    {
      this.ExportToNS.nsStatus=true;
      this.searchByData();
    }
  }
}
