import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {ImportFromNsComponent} from './import-from-ns/import-from-ns.component';
import {ExportedToNsComponent} from './exported-to-ns/exported-to-ns.component';
const routes: Routes = [{
  path: 'From_NS',
  component: ImportFromNsComponent,
},

{
  path: 'To_NS',
  component: ExportedToNsComponent,
},];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NetsuiteRoutingModule { }
