import { Component, ElementRef, OnInit, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { Items } from '../../item/model/item-model';
import { locations } from '../../locationmaster/model/locationmaster-model';
import { Item, PrItems, PurchaseOrder, QAItems, supplierCurrency } from '../../purchase-order/model/purchase-order-module';
import { Subsidiary } from '../../subsidiary/Model/subsidiary-model';
import { SubsidiaryEntry, Supplier, SupplierAddress } from '../../supplier/model/supplier-model';
import { TaxGroup } from '../../tax-group/model/tax-group-model';
import { debitNote,RtvreferenceCopy,ApplyModel,DebitNoteItem,approvers,unapply } from '../model/debit-note-model';
import { CardModule } from 'primeng/card';
import { department } from '../../approval-prefference/model/Approval-Prefference-model';
@Component({
  selector: 'app-dabit-note-add-edit',
  templateUrl: './dabit-note-add-edit.component.html',
  styleUrls: ['./dabit-note-add-edit.component.scss']
})
export class DabitNoteAddEditComponent implements OnInit {
  debitNotes: debitNote = new debitNote();
  //item: Item=new Item();
  debitNoteId: number = 0;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  aproBttn: boolean = false;
  role: any;
  empID: number;
  department:any;
  Chktooltip:boolean=false;
  apply: ApplyModel[] = []
  approvers?:approvers[]=[]
  isAppSequenceVisivble:boolean;
 appSequencelist:any=[];
 departmentname:any;
  //subsidiary:any;
  ProjectList:any[];
  vendor: any;
  departmentOptions: any;
  location: any;
  applied: unapply[] = []
  isApproved:boolean=false;
  purchaseordertype: any;
  rtvreferenceCopy:RtvreferenceCopy[]=[];
  prequisition: any;
  paymentterm: any;
  matchtype: any;
  //currency:any;
  postatus: any;
  markall: boolean;
  markallunapply: boolean;
  markall_item: boolean;
  url:any;
  ApprovalButtonShowHide:Number=0;
  isrecall:boolean=false;
  
  isdisableapply:boolean=true;
  //taxgroup:any;
  //itemlist:any;
  hideunapply:boolean=true;
  unappliedAmountCopy: any;
  Address: any;
  DebitNoteHistoryList: HistoryModel[] = [];
  display_tax: boolean = false;
  display: boolean = false;
  isReloadSub: boolean;
  isReloadSupplier: boolean;
  isReloadCurrency: boolean;
  isReloadItem: boolean;
  isReloadTax: boolean;
  isReloadLocation: boolean;
  Subsidiarylist: any[] = [];
  subsidiary: Subsidiary = new Subsidiary();
  supplier: Supplier = new Supplier();
  supplierlist: Supplier[] = [];
  itemList: Items[] = [];
  PRitemList: PrItems[] = [];
  locationlist: locations[] = [];
  taxGroupList: TaxGroup[] = [];
  taxgroup: TaxGroup = new TaxGroup();
  chkId:any;
  isviewapprovereject:boolean=false;
  currency: supplierCurrency[] = [] //[{ id?: number; name?: string; code?: string; }];
  private subscription: any;
  orderId: number;
  returntype:any[]=[];
  taxamount: number = 0;
  selectedRow: number = 0;
  totalBasicAmount: number = 0;
  totalTaxAmount: number = 0;
  totalAmount: number = 0;
  fiscalCalenderDTLS: any;
  showloader: boolean = false;
  RTVList:any[]=[];
 // PRList: [{ id?: number; name?: string; }];
  QAList: any[] = [];
  QAitemList: QAItems[] = [];
  billingAddressList: SupplierAddress[] = [];
  shippingAddressList: SupplierAddress[] = [];
  poNumber: any;
  id: any
  RetloginDetails: any;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  isviewEditable: boolean = true;
  // For Role Base Access
  RetRoleDetails:any;

  constructor(private httpService: CommonHttpService,
    private router: Router,
    private toastService: ToastService,
    private activatedRoute: ActivatedRoute,
    private elementRef: ElementRef
  ) {
    //this.subsidiary = ['MLBD', 'MLCD'];
    //this.location = ['Location A', 'Location B','Location C'];
    this.prequisition = ['PR/0001/22-23', 'PR/0002/22-23', 'PR/0003/22-23'];
    this.paymentterm = ['15 Days', '30 Days', '60 Days', '90 Days'];
    this.matchtype = ['2 Way', '3 Way'];
    //this.currency = ['GBP', 'USD'];
    this.returntype = [{id:'RTV',value:'RTV'},{id:'Standalone',value:'Standalone'}];
    this.postatus = ['Approved', 'Pending Approval', 'Open', 'Close', 'Applied', 'Partially Applied', 'Partially Approved'];
    //this.taxgroup  = ['VAT US 5', 'VAT US 8'];
    //this.itemlist  = ['item1', 'item2'];
    //this.Address  = ['address1', 'address2'];
  }
  ngOnInit(): void {

    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    const LoggerId = JSON.parse(LDetails);
    this.empID = LoggerId.employeeId;
    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Purchase Order") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
        if (this.isEditable == false)
          this.isviewEditable = false;
      }
    }

    // End For Role Base Access
    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.debitNoteId = +params['id']
            this.GetDebitNote();
          }
          if (params['chkid']) {
            this.chkId = +params['chkid'];
           }
          this.assignMode(params['action']);
          this.GetSubsideryList();
         
          //this.GetCurrencyList();
        } else {
        }
      },
      (error) => {
      }
    );
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        this.aproBttn == false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.aproBttn == true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.aproBttn == true;
        break;
      default:
        break;
    }
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 3) {
      this.LoadHistory();
      // this.displayAddressDialog = false;
    }
  }
  /* Get PO details by PO Number */
  GetDebitNote() {
    debugger
    this.httpService
      .GetById('/finance-ws/debitNote/get?id=' + this.debitNoteId, this.debitNoteId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.errorMessage) {
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
           } else {
            if(this.chkId==1)
            {
              this.isviewapprovereject=true;
            }
            if(res.approvalStatus=='Pending Approval' || res.approvalStatus=='Partially Approved' || res.approvalStatus=='Approved'|| res.approvalStatus=='Rejected' || res.approvalStatus=='Closed'|| res.approvalStatus=='Partially Received'|| res.approvalStatus=='Received' || res.approvalStatus=='Partially Billed'|| res.approvalStatus=='Billed') //Send Approval Mode
            {
            this.ApprovalButtonShowHide=0;
            }
            else{
              this.ApprovalButtonShowHide=1;
            }
      
              
            for(let i=0;i<res.debitNoteItem.length;i++)
            {
              res.debitNoteItem[i].basicAmount=res.debitNoteItem[i].basicAmount.toFixed(2);
              res.debitNoteItem[i].totalAmount=res.debitNoteItem[i].totalAmount.toFixed(2);
            }
            res.amount=res.amount.toFixed(2);
            res.totalAmount=res.totalAmount.toFixed(2);
            this.debitNotes = res;
            this.debitNotes.unappliedAmount = this.debitNotes.unappliedAmount==null?this.debitNotes.totalAmount:this.debitNotes.unappliedAmount.toFixed(2);
            this.unappliedAmountCopy = this.debitNotes.unappliedAmount>0?this.debitNotes.unappliedAmount:this.debitNotes.totalAmount;
            if(this.debitNotes.approvalStatus=="Approved")
            {
              this.isApproved=true;
            }
            if(this.RetloginDetails.email==this.debitNotes.createdBy)
            {
              this.isrecall=true;
            }

            this.debitNotes.debitNoteDate=this.debitNotes.debitNoteDate!=null?new Date(this.debitNotes.debitNoteDate):"";
            this.appSequencelist=this.debitNotes.approvers
            let nextApprover=res.nextApprover;
            let isNextApproverFound:Boolean=false;
            if(this.appSequencelist!=undefined)
            {
              for(let x=0;x<this.appSequencelist.length;x++)
              {
                  let status='';
                  if (this.appSequencelist[x].id == nextApprover)
                  {
                    isNextApproverFound=true;
                    status='current';//this.appSequencelist[x]['status']=;
                  }
                  else
                  {
                    if(isNextApproverFound)
                    {
                      status='pending';
                    }else{
                      status='approved';
                    }
                  }
                  this.appSequencelist[x]['status']=status;
               }
            }
           
            if(res.approvalStatus=="Approved" || res.approvalStatus=="Partially Applied")
            {
              this.isdisableapply=false;
            }
            this.debitNotes.debitNoteDate = this.debitNotes.debitNoteDate ? new Date(this.debitNotes.debitNoteDate) : this.debitNotes.debitNoteDate;
            this.GetAllProjectList(this.debitNotes.subsidiaryId);
            this.GetDepartmentList();
            this.GetSubsidiarybyId();
            this.GetSupplierList();
            this.GetSupplierCurrencyList();
            this.GetTaxGroupList();
            this.GetApply();
            this.GetApplied();
            this.markall_item=true;
            this.chkenableitem();
            this.loadstandaloneitem();
          
            // this.SummuryAmount()
          }
        }
      });
  }
  /*End  Get PO details by PO Number */
  /* start get Get Subsidiary by Id */
  GetSubsidiarybyId() {
    this.httpService
      .GetById('/setup-ws/subsidiary/get?id=' + this.debitNotes.subsidiaryId, this.debitNotes.subsidiaryId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.subsidiary = res;
          if (this.addMode) {
            this.debitNotes.exchangeRate = this.subsidiary.currency == this.debitNotes.currency ? "1.00" : ""
          }
        }
      });
  }
  /* end  get Get Subsidiary by Id */
  /* start get Get Subsidiary List */
  GetSubsideryList() {
    if(this.RetloginDetails.userType=='SUPERADMIN')
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
    
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    
    //this.httpService.GetAll("/setup-ws/subsidiary/get/all", this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.Subsidiarylist = res;
          this.isReloadSub = false;
        }
      },
      (error) => {
        this.isReloadSub = false;
      }
    );
  }else if(this.RetloginDetails.userType=='ENDUSER'){
    this.Subsidiarylist.push({
      id:this.RetRoleDetails[0].subsidiaryId,
      name:this.RetRoleDetails[0].subsidiaryName
    });
  }
  }
  /* End get Get Subsidiary List */
  OnSubsidiaryChnage() {
    //this.GetPoNumber()
    this.ProjectList=[];
    this.debitNotes.projectId=undefined;
    this.GetAllProjectList(this.debitNotes.subsidiaryId);
    this.getRanges();
    this.GetSubsidiarybyId();
    this.GetSupplierList();
    this.GetTaxGroupList();
    //this.GetPRItemList()
  }
  OnSupplierChange() {
    this.debitNotes.currency="";
    this.debitNotes.exchangeRate=undefined;
    this.debitNotes.grnNumber=undefined;
    this.GetSupplierbyId();
    this.GetSupplierCurrencyList();
    this.OnReturnTypeChnage();
    setTimeout(() => {this.GetApply();},600);
    
  }
  /* start get Get Supplier list */
  GetSupplierList() {
    this.httpService
      .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + this.debitNotes.subsidiaryId, this.debitNotes.subsidiaryId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.supplierlist = res;
          this.isReloadSupplier = false;
        }
      });
  }
  /* end get Get Supplier list */
  /* start get Get Supplier id */
  GetSupplierbyId() {
    this.httpService
      .GetById('/masters-ws/supplier/get?id=' + this.debitNotes.supplierId, this.debitNotes.supplierId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.supplier = res;
          this.supplier.supplierSubsidiary.map((data: any) => {
            if (data.preferredCurrency) {
              this.debitNotes.currency = data.supplierCurrency;
            }
          })
          if (this.addMode) {
            this.debitNotes.exchangeRate = this.subsidiary.currency == this.debitNotes.currency ? "1.00" : ""
          }
        }
      });
  }
  /* end get Get Supplier id */
  /* Start Fetch Currency list from api */
  GetCurrencyList(): any {
    this.httpService.GetAll("/setup-ws/currency/get/all", this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              error.errorMessage
            );
            this.itemList = [];
          } else {
            this.currency = res;
          }
        }
      },
        error => {
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
          this.isReloadCurrency = false;
        });
  }
  /* End Fetch Currency list from api */
  /* Start Fetch Currency list by supplier id from api */
  GetSupplierCurrencyList(): any {
    this.httpService.GetAll("/masters-ws/supplier/get-currency-by-supplier?supplierId=" + this.debitNotes.supplierId, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              error.errorMessage
            );
            this.itemList = [];
          } else {
            this.currency = res;
          }
        }
      },
        error => {
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  /* End Fetch Currency list by supplier id from api */
  /* Start Fetch Item list from api */

  /* Start Genrate pr number */
  GetPoNumber() {
    this.httpService.GetByResponseType(`/finance-ws/document-sequence/get-document-sequence-numbers?subsidiaryId=${this.debitNotes.subsidiaryId}&type=Debit&transactionalDate=2022-11-08&isDeleted=false`, 'text')
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (!res.error)
            this.debitNotes.debitNoteNumber = res;
          else {
            var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              error.errorMessage
            );
            this.debitNotes.debitNoteNumber = "";
          }
        }
      },
        error => {
          this.debitNotes.debitNoteNumber = "";
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  /* End Genrate pr number  */

  // CalculateAmmount(quantity:any,rate:any,index:any){
  //   if(quantity && rate){
  //   this.purchaseorder.purchaseOrderItems[index].amount=(parseFloat(quantity)*parseFloat(rate)).toFixed(2);
  //   this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=parseFloat(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount?this.purchaseorder.purchaseOrderItems[this.selectedRow].amount:0)+(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount?this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount:0)).toFixed(2)

  //   }
  //   else if(quantity){
  //     this.purchaseorder.purchaseOrderItems[index].amount=(parseFloat(quantity)*1).toFixed(2)
  //     this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=parseFloat(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount?this.purchaseorder.purchaseOrderItems[this.selectedRow].amount:0)+(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount?this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount:0)).toFixed(2)
  //   }else if(rate){
  //     this.purchaseorder.purchaseOrderItems[index].amount=(1*parseFloat(rate)).toFixed(2)
  //     this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=parseFloat(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount?this.purchaseorder.purchaseOrderItems[this.selectedRow].amount:0)+(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount?this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount:0)).toFixed(2)

  //   }else{

  //   }

  //   //this.showDialog(this.purchaseorder.purchaseOrderItems[index].taxGroupId,index)
  //   if(!this.taxgroup.id && this.editMode){
  //     this.GetTaxGroupbyId(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxGroupId)
  //   }
  //   this.taxgroup.taxRateRules.map((data:any)=>{
  //     this.taxamount+=this.taxgroup.inclusive?(((this.purchaseorder.purchaseOrderItems[this.selectedRow].amount *100)/(100 + (data.taxRates*1)) * data.taxRates) / 100 ):(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount * data.taxRates) / 100
  //   })
  //    this.taxCodeSave();
  // }
  saveDebitNote() {
    var isAmountValid = true
  
    if (!this.debitNotes.subsidiaryId) {
      this.toastService.addSingle(
        'error',
        'Error',
        'Subsidiary is mandatory'
      );
      return;
    }
    if (!this.debitNotes.supplierId) {
      this.toastService.addSingle(
        'error',
        'Error',
        'Supplier is mandatory'
      );
      return;
    }
    if (!this.debitNotes.returnType) {
      this.toastService.addSingle(
        'error',
        'Error',
        'Returntype is mandatory'
      );
      return;
    }
    if (!this.debitNotes.debitNoteDate) {
      this.toastService.addSingle(
        'error',
        'Error',
        'Date is mandatory'
      );
      return;
    }
    let days: any = new Date(this.debitNotes.debitNoteDate).getDate();
    let months: any = new Date(this.debitNotes.debitNoteDate).getMonth() + 1;
    let year: any = new Date(this.debitNotes.debitNoteDate).getFullYear();
    if (months < 10) {
      months = "0".toString() + months.toString();
    }
    if (days < 10) {
      days = "0".toString() + days.toString();
    }
    this.debitNotes.debitNoteDate = year + "-" + months + "-" + days;

    if (this.addMode) {
      this.debitNotes.createdBy = this.RetloginDetails.username; this.debitNotes.lastModifiedBy = this.RetloginDetails.username
    } else if (!this.addMode) {
      this.debitNotes.lastModifiedBy = this.RetloginDetails.username
    }
    this.showloader = true;
    if(this.debitNotes.returnType=="RTV")
    {
      this.debitNotes.debitNoteItem=this.debitNotes.debitNoteItem.filter(x=>x.selected==true);
    }
    if(this.editMode)
    {
       this.debitNotes.debitNoteApply=this.debitNotes.debitNoteApply.filter(x=>x.selected==true);
    }

    if(this.addMode)
    {
       this.url='/finance-ws/debitNote/save';
    }
    else
    {
       this.url='/finance-ws/debitNote/save-apply';
    }

    this.httpService.Insert(this.url, this.debitNotes, this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error){
            this.showloader=false;
              this.toastService.addSingle(
                'error',
                'Error',
                JSON.stringify(res.error)
              );
           }
          else if (res && res.id > 0) {
            this.showloader = false;
            //this.saveAddress();
            this.showSuccess();
            if(this.addMode){
              this.router.navigate(['/main/debit-note/action', 'view',res.id]);
            } else {
              this.router.navigate(['/main/debit-note/list']);
            }
 
          } else {
            this.showloader = false;
            this.showError();
          }
        }
      },
      (error) => {
        this.showloader = false;
      },
      () => { }
    );
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Debit Note Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Debit Note!'
    );
  }
  clearDebitData() {

    this.router.navigate(['/main/debit-note/list']);
    /*if (this.editMode) {
      this.router.navigate(['/main/purchase-order/list']);
    }
    else {
      this.supplier = new Supplier();
      this.subsidiary = new Subsidiary();
      this.debitNotes = new debitNote();
    }*/
  }
  /* tax group list */
  GetTaxGroupList() {
    this.httpService.GetAll("/setup-ws/tax-group/get-by-subsidiary?subsidiaryId=" + this.debitNotes.subsidiaryId, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              error.errorMessage
            );
            this.taxGroupList = [];
          } else {
            this.taxGroupList = res;
          }
        }
      }, error => {
      },
        () => {
          this.isReloadTax = false;
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  /* end tax group list */
  decimalFilter(event: any) {
    const reg = /^-?\d*(\.\d{0,2})?$/;
    let input = event.target.value + String.fromCharCode(event.charCode);

    if (!reg.test(input)) {
      event.preventDefault();
    }
  }
  // SummuryAmount(){
  //   this.purchaseorder.amount=0;
  //   this.purchaseorder.taxAmount=0;
  //   this.purchaseorder.totalAmount=0;
  //   this.purchaseorder.purchaseOrderItems.map((data,index)=>{
  //     this.purchaseorder.amount+=parseFloat(data.amount);
  //     this.purchaseorder.taxAmount+=parseFloat(data.taxAmount)
  //     //this.totalAmount+=parseFloat(data.totalAmount)
  //     if(!this.addMode){
  //       if(this.taxgroup.inclusive){
  //         data.totalAmount =parseFloat(this.purchaseorder.purchaseOrderItems[index].amount).toFixed(2)
  //         this.purchaseorder.totalAmount+=parseFloat(data.totalAmount)
  //       }else{
  //         data.totalAmount =(parseFloat(this.purchaseorder.purchaseOrderItems[index].amount)+parseFloat(this.purchaseorder.purchaseOrderItems[index].taxAmount)).toFixed(2)
  //         this.purchaseorder.totalAmount+=parseFloat(data.totalAmount)

  //       }
  //     }
  //     else{
  //       this.purchaseorder.totalAmount+=parseFloat(data.totalAmount)
  //     }

  //   })
  //   this.purchaseorder.amount=this.purchaseorder.amount?parseFloat(this.purchaseorder.amount).toFixed(2):"0.00";
  //   this.purchaseorder.taxAmount=this.purchaseorder.taxAmount?parseFloat(this.purchaseorder.taxAmount).toFixed(2):"0.00";
  //   this.purchaseorder.totalAmount=this.purchaseorder.totalAmount?parseFloat(this.purchaseorder.totalAmount).toFixed(2):"0.00";
  // }
  /* Start fetching History details */
  LoadHistory() {
    if (this.DebitNoteHistoryList.length == 0)
      this.httpService
        .GetById(`/finance-ws/debitNote/get/history?debitNoteNumber=${this.debitNotes.debitNoteNumber}&pageSize=100`,
          this.debitNotes.debitNoteNumber, this.RetloginDetails.token
        )
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.DebitNoteHistoryList = res;
          }
        });
  }
  /* End fetching History details */
  /* End Fetch Item list from api */
  // [{
  //   "prNumber":"PR/21-22/10001",
  // "currency":"INR"
  // }]
  sendPrForApproval() {
    this.httpService
      .GetById('/procure-ws/po/send-for-approval?id=' + this.debitNotes.id, this.debitNotes.id, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          // if (res == true) {
          //   this.showCSTMAlert("Approval send Successfully","success","Success");
          // } else {
          //   this.showAlert(res.errorMessage);
          // }
          if (res == true) {
            this.toastService.addSingle(
              'success',
              'Success',
              'PO Sent for Approval Successfully!'
            );
          } else {
            this.showAlert(res.errorMessage);
          }
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending PO for Approval!'
          );
        }
      );
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  showCSTMAlert(AlertMSG: string, AlertType: string, Alert: string) {
    this.toastService.addSingle(
      AlertType,
      Alert,
      AlertMSG
    );
  }
  /* Start Reload subsidery */
  reloadSubidery() {
    //$('.refsubsidery').addClass('fa-spin');
    this.ProjectList=[];
    this.debitNotes.projectId=undefined;
    this.subsidiary.currency="";
    this.isReloadSub = false;
    this.debitNotes.subsidiaryId = 0;
    this.Subsidiarylist=[];
    this.GetSubsideryList();
  }
  /* End Reload subsidery */
  /* Start Reload supplier */
  reloadSupplier() {
    //$('.refsubsidery').addClass('fa-spin');
    this.debitNotes.currency="";
    this.debitNotes.exchangeRate=undefined;
    this.debitNotes.grnNumber=undefined;
    this.isReloadSupplier = false;
    this.debitNotes.supplierId = 0;
    this.debitNotes.debitNoteItem=[];
      this.debitNotes.amount=0.00;
      this.debitNotes.taxAmount=0.00;
      this.debitNotes.totalAmount=0.00;
    this.supplierlist=[];
    this.GetSupplierList();
  }
  decimalfrection(event: any) {
    this.debitNotes.exchangeRate = parseFloat(event.target.value).toFixed(2)
    //event.target.value=parseFloat(event.target.value).toFixed(2)
  }
  getRanges() {
    if (this.debitNotes.subsidiaryId != undefined && this.debitNotes.debitNoteDate != undefined) {
      this.httpService
        .GetById('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId=' + this.debitNotes.subsidiaryId, this.debitNotes.subsidiaryId, this.RetloginDetails.token)
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res) {
              this.fiscalCalenderDTLS = res;
              if (this.fiscalCalenderDTLS != null && this.fiscalCalenderDTLS.fiscalCalanderAccounting.length > 0) {
                let AllowMonths: any = "Allow Months: ";
                let IsDateAvailable: boolean = false;

                var Dummymonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

                let PRdays: any = new Date(this.debitNotes.debitNoteDate).getDate();
                let PRmonths: any = new Date(this.debitNotes.debitNoteDate).getMonth() + 1;
                let PRyear: any = new Date(this.debitNotes.debitNoteDate).getFullYear();
                let PRDate: any = this.debitNotes.debitNoteDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""

                for (let x = 0; x < this.fiscalCalenderDTLS.fiscalCalanderAccounting.length; x++) {
                  AllowMonths += this.fiscalCalenderDTLS.fiscalCalanderAccounting.length == (x + 1) ? this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month : this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month + " , "

                  if (PRDate >= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].fromDate && PRDate <= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].toDate && this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month == Dummymonths[PRmonths - 1] + "-" + PRyear) {
                    IsDateAvailable = true;
                  }
                }

                if (IsDateAvailable == false) {
                  this.showAlert("Selected Date is Not available in Fiscal Calendar ! " + AllowMonths);
                  this.debitNotes.debitNoteDate = {};
                }
              } else {
                this.showAlert("Selected Date is Not available in Fiscal Calendar !");
                this.debitNotes.debitNoteDate = {};
              }

            } else {
              this.showAlert("No Data Found");
            }
          }
        },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Error',
              error
            );
          }

        );

    }
  }

  OnReturnTypeChnage()
  {
    this.rtvreferenceCopy=[];
    if(this.debitNotes.returnType=="RTV")
    {
      this.debitNotes.debitNoteItem=[];
      this.debitNotes.amount=0.00;
      this.debitNotes.taxAmount=0.00;
      this.debitNotes.totalAmount=0.00;
      this.httpService
      .GetAll('/procure-ws/rtv/get-rtv-by-subsidiary-supplier?subsidiaryId=' + this.debitNotes.subsidiaryId +'&supplierId='+ this.debitNotes.supplierId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          // if (res == true) {
          //   this.showCSTMAlert("Approval send Successfully","success","Success");
          // } else {
          //   this.showAlert(res.errorMessage);
          // }
          if (res) {
            this.RTVList=res;

            this.debitNotes.grnNumber=res[0].grnNumber;

          }
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending PO for Approval!'
          );
        }
      );
    }
    else if(this.debitNotes.returnType=="Standalone")
    {
      this.debitNotes.debitNoteItem=[];
      this.debitNotes.amount=0.00;
      this.debitNotes.taxAmount=0.00;
      this.debitNotes.totalAmount=0.00;
      this.loadstandaloneitem();
      this.debitNotes.grnNumber=undefined;
      this.debitNotes.rtvId=undefined;
      this.GetDepartmentList();
    }
  
  }
 /*Load Item  */
  loaditem(event:any)
  {

   /* const rtvarray = [];
    this.debitNotes.debitNoteItem=[];
    for(let i=0;i<this.rtvreferenceCopy.length;i++)
      {
       //PRarray.push(this.quotationprCopy[i].prNumber) // old
       rtvarray.push(this.rtvreferenceCopy[i].id)  // new
      
      }*/

      
      this.debitNotes.rtvNumber=event.originalEvent.currentTarget.ariaLabel;
 
      debugger
      this.httpService
      .GetAll('/procure-ws/rtv/get-rtv-item?rtvId='+ this.debitNotes.rtvId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          // if (res == true) {
          //   this.showCSTMAlert("Approval send Successfully","success","Success");
          // } else {
          //   this.showAlert(res.errorMessage);
          // }
          if (res) {
            this.debitNotes.debitNoteItem=[];
            this.calculatetotal();
            
            //this.debitNotes.rtvNumber=event.originalEvent.currentTarget.ariaLabel;
            for(let i=0;i<res.length;i++)
            {
              debugger
              this.GetDepartmntbyId(res[i].deptIdFromPo);

              setTimeout(() => { 

                this.debitNotes.debitNoteItem.push(
                  {
                    itemName:res[i].grnItems[0].itemName,
                    itemDescription:res[i].grnItems[0].itemDescription,
                    quantity:res[i].recievedQuantity,
                    returnquantity:res[i].returnQuantity,
                    rate:parseFloat(res[i].grnItems[0].rate).toFixed(2),
                    basicAmount:res[i].amount,
                    selected:false,
                    departmentId:res[i].deptIdFromPo,
                    department:this.department
  
                    
                  }
                  
                )

                this.loaddepartment();
                this.CalculateAmmount(res[i].recievedQuantity,parseFloat(res[i].grnItems[0].rate).toFixed(2),i);
              },500);
             

            }
           

          }
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending PO for Approval!'
          );
        }
      );



      

    }
 /*Calculate total  */
    calculatetotal()
    {
      
      this.debitNotes.amount=0.00;
      this.debitNotes.taxAmount=0.00;
      this.debitNotes.totalAmount=0.00;
     for(let i=0;i< this.debitNotes.debitNoteItem.length;i++)
     {
     
      if(this.debitNotes.debitNoteItem[i].rate!=undefined && this.debitNotes.debitNoteItem[i].quantity!=undefined)
      {
        this.debitNotes.debitNoteItem[i].basicAmount=(parseFloat(this.debitNotes.debitNoteItem[i].rate)*parseFloat(this.debitNotes.debitNoteItem[i].quantity)).toFixed(2);
       if(this.debitNotes.debitNoteItem[i].taxGroupId!=undefined)
       {
        this.debitNotes.taxAmount+=parseFloat(this.debitNotes.debitNoteItem[i].taxAmount);
       }
       
        this.debitNotes.amount+=parseFloat(this.debitNotes.debitNoteItem[i].basicAmount);
       // this.debitNotes.amount=parseFloat(this.debitNotes.amount).toFixed(2)+parseFloat(this.debitNotes.debitNoteItem[i].basicAmount).toFixed(2);
       if(this.debitNotes.debitNoteItem[i].taxGroupId!=undefined)
       {
        this.debitNotes.totalAmount=this.debitNotes.amount+this.debitNotes.taxAmount;
       }
       else{
        this.debitNotes.totalAmount=this.debitNotes.amount;
       }
      }
       

      }
      this.debitNotes.amount=parseFloat(this.debitNotes.amount).toFixed(2);
      this.debitNotes.taxAmount=parseFloat(this.debitNotes.taxAmount).toFixed(2);
      this.debitNotes.totalAmount=parseFloat(this.debitNotes.totalAmount).toFixed(2);
     
    }
 /*Apply tab load  */

    GetApply() {
      this.httpService
        //.GetAll(`/invoice/get-invoice-by-supplier-and-subsidiary?subsidiaryId=${this.aPayemnt.subsidiaryId}&supplierId=${this.aPayemnt.supplierId}`)
        .GetAll(`/finance-ws/advance/get-invoice-by-supplier-and-subsidiary-and-currency?subsidiaryId=${this.debitNotes.subsidiaryId}&supplierId=${this.debitNotes.supplierId}&currency=${this.debitNotes.currency}`, this.RetloginDetails.token)
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.debitNotes.debitNoteApply = res;
          }
        });
    }

    chkenable() {
    
      if (this.markall) {
       
        for (let i = 0; i < this.debitNotes.debitNoteApply.length; i++) {
          this.debitNotes.debitNoteApply[i].selected = true;
          //this.apply[i].paymentamtdisable=false;
        }
      }
      else {
        for (let i = 0; i < this.debitNotes.debitNoteApply.length; i++) {
          this.debitNotes.debitNoteApply[i].selected = false;
          this.debitNotes.unappliedAmount = this.unappliedAmountCopy;
          this.debitNotes.debitNoteApply[i].applyAmount = "";
          this.debitNotes.debitNoteApply[i].applyDate = "";
          //this.apply[i].paymentamtdisable=true;
        }
      }
    }
    chkenableunapply() {
    
      if (this.markallunapply) {
       
        for (let i = 0; i < this.applied.length; i++) {
          this.applied[i].selected = true;
          //this.apply[i].paymentamtdisable=false;
        }
        this.hideunapply=false;
      }
      else {
        for (let i = 0; i < this.applied.length; i++) {
          this.applied[i].selected = false;
        
          //this.apply[i].paymentamtdisable=true;
        }
        this.hideunapply=true;
      }
    }
     /*markall button function  */
    chkenableitem() {
    
      if (this.markall_item) {
       
        for (let i = 0; i < this.debitNotes.debitNoteItem.length; i++) {
          this.debitNotes.debitNoteItem[i].selected = true;
          //this.apply[i].paymentamtdisable=false;
        }
      }
      else {
        for (let i = 0; i < this.debitNotes.debitNoteItem.length; i++) {
          this.debitNotes.debitNoteItem[i].selected = false;
         }
      }
    }
    onDisableChange(rowindex: number) {

      if (this.apply[rowindex].selected == false) {
        this.apply[rowindex].applyAmount = null;
        this.apply[rowindex].applyAmount = undefined;
        this.apply[rowindex].applyDate = "";
  
      }
      
    }
    decimalfrectionRate(event: any,index:any) {
      if(event.target.value !="")
      this.debitNotes.debitNoteItem[index].rate=parseFloat(event.target.value).toFixed(2)
    }
    /*fraction  */
    decimalfrectionQuntity(event: any,index:any) {
      if(event.target.value !="")
      this.debitNotes.debitNoteItem[index].quantity=parseFloat(event.target.value).toFixed(2)
    }
    /*calculate amount */
    CalculateAmmount(quantity:any,rate:any,index:any){
     quantity=quantity ==undefined?0:quantity==""?0:quantity;
     rate=rate==undefined?0:rate=="" ?0:rate;
     this.debitNotes.debitNoteItem[index].basicAmount=(parseFloat(quantity != undefined ?quantity:0)*parseFloat(rate != undefined ?rate:0)).toFixed(2);
     this.debitNotes.debitNoteItem[index].totalAmount=parseFloat(this.debitNotes.debitNoteItem[index].basicAmount).toFixed(2);
      //this.onChangeTaxCalculate(this.purchaseorder.purchaseOrderItems[index].taxGroupId,index);
    this.calculatetotal();
     }
/* events on item change  */
     onItemChange(index: number, value: string) {
      let that = this;
    
      this.itemList.find(o => {
        if (o.name === (value)) {
           that.debitNotes.debitNoteItem[index].itemDescription = o.description;
           that.debitNotes.debitNoteItem[index].department = this.debitNotes.department;
          // that.purchaseorder.purchaseOrderItems[index].itemUom = o.uom;
          //that.purchaseorder.purchaseOrderItems[index].accountCode=o.accountId
        }
      });
    }
   /*Add item on add button click */
    addItem()
    {
      if (
        this.debitNotes.debitNoteItem.length > 0 &&
        this.debitNotes.debitNoteItem[length - 1] == new DebitNoteItem()
      ) {
        return;
      }
      this.debitNotes.debitNoteItem.push(new DebitNoteItem());
    }
    showDialog(taxgroupId:any,rowIndex:any,type:any) { 
      if(type=="eye")
      {
        this.Chktooltip=true;
      }
      else
      {
       this.Chktooltip=false;
      }
       this.GetTaxGroupbyId(taxgroupId);
       this.selectedRow=rowIndex;
       this.display_tax = true;
     }
    
    /* Delete row level*/
     deleteItemrowlevel(index: number) {
      if (index >= 0) {
        let row_index:any;
        row_index=index+1;
        if(this.addMode)
        {
          this.debitNotes.debitNoteItem.splice(index, 1);
          this.showAlert("Line no "+ row_index +" deleted successfully");
        }
        else
        {
          this.debitNotes.debitNoteItem[index].deleted=true;
          this.showAlert("Line no "+ row_index +" deleted successfully");
        }
    
      
      }

     this.calculatetotal();
    }
    /* Load standalone item*/
    loadstandaloneitem()
    {
     // this.debitNotes.debitNoteItem=[];
      this.httpService
      .GetAll('/masters-ws/item/find-by-subsidiary?subsidiaryId='+ this.debitNotes.subsidiaryId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          // if (res == true) {
          //   this.showCSTMAlert("Approval send Successfully","success","Success");
          // } else {
          //   this.showAlert(res.errorMessage);
          // }
          if (res) {
           debugger
            this.itemList=res;
          }
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending PO for Approval!'
          );
        }
      );
    }
    OpenAppSequence()
    {
      this.isAppSequenceVisivble=true;
    }
    /* debit note approve function*/
    funapprove()
    {
      try { 
       var approveList:any=[];   
       approveList.push(this.debitNoteId);
        if(approveList.length>0){
        this.showloader = true;
        if(this.RetloginDetails.userType=='SUPERADMIN'){
          this.url='/finance-ws/debitNote/approve-all-debit-note?currentApproverId=' + this.empID;
  
         }
         else if(this.RetloginDetails.userType=='ENDUSER')
         {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                this.url='/finance-ws/debitNote/approve-all-debit-note?currentApproverId=' + this.empID;
              }
              else
              {
                this.url='/finance-ws/debitNote/approve-all-debit-note'
              }
        
         }
        this.httpService.Insert(this.url,approveList,this.RetloginDetails.token).subscribe(
          (res) => {
            if(res.status == 401)
        { 
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { 
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {
    
            if (res.messageCode) {
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );
              this.showloader = false;
            } else {
              this.toastService.addSingle(
                'success',
                'Success',
                'Approve selected Debit-note!'
              );
            //this.loadPRApproval();
            this.showloader = false;
            this.router.navigate(['/main/debit-note/debit-note-approval']);
            }
          }
           // this.loading = false;
          },
          (error) => {
            this.showAlert(error);
            this.showloader = false;
           // this.loading = false;
          }
        );
        }
      } catch (err) {
       
        this.showloader = false;
      }
    }
    /*list button page redirect depends on page */
    gotopage()
    {
     
      if(this.chkId)
      {
        this.router.navigate(['/main/debit-note/debit-note-approval']);
      }
      else
      {
        this.router.navigate(['/main/debit-note/list']);
      }
    }
/*send-for approval */
    senddbForApproval()
    {
      let action: string;
      this.showloader=true;
      this.httpService
        .GetById('/finance-ws/debitNote/send-for-approval?id=' + this.debitNoteId , this.debitNoteId ,this.RetloginDetails.token)
        .subscribe((res) => {
          if(res.status == 401)
        { 
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { 
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {
  
         // this.pr = res;
         if (res == true) {
          this.toastService.addSingle(
            'success',
            'Success',
            'Debit Note Sent for Approval Successfully!'
          );
          this.showloader=false;
          window.location.reload();
         } else {
          this.showAlert(res.errorMessage);
          this.showloader=false;
          //this.router.navigate(['/main/purchases-requisition/action', 'view',this.prId]);
          //this.router.navigate(['/main/purchases-requisition/list']);
  
                // [routerLink]="['/main/purchases-requisition/action/view', item.id]
        
        }
      }
        },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Error',
              'Error occured while sending Debit Note for Approval!'
            );
            this.showloader=false;
          });
    }

  /*self-approval */
    selfApproval() {
      let action: string;
      this.showloader=true;
      this.httpService
        .GetById('/finance-ws/debitNote/self-approve?debitNoteId=' + this.debitNoteId , this.debitNoteId ,this.RetloginDetails.token)
        .subscribe((res) => {
          if(res.status == 401)
        { 
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { 
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {
  
         // this.pr = res;
         if (res == true) {
          this.toastService.addSingle(
            'success',
            'Success',
            'Debit Note Approved Successfully!'
          );
          this.showloader=false;
          window.location.reload();
         } else {
          this.showAlert(res.errorMessage);
          this.showloader=false;
          //this.router.navigate(['/main/purchases-requisition/action', action, this.prId]);
        }
      }
        },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Error',
              'Error occured while sending Debit Note for Approval!'
            );
            this.showloader=false;
          }
        );
    }
    /* open the comments model*/
 Opendialog()
{
  this.display=true;
}
/* close the comments window*/
hidepopup()
{
  this.display=false;
}
hidepopup_tax()
{
  this.display_tax=false;

  this.debitNotes.debitNoteItem[this.selectedRow].taxGroupId=0;
  this.debitNotes.debitNoteItem[this.selectedRow].taxAmount=0;  
  this.debitNotes.debitNoteItem[this.selectedRow].taxAmount="0.00";
  this.debitNotes.debitNoteItem[this.selectedRow].totalAmount=this.debitNotes.debitNoteItem[this.selectedRow].quantity * this.debitNotes.debitNoteItem[this.selectedRow].rate;
  this.display_tax = false;
  this.calculatetotal();
}
/* Reject Individual debit-note from add-edit page*/

funreject()
{
 
  try { 
    if(this.debitNotes.comments=="" || this.debitNotes.comments==undefined)
    {
         this.showAlert("Please enter Comments !");
         return;

    }
    else
    {
      var rejectList:any=[];
      var isrejectComments:boolean=false   
      rejectList.push({id:this.id,rejectedComments:this.debitNotes.comments})
     
        this.showloader = true;
      this.httpService.Insert('/finance-ws/debitNote/reject-all-debitNotes',rejectList,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
  
          if (res.messageCode) {
           this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
            this.showloader = false;
            this.display=false;
          } else {
            this.toastService.addSingle(
              'success',
              'Success',
              'Reject selected Debit-Note!'
            );
            this.display=false;
            this.showloader = false;
            this.router.navigate(['/main/debit-note/debit-note-approval']);
          }
          
         // this.loading = false;
        }
        },
        (error) => {
          this.display=false;
          this.showAlert(error);
          this.showloader = false;
         // this.loading = false;
        }
      );
    }
   
    
    
 
  } catch (err:any) {
    this.showAlert(err);
    this.showloader = false;
  }
}
GetTaxGroupbyId(taxgroupId:any){
  this.httpService.GetById("/setup-ws/tax-group/get?id="+taxgroupId,taxgroupId,this.RetloginDetails.token)
  .subscribe(res => {
    
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
    if (res.error){
      var error = JSON.parse(res.error);
      this.toastService.addSingle(
        'error',
        'Error',
        error.errorMessage
      );
      this.taxgroup = new TaxGroup();
      }else{
       
        this.taxgroup=res;
        this.taxgroup.taxRateRules.map((data:any,index:any)=>{
          this.taxamount=0;
        })
        this.taxgroup.taxRateRules.map((data:any,index:any)=>{
          this.taxamount+=this.taxgroup.inclusive?((((this.debitNotes.debitNoteItem[this.selectedRow].quantity*this.debitNotes.debitNoteItem[this.selectedRow].rate) *100)/(100 + (data.taxRates*1)) * data.taxRates) / 100 ):((parseFloat(this.debitNotes.debitNoteItem[this.selectedRow].rate)*parseFloat(this.debitNotes.debitNoteItem[this.selectedRow].quantity)) * data.taxRates) / 100
        })
      }
    }
    }, error => {
      console.log(error);
     },
     () => {
       // 'onCompleted' callback.
       // No errors, route to new page here
     });
}

taxCodeSave(){
 
  this.display_tax = false;
  this.debitNotes.debitNoteItem[this.selectedRow].taxAmount=this.taxamount.toFixed(2);
  this.taxamount=0;
  this.debitNotes.debitNoteItem[this.selectedRow].totalAmount=(parseFloat(this.debitNotes.debitNoteItem[this.selectedRow].quantity != undefined ?this.debitNotes.debitNoteItem[this.selectedRow].quantity:0)*parseFloat(this.debitNotes.debitNoteItem[this.selectedRow].rate != undefined ?this.debitNotes.debitNoteItem[this.selectedRow].rate:0)).toFixed(2);//added by sdas
  if(this.taxgroup.inclusive){
   
    this.debitNotes.debitNoteItem[this.selectedRow].totalAmount=parseFloat( this.debitNotes.debitNoteItem[this.selectedRow].totalAmount)-parseFloat( this.debitNotes.debitNoteItem[this.selectedRow].taxAmount);
    this.debitNotes.debitNoteItem[this.selectedRow].totalAmount=parseFloat( this.debitNotes.debitNoteItem[this.selectedRow].totalAmount).toFixed(2);
  //////this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount).toFixed(2)
  this.debitNotes.debitNoteItem[this.selectedRow].totalAmount=(parseFloat( this.debitNotes.debitNoteItem[this.selectedRow].totalAmount)+parseFloat( this.debitNotes.debitNoteItem[this.selectedRow].taxAmount)).toFixed(2)
  }else{
    this.debitNotes.debitNoteItem[this.selectedRow].totalAmount=(parseFloat( this.debitNotes.debitNoteItem[this.selectedRow].totalAmount)+parseFloat( this.debitNotes.debitNoteItem[this.selectedRow].taxAmount)).toFixed(2)
  }


  this.calculatetotal();
}

chkenablesingle(index:number)
{
  if(this.debitNotes.debitNoteItem[index].selected==true)
  {
    this.debitNotes.debitNoteItem[index].selected=true;
  }
  else
    {
      this.debitNotes.debitNoteItem[index].selected=false;
    }

 
}
recallStatus(mainId:any)
{
  this.showloader = true;
  this.httpService
    .GetAllResponseText('/finance-ws/debitNote/recall?id=' +mainId, this.RetloginDetails.token)
    .subscribe((res) => {
      //For Auth
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else if (res.status == 200) {
          this.toastService.addSingle(
            'success',
            'Success',
            res.error.text
          );
          this.showloader = false;
          window.location.reload();
      }
      else
      {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      }
    },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      });
}
GetAllProjectList(subsidiaryId:any)
{
  this.httpService.GetById('/masters-ws/project/get-by-subsidiary-id?subsidiaryId=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      
      this.ProjectList=[];
      for(let x=0;x<res.length;x++)
      {
        this.ProjectList.push({
          "id":res[x].id,
          "name":res[x].name
        })
      }
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}

reloadProjectList()
{
   this.ProjectList=[];
   this.GetAllProjectList(this.debitNotes.subsidiaryId);

}


calculateDueAmount(Event: any, rowindex: number) {
  debugger
    if (Event.value != null) {
      this.debitNotes.debitNoteApply[rowindex].applyAmount = Event.value;
    if (this.debitNotes.debitNoteApply[rowindex].applyAmount > this.debitNotes.debitNoteApply[rowindex].amountDue) {
      this.showErrorAmount();
      this.debitNotes.debitNoteApply[rowindex].applyAmount = "0.00";
    }
    else {
      this.debitNotes.debitNoteApply[rowindex].applyAmount =this.debitNotes.debitNoteApply[rowindex].applyAmount ? parseFloat(this.debitNotes.debitNoteApply[rowindex].applyAmount).toFixed(2) : 0;
    }
    var totalApplyAmount = 0;
    this.debitNotes.debitNoteApply.map((data: any, index: any) => {
      if (data.selected) {
        totalApplyAmount += data.applyAmount ? Number(data.applyAmount) : 0;
      }
    })
    
    if (totalApplyAmount != 0) {
      if (totalApplyAmount > Number(this.unappliedAmountCopy)) {
        totalApplyAmount = totalApplyAmount - Number(this.debitNotes.debitNoteApply[rowindex].applyAmount);
        this.showAlert("Total Apply Amount cannot be greater than Unapplied Amount");
        this.debitNotes.unappliedAmount = totalApplyAmount > 0 ? Number(this.unappliedAmountCopy) - totalApplyAmount : this.unappliedAmountCopy;
        this.debitNotes.debitNoteApply[rowindex].applyAmount = null;
        //this.apply[rowindex].applyAmount=undefined;
      }
      else {
        this.debitNotes.unappliedAmount = this.unappliedAmountCopy ? (this.unappliedAmountCopy - totalApplyAmount).toFixed(2) : (this.unappliedAmountCopy - totalApplyAmount).toFixed(2);
      }
    }
    else {
      this.debitNotes.unappliedAmount = this.unappliedAmountCopy;
      this.apply[rowindex].applyAmount = "";
    }


  }
  else {
    var totalApplyAmount = 0;
    this.apply.map((data: any, index: any) => {
      if (data.selected) {
        totalApplyAmount += data.applyAmount ? Number(data.applyAmount) : 0;
      }
    })
    this.debitNotes.unappliedAmount = totalApplyAmount > 0 ? Number(this.unappliedAmountCopy) - totalApplyAmount : this.unappliedAmountCopy;
    //this.aPayemnt.unappliedAmount=this.unappliedAmountCopy;
  }
}

showErrorAmount() {
  this.toastService.addSingle(
    'error',
    'Error',
    'Apply Amount must be smaller than Due Amount!'
  );
}

GetDepartmntbyId(id:number)
{
  debugger
  this.httpService.GetById("/masters-ws/department/get?id="+id, id, this.RetloginDetails.token)
  .subscribe(res => {
    if(res.status == 401)
     { this.showAlert("Unauthorized Access !");
       this.router.navigate(['/login']);
     }
     else if(res.status == 404)
     { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
     else if(res.errorMessage){
      this.showAlert(res.errorMessage)
     }else{
     
    this.department=res.departmentName;

    }
  },
  error => {
   this.showAlert(error);
  },
  () => {
    // 'onCompleted' callback.
    // No errors, route to new page here
  });


}

reloadDepartment()
{

}
GetDepartmentList() {
  debugger
    this.httpService.GetAll('/masters-ws/department/get/all/lov?subsidiaryId='+this.debitNotes.subsidiaryId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.departmentOptions=[];
      Object.keys(res).forEach(key => { 
        this.departmentOptions.push({
            "id":Number(key),
            "departmentName":res[key]
          })   
        });
     // this.departmentOptions = res;
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );
  
  }

loaddepartment()
{
  debugger
          let department:any;
          let isdepartment:boolean=false;
          department=this.debitNotes.debitNoteItem[0].department;
          for(let i=0;i<this.debitNotes.debitNoteItem.length;i++)
          { 
            if(department==this.debitNotes.debitNoteItem[i].department)
            {
               isdepartment=false;
            }
            else
            {
               isdepartment=true;
               break;
            }
          }
          if(isdepartment)
          {
            this.debitNotes.department="All";
            this.debitNotes.departmentId=0;
          }
          else
          {
            this.debitNotes.department=this.debitNotes.debitNoteItem[0].department;
            this.debitNotes.departmentId=this.debitNotes.debitNoteItem[0].departmentId;
          }
          isdepartment=false;
}

loaddepttoline(event:any)
{    
  this.departmentname=event.originalEvent.currentTarget.ariaLabel;
  this.debitNotes.department=event.originalEvent.currentTarget.ariaLabel;

 
 
  if(this.debitNotes.debitNoteItem.length>=1)
  {
    for(let i=0;i<this.debitNotes.debitNoteItem.length;i++)
    {
      this.debitNotes.debitNoteItem[i].department=event.originalEvent.currentTarget.ariaLabel;
      this.debitNotes.debitNoteItem[i].departmentId=this.debitNotes.departmentId;
     }
  }

}

recall()
{
  this.showloader = true;
  this.httpService.GetAll('/finance-ws/debitNote/recall?id='+ this.debitNoteId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.showloader = false;
      this.showSuccessrecall();
      this.router.navigate(['/main/debit-note/list']);
    }
    },
    (error) => {
      this.showloader = false;
      this.showAlert(error);
    }
  );
}
showSuccessrecall() {
  this.toastService.addSingle(
    'success',
    'Success',
    'Recalled Successfully!'
  );
}
GetApplied() {
  this.applied = [];
  this.httpService
    //.GetAll(`/invoice/get-invoice-by-supplier-and-subsidiary?subsidiaryId=${this.aPayemnt.subsidiaryId}&supplierId=${this.aPayemnt.supplierId}`)
    .GetAll("/finance-ws/debitNote/get-debit-note-apply?debitId=" + this.debitNoteId, this.RetloginDetails.token)
    .subscribe((res) => {
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        if (res.status != 500) {
          this.applied = res;
          this.applied=this.applied.filter(x=>x.applyAmount!=0.00 && x.unapllied == false)
        }
      }
    });
}
onUnApply()
{
  let invoiceIdList:any=[];
  

      for(let i=0;i<this.applied.length;i++)
      {
           //if(this.applied[i].selected==true)
          // {
            invoiceIdList.push(this.applied[i].invoiceId);
          // }
      }
      this.showloader = true;
      this.httpService.GetAll('/finance-ws/debitNote/debit-note-unapply?debitId=' + this.debitNoteId + '&invoiceId='+invoiceIdList, this.RetloginDetails.token)  
      .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res) {
              this.showloader = false;
              this.showSuccessvoid();
              this.router.navigate(['/main/debit-note/list']);
            }
            else {
              this.showloader = false;
              this.showErrorVoid();
            }
          }
        });




}
showSuccessvoid() {
  this.toastService.addSingle(
    'success',
    'Success',
    'Debit Note Unapply successfully!'
  );
}
showErrorVoid() {
  this.toastService.addSingle(
    'error',
    'Error',
    'Error occured while Unapply Debit Note!'
  );
}
chkenableunapplysingle(index:any)
{
  if (this.applied[index].selected == true) {
  
      this.hideunapply=false;
  }
  else
  {
    this.hideunapply=true;
  }
}

}
