import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DabitNoteAddEditComponent } from './dabit-note-add-edit.component';

describe('DabitNoteAddEditComponent', () => {
  let component: DabitNoteAddEditComponent;
  let fixture: ComponentFixture<DabitNoteAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DabitNoteAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DabitNoteAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
