import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DabitNoteListComponent } from './dabit-note-list.component';

describe('DabitNoteListComponent', () => {
  let component: DabitNoteListComponent;
  let fixture: ComponentFixture<DabitNoteListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DabitNoteListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DabitNoteListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
