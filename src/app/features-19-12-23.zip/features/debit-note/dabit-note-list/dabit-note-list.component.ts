import { Component, OnInit,LOCALE_ID, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch, SubsidiaryEntry, Supplier } from '../../supplier/model/supplier-model';
import { debitNote,BaseSearchPdf } from '../model/debit-note-model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as FileSaver from 'file-saver';
import {formatDate } from '@angular/common';

@Component({
  selector: 'app-dabit-note-list',
  templateUrl: './dabit-note-list.component.html',
  styleUrls: ['./dabit-note-list.component.scss']
})
export class DabitNoteListComponent implements OnInit {
  subsidiary:any;
  potype:any;
  vendor:any;
  columns: any[];
  departments: any[] = [];
  debitNotelist: debitNote[] = [];
  selectedDebitNote: debitNote = new debitNote();
  debitNotes: debitNote = new debitNote();
  totalRecords: number = 0;
  loading: boolean = false;
  exportColumns: any[];
  newevent:any;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  debitnotesPrint: any[] = [];
  taxType:any;
  statusOptions:any;
  baseSearch: BaseSearch = new BaseSearch();
  Subsidiarylist: any[] = [];
  Subsidiaryselect: any[] = [];
  supplierlist:Supplier[] = [];
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  // For Role Base Access
  RetloginDetails:any;
  showloader:boolean;
  SubIdList:any=[];
  RetRoleDetails:any;
  issubsidiaryhidd:boolean=false;
  issubsidiarydis:boolean=false;
  constructor( private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService,
    private primengConfig: PrimeNGConfig,@Inject(LOCALE_ID) public locale: string) { 
    }
     /* */
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
     const retDetails:any = localStorage.getItem("RoleDTLS");
     var role_Dtls = JSON.parse(retDetails);
     this.RetRoleDetails=role_Dtls;

     const LDetails:any=localStorage.getItem("LoggerDTLS");
     this.RetloginDetails = JSON.parse(LDetails);
      for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
     {
       if(role_Dtls[0].rolePermissions[i].accessPoint == "Purchase Order")
       {
         this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
         this.isEditable=role_Dtls[0].rolePermissions[i].edit;
         this.isViewtable=role_Dtls[0].rolePermissions[i].view;
       }
     }
 // End For Role Base Access
    this.GetSubsideryList();
    this.GetSupplierList();
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
      { field: 'Id', header: 'Internal ID' },
      { field: 'Subsidiary', header: 'Subsidiary' },
      { field: 'Debit Note Type', header: ' Debit Note Type' },
      { field: 'Debit Note Date', header: 'Debit Note Date' },
      { field: 'Debit Note Number', header: 'Debit Note Number' },
      { field: 'Supplier', header: 'Supplier' },
      { field: 'RTV Reference Number', header: 'RTV Reference Number' },
      { field: 'Amount', header: 'Amount' },
     ];
     this.statusOptions = ['Draft', 'Pending Approval', 'Partially Approved', 'Approved', 'Rejected', 'Partially Processed', 'Processed'];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }
 /* exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.debitNotelist);
            doc.save('DebitNote.pdf');
        })
    })
}*/
   /* navigate to add-edit page*/
navigateToAddViewEdit(
  action: string,
  selecteDebit: debitNote = new debitNote()
) {
  let debitId = null;
  if (selecteDebit?.id) {
    debitId = selecteDebit.id;
    this.router.navigate(['/main/debit-note/action', action, debitId]);
  } else {
    this.router.navigate(['/main/debit-note/action', action]);
  }
}
   /*reset base search */
resetBaseSearch() {
  this.baseSearch.filters = {subsidiaryId: this.SubIdList};
  this.baseSearch.pageNumber = 0;
  this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
  this.baseSearch.sortColumn = GlobalConstants.DEBIT_NOTE_TABLE_SORT_COLUMN;
  this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
  this.loadDebit(this.newevent);
}
   /* load list*/
loadDebit(event: any) {
  try {
    this.newevent=event
    this.loading = true;
    //this.baseSearch.pageNumber = event.first / event.rows;
    this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
    // this.baseSearch.pageNumber = 1;
    this.baseSearch.pageSize = event.rows;
    // this.baseSearch.sortColumn = event.sortField
    //   ? 's.' + event.sortField
    //   : GlobalConstants.SUPPLIER_TABLE_SORT_COLUMN;
    this.baseSearch.sortColumn = event.sortField
    ?  event.sortField
    : GlobalConstants.DEBIT_NOTE_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder =
      event.sortOrder == -1
        ? GlobalConstants.ASCENDING
        : GlobalConstants.DESCENDING;
        if(this.SubIdList.length==0)
          {
           return;
          }
    this.HttpService.Insert('/finance-ws/debitNote/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res && res.list.length > 0) {
            this.debitNotelist = res.list;
            
            this.totalRecords = res.totalRecords;
            
          for(let x=0;x<this.debitNotelist.length;x++) {
            if( this.debitNotelist[x].approvalStatus == 'Pending Approval' || this.debitNotelist[x].approvalStatus == 'Partially Approved' || this.debitNotelist[x].approvalStatus == 'Approved'|| this.debitNotelist[x].approvalStatus == 'Rejected' || this.debitNotelist[x].approvalStatus == 'Closed'|| this.debitNotelist[x].approvalStatus == 'Partially Received'|| this.debitNotelist[x].approvalStatus == 'Received' || this.debitNotelist[x].approvalStatus == 'Partially Billed'|| this.debitNotelist[x].approvalStatus == 'Billed') //Send Approval Mode
            {
              this.debitNotelist[x].isApprovalButtonShowHide = 0;
            }
            else{
              this.debitNotelist[x].isApprovalButtonShowHide = 1;
            }
          }
          } else {
            this.debitNotelist = [];
          }
          this.loading = false;
        }
          
      },
      (error) => {
       this.loading = false;
      }
    );
  } catch (err) {
   }
}
/* Start fetch filter list of debit-note from api */
findby(event: any){
  let subsidyList:any=[];
    subsidyList.push(this.debitNotes.subsidiaryId);

  let Fromdays: any = new Date(this.debitNotes.fromDate).getUTCDate();
  let Frommonths: any = new Date(this.debitNotes.fromDate).getUTCMonth() + 1;
  let Fromyear: any = new Date(this.debitNotes.fromDate).getUTCFullYear();
  let Todays: any = new Date(this.debitNotes.toDate).getUTCDate();
  let Tomonths: any = new Date(this.debitNotes.toDate).getUTCMonth() + 1;
  let Toyear: any = new Date(this.debitNotes.toDate).getUTCFullYear();

 this.baseSearch.filters={
  subsidiaryId:subsidyList,
  supplierId:this.debitNotes.supplierId,
  fromDate:this.debitNotes.fromDate !== undefined ? (Fromyear + '-' + (Frommonths.toString().length == 1 ? "0" + Frommonths : Frommonths) + '-' + (Fromdays.toString().length == 1 ? "0" + Fromdays : Fromdays)) : null,
  toDate:this.debitNotes.toDate !== undefined ? (Toyear + '-' + (Tomonths.toString().length == 1 ? "0" + Tomonths : Tomonths) + '-' + (Todays.toString().length == 1 ? "0" + Todays : Todays)) : null,
  status:this.debitNotes.status,
  debitNoteNumber:this.debitNotes.debitNoteNumber

 }
 this.baseSearch.pageNumber=-1;
  this.loadDebit(this.newevent);
}
/* End filter list of Subsidiary from api */
GetSubsideryList() {
  if(this.RetloginDetails.userType=='SUPERADMIN')
  //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
  {
    this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
  //this.HttpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
    (res) => {
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        this.Subsidiarylist = res;
        for(let x=0;x<this.Subsidiarylist.length;x++)
        { 
         this.SubIdList.push(this.Subsidiarylist[x].id);
        }
        this.issubsidiaryhidd=false;
        this.issubsidiarydis=false;
      }
    },
    (error) => {
     },
     () => {
      if(localStorage.getItem("DebitNoteFilters") != null)
      {const LocDetails:any =localStorage.getItem("DebitNoteFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.debitNotes.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.GetSupplierList();
      this.debitNotes.supplierId=searcheData.filters.supplierId;
      this.debitNotes.status=searcheData.filters.status;
      this.debitNotes.debitNoteNumber=searcheData.filters.debitNoteNumber;
      this.debitNotes.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
      this.debitNotes.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.loadDebit(this.newevent);
     
    
      localStorage.removeItem("DebitNoteFilters");
      }
      else
     { this.resetBaseSearch();}
    }
  );
}else if(this.RetloginDetails.userType=='ENDUSER'){
  this.Subsidiarylist.push({
    id:this.RetRoleDetails[0].subsidiaryId,
    name:this.RetRoleDetails[0].subsidiaryName
  });
this.debitNotes.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
this.GetSupplierList();
  this.issubsidiaryhidd=true;
  this.issubsidiarydis=true;
  this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
  if(localStorage.getItem("DebitNoteFilters") != null)
      {
	  const LocDetails:any =localStorage.getItem("DebitNoteFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.debitNotes.supplierId=searcheData.filters.supplierId;
      this.debitNotes.status=searcheData.filters.status;
      this.debitNotes.debitNoteNumber=searcheData.filters.debitNoteNumber;
      this.debitNotes.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
      this.debitNotes.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.loadDebit(this.newevent);
      localStorage.removeItem("DebitNoteFilters");
      }
      else
     { this.resetBaseSearch();}
}
}
/* start get Get Supplier list */



GetSupplierList() {
  this.HttpService
    .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + this.debitNotes.subsidiaryId, this.debitNotes.subsidiaryId, this.RetloginDetails.token)
    .subscribe((res) => {
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        this.supplierlist = res;
      }
    });

   
}

   /* reset the page*/
Reset()
{
  if(this.RetloginDetails.userType=='SUPERADMIN')
  {
    this.debitNotes.subsidiaryId=0;
  }
  this.debitNotes.supplierId=0;
  this.debitNotes.fromDate=undefined;
  this.debitNotes.toDate=undefined;
  this.debitNotes.status=undefined;
  this.debitNotes.debitNoteNumber=undefined;
  //this.findby("");
  this.resetBaseSearch();
  this.baseSearch.pageNumber=-1;
  this.loadDebit(this.newevent);
}
/* end get Get Supplier list */
showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}

selfApproval(id:any){
  this.showloader=true;
this.HttpService
  .GetById('/finance-ws/debitNote/self-approve?debitNoteId=' + id, id,this.RetloginDetails.token)
  .subscribe((res) => {
    
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
   if (res == true) {
    this.showloader=false;
    location.reload();
    this.toastService.addSingle(
      'success',
      'Success',
      'Debit-Note Approved Successfully!'
    );
   } else {
    this.showloader=false;
    this.showAlert(res.errorMessage);
  }
}
  },
  
    (error) => {
      this.toastService.addSingle(
        'error',
        'Error',
        'Error occured while sending Debit-Note for Approval!'
      );
      this.showloader=false;
    }

  );
}

sendForApproval(id:any){
  this.showloader=true;
this.HttpService
    .GetById('/finance-ws/debitNote/send-for-approval?id=' + id, id,this.RetloginDetails.token)
    .subscribe((res) => {
      
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        if (res == true) {
          location.reload();
          this.showloader=false;
          this.toastService.addSingle(
            'success',
            'Success',
            'Debit-Note Sent for Approval Successfully!'
          );
        } else {
          this.showloader=false;
          this.showAlert(res.errorMessage);
        }
      }
    },
      (error) => {
        this.showloader=false;
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured while sending Debit-Note for Approval!'
        );
      }

    );
}
editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("DebitNoteFilters") != null)
    {
      localStorage.removeItem("DebitNoteFilters");
    }
    localStorage.setItem("DebitNoteFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/debit-note/action', actionType, mainId,0]);
   }

     /***((Export Excel)) */
     generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.DEBIT_NOTE_TABLE_SORT_COLUMN;
      this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
  
      this.HttpService.Insert('/finance-ws/debitNote/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.debitnotesPrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {

                if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){ 

     

                  this.debitnotesPrint.push({
                    'Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'Debit Note Type':RetData[i].returnType,
                    'Debit Note Date': formatDate(RetData[i].debitNoteDate, 'dd-MM-yyyy' ,this.locale).toString(),
                    'Debit Note Number': RetData[i].debitNoteNumber,
                    'Supplier': RetData[i].supplierName,    
                    'RTV Reference Number':RetData[i].rtvNumber, 
                    'Amount': RetData[i].totalAmount,
  
                    // 
                    
                });
              }
                else{
                  this.debitnotesPrint.push({
                    'Internal Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'Debit Note Type':RetData[i].returnType,
                    'Debit Note Date': formatDate(RetData[i].debitNoteDate, 'dd-MM-yyyy' ,this.locale).toString(),
                    'Debit Note Number': RetData[i].debitNoteNumber,
                    'Supplier': RetData[i].supplierName,    
                    'RTV Reference Number':RetData[i].rtvNumber, 
                    'Amount': RetData[i].totalAmount,
                                  
                  });
                }
  
              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    exportPdf() {
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          //this.= this.employeeExport;
          //this.employeelist=[];
          (doc as any).autoTable(this.exportColumns, this.debitnotesPrint);
          doc.save('debit-note.pdf');
        })
      })
    }
  
  //End PDF
  
  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');
  
   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.debitnotesPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.debitnotesPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'debit-note');
           this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
  //End Excel 
    //List Export option End
  
     /********Export excel */

     onRowSelect(event: any) {
      let dnId = event.data.id;
      
      this.router.navigate(['/main/debit-note/action/view', dnId, 0]);
    }


}

