
export class DebitNoteItem {
    id?: number;
    debitNoteId?: number;
    debitNoteNumber?: string;
    itemId?: number;
    itemName?: string;
    itemDescription?: string;
    glCode?: string;
    quantity?: any;
    returnquantity?: number;
    rate?: any;
    basicAmount?: any;
    taxGroupId?: number;
    taxAmount?: any;
    totalAmount?: any;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    taxName?: any;
    deleted?: boolean;
    selected?:boolean=false;
    departmentId?:number;
    department?:any;
   
}

export class debitNote {
    id: number;
    debitNoteNumber: any;
    subsidiaryId: number;
    supplierId: number;
    debitNoteDate?: any;
    rtvId: any;
    rtvNumber: string;
    rtvid:number;
    grnNumber: any;
    invoiceNumber: string;
    currency: string;
    exchangeRate: any;
    memo: string;
    approvalStatus?: any;
    createdDate: Date;
    createdBy: string;
    lastModifiedDate: Date;
    lastModifiedBy: string;
    debitNoteItem: DebitNoteItem[]=[];
    debitNoteApply:debitNoteApply[]=[];
    approvers:approvers[]=[];
    subsidiaryName?: any;
    supplierName?: any;
    deleted: boolean;
    amount?:any;
    taxAmount?:any;
    totalAmount?:any;
    returnType:string;
    unappliedAmount:any;
    approvalRoutingActive:any;
    fromDate:any;
    toDate:any;
    status:any;
    comments:any;
    isApprovalButtonShowHide?: any;
    projectId?:number;
    department?:any;
    departmentId?:number;
  
}

export class RtvreferenceCopy
{
    id:number;
    rtvNumber:string;
}



export class ApplyModel {
    invoiceId: number;
    supplierId: number;
    debitNoteId: number;
    subsidiaryId: number;
    poId?: number;
    locationId?: number;
    invoiceNo?: any;
    invStatus: string;
    paymentTerm: string;
    integratedId?: any;
    currency: string;
    billTo: string;
    shipTo: string;
    invoiceCode: string;
    invoiceDate: Date;
    dueDate?: any;
    fxRate: number;
    amount: number;
    taxAmount: any;
    totalAmount: any;
    paymentAmount: number;
    amountDue: any;
    approvedBy: string;
    nextApprover?: any;
    nextApproverRole?: any;
    nextApproverLevel?: any;
    approverPreferenceId?: number;
    approverSequenceId?: number;
    approverMaxLevel: string;
    noteToApprover?: any;
    subsidiaryName?: any;
    supplierName?: any;
    invoiceItems?: any;
    totalPaidAmount: number;
    invoicePayments?: any;
    createdBy: string;
    lastModifiedBy: string;
    createdDate: Date;
    lastModifiedDate: Date;
    approvalRoutingActive: boolean;
    selected:boolean;
    applyDate:any;
    applyAmount:any;

}



export class debitNoteApply
    {
        id?:number;
        debitNoteId?:number;
        debitNoteNumber?:string;
        invoiceId?:number;
        applyDate?:any;
        curency?:string;
        invoiceNumber?:string;
        invoiceAmount?:string;
        applyAmount:any;
        amountDue:any;
        createdDate?: Date;
        createdBy?: string;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        taxName?: string;
        deleted?:boolean;
        selected:boolean=false;
    }

    export class approvers{
        id?:any;
        name?:any;
    }

export class debit_note_approval
{
amount: number;
approvalRoutingActive: boolean;
approvalStatus: string;
approvedBy: string;
approvedByName: string;
approverMaxLevel: string;
approverPreferenceId: number;
approverSequenceId: number;
createdBy: string;
createdDate: any;
currency: string;
debitNoteApply: string;
debitNoteDate: any;
debitNoteItem: string;
debitNoteNumber: string;
deleted: boolean
exchangeRate: string;
grnNumber: string;
id: number;
integratedId: number;
invoiceNumber: string;
lastModifiedBy: string;
lastModifiedDate: any;
memo: string;
nextApprover: string;
nextApproverLevel: string;
nextApproverRole: string;
nextApproverUid: number;
noteToApprover: string;
nsMessage: string;
nsStatus: string;
rejectedComments: any;
returnType: string;
rtvNumber: string;
subsidiaryId: number;
subsidiaryName: string;
supplierId: number;
supplierName: string;
taxAmount: string;
totalAmount: string;
selected?:boolean;
roleName:any;
}
 // Base seach model for Supplier
 export class BaseSearchPdf {
    filters: debit_Note_export | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

  //this class holds the custom filter values at component level.
export class debit_Note_export {
    subsidiary: string = '';
    vendorname: string = '';
    vendornumber: string = '';
    vendortype: string = '';
    pan: string = '';
    active: string = '';
  }

  export class unapply
  {
    id:number;
    debitNoteId:number;
    debitNoteNumber:string;
    invoiceId:number;
    applyDate:Date;
    curency:string;
    invoiceNumber:string;
    invoiceAmount:string;
    applyAmount:any;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    taxName: string;
    amountDue:any;
    invoiceDate:Date;
    invAmount:any;
    deleted:boolean;
    unapllied:boolean;
    selected?:boolean=false;
  }  