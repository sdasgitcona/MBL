import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { debit_note_approval } from '../model/debit-note-model';

@Component({
  selector: 'app-debit-note-approval',
  templateUrl: './debit-note-approval.component.html',
  styleUrls: ['./debit-note-approval.component.scss']
})
export class DebitNoteApprovalComponent implements OnInit {
  columns: any[];
  totalRecords: number = 0;
  AllSelected: boolean = false;
  showloader:boolean=false;
  departments: any[] = [];
  loading: boolean = false;
  isRejectPressed: boolean = true;
  approvalRoutingActive: boolean = false;
  debitnoteApprovalModel: debit_note_approval[] = [];
  selecteddebitnoteApproval: debit_note_approval = new debit_note_approval();
  approverRoleList: [{ id?: number; name?: string; }];
  SubsidiaryId: any;
  roleId: any;
  url:any;
  empID: number;
  userRoleId: number;
  @ViewChild('dt') dt: Table;
  userId: number;
  RetloginDetails: any;
  RetRoleDetails: any;
  IsLoggerAdmin:any;
  visibleSaveButton:boolean;
  constructor( private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService) { }

  ngOnInit(): void {
    if (localStorage.getItem("LoggerDTLS") == null) {
      this.router.navigate(['/login']);
    }
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    //--Login Details
    const logDetails: any = localStorage.getItem("LoggerDTLS");
    const LoggerId = JSON.parse(logDetails);
    this.empID = LoggerId.employeeId;
    const retLoggerDetails: any = localStorage.getItem("LoggerDTLS");
    var logger_Dtls = JSON.parse(retLoggerDetails);
    this.userId = logger_Dtls.id;
    // For Role ID
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails = role_Dtls;
    this.IsLoggerAdmin=role_Dtls[0].selectedAccess;

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "PO Approval") {
        this.userRoleId = role_Dtls[0].rolePermissions[i].roleId
      }
    }
    this.loadDebitNoteApproval();
  }
   /* search globally*/
  globalSearch(event: any) {
    this.dt.filterGlobal(event.target.value, 'contains')
  }
   /* Load approval list*/
  loadDebitNoteApproval() {
    try {
      let ReqData;
      let ReqParam;
      let ReqDataa;
      let ReqParama;
      let reqUrl:any='';
      //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null) //--User:Super Admin
      if(this.RetloginDetails.userType=='SUPERADMIN')
      {
        ReqData=this.RetRoleDetails[0].accountId;
        ReqParam='accountId';
        
       // reqUrl='/procure-ws/rtv/approval-list?'+ReqParam+'=' + ReqData;
       reqUrl='/finance-ws/debitNote/get-debit-note-appoval?'+ReqParam+'=1bbc34bb6d0d4f';
      }
      //else if((this.RetRoleDetails[0].selectedAccess == 'ADMIN'|| this.RetRoleDetails[0].selectedAccess == 'ADMIN_APPROVER') && this.RetRoleDetails[0].subsidiaryId != null) //--User:Admin
      else if(this.RetloginDetails.userType=='ENDUSER')
      {
        if( this.RetRoleDetails[0].selectedAccess == 'APPROVER')
        {
          ReqData=this.empID;
          ReqParam='userId';
          ReqDataa=this.RetRoleDetails[0].subsidiaryId;
          ReqParama = 'subsidiaryId';
          reqUrl='/finance-ws/debitNote/get-debit-note-appoval?'+ReqParam+'=' + ReqData+'&' +ReqParama+'=' + ReqDataa;
        }
        else
        {
          ReqData=this.RetRoleDetails[0].subsidiaryId;
          ReqParam='subsidiaryId';
          reqUrl='/finance-ws/debitNote/get-debit-note-appoval?'+ReqParam+'=' + ReqData;
        }
      }
      else //--User:Others
      {
        ReqData=this.empID;
        ReqParam='userId'
        reqUrl='/finance-ws/debitNote/get-debit-note-appoval?'+ReqParam+'=' + ReqData;
      }
         this.HttpService.GetAll(reqUrl, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else if (res && res.length > 0) {
            for (let i = 0; i < res.length; i++) {
              this.NextApproverLov(res[i].subsidiaryId)
            }
            this.debitnoteApprovalModel = res;
            this.totalRecords = res.length;
            //this.debitnoteApprovalModel.isAdminRole=(this.IsLoggerAdmin=="ADMIN" || this.IsLoggerAdmin=="ADMIN_APPROVER")?true:false;
           // this.SubsidiaryId = this.supplierApprovalList[0]?.subsidiaryId;
         /*   this.supplierApprovalList.map((data:supplierApprovalModel)=>{
             data.isAdminRole=(this.IsLoggerAdmin=="ADMIN" || this.IsLoggerAdmin=="ADMIN_APPROVER")?false:true;
              data.isAdminRole=(this.IsLoggerAdmin=="ADMIN" || this.IsLoggerAdmin=="ADMIN_APPROVER")?true:false;

            data.isAdminForSave=true;
            data.nextApprover=Number(data.nextApprover)
            })*/

            setTimeout(() => {
             // this.NextApproverLov();
            }, 250);
           

            //this.supplierApprovalList[0].isAdminRole=this.IsLoggerAdmin=="ADMIN"?false:true;
            
          } else {
            //this.supplierApprovalList = [];
            this.totalRecords = res.length;

          }
          this.loading = false;
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {
    }
  }

  showAlert(AlertMSG: any) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
   /*Mark all button  */
  onAllSelectChange(event: any) {
    if (event.checked) {
      this.debitnoteApprovalModel.map((data: debit_note_approval) => {
        data.selected = true;
        this.isRejectPressed = true
        //this.approvalRoutingActive=true;
      })
    }
    else {
      this.debitnoteApprovalModel.map((data: debit_note_approval) => {
        data.selected = false;
        this.isRejectPressed = true;
        // this.approvalRoutingActive=false;

      })
    }
  }
     /*approve multiple */
  approvedebitnote()
  {
    try {
      this.isRejectPressed = false
      var approveList: any = [];
      this.debitnoteApprovalModel.map((data: debit_note_approval) => {
        if (data.selected) {
          approveList.push(data.id)
        }
      })
      if (approveList.length > 0) {
        this.showloader = true;
        if(this.RetloginDetails.userType=='SUPERADMIN'){
          this.url='/finance-ws/debitNote/approve-all-debit-note?currentApproverId=' + this.empID;
  
         }
         else if(this.RetloginDetails.userType=='ENDUSER')
         {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                this.url='/finance-ws/debitNote/approve-all-debit-note?currentApproverId=' + this.empID;
              }
              else
              {
                this.url='/finance-ws/debitNote/approve-all-debit-note'
              }
        
         }


        this.HttpService.Insert(this.url, approveList, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );

            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Approve selected debit-note!'
              );
              this.loadDebitNoteApproval();
            }
            // this.loading = false;
          },
          (error) => {
          }
        );
      }
    } catch (err) {
    }
  }
     /*reject multiple */
  rejectdebitnote()
  {
    try {
      if (this.isRejectPressed) {
        var rejectList: any = [];
        var isrejectComments: boolean = false
        this.debitnoteApprovalModel.map((data: debit_note_approval) => {
          if (data.selected) {
            if (data.rejectedComments) {
              rejectList.push({ id: data.id, rejectComments: data.rejectedComments })
              isrejectComments = true;
              this.isRejectPressed = true

            } else {
              this.toastService.addSingle(
                'error',
                'Error',
                'Please enter Reject Comments'
              );
              isrejectComments = false;
              this.isRejectPressed = true
              return;
            }
          }
        })
        if (isrejectComments) {
          this.showloader = true;
          this.HttpService.Insert('/finance-ws/debitNote/reject-all-debitNotes', rejectList, this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else if (res.messageCode) {
                this.showloader = false;
                this.isRejectPressed = true
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );

              }
              else {
                this.showloader = false;
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Reject selected Debit-Note!'
                );
                this.loadDebitNoteApproval();
              }
              this.isRejectPressed = true
            },
            (error) => {
            }
          );
        }
      } else {
        this.toastService.addSingle(
          'error',
          'Error',
          'Please enter Reject Comments'
        );
        this.isRejectPressed = true;
        this.showloader = false;
      }
    } catch (err) {
    }
  }
     /*approve individual */
  approveIndividual(mainId:any)
  {
    try {
      this.isRejectPressed = true
      var approveList: any = [];
      approveList.push(mainId);

      if (approveList.length > 0) {
        this.showloader = true;
        if(this.RetloginDetails.userType=='SUPERADMIN'){
          this.url='/finance-ws/debitNote/approve-all-debit-note?currentApproverId=' + this.empID;
  
         }
         else if(this.RetloginDetails.userType=='ENDUSER')
         {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                this.url='/finance-ws/debitNote/approve-all-debit-note?currentApproverId=' + this.empID;
              }
              else
              {
                this.url='/finance-ws/debitNote/approve-all-debit-note'
              }
        
         }
        //this.HttpService.Insert('/masters-ws/supplier/approve-all-supplier', approveList, this.RetloginDetails.token).subscribe(
          this.HttpService.Insert(this.url,approveList,this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );

            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Approve selected Debit-Note!'
              );
              this.loadDebitNoteApproval();
            }
            // this.loading = false;
          },
          (error) => {
            this.showAlert(error);
          }
        );
      }
    } catch (err) {
    }
  }
     /* reject individual*/
  rejectIndividual(mainId:any,rejectComments:any,RowNo:any)
  {
   try {
      this.debitnoteApprovalModel[RowNo].selected=true;
      this.isRejectPressed=true;

      if( this.debitnoteApprovalModel[RowNo].rejectedComments==undefined)
      {
        this.showAlert("Please enter Reject Comments");
        return true;
      }

      if (this.isRejectPressed) {
        var rejectList: any = [];
        var isrejectComments: boolean = false;
        rejectList.push({id:mainId,rejectedComments:this.debitnoteApprovalModel[RowNo].rejectedComments})
              isrejectComments = true;
              this.isRejectPressed = true
         if (isrejectComments) {
          this.showloader = true;
          //this.HttpService.Insert('/masters-ws/supplier/reject-all-supplier', rejectList, this.RetloginDetails.token).subscribe(
            this.HttpService.Insert('/finance-ws/debitNote/reject-all-debitNotes',rejectList,this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else if (res.messageCode) {
                this.showloader = false;
                this.isRejectPressed = true
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );
                this.debitnoteApprovalModel[RowNo].selected=false;
                this.isRejectPressed=true;
                isrejectComments=false;
                this.debitnoteApprovalModel[RowNo].rejectedComments=undefined;
              }
              else {
                this.showloader = false;
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Reject selected Debit-Note!'
                );
                this.loadDebitNoteApproval();
              }
              this.isRejectPressed = true
              // this.loading = false;
            },
            (error) => {
            }
          );
        }
      } else {
        this.showAlert("Please enter Reject Comments");
        this.isRejectPressed = true;
        this.showloader = false;
      }
    } catch (err) {
      this.showAlert(err);
    }
  }

  NextApproverLov(subId: any) {
    try {

      if(this.RetloginDetails.userType=='SUPERADMIN'){
        this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + subId + '&formName=Debit Note Approval';

       }
       else if(this.RetloginDetails.userType=='ENDUSER')
       {
          if(this.RetRoleDetails[0].selectedAccess=="ADMIN"|| this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
          {
            this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + subId + '&formName=Debit Note Approval';
          }
          else
          {
            this.url='/masters-ws/employee/get-by-role-subsidiary?roleId=' + this.userRoleId + '&subsidiaryId=' + subId + '&formName=Debit Note Approval';
          }
        
       }

      this.HttpService.GetAll(this.url, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.length > 0) {
              this.approverRoleList = res;
              // this.totalRecords = res.length;
            } else {
              this.approverRoleList = [{}];
            }
            this.loading = false;
          }
        },
        (error) => {
          this.showAlert(error);
          this.loading = false;
        }
      );
    } catch (err) {
      this.showAlert(err);
    }
  }

  OnChangeVisibleButton(row:any,)
  {
   if(this.IsLoggerAdmin=="ADMIN")
   {
      if(this.debitnoteApprovalModel[row].selected)
      {
        //this.supplierApprovalList[row].isAdminForSave=false;
        this.visibleSaveButton=true;
      }
   }
  }
  
  cancel()
  {
    window.location.reload();
  }

  onApproverSave() {
    try {
      let selectedDN;
      let selectedapprover;
      for(let x=0;x<this.debitnoteApprovalModel.length;x++)
      {
        if(this.debitnoteApprovalModel[x].selected)
      {
        selectedDN=this.debitnoteApprovalModel[x].id;
        selectedapprover=this.debitnoteApprovalModel[x].nextApprover
        break;
      }
      }
      this.HttpService.GetAll(`/finance-ws/debitNote/update-next-approver?debitNoteId=${selectedDN}&approverId=${selectedapprover}`, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          } else if (res == true) {
            this.showloader = false;
            this.toastService.addSingle(
              'success',
              'Success',
              'saved selected Debit-Note!'
            );
            window.location.reload();
            //this.loadSuppliersApproval();
          } 
        },
        (error) => {
        }
      );
    } catch (err) {
    }
  }

}
