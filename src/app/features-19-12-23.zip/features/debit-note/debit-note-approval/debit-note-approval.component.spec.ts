import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DebitNoteApprovalComponent } from './debit-note-approval.component';

describe('DebitNoteApprovalComponent', () => {
  let component: DebitNoteApprovalComponent;
  let fixture: ComponentFixture<DebitNoteApprovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DebitNoteApprovalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DebitNoteApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
