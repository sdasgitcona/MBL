import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DabitNoteAddEditComponent } from './dabit-note-add-edit/dabit-note-add-edit.component';
import { DabitNoteListComponent } from './dabit-note-list/dabit-note-list.component';
import { DebitNoteApprovalComponent } from './debit-note-approval/debit-note-approval.component';
const routes: Routes = [
  {
    path: '',
    component: DabitNoteListComponent,
  },
  {
    path: 'list',
    component: DabitNoteListComponent,
  },
  {
    path: 'action/:action/:id/:chkid',
    component: DabitNoteAddEditComponent,
  },
  {
    path: 'action/:action',
    component: DabitNoteAddEditComponent,
  },
  {
    path: 'debit-note-approval',
    component: DebitNoteApprovalComponent,
  },
  {
    path: 'debit-note-approval/:status',
    component: DebitNoteApprovalComponent,
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DebitNoteRoutingModule { }
