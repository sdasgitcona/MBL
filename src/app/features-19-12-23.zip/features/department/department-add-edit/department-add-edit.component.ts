import { Component, OnInit } from '@angular/core';
import { flush } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { department } from '../model/department-module';

@Component({
  selector: 'app-department-add-edit',
  templateUrl: './department-add-edit.component.html',
  styleUrls: ['./department-add-edit.component.scss']
})
export class DepartmentAddEditComponent implements OnInit {
  columns: any[];
  department: department = new department();
  departmentlist:department[]=[];
  departmentId: number = 0;
  private subscription: any;
  viewMode: boolean = false;
  itcdis :boolean = false;
  addMode: boolean = false;
  vatMode: boolean = false;
  tdsMode: boolean = false;
  editMode: boolean = false;
  exportColumns: any[];
  RetRoleDetails:any;
  isReloadSub:boolean;
  showloader: boolean=false;
  Subsidiarylist:any=[]=[];
  ParentDepartmentlist:any=[]=[];
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   isviewEditable:boolean=true;
   // For Role Base Access
   RetloginDetails: any;
   departmentHistoryList: HistoryModel[] = [];
  constructor(  private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,) { }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;
 const LDetails: any = localStorage.getItem("LoggerDTLS");
 this.RetloginDetails = JSON.parse(LDetails);
 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Department")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.departmentId = +params['id']; // (+) converts string 'id' to a number
            
            this.GetDepartmntbyId();
            this.LoadHistory();
          }
          this.GetSubsideryList();
          this.assignMode(params['action']);       
         
          
        } else {
          console.log('cannot get params');
        }
      },
      (error) => {
        console.log('add');
      }
    );

  }

  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;

      default:
        break;
    }
  }


  reloadSubidery()
  {
    this.department.subsidiaryId=0;
     this.Subsidiarylist=[];
     this.GetSubsideryList();

   
  }
  clearDepartment()
  {
      this.router.navigate(['/main/department/list']);
  }

  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 0) {
      this.LoadHistory();
    }
  }

  LoadHistory()
  {
    if (this.departmentHistoryList.length == 0)
    this.httpService.GetById(`/masters-ws/department/get/history?id=${this.departmentId}&pageSize=100`,
        this.departmentId, this.RetloginDetails.token
      )
      .subscribe((res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
       else { this.departmentHistoryList = res;}
      });
  }

  GetSubsideryList() {
    this.Subsidiarylist=[];
   
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { 
        this.Subsidiarylist=res;

      }
      },
      (error) => {
        
       },
       ()=>{

       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
     
    }
  }

  GetParentDepartment() {
   
     this.httpService.GetAll('/masters-ws/department/get-parent-department-names?subsidiaryId='+this.department.subsidiaryId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { 
        this.ParentDepartmentlist=res;

       }
      },
      (error) => {
        
       },
       ()=>{

       }
    );
   
  }

  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  GetDepartmntbyId()
  {
    this.httpService.GetById("/masters-ws/department/get?id="+this.departmentId, this.departmentId, this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
       else if(res.errorMessage){
        this.showAlert(res.errorMessage)
       }else{
       
        this.department=res;
        this.department.effectiveFrom=this.department.effectiveFrom?new Date(this.department.effectiveFrom):this.department.effectiveFrom;
        this.department.effectiveTo=this.department.effectiveTo?new Date(this.department.effectiveTo):this.department.effectiveTo;
      }
    },
    error => {
     this.showAlert(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    });
    setTimeout(() => {this.GetParentDepartment()},300);
  
  }

  savedepartment(){

    if(this.department.subsidiaryId== undefined)
  {
      this.showAlert("Please select Subsidiary");
      return;
  }  
  if(this.department.departmentName== undefined)
  {
      this.showAlert("Please enter Department Name");
      return;
  }  
  if(this.department.effectiveFrom == undefined)
  {
      this.showAlert("Please enter Effective From Date");
      return;
  }  
  
  this.departmentlist.push(this.department);
   this.httpService.Insert("/masters-ws/department/save",this.departmentlist, this.RetloginDetails.token)
   .subscribe(res => {
    if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
   else  if (res) {
      this.showSuccess();
      // this.router.navigate(['/main/department/list']);
      if(this.addMode){
        this.router.navigate(['/main/department/action', 'view',res[0].id]);
      }else{
        this.router.navigate(['/main/department/list']);
      }
    } else {
      this.showError();
    }
     },
     error => {
       this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
    }
    showSuccess() {
      this.toastService.addSingle(
        'success',
        'Success',
        'Department Saved Successfully!'
      );
    }
    showError() {
      this.toastService.addSingle(
        'error',
        'Error',
        'Error occured while saving Department!'
      );
    }

  


}
