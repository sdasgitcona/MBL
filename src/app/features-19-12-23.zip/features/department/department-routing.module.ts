import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DepartmentAddEditComponent } from './department-add-edit/department-add-edit.component';
import { DepartmentListComponent } from './department-list/department-list.component';
const routes: Routes = [
  {
    path: '',
    component: DepartmentListComponent,
  },
  {
    path: 'list',
    component: DepartmentListComponent,
  },
  {
    path: 'action/:action/:id',
    component: DepartmentAddEditComponent,
  },
  {
    path: 'action/:action',
    component: DepartmentAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DepartmentRoutingModule { }
