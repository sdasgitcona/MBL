import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DepartmentRoutingModule } from './department-routing.module';
import { DepartmentAddEditComponent } from './department-add-edit/department-add-edit.component';
import { DepartmentListComponent } from './department-list/department-list.component';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { CalendarModule } from 'primeng/calendar';
import { TabMenuModule } from 'primeng/tabmenu';
import { DialogModule } from 'primeng/dialog';
import { TabViewModule } from 'primeng/tabview';
import { SharedComponentsModule } from 'src/app/shared/shared-components/shared-components.module';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { MultiSelectModule } from 'primeng/multiselect';
import { FieldsetModule } from 'primeng/fieldset';
import { InputSwitchModule } from 'primeng/inputswitch';
import { DividerModule } from "primeng/divider";
import { TagModule } from "primeng/tag";
import {InputNumberModule} from 'primeng/inputnumber';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { CardModule } from 'primeng/card';
import { OverlayPanelModule } from 'primeng/overlaypanel';


@NgModule({
  declarations: [
    DepartmentAddEditComponent,
    DepartmentListComponent
  ],
  imports: [
    CommonModule,
    DepartmentRoutingModule,
    ButtonModule,
    InputTextModule,
    PanelModule,
    TableModule,
    CalendarModule,
    TabMenuModule,
    DialogModule,
    TabViewModule,
    SharedComponentsModule,
    DropdownModule,
    FormsModule,
    ReactiveFormsModule,
    CheckboxModule,
    ToggleButtonModule,
    MultiSelectModule,
    FieldsetModule,
    InputSwitchModule,
    DividerModule,
    TagModule,
    InputNumberModule,
    ProgressSpinnerModule,
    CardModule,
    OverlayPanelModule
  ]
})
export class DepartmentModule { }
