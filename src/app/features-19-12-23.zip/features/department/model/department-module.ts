import { AnimationKeyframesSequenceMetadata } from "@angular/animations";
import { NumberValueAccessor } from "@angular/forms";

export class department{
    subsidiaryId:number
    departmentName:string;
    parentDepartmentId:number;
    effectiveFrom:any;
    effectiveTo:any;
    integratedId:number;
    parentDepartment:boolean
}

export class department_list
{
createdBy: string;
lastModifiedBy: string;
createdDate: Date;
lastModifiedDate: Date;
deleted:boolean;
departmentName:string;
effectiveFrom:any;
effectiveTo:any;
id:number;
isparentDepartment:boolean;
parentDepartmentId:number;
parentDepartmentName:string;
subsidiaryId:number;
subsidiaryName:string;


}

export class department_filter
{
    subdidiaryId:Number;
    effectivefrom:any;
    effectiveto:any;
    department:any;
}

export class BaseSearchPdf {
    filters: departmentFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class departmentFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}


