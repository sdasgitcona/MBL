import { Component, OnInit, ViewChild,LOCALE_ID, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch, SubsidiaryEntry, Supplier } from '../../supplier/model/supplier-model';
import { PurchaseOrder,file_upliad ,PurchaseOrderFilter,BaseSearchPdf,send_for_approval_object} from '../model/purchase-order-module';
import * as FileSaver from 'file-saver';
import { HttpHeaderResponse, HttpHeaders } from '@angular/common/http';
import { ToastService } from 'src/app/core/services/toast.service';
import { saveAs } from 'file-saver';
import { PoReportComponent } from '../../reports/po-report/po-report.component';
import {formatDate } from '@angular/common';
import { PrReportComponent } from '../../reports/pr-report/pr-report.component';
@Component({
  selector: 'app-purchase-order-list',
  templateUrl: './purchase-order-list.component.html',
  styleUrls: ['./purchase-order-list.component.scss']
})
export class PurchaseOrderListComponent implements OnInit {

  subsidiary:any;
  potype:any;
  vendor:any;

  columns: any[];
  departments: any[] = [];
  RetloginDetails:any;
  purchaseorderlist: PurchaseOrder[] = [];
  selectedpurchaseorder: PurchaseOrder = new PurchaseOrder();
  purchaseorder: PurchaseOrderFilter = new PurchaseOrderFilter();
  totalRecords: number = 0;
  loading: boolean = false;
  send_for_approval_object:any={};
  exportColumns: any[];
  newevent:any;
  taxType:any;
  baseSearch: BaseSearch = new BaseSearch();
  Subsidiarylist: any[] = [];
  supplierlist:Supplier[] = [];
  issubsidiaryhidden:boolean=false;
  issubsidiarydisable:boolean=false;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  POPrint: any[] = [];
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  // For Role Base Access
showloader:boolean;
  file: File ;
  displayModal:boolean;
  file_upliad:file_upliad=new file_upliad();
  RetRoleDetails:any;
  SubIdList:any=[];
  POList:any=[];
  statusOptions:any=[];
  Locationlist:any=[];
  ProjectList:any=[];
  ApprovalButtonShowHide: Number = 0;
  isParams: boolean = true;
  status:any;
  date_to:any;
  date_from:any;
  subId:any;
  CFOSubsidiaryId:any = [];
  CFOSubsidiaryIdList:any = [];
  
  constructor( private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService,private poReport: PoReportComponent,@Inject(LOCALE_ID) public locale: string,private prReport: PrReportComponent) { 

      this.subsidiary = ['MLBD', 'MLCD'];
      this.potype =['PR Based', 'Standalone Purchase Order','QA Based'];
      this.vendor = ['Vendor A', 'Vendor B'];
      this.statusOptions=['Draft', 'Pending Approval', 'Partially Approved', 'Approved', 'Rejected', 'Partially Received', 'Received','Billed','Partially Billed']
    }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    
     // For Role Base Access
     const retDetails:any = localStorage.getItem("RoleDTLS");
     var role_Dtls = JSON.parse(retDetails);
     this.RetRoleDetails=role_Dtls;

     // Get Subsidiary Id for CFO Dashboard from LocalStorage
    const GetCfoSubsidiaryId: any = localStorage.getItem("CFOSelectedSubId");
    this.CFOSubsidiaryIdList = JSON.parse(GetCfoSubsidiaryId);

     for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
     {
       if(role_Dtls[0].rolePermissions[i].accessPoint == "Purchase Order")
       {
         this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
         this.isEditable=role_Dtls[0].rolePermissions[i].edit;
         this.isViewtable=role_Dtls[0].rolePermissions[i].view;
       }
     }
 // End For Role Base Access

    this.GetSubsideryList();
    //this.GetSupplierList();
    //this.resetBaseSearch();
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
      { field: 'Id', header: 'Internal ID' },
      { field: 'Subsidiary', header: 'Subsidiary' },
      { field: 'PO Number', header: 'PO Number' },
      { field: 'PO Date', header: 'PO Date' },
      { field: 'PO Type', header: 'PO Type' },
      { field: 'Vendor', header: 'Vendor' },
      { field: 'Currency', header: 'Currency' },
      { field: 'Amount', header: 'Amount' },
      { field: 'Creator', header: 'Creator' },
      { field: 'Status', header: 'Status' },


     ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));

    // For Getting Filtered Data from Dashboard
    let subsidyList: any = [];
    subsidyList.push(this.purchaseorder.subsidiaryId);
    this.activatedRoute.params.subscribe((params) => {
      if (params) {
        if (params['status']) {
          this.isParams = true;
          this.status = params['status'];
          this.subId = params['id'];
          if (this.status == 'Recent') {
            this.getDate();
            this.baseSearch.filters = {
              subsidiaryId: subsidyList,
              recentlyCreated:this.purchaseorder.recent = true
            }
            this.baseSearch.pageNumber = -1;
            this.loadPO(this.newevent);
          } else if (this.status == 'DraftPO') {
            let subIdList = this.subId.split(",").map(Number);
            this.CFOSubsidiaryId.push(subIdList);
            if(subIdList.length > 1){
              setTimeout(() => { 
                this.baseSearch.filters = {
                  subsidiaryId: this.CFOSubsidiaryId[0],
                  status: this.purchaseorder.status = 'Draft',
                }
                this.baseSearch.pageNumber=-1;
                this.loadPO(this.newevent);
              },800);
            } else {
              setTimeout(() => { 
                this.baseSearch.filters = {
                  subsidiaryId: this.CFOSubsidiaryId[0],
                  status: this.purchaseorder.status = 'Draft',
                }
                this.baseSearch.pageNumber = -1;
                this.loadPO(this.newevent);
              },800);
            }
          } else if (this.status == 'UnapprovedPO') {
            let subIdList = this.subId.split(",").map(Number);
            this.CFOSubsidiaryId.push(subIdList);
            if(subIdList.length > 1){
              setTimeout(() => { 
                this.baseSearch.filters = {
                  subsidiaryId: this.CFOSubsidiaryId[0],
                  unApproved:this.purchaseorder.unApproved = true
                }
                this.baseSearch.pageNumber=-1;
                this.loadPO(this.newevent);
              },800);
            } else {
              setTimeout(() => { 
                this.baseSearch.filters = {
                  subsidiaryId: this.CFOSubsidiaryId[0],
                  unApproved:this.purchaseorder.unApproved = true
                }
                this.baseSearch.pageNumber = -1;
                this.loadPO(this.newevent);
              },800);
            }
          } else {
            this.baseSearch.filters = {
              subsidiaryId: subsidyList,
              status: this.purchaseorder.status = this.status,
            }
            this.baseSearch.pageNumber = -1;
            this.loadPO(this.newevent);
          }
        }
      }
    });
    // For Getting Filtered Data from Dashboard
  }

 /* exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.purchaseorderlist);
            doc.save('po.pdf');
        })
    })
}*/

// navigateToAddViewEdit(action: string) {

//   let taxRateRuleId = 0;
 
//   if (taxRateRuleId==0) {
    
//      taxRateRuleId = 0;
//     this.router.navigate(['/main/purchase-order/action', action, taxRateRuleId]);
//   } else {
//     this.router.navigate(['/main/purchase-order/action', action]);
//   }
//   console.log('Action is ' + action);
// }
navigateToAddViewEdit(
  action: string,
  selectedorder: PurchaseOrder = new PurchaseOrder()
) {
  let orderid = null;
  if (selectedorder?.id) {
    orderid = selectedorder.id;
    this.router.navigate(['/main/purchase-order/action', action, orderid]);
  } else {
    this.router.navigate(['/main/purchase-order/action', action]);
  }
}
resetBaseSearch() {
  this.baseSearch.filters = {subsidiaryId: this.SubIdList,supplierId:
  this.RetRoleDetails[0].selectedAccess=='VENDOR' ?this.RetloginDetails.supplierId : undefined};
  this.baseSearch.pageNumber = 0;
  this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
  this.baseSearch.sortColumn = GlobalConstants.PO_TABLE_SORT_COLUMN;
  this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
  this.loadPO(this.newevent);
}
loadPO(event: any) {
  try {
    this.newevent=event
    this.loading = true;
    this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
    //this.baseSearch.pageNumber = event.first / event.rows;
    // this.baseSearch.pageNumber = 1;
    this.baseSearch.pageSize = event.rows;
    // this.baseSearch.sortColumn = event.sortField
    //   ? 's.' + event.sortField
    //   : GlobalConstants.SUPPLIER_TABLE_SORT_COLUMN;
    this.baseSearch.sortColumn = event.sortField
    ?  event.sortField
    : GlobalConstants.PO_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder =
      event.sortOrder == -1
        ? GlobalConstants.ASCENDING
        : GlobalConstants.DESCENDING;
        if(this.SubIdList.length==0)
        {
         return;
        }
    this.HttpService.Insert('/procure-ws/po/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        if (res && res.list.length > 0) {
          this.purchaseorderlist = res.list;
          this.totalRecords = res.totalRecords;

          for(let x=0;x<this.purchaseorderlist.length;x++) {
          if( this.purchaseorderlist[x].poStatus == 'Pending Approval' || this.purchaseorderlist[x].poStatus == 'Partially Approved' || this.purchaseorderlist[x].poStatus == 'Approved'|| this.purchaseorderlist[x].poStatus == 'Rejected' || this.purchaseorderlist[x].poStatus == 'Closed'|| this.purchaseorderlist[x].poStatus == 'Partially Received'|| this.purchaseorderlist[x].poStatus == 'Received' || this.purchaseorderlist[x].poStatus == 'Partially Billed'|| this.purchaseorderlist[x].poStatus == 'Billed') //Send Approval Mode
          {
            this.purchaseorderlist[x].isApprovalButtonShowHide = 0;
          }
          else{
            this.purchaseorderlist[x].isApprovalButtonShowHide = 1;
          }
        }

        } else {
          this.purchaseorderlist = [];
          this.baseSearch=new BaseSearch();
          this.baseSearch.pageNumber = 0;
          this.totalRecords = 0;
        }
        this.loading = false;
      }
      },
      (error) => {
        this.showAlert(error);
        this.loading = false;
      }
    );
  } catch (err) {
    this.loading = false;
    //this.showAlert(err);
  }
}


/* Start fetch filter list of Subsidiary from api */
findby(event: any){
  let subsidyList:any=[];
  subsidyList.push(this.purchaseorder.subsidiaryId);

  let Fromdays: any = new Date(this.purchaseorder.fromDate).getUTCDate();
  let Frommonths: any = new Date(this.purchaseorder.fromDate).getUTCMonth() + 1;
  let Fromyear: any = new Date(this.purchaseorder.fromDate).getUTCFullYear();
  let Todays: any = new Date(this.purchaseorder.toDate).getUTCDate();
  let Tomonths: any = new Date(this.purchaseorder.toDate).getUTCMonth() + 1;
  let Toyear: any = new Date(this.purchaseorder.toDate).getUTCFullYear();

 this.baseSearch.filters={
  subsidiaryId:subsidyList,
  supplierId:this.purchaseorder.supplierId,
  type:this.purchaseorder.type,
  name:this.purchaseorder.name,
  locationId:this.purchaseorder.location,
  status:this.purchaseorder.status,
  fromDate:this.purchaseorder.fromDate !== undefined ? (Fromyear + '-' + (Frommonths.toString().length == 1 ? "0" + Frommonths : Frommonths) + '-' + (Fromdays.toString().length == 1 ? "0" + Fromdays : Fromdays)) : null,
  toDate:this.purchaseorder.toDate !== undefined ? (Toyear + '-' + (Tomonths.toString().length == 1 ? "0" + Tomonths : Tomonths) + '-' + (Todays.toString().length == 1 ? "0" + Todays : Todays)) : null,
  projectName:this.purchaseorder.projectName,
  requestor:this.purchaseorder.requestor,
  recentlyCreated:this.purchaseorder.recent,
  unApproved:this.purchaseorder.unApproved
 }

 this.baseSearch.pageNumber=-1;
 this.loadPO(this.newevent);
}
Reset(){
  if(this.RetloginDetails.userType=='SUPERADMIN')
  {
  this.purchaseorder.subsidiaryId =undefined;
  }
  this.purchaseorder.supplierId=undefined;
  this.purchaseorder.type=undefined;
  this.purchaseorder.name=undefined;
  this.purchaseorder.projectName=undefined;
  this.purchaseorder.location=undefined;
  this.purchaseorder.status=undefined;
  this.purchaseorder.fromDate=undefined;
  this.purchaseorder.toDate=undefined;
  this.purchaseorder.requestor=undefined;
  this.supplierlist=[];
  this.POList=[];
  this.ProjectList=[];
  this.Locationlist=[];

  //.findby("");
  this.resetBaseSearch();
  this.baseSearch.pageNumber=-1;
  this.loadPO(this.newevent);
  //if (this.RetRoleDetails[0].accountId != null && this.RetRoleDetails[0].subsidiaryId != null) {
    //this.purchaseorder.subsidiaryId =this.RetRoleDetails[0].subsidiaryId;
    this.GetSupplierListBySubsidiary();
    this.getLocationList();
    this.GetPOListBySubsidiary();
    this.GetAllProjectList();
    
  // }
}
/* End filter list of Subsidiary from api */
GetSubsideryList() {
  if(this.RetloginDetails.userType=='SUPERADMIN')
  //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
     
  //this.HttpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
     this.Subsidiarylist = res;
     for(let x=0;x<this.Subsidiarylist.length;x++)
     { 
      this.SubIdList.push(this.Subsidiarylist[x].id);
    }
    this.issubsidiaryhidden=false;
    this.issubsidiarydisable=false;
    }
    },
    (error) => {
      this.showAlert(error);
    },
    () => {
      if(localStorage.getItem("POFilters") != null)
      {const LocDetails:any =localStorage.getItem("POFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;

      this.purchaseorder.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.purchaseorder.type=searcheData.filters.type;
      this.purchaseorder.supplierId=searcheData.filters.supplierId;
      this.purchaseorder.name=searcheData.filters.name;
      this.purchaseorder.projectName=searcheData.filters.projectName;
      this.purchaseorder.location=searcheData.filters.locationId;
      this.purchaseorder.status=searcheData.filters.status;
      this.purchaseorder.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
      this.purchaseorder.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.purchaseorder.requestor=searcheData.filters.requestor;
      this.loadPO(this.newevent);
      localStorage.removeItem("POFilters");
      }
      else
     { this.resetBaseSearch();}
    }
  );
}else if(this.RetloginDetails.userType=='ENDUSER' || this.RetloginDetails.userType==null){
  this.purchaseorder.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
  this.GetSupplierListBySubsidiary();
  this.getLocationList();
  this.GetPOListBySubsidiary();
  this.GetAllProjectList();
  this.Subsidiarylist.push({
    "id":this.RetRoleDetails[0].subsidiaryId,
    "name":this.RetRoleDetails[0].subsidiaryName
  });
  this.issubsidiaryhidden=true;
  this.issubsidiarydisable=true;
  this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
  if(localStorage.getItem("POFilters") != null)
  {const LocDetails:any =localStorage.getItem("POFilters");
  let RetLocDetails = JSON.parse(LocDetails);
  this.baseSearch=RetLocDetails;
  let searcheData:any = RetLocDetails;


  this.purchaseorder.subsidiaryId=searcheData.filters.subsidiaryId[0];
  this.purchaseorder.type=searcheData.filters.type;
      this.purchaseorder.supplierId=searcheData.filters.supplierId;
      this.purchaseorder.name=searcheData.filters.name;
      this.purchaseorder.projectName=searcheData.filters.projectName;
      this.purchaseorder.location=searcheData.filters.locationId;
      this.purchaseorder.status=searcheData.filters.status;
      this.purchaseorder.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
      this.purchaseorder.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.purchaseorder.requestor=searcheData.filters.requestor;
  this.loadPO(this.newevent);
  localStorage.removeItem("POFilters");
  }
  else
 { this.resetBaseSearch();}
}
}
/* start get Get Supplier list */
GetSupplierList() {
  this.HttpService
    .GetAll('/masters-ws/supplier/get-suppliers',this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      this.supplierlist = res;
    }
    });
}
/* end get Get Supplier list */

getSubsidiaryDependency()
{
  this.GetSupplierListBySubsidiary();
  this.getLocationList();
  this.GetPOListBySubsidiary();
  this.GetAllProjectList();
}

GetSupplierListBySubsidiary() {
  let subsidiaryId:any= this.purchaseorder.subsidiaryId > 0 ?this.purchaseorder.subsidiaryId:0;
  this.HttpService
    .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + subsidiaryId, subsidiaryId, this.RetloginDetails.token)
    .subscribe((res) => {
      //For Auth
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        this.supplierlist = res;
      }
    });
   
}
GetPOListBySubsidiary(): any {

  let subsidiaryId:any= this.purchaseorder.subsidiaryId > 0 ?this.purchaseorder.subsidiaryId:0;
  let supplierId=this.purchaseorder.supplierId > 0 ?this.purchaseorder.supplierId:0;
  this.HttpService.GetAll(`/procure-ws/po/getBySupplierSubsidiary?supplierId=${supplierId}&subsidiaryId=${subsidiaryId}`, this.RetloginDetails.token)
    .subscribe(res => {
      //For Auth
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        if (res.error) {
          //var error = JSON.parse(res.error);
          this.toastService.addSingle(
            'error',
            'Error',
            res.error.errorMessage
          );
          this.POList = [];
        }
        else {
          this.POList = [];
          this.POList = res;
        }
      }
    },
      (error:any) => {
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
}
getLocationList()
{
  this.HttpService.GetAll('/masters-ws/location/get/all/lov?subsidiaryId='+this.purchaseorder.subsidiaryId ,this.RetloginDetails.token).subscribe(
    (res) => {
      //For Auth
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else
      {
        this.Locationlist=[]
        for (const [key, value] of Object.entries(res)) {
          this.Locationlist.push({locationId:Number(key),name:value})
        }
      } 
    },
    (error) => {
     this.showAlert(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    }
  );
}
GetAllProjectList()
{
  let subsidiaryId:any= this.purchaseorder.subsidiaryId > 0 ?this.purchaseorder.subsidiaryId:0;
  this.HttpService.GetById('/masters-ws/project/get-by-subsidiary-id?subsidiaryId=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {

      this.ProjectList=[];
      for(let x=0;x<res.length;x++)
      {
        this.ProjectList.push({
          "id":res[x].id,
          "name":res[x].name
        })
      }
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}
// CSV UPLOAD
csvUploadDownload(){
  this.displayModal = true;
}

@ViewChild('attachments') attachment: any;

fileList: File[] = [];
listOfFiles: any[] = [];
isLoading = false;

onFileChanged(event: any) {
  this.isLoading = true;
  this.file = event.target.files[0];
  this.listOfFiles=[]
  this.listOfFiles.push({subsidiary:this.RetRoleDetails[0].subsidiaryName,file:this.file .name});
  this.isLoading = false;
}

uploadFile(event:any){
  const httpOptions = {
    headers: new HttpHeaders({
     //"Content-Type": "multipart/form-data" 
     "mimeType": "multipart/form-data",
     "Content-Type": "false"
    })
  };
  
  //this.file = event.target.files[0];
  //let fileElement:any;
  //fileElement =document.getElementById('file_');
  //this.file = fileElement.files[0]

  const formData:FormData = new FormData();
  //this.file=event.currentTarget.files[0];
if(this.file)
{
  // formData.set('file', this.file);
   formData.append('file', this.file,this.file.name);
   this.showloader=true;
  //this.HttpService.uploadFile_("/masters-ws/supplier/upload",formData,{responseType: 'arraybuffer'},this.RetloginDetails.token)
  this.HttpService.uploadFile_("/procure-ws/po/upload?subsidiaryId=" +this.RetRoleDetails[0].subsidiaryId+ '&requestor='+this.RetloginDetails.empName , formData ,{responseType: 'blob'},this.RetloginDetails.token)
  .subscribe(res => {
    if(res.status == 401)
    { this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { this.showAlert("Wrong/Invalid Token!");
       this.router.navigate(['/login']);
     }
     else
 {  this.executeSaveAs(res)
    if (res.error){
      this.toastService.addSingle(
        'error',
        'Error',
        res.error.errorMessage
      );
      }
      else{
        
        this.toastService.addSingle(
          'success',
          'Success',
          'File uploaded Successfully!'
        );
        window.location.reload();
      }}
      this.showloader=false;
  },
    (error) => {
      this.showAlert(error.message);
      this.showloader=false;
    },
    () => {

      // 'onCompleted' callback.
      // No errors, route to new page here
    });
  }
  else
{
  this.showAlert("No Attachment Found !")
}
}
uploadFile_2(event:any){
  const httpOptions = {
    headers: new HttpHeaders({
     //"Content-Type": "multipart/form-data" 
     "mimeType": "multipart/form-data",
     "Content-Type": "false"
    })
  };


  const formData:FormData = new FormData();
  
  // formData.set('file', this.file);
   formData.append('file', this.file,this.file.name);
  //this.HttpService.uploadFile_("/procure-ws/po/upload",formData,{responseType: 'arraybuffer'},this.RetloginDetails.token)
  this.HttpService.uploadFile("/procure-ws/po/upload", formData ,this.RetloginDetails.token)
  .subscribe(res => {
    if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
    this.executeSaveAs(res)
    if (res.error){
      this.toastService.addSingle(
        'error',
        'Error',
        res.error.errorMessage
      );
      }
      else{
        
        this.toastService.addSingle(
          'success',
          'Success',
          'File uploaded Successfully!'
        );
        window.location.reload();
      }
    }
  },
    error => {
      this.showAlert(error.message);
    },
    () => {
    });
}

onFileChanged1(event:any) {
this.file = event.target.files[0];
  this.HttpService.uploadFile("/procure-ws/po/upload", this.file,this.RetloginDetails.token)
  .subscribe(res => {
    if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
    if (res.error){
      this.toastService.addSingle(
        'error',
        'Error',
        res.error.errorMessage
      );
      }
      else{
        this.toastService.addSingle(
          'success',
          'Success',
          'File uploaded Successfully!'
        );
        window.location.reload();
      }
    }
  },
    error => {
      this.showAlert(error);
    },
    () => {

      // 'onCompleted' callback.
      // No errors, route to new page here
    });
}

removeSelectedFile(index: number) {
  // Delete the item from fileNames list
  this.listOfFiles.splice(index, 1);
  // delete file from FileList
  this.fileList.splice(index, 1);
}
  executeSaveAs(content:any){
  //let blob = new Blob([content], {'type': "application/octet-stream"});
 saveAs(content, "Purchase Order.xlsx"); // This is from https://github.com/eligrey/FileSaver.js
};


DownloadTemplete() {
  //window.open(this.HttpService.baseUrl+"/po/download-template");
  this.HttpService.downloadFile("/procure-ws/po/download-template",this.RetloginDetails.token)
  .subscribe(res => {
    saveAs(res, 'Purchase Order.xlsx');
  });
 
}

// End CSV

// Download Report 
DownloadReport_old(poNumber:any){
  window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
  }

  DownloadReport(poNumber:any,type:any){
    this.showloader=true;
    //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
  this.poReport.exportPdf(poNumber,type);  
  this.showloader=false;
  }
  showAlert(AlertMSG:any) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }



  selfApproval(id:any){
    this.showloader=true;
  this.HttpService
    .GetById('/procure-ws/po/self-approve?poId=' + id, id,this.RetloginDetails.token)
    .subscribe((res) => {
      
        if(res.status == 401)
        { 
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { 
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {
     if (res == true) {
      this.showloader=false;
      location.reload();
      this.toastService.addSingle(
        'success',
        'Success',
        'PO Approved Successfully!'
      );
     } else {
      this.showloader=false;
      this.showAlert(res.errorMessage);
    }
  }
    },
    
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured while sending PO for Approval!'
        );
        this.showloader=false;
      }

    );
  }

  sendForApproval(id:any,poNumber:any,type:any){

    this.DownloadReport(poNumber,type);
    setTimeout(() => { 
      this.showloader=true;
      this.send_for_approval_object.id=id;
      this.send_for_approval_object.base64=this.prReport.base64;
      this.HttpService.Insert('/procure-ws/po/send-for-approval', this.send_for_approval_object,this.RetloginDetails.token)
      .subscribe((res) => {
        
        if(res.status == 401)
        { 
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { 
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {
          if (res == true) {
            location.reload();
            this.showloader=false;
            this.toastService.addSingle(
              'success',
              'Success',
              'PO Sent for Approval Successfully!'
            );
          } else {
            this.showloader=false;
            this.showAlert(res.errorMessage);
          }
        }
      },
        (error) => {
          this.showloader=false;
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending PO for Approval!'
          );
        }

      );
    },300);


 

  }

  getDate() {
    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
    const day = (currentDate.getDate()-1).toString().padStart(2, '0');
    this.date_to = `${year}-${month}-${day}`;
  
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(currentDate.getDate() - 7);
    const fromYear = sevenDaysAgo.getFullYear();
    const fromMonth = (sevenDaysAgo.getMonth() + 1).toString().padStart(2, '0');
    const fromDay = sevenDaysAgo.getDate().toString().padStart(2, '0');
    this.date_from = `${fromYear}-${fromMonth}-${fromDay}`;
  }

  editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("POFilters") != null)
    {
      localStorage.removeItem("POFilters");
    }
    localStorage.setItem("POFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/purchase-order/action', actionType, mainId]);
   }

    /***((Export Excel)) */
    generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.PO_TABLE_SORT_COLUMN;
      this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
  
      this.HttpService.Insert('/procure-ws/po/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.POPrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {

                if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){ 

               

                  this.POPrint.push({
                    'Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'PO Number':  RetData[i].poNumber,
                    'PO Date': formatDate(RetData[i].poDate, 'dd-MM-yyyy hh:mm' ,this.locale),
                    'PO Type': RetData[i].poType,
                    'Vendor':  RetData[i].supplierName,  
                    'Currency': RetData[i].currency, 
                    'Amount': RetData[i].totalAmount,
                    'Creator': RetData[i].requestor,
                    'Status': RetData[i].poStatus,
                  
                    // 
                    
                });
              }
                else{
                  this.POPrint.push({
                    'Internal Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'PO Number':  RetData[i].poNumber,
                    'PO Date': formatDate(RetData[i].poDate, 'dd-MM-yyyy hh:mm' ,this.locale),
                    'PO Type': RetData[i].poType,
                    'Vendor':  RetData[i].supplierName,  
                    'Currency': RetData[i].currency, 
                    'Amount': RetData[i].totalAmount,
                    'Creator': RetData[i].requestor,
                    'Status': RetData[i].poStatus,
                  });
                }
  
              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    exportPdf() {
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          //this.= this.employeeExport;
          //this.employeelist=[];
          (doc as any).autoTable(this.exportColumns, this.POPrint);
          doc.save('po.pdf');
        })
      })
    }
  
  //End PDF
  
  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');
  
   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.POPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.POPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'po');
           this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }

 recall(id:number)
{
  this.showloader = true;
  this.HttpService.GetAll('/procure-ws/po/change-to-draft?id='+ id,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.showloader = false;
      this.showSuccessrecall();
      location.reload();
    }
    },
    (error) => {
      this.showloader = false;
      this.showAlert(error);
    }
  );
}
showSuccessrecall() {
  this.toastService.addSingle(
    'success',
    'Success',
    'Recalled Successfully!'
  );
}
  //End Excel 
    //List Export option End
  
     /********Export excel */

     onRowSelect(event: any) {
      console.log(event)

      let poId = event.data.id;
      
      this.router.navigate(['/main/purchase-order/action/view', poId]);
    }
}
