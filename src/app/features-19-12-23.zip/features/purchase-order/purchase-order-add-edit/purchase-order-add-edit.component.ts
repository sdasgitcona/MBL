import { ParseError } from '@angular/compiler';
import { Component, ElementRef, OnInit,AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { throttleTime } from 'rxjs';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { Items } from '../../item/model/item-model';
import { locations } from '../../locationmaster/model/locationmaster-model';
import { Subsidiary } from '../../subsidiary/Model/subsidiary-model';
import { SubsidiaryEntry, Supplier, SupplierAddress } from '../../supplier/model/supplier-model';
import { TaxGroup } from '../../tax-group/model/tax-group-model';
import { PurchaseOrder,Item,PrItems, QAItems, supplierCurrency,POPrs,RequesterList } from '../model/purchase-order-module';
import { PoReportComponent } from '../../reports/po-report/po-report.component';
@Component({
  selector: 'app-purchase-order-add-edit',
  templateUrl: './purchase-order-add-edit.component.html',
  styleUrls: ['./purchase-order-add-edit.component.scss']
})
export class PurchaseOrderAddEditComponent implements OnInit {

  purchaseorder: PurchaseOrder = new PurchaseOrder();
  //item: Item=new Item();
  purchaseorderId: number = 0;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  approveBttn: boolean = false;
  role: any;
  isrecall:boolean=false;
  url:any;
  EmployeeList:RequesterList[];
  ProjectList:any[];
  //subsidiary:any;
  departmentOptions: any;
  vendor:any;
  location:any;
  purchaseordertype:any;
  prequisition:any;
  supplierId_:any;
  send_for_approval_object:any={};
  paymentterm:any;
  matchtype:any;
  departmentname:any;
  //currency:any;
  postatus:any;
  //taxgroup:any;
  //itemlist:any;
  Address:any;
  purchaseorderHistoryList: PurchaseOrder[] = [];
  display: boolean = false;
  isReloadSub:boolean;
  isReloadSupplier:boolean;
  isReloadCurrency:boolean;
  isReloadItem:boolean;
  isReloadTax:boolean;
  isReloadLocation:boolean;
  Subsidiarylist: any[] = [];
  subsidiary:Subsidiary=new Subsidiary();
  supplier: Supplier = new Supplier();
  supplierlist:Supplier[] = [];
  itemList: Items[] = [];
  PRitemList: PrItems[] = [];
  locationlist:locations[]=[];
  taxGroupList: TaxGroup[] = [];
  taxgroup:TaxGroup=new TaxGroup();
  currency:supplierCurrency[]=[] //[{ id?: number; name?: string; code?: string; }];
  private subscription: any;
  orderId:number;
  taxamount:number=0;
  selectedRow:number=0;
  totalBasicAmount:number=0;
  totalTaxAmount:number=0;
  totalAmount:number=0;
  ExSameCurrency:boolean=false;
  ExOtherCurrency:boolean=true;
  disabledQRbased:boolean=false;
  ishiddencrfqpo_:boolean=true;
  ishiddencrfqpo:boolean=false;
  
  //PRList:any;
  //PRList:[{ id?: number; name?: string; }];
  PRList:POPrs[]=[];
  PRListcatche:POPrs[]=[];
  SelectedPRList:POPrs[]=[];
  QAList:any[]=[];
  QAitemList: QAItems[] = [];
  billingAddressList:SupplierAddress[]=[];
  shippingAddressList:SupplierAddress[]=[];
  poNumber:any;
  POHistoryList: HistoryModel[] = [];
  ApprovalButtonShowHide:Number=0;
  id:any;
  Chktooltip:boolean=false;
  display_comments: boolean = false;
  isloadbyId:boolean=false;
  chkdeleteedit:Boolean=false;
  shiptoloc:boolean=false;
  shiptolocreq:boolean=true;
 // For Role Base Access
    isEditable:boolean;
    isCreatetable:boolean;
    isViewtable:boolean;
    isviewEditable:boolean=true;
    // For Role Base Access
    fiscalCalenderDTLS: any;
    showloader:boolean = false;
    RetloginDetails:any;
    RetRoleDetails:any;
    listURL:any;
    loginId:number;
    isAppSequenceVisivble:boolean;
    appSequencelist:any=[];

  constructor( private httpService: CommonHttpService,
    private router: Router,
    private toastService: ToastService,
    private activatedRoute: ActivatedRoute,
    private elementRef:ElementRef,
    private poReport: PoReportComponent

   ) {
    //this.subsidiary = ['MLBD', 'MLCD'];
    this.vendor = ['Vendor A', 'Vendor B','Vendor C'];
    this.purchaseordertype = ['PR Based', 'Standalone Purchase Order','QA Based'];
    //this.location = ['Location A', 'Location B','Location C'];
    this.prequisition = ['PR/0001/22-23', 'PR/0002/22-23','PR/0003/22-23'];
    this.paymentterm = ['15 Days','30 Days', '60 Days','90 Days'];
    this.matchtype = [{id:'2 Way',value:'PO'},{id:'3 Way',value:'GRN'}];
    //this.matchtype = ['2 Way', '3 Way'];
    //this.currency = ['GBP', 'USD'];
    this.postatus = ['Pending Approval', 'Approved', 'Open', 'Close', 'Rejected', 'Processed', 'Partially Approved','Partially Received','Received','Partially Billed','Billed'];
    //this.taxgroup  = ['VAT US 5', 'VAT US 8'];
    //this.itemlist  = ['item1', 'item2'];
    //this.Address  = ['address1', 'address2'];
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    this.loginId= this.RetloginDetails.employeeId;
    // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;
 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Purchase Order")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.poNumber = decodeURIComponent(params['id']); // (+) converts string 'id' to a number          
            this.id=+params['id']
            this.GetPObyPONumber();  
            }
          this.assignMode(params['action']);
          this.GetSubsideryList();
          if(params['action']== "Approval")
          {
            this.listURL="/main/purchase-order/po-approval";
          }
          else
          {
            this.listURL="/main/purchase-order/list";
          }
          //this.GetCurrencyList();
        } else {
         this.showAlert('cannot get params');
         this.listURL="/main/purchase-order/list";
        }
        if(this.addMode)
        {
          this.loadrequestor();
        }
      },
      (error) => {
        this.showAlert(error);
      }
    );
    
    
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        this.approveBttn = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.approveBttn = false;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.approveBttn = false;
        break;
      case 'Approval':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.approveBttn = true;
        break;
      default:
        break;
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 2) {
      this.LoadHistory();
     // this.displayAddressDialog = false;
    }
  }

  deleteItemrowlevel(index: number) {
    if (index >= 0) {
      let row_index:any;
      row_index=index+1;
      if(this.addMode)
      {
        this.purchaseorder.purchaseOrderItems.splice(index, 1);
        this.showAlert("PO Line no "+ row_index +" deleted successfully");
      }
      else
      {
        this.purchaseorder.purchaseOrderItems[index].deleted=true;
        this.showAlert("PO Line no "+ row_index +" deleted successfully");
      }
  
    
    }
   //if (index >= 0) this.purchaseorder.purchaseOrderItems.splice(index, 1);
   this.taxgroup.taxRateRules=[];
   this.SummuryAmount();
  }
  addItem() {
    
    if (
      this.purchaseorder.purchaseOrderItems.length > 0 &&
      this.purchaseorder.purchaseOrderItems[length - 1] == new Item()
    ) {
      return;
    }
    
    let item_=new Item();
    item_.department=this.departmentname;
    item_.departmentId=this.purchaseorder.departmentId;

    this.purchaseorder.purchaseOrderItems.push(item_);
  }
  

  hidepopup() {
    this.purchaseorder.purchaseOrderItems[this.selectedRow].taxGroupId=0;
    this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount=0;  
    this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount="0.00";
    this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=this.purchaseorder.purchaseOrderItems[this.selectedRow].quantity * this.purchaseorder.purchaseOrderItems[this.selectedRow].rate;
    this.display = false;
    this.SummuryAmount();
}
/* Get PO details by PO Number */
GetPObyPONumber() {

 this.isloadbyId=false;
  this.httpService
     .GetById('/procure-ws/po/get?id='+this.id, this.id,this.RetloginDetails.token)
    // .GetById('/po/get?poNumber='+this.poNumber, this.poNumber)
    .subscribe((res) => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      //console.log(res);

      if( res.poStatus=='Pending Approval' || res.poStatus=='Partially Approved' || res.poStatus=='Approved'|| res.poStatus=='Rejected' || res.poStatus=='Closed'|| res.poStatus=='Partially Received'|| res.poStatus=='Received' || res.poStatus=='Partially Billed'|| res.poStatus=='Billed') //Send Approval Mode
      {
      this.ApprovalButtonShowHide=0;
      }
      else{
        this.ApprovalButtonShowHide=1;
      }

      res.purchaseOrderItems.sort((a:any,b:any) => a.id - b.id);
      for(let i=0;i<res.purchaseOrderItems.length;i++)
      {
        res.purchaseOrderItems[i].rate=parseFloat(res.purchaseOrderItems[i].rate).toFixed(2);
        res.purchaseOrderItems[i].amount=parseFloat(res.purchaseOrderItems[i].amount).toFixed(2);
        res.purchaseOrderItems[i].taxAmount=parseFloat(res.purchaseOrderItems[i].taxAmount).toFixed(2);
      }
      
      this.purchaseorder = res;
      this.supplierId_=this.purchaseorder.supplierId;
   

      if(this.RetloginDetails.email==this.purchaseorder.createdBy)
      {
        this.isrecall=true;
      }
      this.appSequencelist=res.approvers;
      let nextApprover=this.purchaseorder.nextApprover;
      let isNextApproverFound:Boolean=false;
      if(this.appSequencelist != null)
      {for(let x=0;x<this.appSequencelist.length;x++)
      {
        let status='';
        if (this.appSequencelist[x].id == nextApprover)
        {
          isNextApproverFound=true;
          status='current';//this.appSequencelist[x]['status']=;
        }
        else
        {
          if(isNextApproverFound)
          {
            status='pending';
            //this.appSequencelist[x]['status']='pending';
          }else{
            status='approved';
            //this.appSequencelist[x]['status']='approved';
          }
        }
        this.appSequencelist[x]['status']=status;
      }}
     // this.purchaseorder.requestor=(parseInt(res.requestor))
      this.chkforshiptoloc();
      this.GetAllProjectList(this.purchaseorder.subsidiaryId);
      this.GetDepartmentList();

        this.GetDepartmentList_edit_header(this.purchaseorder.departmentId);
 
     // 
     this.GetDepartmentList_edit_line();
     
      if( this.purchaseorder.totalAmount==null)
      {

        for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
        {
          this.purchaseorder.purchaseOrderItems[i].totalAmount=="0.00";
          this.purchaseorder.purchaseOrderItems[i].taxAmount="0.00";
          this.CalculateAmmount(this.purchaseorder.purchaseOrderItems[i].quantity,this.purchaseorder.purchaseOrderItems[i].rate,i);
        }
       
     }    
   

    for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
    {
      this.purchaseorder.purchaseOrderItems[i].receivedByDate=this.purchaseorder.purchaseOrderItems[i].receivedByDate!=null?new Date(this.purchaseorder.purchaseOrderItems[i].receivedByDate):"";
    }
      if(res.errorMessage){
        this.toastService.addSingle(
          'error',
          'Error',
          res.errorMessage
        );
      }else{  
      this.purchaseorder.poDate=this.purchaseorder.poDate?new Date(this.purchaseorder.poDate):this.purchaseorder.poDate;
      this.GetSubsidiarybyId();
      this.GetTaxGroupList();
      this.GetAddressList()
      //this.GetPRItemList()
      if(this.purchaseorder.poType=='PR Based'){
       // this.purchaseorder.prNumber=this.purchaseorder.prNumber.split("|");
       this.purchaseorder.prId=this.purchaseorder.prId?this.purchaseorder.prId.split("|"):this.purchaseorder.prId;
       this.purchaseorder.prId.map((data:any,index:any)=>{
        this.purchaseorder.prId[index]=parseInt(data)
       })
        this.GetSupplierList();
        this.GetLocationList();
        this.GetSupplierCurrencyList();

        if(this.purchaseorder.locationId){
          this.GetPRList();
        ////  this.GetPRItemList()
          setTimeout(() => {this.SelectPRS()},1200);
      

        }
      }
      else if(this.purchaseorder.poType=='Standalone Purchase Order'){
        this.GetSupplierList();
        this.GetSupplierCurrencyList();
        this.GetLocationList();
        this.GetItemList();
      }
      else if(this.purchaseorder.poType=='QA Based'){
        
       this.GetQAList();
       this.GetSupplierListByQA();
       this.GetSupplierCurrencyList();
       this.GetQALocationList();
      
      setTimeout(() => {
        
        this.GetQAItemList();},2200);
      }
      this.SummuryAmount()

           
      for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
      {
        if(this.purchaseorder.purchaseOrderItems[i].totalAmount=="NaN")
        {
          this.purchaseorder.purchaseOrderItems[i].totalAmount=="0.00";
          this.purchaseorder.purchaseOrderItems[i].taxAmount="0.00";
          this.CalculateAmmount(this.purchaseorder.purchaseOrderItems[i].quantity,this.purchaseorder.purchaseOrderItems[i].rate,i);

        }
        
      }  
    }
  }
    });
   //////
   
    setTimeout(() => { this.isloadbyId=true; },2200);
    //setTimeout(() => { this.fnRequesterList(); },600);


  
   // const quantity = "12";
    //console.log(parseInt(quantity, 10));
   
   

//alert(this.purchaseorder.purchaseOrderItems.length);

}
/*End  Get PO details by PO Number */

/* start get Get Subsidiary by Id */
GetSubsidiarybyId() {
  this.httpService
    .GetById('/setup-ws/subsidiary/get?id='+this.purchaseorder.subsidiaryId ,this.purchaseorder.subsidiaryId,this.RetloginDetails.token)
    .subscribe((res) => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      this.subsidiary = res;
      if(this.addMode){

      
      this.purchaseorder.exchangeRate=this.subsidiary.currency==this.purchaseorder.currency?"1.00":""
      
      this.purchaseorder.exchangeRate=this.purchaseorder.exchangeRate==""?"":parseFloat(this.purchaseorder.exchangeRate).toFixed(2);
      }
else
{
      if(this.subsidiary.currency==this.purchaseorder.currency)
      {
        this.ExSameCurrency=false;
        this.ExOtherCurrency=true;
        this.purchaseorder.exchangeRate=parseFloat( this.purchaseorder.exchangeRate).toFixed(2);
      }
      else
      {
        this.ExSameCurrency=true;
        this.ExOtherCurrency=false;
        this.purchaseorder.exchangeRate=parseFloat( this.purchaseorder.exchangeRate).toFixed(2);
      }
    }
  }
    });
}
/* end  get Get Subsidiary by Id */

/* start get Get Subsidiary List */
GetSubsideryList() {
  if(this.RetloginDetails.userType=='SUPERADMIN')
 // if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
  {
    this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(

  //this.httpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
    (res) => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
     this.Subsidiarylist = res;
       this.isReloadSub=false;
    }
    },
    (error) => {
      this.showAlert(error);
      this.isReloadSub=false;
    }
  );
  }
  else if(this.RetloginDetails.userType=='ENDUSER'){
    this.Subsidiarylist.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });

  }
}
/* End get Get Subsidiary List */

OnSubsidiaryChnage(){

  this.purchaseorder.purchaseOrderItems=[];
  this.purchaseorder.amount=0.00;
  this.purchaseorder.taxAmount=0.00;
  this.purchaseorder.totalAmount=0.00;
  //this.GetPoNumber()
  this.GetSubsidiarybyId();
  this.GetTaxGroupList();
  //this.fnRequesterList();
  this.GetDepartmentList();
  this.GetAllProjectList(this.purchaseorder.subsidiaryId);
  
  //this.GetPRItemList()
  if(this.purchaseorder.poType=='PR Based'){
    
    this.PRitemList = [];
    this.GetSupplierList();
    this.GetLocationList();

    
    if(this.purchaseorder.locationId){
      this.GetPRList();
    }
  }
  else if(this.purchaseorder.poType=='Standalone Purchase Order'){
    
    this.GetSupplierList();
    this.GetLocationList();
    this.GetItemList();
  }
  else if(this.purchaseorder.poType=='QA Based'){
  
    this.GetQAList();
  }
}
OnSupplierChange(){
  this.GetSupplierbyId();
  this.GetAddressList();
  this.GetSupplierCurrencyList();
   if(this.purchaseorder.poType=='QA Based'){   
    this.GetQALocationList();
    if(this.purchaseorder.locationId)
    {
      this.supplierId_=this.purchaseorder.supplierId;
      this.GetQAItemList();
    }
   
  }

     

}

/* start get Get Supplier list */
GetSupplierList() {
  this.httpService
    .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + this.purchaseorder.subsidiaryId,this.purchaseorder.subsidiaryId,this.RetloginDetails.token)
    .subscribe((res) => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      this.supplierlist = res;
      this.isReloadSupplier=false;
    }
    });
  
}
/* end get Get Supplier list */
/* start get Get Supplier id */
GetSupplierbyId() {
  this.httpService
    .GetById('/masters-ws/supplier/get?id=' + this.purchaseorder.supplierId,this.purchaseorder.supplierId,this.RetloginDetails.token)
    .subscribe((res) => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      this.supplier = res;
      this.purchaseorder.paymentTerm=this.supplier.paymentTerm!;
      this.supplier.supplierSubsidiary.map((data:any)=>{
        if(data.preferredCurrency){
          this.purchaseorder.currency=data.supplierCurrency;
        }
      })
    
      if(this.addMode){
      this.purchaseorder.exchangeRate=this.subsidiary.currency==this.purchaseorder.currency?"1.00":""
      if(this.subsidiary.currency==this.purchaseorder.currency)
      {
        this.ExSameCurrency=false;
        this.ExOtherCurrency=true;
      }
      else
      {
        this.ExSameCurrency=true;
        this.ExOtherCurrency=false;
      }


      }
    }
     // this.purchaseorder.currency=this.supplier.supplierSubsidiary.supplierCurrency!;
    });
}
/* end get Get Supplier id */

 /* Start Fetch Currency list from api */
 GetCurrencyList(): any {
  this.httpService.GetAll("/setup-ws/currency/get/all",this.RetloginDetails.token)
    .subscribe(res => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      //console.log(res);
      if (res.error){
        var error = JSON.parse(res.error);
        this.toastService.addSingle(
          'error',
          'Error',
          error.errorMessage
        );
        this.itemList = [];
        }else{
          this.currency = res;
        }
      }
    },
      error => {
        this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
        this.isReloadCurrency=false;
      });
}
/* End Fetch Currency list from api */
/* Start Fetch Currency list by supplier id from api */
GetSupplierCurrencyList(): any {
  this.httpService.GetAll("/masters-ws/supplier/get-currency-by-supplier?supplierId="+this.purchaseorder.supplierId,this.RetloginDetails.token)
    .subscribe(res => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      //console.log(res);
      if (res.error){
        var error = JSON.parse(res.error);
        this.toastService.addSingle(
          'error',
          'Error',
          error.errorMessage
        );
        this.itemList = [];
        }else{
          this.currency = res;
        }
      }
    },
      error => {
       this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
}
/* End Fetch Currency list by supplier id from api */
 /* Start Fetch Item list from api */
 GetItemList(): any {
  this.httpService.GetById("/masters-ws/item/find-by-subsidiary?subsidiaryId="+this.purchaseorder.subsidiaryId,this.purchaseorder.subsidiaryId,this.RetloginDetails.token)
    .subscribe(res => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      //console.log(res);
      if (res.error){
        var error = JSON.parse(res.error);
        this.toastService.addSingle(
          'error',
          'Error',
          error.errorMessage
        );
        this.itemList = [];
        }
        else{
          this.itemList = res;
        }
      }
    },
      error => {
        this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
}
/* End Fetch Item list from api */

onItemChange(index: number, value: string) {
  let that = this;
  this.itemList.find(o => {
    if (o.id === parseInt(value)) {
      that.purchaseorder.purchaseOrderItems[index].itemDescription = o.description;
      that.purchaseorder.purchaseOrderItems[index].itemUom = o.uom;
      that.purchaseorder.purchaseOrderItems[index].accountCode=o.accountId
    }
  });
}
/* Start Genrate pr number */
// GetPRNumber(subsidiaryId: string) {
//   this.httpService.GetAllResponseText(`/document-sequence/get-document-sequence-numbers?subsidiaryId=${subsidiaryId}&type=PR&transactionalDate=2022-08-31&isDeleted=false`)
//     .subscribe(res => {
//       console.log(res);
//       if (!res.error)
//         this.prModel.prNumber = res;
//       else {
//         var error = JSON.parse(res.error);
//         alert(error.errorMessage)
//         this.prModel.prNumber = "";
//       }
//     },
//       error => {
//         console.log(error);
//         this.prModel.prNumber = "";

//       },
//       () => {
//         // 'onCompleted' callback.
//         // No errors, route to new page here
//       });
// }
/* End Genrate pr number  */
/* Start Genrate pr number */
GetPoNumber() {
  this.httpService.GetByResponseType(`/setup-ws/document-sequence/get-document-sequence-numbers?subsidiaryId=${this.purchaseorder.subsidiaryId}&type=PO&transactionalDate=2022-11-08&isDeleted=false`,'text',this.RetloginDetails.token)
    .subscribe(res => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      if (!res.error)
        this.purchaseorder.poNumber = res;
      else {
        var error = JSON.parse(res.error);
        this.toastService.addSingle(
          'error',
          'Error',
          error.errorMessage
        );
        this.purchaseorder.poNumber = "";
      }
    }
    },
      error => {
        this.showAlert(error);
        this.purchaseorder.poNumber = "";
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
}
/* End Genrate pr number  */
GetLocationList(){
  this.httpService.GetAll("/masters-ws/location/get-parent-location-names?subsidiaryId="+this.purchaseorder.subsidiaryId,this.RetloginDetails.token)
  .subscribe(res => {
    
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
    if (res.error){
    var error = JSON.parse(res.error);
    this.toastService.addSingle(
      'error',
      'Error',
      error.errorMessage
    );
    this.locationlist = [];
    }
    else {
    this.locationlist=res;
    }
  }
    }, error => {
      this.showAlert(error);
     },
     () => {
      this.isReloadLocation=false
       // 'onCompleted' callback.
       // No errors, route to new page here
     });
}
CalculateAmmount(quantity:any,rate:any,index:any){
 
 //this.purchaseorder.purchaseOrderItems[index].taxGroupId=0;
 //this.purchaseorder.purchaseOrderItems[index].taxAmount=0;  
 //this.purchaseorder.purchaseOrderItems[index].taxAmount="0.00";

    quantity=quantity ==undefined?0:quantity==""?0:quantity;
    rate=rate==undefined?0:rate=="" ?0:rate;

  this.purchaseorder.purchaseOrderItems[index].amount=(parseFloat(quantity != undefined ?quantity:0)*parseFloat(rate != undefined ?rate:0)).toFixed(2);
  this.purchaseorder.purchaseOrderItems[index].totalAmount=(parseFloat(this.purchaseorder.purchaseOrderItems[index].amount)+ (this.purchaseorder.purchaseOrderItems[index].taxAmount > 0 ? parseFloat(this.purchaseorder.purchaseOrderItems[index].taxAmount):parseFloat("0")) ).toFixed(2)

  this.onChangeTaxCalculate(this.purchaseorder.purchaseOrderItems[index].taxGroupId,index);
//   if(quantity!="" && rate!=""){
  
//   this.purchaseorder.purchaseOrderItems[index].amount=(parseFloat(quantity)*parseFloat(rate != undefined ?rate:0)).toFixed(2);
//  // this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=parseFloat(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount?this.purchaseorder.purchaseOrderItems[this.selectedRow].amount:0.00)+(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount?this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount:0.00)).toFixed(2)

//   this.purchaseorder.purchaseOrderItems[index].totalAmount=(parseFloat(this.purchaseorder.purchaseOrderItems[index].amount)+parseFloat(this.purchaseorder.purchaseOrderItems[index].taxAmount)).toFixed(2)

//   }
//   else if(quantity!=""){
//     this.purchaseorder.purchaseOrderItems[index].amount=(parseFloat(quantity)*1).toFixed(2)
//     this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=parseFloat(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount?this.purchaseorder.purchaseOrderItems[this.selectedRow].amount:0)+(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount?this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount:0)).toFixed(2)
//   }else if(rate!=""){
//     this.purchaseorder.purchaseOrderItems[index].amount=(1*parseFloat(rate)).toFixed(2)
//     this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=parseFloat(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount?this.purchaseorder.purchaseOrderItems[this.selectedRow].amount:0)+(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount?this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount:0)).toFixed(2)

//   }else{
//     this.purchaseorder.purchaseOrderItems[index].amount=0;
//     this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=0;

//   }
 
  //this.showDialog(this.purchaseorder.purchaseOrderItems[index].taxGroupId,index)
  
  // if(!this.taxgroup.id && this.editMode){
  //   this.GetTaxGroupbyId(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxGroupId)
  // }
  // this.taxgroup.taxRateRules.map((data:any)=>{
  //   this.taxamount+=this.taxgroup.inclusive?(((this.purchaseorder.purchaseOrderItems[this.selectedRow].amount *100)/(100 + (data.taxRates*1)) * data.taxRates) / 100 ):(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount * data.taxRates) / 100
  // })
  // this.taxCodeSave1(index);

}

showDialog(taxgroupId:any,rowIndex:any,type:any) { 
  if(type=="eye")
  {
    this.Chktooltip=true;
  }
  else
  {
   this.Chktooltip=false;
  }
   this.GetTaxGroupbyId(taxgroupId);
   this.selectedRow=rowIndex;
   this.display = true;
 }

 /* tax group by id */
onChangeTaxCalculate(taxgroupId:number,RowNo:any)
{
  if(taxgroupId!=null)
  {
    this.httpService.GetById("/setup-ws/tax-group/get?id="+taxgroupId,taxgroupId,this.RetloginDetails.token)
    .subscribe(res => {
      
  if(res.status == 401)
  { 
    this.showAlert("Unauthorized Access !");
    this.router.navigate(['/login']);
  }
  else if(res.status == 404)
  { 
    this.showAlert("Wrong/Invalid Token!");
    this.router.navigate(['/login']);
  }
  else
  {
      if (res.error){
       
        var error = JSON.parse(res.error);
        this.toastService.addSingle(
          'error',
          'Error',
          error.errorMessage
        );
        this.taxgroup = new TaxGroup();
        }else{
          
          this.selectedRow=RowNo;
          this.taxgroup=res;
          this.taxgroup.taxRateRules.map((data:any,index:any)=>{
            this.taxamount=0;
          })
          this.taxgroup.taxRateRules.map((data:any,index:any)=>{
            this.taxamount+=this.taxgroup.inclusive?((((this.purchaseorder.purchaseOrderItems[this.selectedRow].quantity*this.purchaseorder.purchaseOrderItems[this.selectedRow].rate) *100)/(100 + (data.taxRates*1)) * data.taxRates) / 100 ):((parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].rate)*parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].quantity)) * data.taxRates) / 100
          })
  
          this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount=this.taxamount.toFixed(2);
    this.taxamount=0;
    this.purchaseorder.purchaseOrderItems[this.selectedRow].amount=(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].quantity != undefined ?this.purchaseorder.purchaseOrderItems[this.selectedRow].quantity:0)*parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].rate != undefined ?this.purchaseorder.purchaseOrderItems[this.selectedRow].rate:0)).toFixed(2);//added by sdas
    if(this.taxgroup.inclusive){
     
      this.purchaseorder.purchaseOrderItems[this.selectedRow].amount=parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount)-parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount);
      this.purchaseorder.purchaseOrderItems[this.selectedRow].amount=parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount).toFixed(2);
    //////this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount).toFixed(2)
    this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount)+parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount)).toFixed(2)
    }else{
      this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount)+parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount)).toFixed(2)
    }
        }
      }
      }, error => {
        console.log(error);
       },
       () => {
         this.SummuryAmount();
       });
  }
  this.SummuryAmount();

}
GetTaxGroupbyId(taxgroupId:any){
  this.httpService.GetById("/setup-ws/tax-group/get?id="+taxgroupId,taxgroupId,this.RetloginDetails.token)
  .subscribe(res => {
    
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
    if (res.error){
      var error = JSON.parse(res.error);
      this.toastService.addSingle(
        'error',
        'Error',
        error.errorMessage
      );
      this.taxgroup = new TaxGroup();
      }else{
       
        this.taxgroup=res;
        this.taxgroup.taxRateRules.map((data:any,index:any)=>{
          this.taxamount=0;
        })
        this.taxgroup.taxRateRules.map((data:any,index:any)=>{
          this.taxamount+=this.taxgroup.inclusive?((((this.purchaseorder.purchaseOrderItems[this.selectedRow].quantity*this.purchaseorder.purchaseOrderItems[this.selectedRow].rate) *100)/(100 + (data.taxRates*1)) * data.taxRates) / 100 ):((parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].rate)*parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].quantity)) * data.taxRates) / 100
        })
      }
    }
    }, error => {
      console.log(error);
     },
     () => {
       // 'onCompleted' callback.
       // No errors, route to new page here
     });
}
fnOnActiveTax()
  {
    // var TGRow=this.TaxGroupRowIndex;
    // if(this.taxgroup.activeTaxAmount)
    // {
    // this.isEditableTaxAmount=true;
    // for(let a=0;a<this.taxgroup.taxRateRules.length;a++)
    // {
    //   //var TotaltaxAmount= this.taxgroup.inclusive?(((this.invoiceDetails.invoiceItems[a].amount *100)/(100 + (this.taxgroup.taxRateRules[a].taxRates*1)) * this.taxgroup.taxRateRules[a].taxRates) / 100 ):(this.invoiceDetails.invoiceItems[a].amount * this.taxgroup.taxRateRules[a].taxRates) / 100 ;
    //   //var aa=this.taxgroup.taxRateRules[a].CustomtaxAmount;
    //   //this.taxgroup.taxRateRules[a].CustomtaxAmount= this.taxgroup.inclusive?(((this.purchaseorder.purchaseOrderItems[TGRow].amount *100)/(100 + (this.taxgroup.taxRateRules[a].taxRates*1)) * this.taxgroup.taxRateRules[a].taxRates) / 100 ):(this.purchaseorder.purchaseOrderItems[TGRow].amount * this.taxgroup.taxRateRules[a].taxRates) / 100 ;
    //   this.taxamount+=this.taxgroup.inclusive?((((this.purchaseorder.purchaseOrderItems[this.selectedRow].quantity*this.purchaseorder.purchaseOrderItems[this.selectedRow].rate) *100)/(100 + (data.taxRates*1)) * data.taxRates) / 100 ):((parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].rate)*parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].quantity)) * data.taxRates) / 100
    // }
    // }
    // else
    // {
    //   this.isEditableTaxAmount=false;
    // }
  }
/* end tax group by id */

 savePO() {
  var isAmountValid=true
  if(!this.purchaseorder.subsidiaryId){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Subsidiary'
    );
    return;
  }
  if(!this.purchaseorder.poType){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select PO Type'
    );
    return;
  }
  if(!this.purchaseorder.supplierId){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Supplier'
    );
    return;
  }
  if(!this.purchaseorder.locationId){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter PR/Ship to Location'
    );
    return;
  }
  if(!this.purchaseorder.poDate){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select PO Date'
    );
    return;
  }
  if(!this.purchaseorder.currency){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Currency'
    );
    return;
  }
  if(!this.purchaseorder.matchType){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Match Type'
    );
    return;
  }
  if(!this.purchaseorder.paymentTerm){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Payment Term'
    );
    return;
  }

  if(!this.purchaseorder.departmentId && this.purchaseorder.departmentId!=0){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Department'
    );
    return;
  }
  if(this.purchaseorder.currency!=this.subsidiary.currency)
  {
    if(!this.purchaseorder.exchangeRate){
      this.toastService.addSingle(
        'error',
        'Error',
        'Please enter Exchange Rate'
      );
      return;
    }
  }

  // if(this.purchaseorder.matchType=="3 Way")
  // {
  //   if(this.purchaseorder.poType=="Standalone Purchase Order")
  //   {
  //     if(!this.purchaseorder.locationId){
  //       this.toastService.addSingle(
  //         'error',
  //         'Error',
  //         'Please enter PR/Ship to Location'
  //       );
  //       return;
  //     }
  //   }
  // }
 
 /* if(this.purchaseorder.purchaseOrderItems.length>0){

    for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
    {
      if(this.purchaseorder.purchaseOrderItems[i].deleted!=true)
      {
           for(let j=0;j<this.purchaseorder.purchaseOrderItems.length;j++)
           {
                if(this.purchaseorder.purchaseOrderItems[j].itemId==this.purchaseorder.purchaseOrderItems[i].itemId && i!=j)
                {
                  this.showAlert("Duplicate Item found");
                  return;
                }
           }
      }
    }


  }*/



  
  if(this.purchaseorder.purchaseOrderItems.length>0){
    for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
    {
      if(this.purchaseorder.purchaseOrderItems[i].deleted!=true)
      {
        if(this.purchaseorder.purchaseOrderItems[i].itemId ==null || typeof this.purchaseorder.purchaseOrderItems[i].itemId === "undefined" || this.purchaseorder.purchaseOrderItems[i].itemId==0){
          this.toastService.addSingle(
            'error',
            'Error',
            `Please enter Item Name`
          );
          isAmountValid=false
          return
        }
        if(this.purchaseorder.purchaseOrderItems[i].quantity ==null || typeof this.purchaseorder.purchaseOrderItems[i].quantity === "undefined" || this.purchaseorder.purchaseOrderItems[i].quantity==0){
          this.toastService.addSingle(
            'error',
            'Error',
            `Please enter Quantity and Rate`
          );
          isAmountValid=false
          return
        }
        if(this.purchaseorder.purchaseOrderItems[i].rate ==null || typeof this.purchaseorder.purchaseOrderItems[i].rate === "undefined" || this.purchaseorder.purchaseOrderItems[i].rate==0){
          this.toastService.addSingle(
            'error',
            'Error',
            `Please enter Quantity and Rate`
          );
          isAmountValid=false
          return
        }
        if((this.purchaseorder.purchaseOrderItems[i].receivedByDate ==null || typeof this.purchaseorder.purchaseOrderItems[i].receivedByDate == undefined || this.purchaseorder.purchaseOrderItems[i].receivedByDate=="") && this.purchaseorder.purchaseOrderItems[i].deleted==false){
          this.showAlert("Received Date is mandatory for Row-" + (i+1));
          isAmountValid=false
          return
        }
        if(this.purchaseorder.purchaseOrderItems[i].receivedByDate==undefined  || JSON.stringify(this.purchaseorder.purchaseOrderItems[i].receivedByDate) === '{}')
          {
            this.showAlert("Received Date is mandatory for Row-" + (i+1));
            isAmountValid=false
            return
        }
        if(new Date(this.purchaseorder.purchaseOrderItems[i].receivedByDate) < new Date(this.purchaseorder.poDate))
        {
         this.showAlert("Receive Date must be greater than and equal to PO Date");
         isAmountValid=false
         return;
       }

      }
    }
   /* this.purchaseorder.purchaseOrderItems.map((data:any,index:any)=>{

      if(data.deleted!=true)
      {
       
      if(data.itemId ==null || typeof data.itemId === "undefined" || data.itemId==0){
        this.toastService.addSingle(
          'error',
          'Error',
          `Please enter Item`
        );
        isAmountValid=false
        return
      }
      if(data.quantity ==null || typeof data.quantity === "undefined" || data.quantity==0){
        this.toastService.addSingle(
          'error',
          'Error',
          `Please enter Quantity and Rate`
        );
        isAmountValid=false
        return
      }
      if(data.rate ==null || typeof data.rate === "undefined" || data.rate==0){
        this.toastService.addSingle(
          'error',
          'Error',
          `Please enter Quantity and Rate`
        );
        isAmountValid=false
        return
      }
   
      if((data.receivedByDate ==null || typeof data.receivedByDate == undefined || data.receivedByDate=="") && data.deleted==false){
        this.toastService.addSingle(
          'error',
          'Error',
          `Please enter Receive Date`
        );
        isAmountValid=false
        return
      }

 if(data.receivedByDate==undefined  || JSON.stringify(data.receivedByDate) === '{}')
 {
   this.toastService.addSingle(
     'error',
     'Error',
     `Please enter Receive Date`
   );
   isAmountValid=false
   return
 }
      if(new Date(data.receivedByDate) < new Date(this.purchaseorder.poDate))
      {
       this.showAlert("Receive Date must be greater than and equal to PO Date");
       isAmountValid=false
       return;
     }

    }
    })*/
    
    if(isAmountValid){
      if(this.purchaseorder.poType=='PR Based'){ 
        this.purchaseorder.prId="";
        //this.purchaseorder.prNumber=this.purchaseorder.prNumber.join("|")
       for(let i=0;i<this.SelectedPRList.length;i++)
       {
        this.purchaseorder.prId+=this.SelectedPRList[i].id+"|";
       }

       this.purchaseorder.prId = this.purchaseorder.prId.substring(0, this.purchaseorder.prId.length-1);

       // this.purchaseorder.prId=this.SelectedPRList.id?this.SelectedPRList.join("|"):this.SelectedPRList
      }
      else{
        this.purchaseorder.prId=""
      }
  
      
  let po_days:any = new Date(this.purchaseorder.poDate).getDate();
  let po_months:any = new Date(this.purchaseorder.poDate).getMonth()+1;
  let po_year:any = new Date(this.purchaseorder.poDate).getFullYear();
  if(po_months<10)
  {
    po_months="0".toString()+po_months.toString();
  }
  if(po_days<10)
  {
    po_days="0".toString()+po_days.toString();
  }
  //this.purchaseorder.poDate=po_year+"-"+po_months+"-"+po_days;

  if(this.editMode)
  {
    let result=this.purchaseorder.purchaseOrderItems.find(o=>o.deleted!=true);
    if(!result)
    {
          this.showAlert("Atleast one Item line is mandatory");
          return;
    }
  }
  if(this.addMode)
  {
    for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
    {
      this.purchaseorder.purchaseOrderItems[i].id=null;
    }
  }

  this.showloader = true;
  if(this.addMode){
    this.purchaseorder.createdBy=this.RetloginDetails.username;this.purchaseorder.lastModifiedBy=this.RetloginDetails.username
    }
   else if(!this.addMode){
    this.purchaseorder.lastModifiedBy=this.RetloginDetails.username
    }
  
  this.httpService.Insert('/procure-ws/po/save', this.purchaseorder,this.RetloginDetails.token).subscribe(
    (res) => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      if (res.error){
          this.toastService.addSingle(
            'error',
            'Error',
            JSON.stringify(res.error)
          );
       
        }        
      else if (res && res.id > 0) {
        this.showloader = false;
        this.showSuccess();
        if(this.addMode)
            this.router.navigate(['/main/purchase-order/action', 'view',res.id]);
            else
        this.router.navigate(['/main/purchase-order/list']);
      } else {
        this.showError();
        this.showloader = false;
      }
    }
    },
    (error) => {
      this.showloader = false;
      this.showAlert('error-' + error);
    },
    () => { }
  );}
  }else{
    this.toastService.addSingle(
      'error',
      'Error',
      'Atleast one Item line is mandatory'
    );
  }
}
showSuccess() {
  this.toastService.addSingle(
    'success',
    'Success',
    'Purchase Order saved Successfully!'
  );
}
showSuccessrecall() {
  this.toastService.addSingle(
    'success',
    'Success',
    'Recalled Successfully!'
  );
}
showError() {
  this.toastService.addSingle(
    'error',
    'Error',
    'Error occured while saving Purchase Order!'
  );
}
clearPOData() {
  this.router.navigate(['/main/purchase-order/list']);
  // if (this.editMode) {
  //   this.router.navigate(['/main/purchase-order/list']);
  // }
  // else {
  //  location.reload();
  // }
}
/* tax group list */
GetTaxGroupList(){
  this.httpService.GetAll("/setup-ws/tax-group/get-by-subsidiary?subsidiaryId="+this.purchaseorder.subsidiaryId,this.RetloginDetails.token)
  .subscribe(res => {
    
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
    if (res.error){
      var error = JSON.parse(res.error);
      this.toastService.addSingle(
        'error',
        'Error',
        error.errorMessage
      );
      this.taxGroupList = [];
      }else{
        this.taxGroupList=res;
      }
    }
    }, error => {
      console.log(error);
     },
     () => {
      this.isReloadTax=false;
       // 'onCompleted' callback.
       // No errors, route to new page here
     });
}
/* end tax group list */



decimalFilter(event: any) {
  const reg = /^-?\d*(\.\d{0,2})?$/;
  let input = event.target.value + String.fromCharCode(event.charCode);

  if (!reg.test(input)) {
      event.preventDefault();
  }
}

taxCodeSave(){
 
  this.display = false;
  this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount=this.taxamount.toFixed(2);
  this.taxamount=0;
  this.purchaseorder.purchaseOrderItems[this.selectedRow].amount=(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].quantity != undefined ?this.purchaseorder.purchaseOrderItems[this.selectedRow].quantity:0)*parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].rate != undefined ?this.purchaseorder.purchaseOrderItems[this.selectedRow].rate:0)).toFixed(2);//added by sdas
  if(this.taxgroup.inclusive){
   
    this.purchaseorder.purchaseOrderItems[this.selectedRow].amount=parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount)-parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount);
    this.purchaseorder.purchaseOrderItems[this.selectedRow].amount=parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount).toFixed(2);
  //////this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount).toFixed(2)
  this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount)+parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount)).toFixed(2)
  }else{
    this.purchaseorder.purchaseOrderItems[this.selectedRow].totalAmount=(parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].amount)+parseFloat(this.purchaseorder.purchaseOrderItems[this.selectedRow].taxAmount)).toFixed(2)
  }


  this.SummuryAmount()
}
taxCodeSave1(index:any){
 this.taxamount=0.00;
  this.display = false;
  this.purchaseorder.purchaseOrderItems[index].taxAmount=this.taxamount.toFixed(2);
  this.taxamount=0;
  if(this.taxgroup.inclusive){
  this.purchaseorder.purchaseOrderItems[index].totalAmount=parseFloat(this.purchaseorder.purchaseOrderItems[index].amount).toFixed(2)
  }else{
    this.purchaseorder.purchaseOrderItems[index].totalAmount=(parseFloat(this.purchaseorder.purchaseOrderItems[index].amount)+parseFloat(this.purchaseorder.purchaseOrderItems[index].taxAmount)).toFixed(2)
  }


  this.SummuryAmount()
}
taxCodeSaveforrefresh(index:any){
 
  this.display = false;
  this.purchaseorder.purchaseOrderItems[index].taxAmount=this.taxamount.toFixed(2);
  this.taxamount=0;
  if(this.taxgroup.inclusive){
  this.purchaseorder.purchaseOrderItems[index].totalAmount=parseFloat(this.purchaseorder.purchaseOrderItems[index].amount).toFixed(2)
  }else{
    this.purchaseorder.purchaseOrderItems[index].totalAmount=(parseFloat(this.purchaseorder.purchaseOrderItems[index].amount)+parseFloat(this.purchaseorder.purchaseOrderItems[index].taxAmount)).toFixed(2)
  }
  this.SummuryAmount()
}
SummuryAmount(){

  this.purchaseorder.amount=0;
  this.purchaseorder.taxAmount=0;
  this.purchaseorder.totalAmount=0;
  this.purchaseorder.purchaseOrderItems.map((data,index)=>{

    if(data.deleted!=true)
    {
    this.purchaseorder.amount+=parseFloat(data.amount);
    this.purchaseorder.taxAmount+=data.taxAmount!=undefined?parseFloat(data.taxAmount):0.00;
    //this.totalAmount+=parseFloat(data.totalAmount)
    if(!this.addMode){
      if(this.taxgroup.inclusive){
        data.totalAmount =parseFloat(this.purchaseorder.purchaseOrderItems[index].amount).toFixed(2)
        this.purchaseorder.totalAmount+=parseFloat(data.totalAmount)
      }else{
        data.totalAmount =(parseFloat(this.purchaseorder.purchaseOrderItems[index].amount)+parseFloat(this.purchaseorder.purchaseOrderItems[index].taxAmount)).toFixed(2)
        this.purchaseorder.totalAmount+=parseFloat(data.totalAmount)

      }
    }
    else{
      this.purchaseorder.totalAmount+=parseFloat(data.amount)+parseFloat(data.taxAmount!=undefined?data.taxAmount:0.00);
    }
  }
  })
  this.purchaseorder.amount=this.purchaseorder.amount?parseFloat(this.purchaseorder.amount).toFixed(2):"0.00";
  this.purchaseorder.taxAmount=this.purchaseorder.taxAmount?parseFloat(this.purchaseorder.taxAmount).toFixed(2):"0.00";
  this.purchaseorder.totalAmount=this.purchaseorder.totalAmount?parseFloat(this.purchaseorder.totalAmount).toFixed(2):"0.00";


}
SummuryAmount1(){
  this.totalBasicAmount=0;
  this.totalTaxAmount=0;
  this.totalAmount=0;
  this.purchaseorder.purchaseOrderItems.map((data,index)=>{
    if(data.deleted!=true)
    {
    this.totalBasicAmount+=parseFloat(data.amount);
    this.totalTaxAmount+=data.taxAmount
    //this.totalAmount+=parseFloat(data.totalAmount)
    if(!this.addMode){
      if(this.taxgroup.inclusive){
        data.totalAmount =parseFloat(this.purchaseorder.purchaseOrderItems[index].amount).toFixed(2)
        this.totalAmount+=parseFloat(data.totalAmount)
      }else{
        data.totalAmount =(parseFloat(this.purchaseorder.purchaseOrderItems[index].amount)+parseFloat(this.purchaseorder.purchaseOrderItems[index].taxAmount)).toFixed(2)
        this.totalAmount+=parseFloat(data.totalAmount)

      }
    }
    else{
      this.totalAmount+=parseFloat(data.totalAmount)
    }
  }
  })
}
GetPRList(){

  if(this.purchaseorder.projectId!=undefined)
  {
    
   this.url='/procure-ws/pr/get-pending-pr-for-po?subsidiaryId='+this.purchaseorder.subsidiaryId+'&locationId='+this.purchaseorder.locationId+'&projectId='+ this.purchaseorder.projectId;
        
  }
  else{
    this.url='/procure-ws/pr/get-pending-pr-for-po?subsidiaryId='+this.purchaseorder.subsidiaryId+'&locationId='+this.purchaseorder.locationId;
  }
  

  this.httpService.GetAll(this.url,this.RetloginDetails.token)
    .subscribe(res => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      //console.log(res);
      if (res.error){
        var error = JSON.parse(res.error);
        this.toastService.addSingle(
          'error',
          'Error',
          error.errorMessage
        );
        this.PRList = [{}]//{};
        }
        else{
          this.PRList = res;
       }
      }
    },
      error => {
        console.log(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
}
GetPRItemList(event:any): any {
  this.disabledQRbased=false;
  if(this.id==undefined || this.isloadbyId==true)
  {
   // this.purchaseorder.purchaseOrderItems=[];
    //this.purchaseorder.amount=0.00;
    //this.purchaseorder.taxAmount=0.00;
    //this.purchaseorder.totalAmount=0.00;
  }
  this.PRitemList = [];

  const PRarray = [];

 for(let i=0;i<this.SelectedPRList.length;i++)
 {

  //PRarray.push(this.quotationprCopy[i].prNumber) // old
 // alert(this.SelectedPRList[i].id);
  PRarray.push(this.SelectedPRList[i].id)  // new
 
 }

  this.httpService.Insert("/procure-ws/pr/get-unprocessed-items-by-pr-ids?formName=PO Approval",PRarray,this.RetloginDetails.token)
 // this.httpService.Insert("/pr/get-unprocessed-items-by-pr-numbers",this.purchaseorder.prNumber) // old
 // this.httpService.GetById("/pr/get-unprocessed-items-by-pr-number?prNumber="+this.purchaseorder.prNumber,this.purchaseorder.prNumber)
  .subscribe(res => {
    
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      //console.log(res);
      if (res.error){
        //var error = JSON.parse(res.error);
        this.toastService.addSingle(
          'error',
          'Error',
          res.error.errorMessage
        );
        this.PRitemList = [];
       // this.purchaseorder.purchaseOrderItems= [];
        }
        else{
         // this.purchaseorder.purchaseOrderItems=res.length==0?[]: this.purchaseorder.purchaseOrderItems;
         if(this.addMode)
         {
          
          this.PRitemList = res;
          this.purchaseorder.purchaseOrderItems=res;
          this.purchaseorder.amount=0.00;
          this.purchaseorder.taxAmount=0.00;
          this.purchaseorder.totalAmount=0.00;
         
          for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
          {
            this.purchaseorder.purchaseOrderItems[i].receivedByDate=res[i].receivedDate!=null?new Date(res[i].receivedDate):"";
            this.purchaseorder.purchaseOrderItems[i].department=res[i].departmentName;
            this.purchaseorder.purchaseOrderItems[i].departmentId=res[i].departmentId;
            this.purchaseorder.purchaseOrderItems[i].amount=(res[i].quantity*res[i].rate).toFixed(2);
            this.purchaseorder.purchaseOrderItems[i].totalAmount=parseFloat(this.purchaseorder.purchaseOrderItems[i].amount)+(this.purchaseorder.purchaseOrderItems[i].taxAmount != undefined? this.purchaseorder.purchaseOrderItems[i].taxAmount:0.00)    
            this.purchaseorder.purchaseOrderItems[i].shipToLocation=res[i].prLocationName;
            this.purchaseorder.purchaseOrderItems[i].memo=res[i].memo;
            this.purchaseorder.purchaseOrderItems[i].taxAmount="0.00";
            this.purchaseorder.purchaseOrderItems[i].rate=parseFloat(this.purchaseorder.purchaseOrderItems[i].rate).toFixed(2);
            this.CalculateAmmount(this.purchaseorder.purchaseOrderItems[i].quantity,this.purchaseorder.purchaseOrderItems[i].rate,i);
          }

          this.loaddepartment();
         
         } 
         else
         {
          let PrCheckedId=0;
          let isPrChcked:boolean;
          PrCheckedId=event.itemValue.id;
          if (this.SelectedPRList.find((a:any) => a.id == PrCheckedId)) {
            isPrChcked=true;
          
            }
            else
            {
              isPrChcked=false;
             
            }
         
          
          this.PRitemList = res;

          for(let i=0;i<res.length;i++)
          {

            if(this.isloadbyId=true)
            {
              this.purchaseorder.amount=0.00;
              this.purchaseorder.taxAmount=0.00;
              this.purchaseorder.totalAmount=0.00;
            }
       
           // if(this.purchaseorder.purchaseOrderItems.find(o=>o.prNumber!=res[i].prNumber)) 
           // {
       
              this.purchaseorder.purchaseOrderItems.push({
               itemId:res[i].itemId,
               itemDescription:res[i].itemDescription,
               itemUom:res[i].itemUom,
               accountCode:res[i].accountId,
               prNumber:res[i].prNumber,
               prId:res[i].prId,
               shipToLocation:res[i].prLocationName,
               rate:res[i].rate.toFixed(2),
               quantity:res[i].quantity,
               memo:res[i].memo,
               receivedByDate:res[i].receivedDate!=null?new Date(res[i].receivedDate):"",
               department:res[i].departmentName,
               amount:(res[i].quantity*res[i].rate).toFixed(2),
               totalAmount:(res[i].quantity*res[i].rate).toFixed(2),
               taxAmount:"0.00",
               deleted:false,
               departmentId:res[i].departmentId
              });
            //}
            this.loaddepartment();
            this.CalculateAmmount(this.purchaseorder.purchaseOrderItems[i].quantity,this.purchaseorder.purchaseOrderItems[i].rate,i);
           
   
          }
                if(this.isloadbyId==true)
                {
                      for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
                      {
                        let obj = this.SelectedPRList.find(o => o.name === this.purchaseorder.purchaseOrderItems[i].prNumber);

                                  if(!obj)
                                  {
                                    this.purchaseorder.purchaseOrderItems[i].deleted=true;
                                  }
                      }

                }

         }
     
    
        }
      }
    },
      error => {
        console.log(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
}
GetAddressList(): any {
  this.httpService.GetAll("/masters-ws/supplier/address/get?supplierId="+this.purchaseorder.supplierId,this.RetloginDetails.token)
    .subscribe(res => {

      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      
      //console.log(res);
      if (res.error){
        var error = JSON.parse(res.error);
        this.toastService.addSingle(
          'error',
          'Error',
          error.errorMessage
        );
        this.billingAddressList = [];
        this.shippingAddressList = [];

        }
        else{
        /*  this.billingAddressList = res;
          this.shippingAddressList = res;
          res.map((val:any,index:any)=>{
            if(val.defaultBilling){
              this.purchaseorder.billTo=val.id;
              this.purchaseorder.trn=val.taxRegistrationNumber;

            //this.billingAddressList.push(val)
            }
             if(val.defaultShipping){
              this.purchaseorder.shipTo=val.id;

             // this.shippingAddressList.push(val)
            }
          })*/
          this.billingAddressList = res;
          this.shippingAddressList = res;
          this.purchaseorder.billTo=null
          this.purchaseorder.shipTo=null

          res.map((val:any,index:any)=>{
            var address=(val.address1?val.address1:"")+(val.address2?" "+val.address2:"")+(val.city?" "+val.city:"")+(val.state?" "+val.state:"")+(val.country?" "+val.country:"")+(val.pin?"- "+val.pin:"");
            this.billingAddressList[index].address1=address;
            this.shippingAddressList[index].address1=address

            if(val.defaultBilling){
              this.purchaseorder.billTo=val.id;
              this.purchaseorder.trn=val.taxRegistrationNumber;

            //this.billingAddressList.push(val)
            }
             if(val.defaultShipping){
              this.purchaseorder.shipTo=val.id;

             // this.shippingAddressList.push(val)
            }
          })
        }
      }
    },
      error => {
        console.log(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
}

onAddressChange(value: string) {
  let that = this;
  this.billingAddressList.find(o => {
    if (o.id === parseInt(value)) {
      this.purchaseorder.trn=o.taxRegistrationNumber;
    }
  });
}
OnTypeChange(){
  //this.purchaseorder.qaId=0;
  this.purchaseorder.purchaseOrderItems= [];
  this.SelectedPRList=[];
  this.PRList=[];
  this.purchaseorder.amount=0.00;
  this.purchaseorder.taxAmount=0.00;
  this.purchaseorder.totalAmount=0.00;
  this.taxgroup.taxRateRules=[];
  this.purchaseorder.department=undefined;
  this.GetAllProjectList(this.purchaseorder.subsidiaryId);
  if(this.purchaseorder.poType=='PR Based'){
    this.GetSupplierList();
    this.GetLocationList();
  
    this.QAList=[];
    if(this.purchaseorder.locationId){
      this.GetPRList();
    }
  }
  else if(this.purchaseorder.poType=='Standalone Purchase Order'){
    this.GetSupplierList();
    this.GetLocationList();
    this.GetItemList();
    this.purchaseorder.prId=[]
    this.QAList=[];
  }
  else if(this.purchaseorder.poType=='QA Based'){   
    this.GetQAList();
    this.purchaseorder.prId=[]

  }
  this.chkforshiptoloc();
}
OnPrChange(){

  //this.GetPRItemList();
}
test():boolean{
  return true;
}
onLocationChange(){
this.checkLocationAllow();

  if(this.id==undefined || this.isloadbyId==true)
  {
        if(this.purchaseorder.poType!='Standalone Purchase Order')
        {
          this.purchaseorder.purchaseOrderItems=[];
          this.purchaseorder.amount=0.00;
          this.purchaseorder.taxAmount=0.00;
          this.purchaseorder.totalAmount=0.00;
        }
  }

  if(this.purchaseorder.poType=='PR Based'){  
    this.SelectedPRList=[]; 
    this.PRitemList=[];
    this.GetPRList();
  }else if(this.purchaseorder.poType=='QA Based'){ 
    this.SelectedPRList=[];
    this.supplierId_=this.purchaseorder.supplierId;
    this.GetQAItemList();
  }

 
}

checkLocationAllow()
{
  let result:boolean=false;
  let PRdays: any = new Date(this.purchaseorder.poDate).getDate();
  let PRmonths: any = new Date(this.purchaseorder.poDate).getMonth() + 1;
  let PRyear: any = new Date(this.purchaseorder.poDate).getFullYear();
  let PRDate: any = this.purchaseorder.poDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""

  if(this.purchaseorder.locationId != undefined && this.purchaseorder.poDate != undefined){
    //this.httpService.GetById('/masters-ws/location/get-by-valid-date?locationId=' + this.pr.subsidiaryId, this.pr.subsidiaryId,this.RetloginDetails.token)
    this.httpService.GetAll(`/masters-ws/location/get-by-valid-date?id=${this.purchaseorder.locationId}&date=${PRDate}&formName=${'Purchase Order'}`,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
      if (res == false) {
        this.purchaseorder.locationId=undefined;
        this.showAlert("This Location not active");
      } 
      }
    },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
           error
        );
        result= false;
      }
    );
} 
}

onPRItemChange(index: number, value: string) {


  //if(this.purchaseorder.purchaseOrderItems.find(x=>x.itemId==this.purchaseorder.purchaseOrderItems[index].itemId))
  //{

        if(this.purchaseorder.purchaseOrderItems.length>1)
        {
        for(let i=0;i<this.purchaseorder.purchaseOrderItems.length-1;i++)
        {
         if(this.purchaseorder.purchaseOrderItems[i].deleted!=true)
          {
              if(this.purchaseorder.purchaseOrderItems[i].itemId==this.purchaseorder.purchaseOrderItems[index].itemId && index!=i)
              {
                    this.showAlert("Duplicate Item Found");
                    this.isReloadItem=true;
                    this.purchaseorder.purchaseOrderItems[index].itemId=0;
                    this.isReloadItem=false;
                    if (index >= 0) this.purchaseorder.purchaseOrderItems.splice(index, 1);
                    return;
              }
          }

        }


        }
        else
        {

        }
 // }


  let that = this;
  this.PRitemList.find(o => {
    if (o.itemId === parseInt(value)) {
      that.purchaseorder.purchaseOrderItems[index].itemDescription = o.itemDescription;
      that.purchaseorder.purchaseOrderItems[index].itemUom = o.itemUom;
      that.purchaseorder.purchaseOrderItems[index].accountCode=o.accountId;
      that.purchaseorder.purchaseOrderItems[index].prNumber=o.prNumber;
      that.purchaseorder.purchaseOrderItems[index].prId=o.prId;
      that.purchaseorder.purchaseOrderItems[index].shipToLocation=o.prLocationName;
      that.purchaseorder.purchaseOrderItems[index].rate=o.rate.toFixed(2);
      that.purchaseorder.purchaseOrderItems[index].quantity=o.quantity;
      that.purchaseorder.purchaseOrderItems[index].memo=o.memo;
      that.purchaseorder.purchaseOrderItems[index].receivedByDate=o.receivedDate!=null?new Date(o.receivedDate):"";
      that.purchaseorder.purchaseOrderItems[index].department=o.department;
      this.purchaseorder.purchaseOrderItems[index].amount=(o.quantity*o.rate).toFixed(2);
      this.purchaseorder.purchaseOrderItems[index].totalAmount=parseFloat(this.purchaseorder.purchaseOrderItems[index].amount)+(this.purchaseorder.purchaseOrderItems[index].taxAmount != undefined? this.purchaseorder.purchaseOrderItems[index].taxAmount:0.00)    
      this.purchaseorder.purchaseOrderItems[index].taxAmount="0.00";
    }
  });
  this.CalculateAmmount(that.purchaseorder.purchaseOrderItems[index].quantity,that.purchaseorder.purchaseOrderItems[index].rate,index);
}
/* Get QA List */
GetQAList(){
 
  this.httpService.GetAll(`/procure-ws/quotation-analysis/get-qa-number-by-subsidiary?subsidiaryId=${this.purchaseorder.subsidiaryId}`,this.RetloginDetails.token)
  .subscribe(res => {
    
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
    //console.log(res);
    if (res.error){
      var error = JSON.parse(res.error);
      this.toastService.addSingle(
        'error',
        'Error',
        error.errorMessage
      );
      this.QAList = [];
      }
      else{
        this.QAList = res;
        if(!this.addMode)
        {
          let _QA = this.QAList.find(
            (o) => o.id == this.purchaseorder.qaId
          );
          if(!_QA)
          {
            this.QAList.push({name:this.purchaseorder.qaNumber,id:this.purchaseorder.qaId})
          }
        }
        setTimeout(() => {
          this.purchaseorder.qaId=this.purchaseorder.qaId
        }, 200);
        // res.map((data:any)=>{
        //   this.QAList.push({qanumber:data})
        // })
      }
    }
  },
    error => {
      console.log(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    });
}
/* End Get QA List */
/* Get QA Supplier List */
GetSupplierListByQA(){

  this.httpService
  //.GetById('/quotation-analysis/get-suppliers-by-qa-number?qaNumber=' + this.purchaseorder.qaNumber,this.purchaseorder.qaNumber)
  .GetById('/procure-ws/quotation-analysis/get-suppliers-by-qa-id?qaId=' + this.purchaseorder.qaId,this.purchaseorder.qaId,this.RetloginDetails.token)
  .subscribe((res) => {
    
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
    //console.log(res);
    this.supplierlist = res;
    if(this.editMode || this.viewMode)
    {
       if(this.supplierlist.length==0)
       {

            let sid=this.purchaseorder.supplierId;
                
            this.httpService.GetAll("/masters-ws/supplier/get?id="+this.purchaseorder.supplierId,this.RetloginDetails.token)
            .subscribe(res => {
              
          if(res.status == 401)
          { 
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { 
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
          {
              //console.log(res);
              if (res.error){
                var error = JSON.parse(res.error);
                this.toastService.addSingle(
                  'error',
                  'Error',
                  error.errorMessage
                );
                this.PRList =[{}] //{};
                }
                else{
                 
                   this.purchaseorder.supplierId=sid;
                   this.purchaseorder.supplierNametoshow=res.name;
                   this.ishiddencrfqpo=true;
                   this.ishiddencrfqpo_=false;

                }
              }
            },
              error => {
                console.log(error);
              },
              () => {
                // 'onCompleted' callback.
                // No errors, route to new page here
              });
       }

    }




  }
   
  });
}
/*End Get QA Supplier List */

/* Get PR List by QA*/
GetPRListByQA(){
  debugger
  //this.httpService.GetAll(`/quotation-analysis/get-pr-number-by-qa-number?qaNumber=${this.purchaseorder.qaNumber}`)
  this.httpService.GetAll(`/procure-ws/quotation-analysis/get-pr-number-by-qa-id?qaId=${this.purchaseorder.qaId}`,this.RetloginDetails.token)
  .subscribe(res => {
    
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
    //console.log(res);
    if (res.error){
      var error = JSON.parse(res.error);
      this.toastService.addSingle(
        'error',
        'Error',
        error.errorMessage
      );
      this.PRList =[{}] //{};
      }
      else{
        this.PRList = res;
      }
    }
  },
    error => {
      console.log(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    });
}
/* Get PR List by QA*/
OnChnageQA(){
  this.GetSupplierListByQA();
  this.GetPRListByQA();
}
/* Get GA location list */
GetQALocationList(){
  this.httpService.GetAll(`/procure-ws/quotation-analysis/get-locations-by-qa-and-supplier?qaId=${this.purchaseorder.qaId}&supplierId=${this.purchaseorder.supplierId}`,this.RetloginDetails.token)
  .subscribe(res => {
    
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
    console.log(res);
    if (res.error){
    var error = JSON.parse(res.error);
    this.toastService.addSingle(
      'error',
      'Error',
      error.errorMessage
    );
    this.locationlist = [];
    }
    else {
    this.locationlist=res;
    }
  }
    }, error => {
      console.log(error);
     },
     () => {
       // 'onCompleted' callback.
       // No errors, route to new page here
     });
}
/*End Get GA location list */
 /* Start Fetch Item list from api */
 GetQAItemList(): any {
  
  this.httpService.GetAll(`/procure-ws/quotation-analysis/get-items-by-qa-supplier-location?qaId=${this.purchaseorder.qaId}&supplierId=${this.supplierId_}&locationId=${this.purchaseorder.locationId}`,this.RetloginDetails.token)
  .subscribe(res => {
      //console.log(res);
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      if (res.error){
        var error = JSON.parse(res.error);
        this.toastService.addSingle(
          'error',
          'Error',
          error.errorMessage
        );
        this.QAitemList = [];
        }
        else{
          if(this.addMode)
          {
          
          this.QAitemList = res;
          this.disabledQRbased=true;
          this.purchaseorder.purchaseOrderItems=[];
          for(let i=0;i<res.length;i++)
          {
           
            if(res[i].poId==null)
            {
              this.purchaseorder.purchaseOrderItems.push(res[i]);
            }
          }
          this.purchaseorder.amount=0.00;
          this.purchaseorder.taxAmount=0.00;
          this.purchaseorder.totalAmount=0.00;
          debugger
          for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
          {
            this.purchaseorder.purchaseOrderItems[i].receivedByDate=res[i].receivedDate!=null?new Date(res[i].receivedDate):"";
            this.purchaseorder.purchaseOrderItems[i].department=res[i].departmentName;
            this.purchaseorder.purchaseOrderItems[i].departmentId=res[i].departmentId;
            this.purchaseorder.purchaseOrderItems[i].amount=(res[i].quantity*res[i].rate).toFixed(2);
            this.purchaseorder.purchaseOrderItems[i].totalAmount=parseFloat(this.purchaseorder.purchaseOrderItems[i].amount)+(this.purchaseorder.purchaseOrderItems[i].taxAmount != undefined? this.purchaseorder.purchaseOrderItems[i].taxAmount:0.00)    
            this.purchaseorder.purchaseOrderItems[i].shipToLocation=res[i].prLocationName;
            this.purchaseorder.purchaseOrderItems[i].memo=res[i].memo;
            this.purchaseorder.purchaseOrderItems[i].taxAmount="0.00";
            this.purchaseorder.purchaseOrderItems[i].itemUom=res[i].uom;
            this.purchaseorder.purchaseOrderItems[i].shipToLocation=res[i].prLocation;
            this.purchaseorder.purchaseOrderItems[i].rate=parseFloat(res[i].ratePerUnit).toFixed(2);
            this.CalculateAmmount(this.purchaseorder.purchaseOrderItems[i].quantity,this.purchaseorder.purchaseOrderItems[i].rate,i);
          }
          this.loaddepartment();
        }
        else
        {
          
          this.QAitemList = res;
          this.disabledQRbased=true;
          /*if(this.isloadbyId==true)
          {
          for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
          {
            this.purchaseorder.purchaseOrderItems[i].deleted=true;
          }
          for(let i=0;i<res.length;i++)
          {
          this.purchaseorder.purchaseOrderItems.push({
            itemId:res[i].itemId,
            itemDescription:res[i].itemDescription,
            itemUom:res[i].uom,
            //accountCode:res[i].accountId,
            prNumber:res[i].prNumber,
            prId:res[i].prId,
            shipToLocation:res[i].prLocation,
            rate:res[i].ratePerUnit.toFixed(2),
            quantity:res[i].quantity,
            //memo:res[i].memo,
            receivedByDate:res[i].receivedDate!=null?new Date(res[i].receivedDate):"",
            department:res[i].department,
            amount:(res[i].quantity*res[i].ratePerUnit).toFixed(2),
            totalAmount:(res[i].quantity*res[i].ratePerUnit).toFixed(2),
            //totalAmount:parseFloat(this.purchaseorder.purchaseOrderItems[i].amount)+(this.purchaseorder.purchaseOrderItems[i].taxAmount != undefined? this.purchaseorder.purchaseOrderItems[i].taxAmount:0.00),
            taxAmount:"0.00",
            deleted:false
           });
           this.CalculateAmmount(this.purchaseorder.purchaseOrderItems[i].quantity,this.purchaseorder.purchaseOrderItems[i].rate,i);
          }
          
          }*/
         //this.purchaseorder.purchaseOrderItems=res;
         //this.purchaseorder.purchaseOrderItems=res;
        }
        }
      }
    },
      error => {
        console.log(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
}
onQAItemChange(index: number, value: string) {


    if(this.purchaseorder.purchaseOrderItems.length>1)
    {
    for(let i=0;i<this.purchaseorder.purchaseOrderItems.length-1;i++)
    {
      if(this.purchaseorder.purchaseOrderItems[i].deleted!=true)
      {
      if(this.purchaseorder.purchaseOrderItems[i].itemId==this.purchaseorder.purchaseOrderItems[index].itemId && index!=i)
      {
            this.showAlert("Duplicate Item Found");
            this.isReloadItem=true;
            this.purchaseorder.purchaseOrderItems[index].itemId=0;
            this.isReloadItem=false;
            if (index >= 0) this.purchaseorder.purchaseOrderItems.splice(index, 1);
            return;
      }
    }

    }


    }
    else
    {

    }
 
  let that = this;
  this.httpService
  .GetAll(`/procure-ws/po/find-poitems-in-po-by-qa-item?qaId=${this.purchaseorder.qaId}&itemId=${value}`,this.RetloginDetails.token )
  .subscribe((res) => {
    
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
    if(res){
      this.toastService.addSingle(
        'error',
        'Error',
        res
      );
      this.purchaseorder.purchaseOrderItems[index].itemId=0
    }else{
    this.QAitemList.find(o => {
      if (o.itemId === parseInt(value)) {
        that.purchaseorder.purchaseOrderItems[index].itemDescription = o.itemDescription;
        that.purchaseorder.purchaseOrderItems[index].itemUom = o.uom;
        that.purchaseorder.purchaseOrderItems[index].accountCode=o.accountCode!;
        that.purchaseorder.purchaseOrderItems[index].prNumber=o.prNumber;
        that.purchaseorder.purchaseOrderItems[index].shipToLocation=that.purchaseorder.locationName;
        that.purchaseorder.purchaseOrderItems[index].rate=o.ratePerUnit.toFixed(2);
        that.purchaseorder.purchaseOrderItems[index].quantity=o.quantity;
        //that.purchaseorder.purchaseOrderItems[index].memo=o.memo;
        that.purchaseorder.purchaseOrderItems[index].receivedByDate=o.recievedDate;
        //that.purchaseorder.purchaseOrderItems[index].department=o.department;
        this.purchaseorder.purchaseOrderItems[index].amount=(o.quantity*o.ratePerUnit).toFixed(2);
        this.purchaseorder.purchaseOrderItems[index].totalAmount=parseFloat(this.purchaseorder.purchaseOrderItems[index].amount)+this.purchaseorder.purchaseOrderItems[index].taxAmount;
      }
    });
    this.CalculateAmmount(that.purchaseorder.purchaseOrderItems[index].quantity,that.purchaseorder.purchaseOrderItems[index].rate,index);
   }
  }
  });
  // this.QAitemList.find(o => {
  //   if (o.itemId === parseInt(value)) {
  //     that.purchaseorder.purchaseOrderItems[index].itemDescription = o.itemDescription;
  //     that.purchaseorder.purchaseOrderItems[index].itemUom = o.uom;
  //     that.purchaseorder.purchaseOrderItems[index].accountCode=o.accountCode!;
  //     that.purchaseorder.purchaseOrderItems[index].prNumber=o.prNumber;
  //     that.purchaseorder.purchaseOrderItems[index].shipToLocation=that.purchaseorder.locationName;
  //     that.purchaseorder.purchaseOrderItems[index].rate=o.ratePerUnit;
  //     that.purchaseorder.purchaseOrderItems[index].quantity=o.quantity;
  //     //that.purchaseorder.purchaseOrderItems[index].memo=o.memo;
  //     that.purchaseorder.purchaseOrderItems[index].receivedByDate=o.recievedDate;
  //     //that.purchaseorder.purchaseOrderItems[index].department=o.department;
  //     this.purchaseorder.purchaseOrderItems[index].amount=(o.quantity*o.ratePerUnit).toFixed(2);
  //     this.purchaseorder.purchaseOrderItems[index].totalAmount=parseFloat(this.purchaseorder.purchaseOrderItems[index].amount)+this.purchaseorder.purchaseOrderItems[index].taxAmount    

  //   }
  // });
}
onSupplierAllChange(){
  if(this.purchaseorder.supplierUpdatable){
    this.GetSupplierList();
  }
  else{
    if(this.purchaseorder.qaId)
    this.GetSupplierListByQA();
  }
}
/* Start fetching History details */
LoadHistory() {
  if (this.POHistoryList.length == 0)
    this.httpService
      .GetById(`/procure-ws/po/get/history?poNumber=${this.purchaseorder.poNumber}&pageSize=100`,
        this.poNumber,this.RetloginDetails.token
      )
      .subscribe((res) => {
        
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
        this.POHistoryList = res;
      }
      });
}

/* End fetching History details */

/* End Fetch Item list from api */
// [{
//   "prNumber":"PR/21-22/10001",
// "currency":"INR"
// }]
sendPrForApproval(po_no:any,type:any) {

  this.DownloadReport(po_no,type);  
  
  setTimeout(() => {
    this.showloader=true;
  this.send_for_approval_object.id=this.purchaseorder.id;
  this.send_for_approval_object.base64=this.poReport.base64;

  this.httpService.Insert('/procure-ws/po/send-for-approval' ,this.send_for_approval_object,this.RetloginDetails.token)
      .subscribe((res) => {
        
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
       if (res == true) {
        location.reload();
        this.showloader=false;
        this.toastService.addSingle(
          'success',
          'Success',
          'PO Sent for Approval Successfully!'
        );
        this.router.navigate([this.listURL]);
       } else {
        this.showloader=false;
        this.showAlert(res.errorMessage);
      }
    }
      },
        (error) => {
          this.showloader=false;
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending PO for Approval!'
          );
        }

      );
  },800);
  
}

selfApproval() {
  this.showloader=true;
  this.httpService
    .GetById('/procure-ws/po/self-approve?poId=' + this.purchaseorder.id, this.purchaseorder.id,this.RetloginDetails.token)
    .subscribe((res) => {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
     if (res == true) {
      this.showloader=false;
      location.reload();
      this.toastService.addSingle(
        'success',
        'Success',
        'PO Approved Successfully!'
      );
     } else {
      this.showloader=false;
      this.showAlert(res.errorMessage);
    }
  }
    },
    
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured while sending PO for Approval!'
        );
        this.showloader=false;
      }

    );
}

showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}
showCSTMAlert(AlertMSG:string,AlertType:string,Alert:string) {
  this.toastService.addSingle(
    AlertType,
    Alert,
    AlertMSG
  );
}
/* Start Reload subsidery */
reloadSubidery(){
  //$('.refsubsidery').addClass('fa-spin');
  /*this.PRitemList = [];
  this.isReloadSub=true;
  this.purchaseorder.subsidiaryId=0;
  this.GetSubsideryList();
 
  this.supplierlist=[];
  this.locationlist=[];
  this.purchaseorder.amount=0.00;
  this.purchaseorder.taxAmount=0.00;
  this.purchaseorder.totalAmount=0.00;
  this.PRList=[];
  this.SelectedPRList=[];
  this.purchaseorder.purchaseOrderItems=[];*/
  location.reload();
}
/* End Reload subsidery */
/* Start Reload supplier */
reloadSupplier(){

  //$('.refsubsidery').addClass('fa-spin');
 // this.isReloadSupplier=true;
  this.purchaseorder.supplierId=0;
  if(this.purchaseorder.poType=="QA Based")
  {
  
    this.GetSupplierListByQA();
  }
  else
  {
    this.GetSupplierList();
  }
 
  this.taxgroup.taxRateRules=[];
  this.purchaseorder.purchaseOrderItems=[];
  this.billingAddressList=[];
  this.shippingAddressList=[];
  this.purchaseorder.trn="";

  this.currency=[];
  this.purchaseorder.exchangeRate="";
  this.purchaseorder.paymentTerm="";
  this.purchaseorder.amount=0.00;
  this.purchaseorder.taxAmount=0.00;
  this.purchaseorder.totalAmount=0.00;
  




}
/* Start Reload Currency */
reloadCurrency(){
  //$('.refsubsidery').addClass('fa-spin');
  //this.isReloadCurrency=true;
  this.purchaseorder.currency="";
  this.GetSupplierCurrencyList();

}
/* End Reload Currency */
reloadItem(index:any){
  //$('.refsubsidery').addClass('fa-spin');
  this.isReloadItem=true;
  this.purchaseorder.purchaseOrderItems[index].itemId=0;
  this.isReloadItem=false;
  this.taxgroup.taxRateRules=[];
  this.purchaseorder.purchaseOrderItems[index].itemDescription = "";
  this.purchaseorder.purchaseOrderItems[index].itemUom = "";
  this.purchaseorder.purchaseOrderItems[index].accountCode=0;
  this.purchaseorder.purchaseOrderItems[index].prNumber="";
  this.purchaseorder.purchaseOrderItems[index].prId="";
  this.purchaseorder.purchaseOrderItems[index].shipToLocation="";
  this.purchaseorder.purchaseOrderItems[index].rate="";
  this.purchaseorder.purchaseOrderItems[index].quantity="";
  this.purchaseorder.purchaseOrderItems[index].memo="";
  this.purchaseorder.purchaseOrderItems[index].receivedByDate="";
  this.purchaseorder.purchaseOrderItems[index].department="";
  this.purchaseorder.purchaseOrderItems[index].amount="";
  this.purchaseorder.purchaseOrderItems[index].totalAmount="";  
  this.purchaseorder.purchaseOrderItems[index].amount=0;
  this.purchaseorder.purchaseOrderItems[index].totalAmount=0;
  this.purchaseorder.purchaseOrderItems[index].taxGroupId=0;
 // this.purchaseorder.amount=0;
 //this.purchaseorder.taxAmount=0;
  //this.purchaseorder.totalAmount=0;
  this.taxamount=0;
  this.taxCodeSaveforrefresh(index);
  this.isReloadTax=true;
  this.purchaseorder.purchaseOrderItems[index].taxGroupId=0;
  this.GetTaxGroupList();

}
reloadTax(index:any){
  //$('.refsubsidery').addClass('fa-spin');

  this.taxamount=0;
  this.taxCodeSaveforrefresh(index);
  this.isReloadTax=true;
  this.purchaseorder.purchaseOrderItems[index].taxGroupId=0;
  this.GetTaxGroupList();
  //this.isReloadTax=false;

}
reloadLocation(){
  this.isReloadLocation=true;
  this.purchaseorder.locationId=0
  this.PRList = [];
  this.SelectedPRList=[];
  this.GetLocationList();
  if(this.purchaseorder.poType=="PR Based")
  {

    this.PRitemList=[];
  }
  if(this.purchaseorder.poType=="QA Based")
  {
    this.taxgroup.taxRateRules=[];
    this.QAitemList=[];
    this.GetQALocationList();
  }
  
  if(this.id==undefined || this.isloadbyId==true)
  {
    if(this.purchaseorder.poType!='Standalone Purchase Order')
    {
      this.purchaseorder.purchaseOrderItems=[];
      this.purchaseorder.amount=0.00;
      this.purchaseorder.taxAmount=0.00;
      this.purchaseorder.totalAmount=0.00;
    }
  }


}
decimalfrection(event: any) {

  this.purchaseorder.exchangeRate=parseFloat(event.target.value).toFixed(2)
  //event.target.value=parseFloat(event.target.value).toFixed(2)
 //console.log(this.purchaseorder.exchangeRate)
}
decimalfrectionRate(event: any,index:any) {
  if(event.target.value !="")
  this.purchaseorder.purchaseOrderItems[index].rate=parseFloat(event.target.value).toFixed(2)
}
decimalfrectionQuntity(event: any,index:any) {
  if(event.target.value !="")
  this.purchaseorder.purchaseOrderItems[index].quantity=parseFloat(event.target.value).toFixed(2)
}
// ngAfterViewInit() {
//   this.elementRef.nativeElement.querySelector('.aftab').addEventListener('keypress', this.onClick.bind(this));
// }

// onClick(event:any) {
//   console.log(event);
// }

Checkdate()
{
  this.checkLocationAllow();
  this.getRanges();

  if(this.purchaseorder.poType=="PR Based")
    {
            if(this.purchaseorder.poDate != undefined || this.purchaseorder.poDate != null)
            {
            for(let i=0;i<this.SelectedPRList.length;i++)
            {
              this.httpService.GetAll("/procure-ws/pr/get?id="+this.SelectedPRList[i].id,this.RetloginDetails.token)
              .subscribe(res => {
                
                if(res.status == 401)
                { 
                  this.showAlert("Unauthorized Access !");
                  this.router.navigate(['/login']);
                }
                else if(res.status == 404)
                { 
                  this.showAlert("Wrong/Invalid Token!");
                  this.router.navigate(['/login']);
                }
                else
                {
                if(res)
                {
                  
                  if(new Date(this.purchaseorder.poDate) < new Date(res.prDate))
                   {
          
                      let POdays:any = new Date(this.purchaseorder.poDate).getDate();
                      let POmonths:any = new Date(this.purchaseorder.poDate).getMonth()+1;
                      let POyear:any = new Date(this.purchaseorder.poDate).getFullYear();
                      let PRdays:any = new Date(res.prDate).getDate();
                      let PRmonths:any = new Date(res.prDate).getMonth()+1;
                      let PRyear:any = new Date(res.prDate).getFullYear();
                      if(POdays==PRdays && POmonths==PRmonths && POyear==PRyear)
                      {
          
                      }
                      else
                      {
                        this.showAlert("PO Date must be greater than and equal to PR Date: "+(res.prDate !== undefined ? ((PRdays.toString().length ==1?"0"+PRdays:PRdays)+ '-' +(PRmonths.toString().length ==1?"0"+PRmonths:PRmonths)+ '-' + PRyear  ) :""));
                        this.purchaseorder.poDate={};
                        return;
                      }
          
          
          
                  }
                  
                }
              }
              },
                error => {
                  this.showAlert(error);
                },
                () => {
                  // 'onCompleted' callback.
                  // No errors, route to new page here
                });
            }
            }
   }
   else  if(this.purchaseorder.poType=="QA Based")
   {
    this.httpService.GetAll("/procure-ws/quotation-analysis/get?id="+this.purchaseorder.qaId,this.RetloginDetails.token)
    .subscribe(res => {
      if(res)
      {
  
        if(res.status == 401)
        { 
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { 
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {
        this.httpService.GetById("/procure-ws/quotation/get?id=" + res.rfqId, res.rfqId,this.RetloginDetails.token)
        .subscribe(res => {
          
          if(res.status == 401)
          { 
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { 
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
          {
          if (res != undefined) {
                  
           if(new Date(this.purchaseorder.poDate) < new Date(res.bidOpenDate))
           {
            let bidOpendays:any = new Date(res.bidOpenDate).getDate();
            let bidOpenmonths:any = new Date(res.bidOpenDate).getMonth()+1;
            let bidOpenyear:any = new Date(res.bidOpenDate).getFullYear();
            this.showAlert("PO Date must be greater than and equal to Bid Open Date : "+(res.bidOpenDate !== undefined ? ((bidOpendays.toString().length ==1?"0"+bidOpendays:bidOpendays)+ '-' +(bidOpenmonths.toString().length ==1?"0"+bidOpenmonths:bidOpenmonths)+ '-' + bidOpenyear  ) :""));
            this.purchaseorder.poDate={};
            return;
           }

          }
        }
        },
          error => {
           this.showAlert(error);
          },
          () => {

            // 'onCompleted' callback.
            // No errors, route to new page here
          });
        }

      }
    },
      error => {
        this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
   }


}
CheckReceivedate(rowIndex:number)
{
    if(new Date(this.purchaseorder.purchaseOrderItems[rowIndex].receivedByDate) < new Date(this.purchaseorder.poDate))
    {
      let podays: any = new Date(this.purchaseorder.poDate).getDate();
      let pomonths: any = new Date(this.purchaseorder.poDate).getMonth() + 1;
      let poyear: any = new Date(this.purchaseorder.poDate).getFullYear();

      let receivedays: any = new Date(this.purchaseorder.purchaseOrderItems[rowIndex].receivedByDate).getDate();
      let receivemonths: any = new Date(this.purchaseorder.purchaseOrderItems[rowIndex].receivedByDate).getMonth() + 1;
      let receiveyear: any = new Date(this.purchaseorder.purchaseOrderItems[rowIndex].receivedByDate).getFullYear();

     if(podays==receivedays &&  pomonths==receivemonths && poyear==receiveyear)
     {

     }
     else
     {
      this.showAlert("Receive Date must be greater than and equal to PO Date");
      this.purchaseorder.purchaseOrderItems[rowIndex].receivedByDate= {};
      return;
     }



   }
}

// SelectPRS()
// {

//   if (this.purchaseorder.prNumbers ) {
//     for (var key in this.purchaseorder.prNumbers) {
//       if (this.purchaseorder.prNumbers.hasOwnProperty(key)) {
//         let _key:any;
//         _key=key;

//             this.PRList.push({name:this.purchaseorder.prNumbers[key],id:_key})

//       }
//   }
//     this.PRListcatche=[];

//     for (var key in this.purchaseorder.prNumbers) {
//       if (this.purchaseorder.prNumbers.hasOwnProperty(key)) {
//         let _key:any;
//         _key=key;
         
//             this.PRListcatche.push({name:this.purchaseorder.prNumbers[key],id:_key})
         
//       }
//   }




//       let copiedValue = JSON.parse(
//       JSON.stringify(this.PRListcatche)
//      );
//       //this.supplier.supplierAccess.supplierRoles = [];
//       this.SelectedPRList=[];
//       copiedValue.forEach((element: any) => {
//         let item = this.PRList.find(
//           (o) => o.id == element.id
//         );
//         if (item) {
//           let role = new POPrs();
//           role.id=element.id;
//           role.name = item.name;
//           //role.deleted=element.deleted;
          
          
//           //role.roleName = item.roleName;
//           //this.supplier.supplierAccess.supplierRoles?.push(role);
//           this.SelectedPRList?.push(role);
//         }
//       });
//    // }
//   }
// }

SelectPRS()
{
  this.PRListcatche=[];

  for (var key in this.purchaseorder.prNumbers) {
    if (this.purchaseorder.prNumbers.hasOwnProperty(key)) {
      let _key:any;
      _key=key;
       
          this.PRListcatche.push({name:this.purchaseorder.prNumbers[key],id:_key})
    }
}

for(let i=0;i<this.PRListcatche.length;i++)
{
  for(let j=0;j<this.PRList.length;j++)
  {
    if(this.PRList[j].name==this.PRListcatche[i].name)
    {
      this.PRList.splice(j,1);
    }
  }
}
  if (this.purchaseorder.prNumbers ) {
    for (var key in this.purchaseorder.prNumbers) {
      if (this.purchaseorder.prNumbers.hasOwnProperty(key)) {
        let _key:any;
        _key=key;
        //this.PRList.splice(6,1);
        this.PRList.push({name:this.purchaseorder.prNumbers[key],id:_key})

      }
  }

      let copiedValue = JSON.parse(
      JSON.stringify(this.PRListcatche)
     );
      //this.supplier.supplierAccess.supplierRoles = [];
      this.SelectedPRList=[];
      copiedValue.forEach((element: any) => {
        let item = this.PRList.find(
          (o) => o.id == element.id
        );
        if (item) {
          let PO = new POPrs();
          PO.id=element.id;
          PO.name = item.name;
          //role.deleted=element.deleted;
          
          
          //role.roleName = item.roleName;
          //this.supplier.supplierAccess.supplierRoles?.push(role);
          this.SelectedPRList?.push(PO);
        }
      });
   // }
  }
}

reloadPRList()
{
  if(this.purchaseorder.poType=="PR Based")
  {
    this.PRList=[];
    this.SelectedPRList=[];
    this.taxgroup.taxRateRules=[];
    this.purchaseorder.purchaseOrderItems=[];
    this.purchaseorder.amount=0.00;
    this.purchaseorder.taxAmount=0.00;
    this.purchaseorder.totalAmount=0.00;
    this.reloadLocation();
  }
  
}

chkforshiptoloc()
{


    if(this.purchaseorder.matchType=="3 Way")
    {
      if(this.purchaseorder.poType=="Standalone Purchase Order")
      {
        this.shiptoloc=true;
        this.shiptolocreq=false;
      }
      else{
        this.shiptoloc=false;
        this.shiptolocreq=true;
      }

    }
    else{
      this.shiptoloc=false;
      this.shiptolocreq=true;
    }
}

// Report
DownloadReport_old(poNumber:any){
  window.open(this.httpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
  }
  DownloadReport(poNumber:any,type:any){
    this.showloader=true;
    //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
  this.poReport.exportPdf(poNumber,type);  
  this.showloader=false;
  }

checkforexchangerate()
{
 
  if(this.subsidiary.currency==this.purchaseorder.currency)
  {
    this.ExSameCurrency=false;
    this.ExOtherCurrency=true;
    this.purchaseorder.exchangeRate=parseFloat( this.purchaseorder.exchangeRate).toFixed(2);
  
  }
  else
  {
    this.ExSameCurrency=true;
    this.ExOtherCurrency=false;
    
  }
}

getRanges() {
  if(this.purchaseorder.subsidiaryId != undefined){
  this.httpService
  .GetById('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId=' + this.purchaseorder.subsidiaryId, this.purchaseorder.subsidiaryId,this.RetloginDetails.token)
  .subscribe((res) => {
    if (res) {
      
if(res.status == 401)
{ 
  this.showAlert("Unauthorized Access !");
  this.router.navigate(['/login']);
}
else if(res.status == 404)
{ 
  this.showAlert("Wrong/Invalid Token!");
  this.router.navigate(['/login']);
}
else
{
      this.fiscalCalenderDTLS=res;
      if(this.fiscalCalenderDTLS != null && this.fiscalCalenderDTLS.fiscalCalanderAccounting.length >0)
      {
      let AllowMonths: any = "Allow Months: ";
      let IsDateAvailable:boolean = false;
    
      var Dummymonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    
      let PRdays: any = new Date(this.purchaseorder.poDate).getDate();
      let PRmonths: any = new Date(this.purchaseorder.poDate).getMonth() + 1;
      let PRyear: any = new Date(this.purchaseorder.poDate).getFullYear();
      let PRDate: any = this.purchaseorder.poDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""
    
      for (let x = 0; x < this.fiscalCalenderDTLS.fiscalCalanderAccounting.length; x++) {
        AllowMonths += this.fiscalCalenderDTLS.fiscalCalanderAccounting.length == (x + 1) ? this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month : this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month + " , "
    
        if (PRDate >= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].fromDate && PRDate <= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].toDate && this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month == Dummymonths[PRmonths - 1] + "-" + PRyear) {
          IsDateAvailable = true;
        }
      }
    
      if (IsDateAvailable == false) {
        this.showAlert("Selected Date is Not available in Fiscal Calendar ! " + AllowMonths);
        this.purchaseorder.poDate = {};
      }
    }
    else
    {
      this.showAlert("Selected Date is Not available in Fiscal Calendar !");
      this.purchaseorder.poDate = {};
    }
  }
    } else {
      this.showAlert("No Data Found");
    }
  },
    (error) => {
      this.toastService.addSingle(
        'error',
        'Error',
         error
      );
    }
  );

}

}

approveIndividual(mainId:any)
{
  try {
    var approveList: any = [];
    approveList.push(mainId);

    if (approveList.length > 0) {
      this.showloader = true;
        //this.HttpService.Insert('/procure-ws/pr/approve-all-prs',approveList,this.RetloginDetails.token).subscribe(
          this.httpService.Insert('/procure-ws/po/approve-all-po', approveList, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else if (res.messageCode) {
            this.showloader = false;
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );

          } else {
            this.showloader = false;
            this.toastService.addSingle(
              'success',
              'Success',
              'Purchase Order successfully approved'
            );
            this.router.navigate([this.listURL]);
          }
          // this.loading = false;
        },
        (error) => {
          this.showAlert(error);
        }
      );
    }
  } catch (err) {
  }
}
rejectIndividual(mainId:any,RowNo:any)
{
  try {
    if( this.purchaseorder.comments==undefined)
    {
      this.showAlert("Please enter Reject Comments");
      return true;
    }
      var rejectList: any = [];
      var isrejectComments: boolean = true;
      rejectList.push({ id: mainId, rejectedComments: this.purchaseorder.comments })
            isrejectComments = true;
            //this.isRejectPressed = true
            
      if (isrejectComments) {
        this.showloader = true;
          //this.HttpService.Insert('/procure-ws/pr/reject-all-prs',rejectList,this.RetloginDetails.token).subscribe(
            this.httpService.Insert('/procure-ws/po/reject-all-pos', rejectList, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );
              isrejectComments=false;
            }
            else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Reject selected Purchases Order!'
              );
              this.router.navigate(['/main/purchase-order/po-approval']);
            }
            // this.loading = false;
          },
          (error) => {
            this.showloader = false;
            this.showAlert(error);
          }
        );
      }
    
  } catch (err:any) {
    this.showAlert(err);
  }
}
hidepopupcomments()
{
    this.display_comments=false;
}



opendialog()
{
  this.display_comments=true;
}
ReloadGetAllEmployeeList()
{
  //this.EmployeeList=[];
  //this.fnRequesterList();
}
fnRequesterList()
{
  
  this.httpService.GetById('/masters-ws/employee/get-employee-by-subsidiary?subsidiaryId=' + this.purchaseorder.subsidiaryId, this.purchaseorder.subsidiaryId,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

      if (res != undefined) {
        this.EmployeeList=[];
      this.EmployeeList = res;
      }
    }
    },
    (error) => {
      this.showAlert(error);
    },
    ()=>{
      if(this.addMode)
      {//this.purchaseorder.requestor=0;
      //  this.purchaseorder.requestor=this.loginId;
    }
    }
    );
}
loadrequestor()
{
  this.httpService.GetAll('/masters-ws/employee/get?id='+this.loginId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.purchaseorder.requestor=res.fullName
     
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );

}

OpenAppSequence()
{
  this.isAppSequenceVisivble=true;
}
GetDepartmentList() {
debugger
  this.httpService.GetAll('/masters-ws/department/get/all/lov?subsidiaryId='+this.purchaseorder.subsidiaryId,this.RetloginDetails.token).subscribe(
  (res) => {
    if(res.status == 401)
  { 
    this.showAlert("Unauthorized Access !");
    this.router.navigate(['/login']);
  }
  else if(res.status == 404)
  { 
    this.showAlert("Wrong/Invalid Token!");
    this.router.navigate(['/login']);
  }
  else
  {
    this.departmentOptions=[];
    Object.keys(res).forEach(key => { 
      this.departmentOptions.push({
          "id":Number(key),
          "departmentName":res[key]
        })   
      });
   // this.departmentOptions = res;
  }
  },
  (error) => {
    this.showAlert(error);
  }
);

}
GetDepartmentList_edit_header(id:any) {

  if(id==null)
  {
          let departmentId:any;
          let isdepartment:boolean=false;
          departmentId=this.purchaseorder.purchaseOrderItems[0].departmentId;
          for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
          { 
            if(departmentId==this.purchaseorder.purchaseOrderItems[i].departmentId)
            {
               isdepartment=false;
            }
            else
            {
               isdepartment=true;
               break;
            }
          }
          if(isdepartment)
          {
            this.purchaseorder.department="All";
            this.purchaseorder.departmentId=0;
          }
          else
          {
            this.GetDepartmentList_edit_header(this.purchaseorder.purchaseOrderItems[0].departmentId);
            this.purchaseorder.departmentId=this.purchaseorder.purchaseOrderItems[0].departmentId;
          }
          isdepartment=false;
  }

else if(id==0)
{
  this.purchaseorder.department= "All";
}
else
{
  this.httpService.GetById("/masters-ws/department/get?id="+id, id, this.RetloginDetails.token)
  .subscribe(res => {
    if(res.status == 401)
     { this.showAlert("Unauthorized Access !");
       this.router.navigate(['/login']);
     }
     else if(res.status == 404)
     { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
     else if(res.errorMessage){
      this.showAlert(res.errorMessage)
     }else{
     
      this.purchaseorder.department= res.departmentName;
    }
  },
  error => {
   this.showAlert(error);
  },
  () => {
    // 'onCompleted' callback.
    // No errors, route to new page here
  });
}



}

GetDepartmentList_edit_line() {
  for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
  {
    
    this.httpService.GetById("/masters-ws/department/get?id="+this.purchaseorder.purchaseOrderItems[i].departmentId, this.purchaseorder.purchaseOrderItems[i].departmentId, this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
       else if(res.errorMessage){
        this.showAlert(res.errorMessage)
       }else{
       
        this.purchaseorder.purchaseOrderItems[i].department= res.departmentName;
      }
    },
    error => {
     this.showAlert(error);
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    });
  }



}

reloadDepartment()
{
  this.purchaseorder.departmentId=undefined;
  this.GetDepartmentList();
}

recall()
{
  this.showloader = true;
  this.httpService.GetAll('/procure-ws/po/change-to-draft?id='+ this.poNumber,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.showloader = false;
      this.showSuccessrecall();
      this.router.navigate(['/main/purchase-order/list']);
    }
    },
    (error) => {
      this.showloader = false;
      this.showAlert(error);
    }
  );
}
reloadProjectList()
{
  this.ProjectList=[];
  this.GetAllProjectList(this.purchaseorder.subsidiaryId);
  this.PRList=[];
  this.SelectedPRList=[];
  this.purchaseorder.purchaseOrderItems=[];
  this.purchaseorder.department=undefined;
  this.purchaseorder.amount=0.00;
  this.purchaseorder.taxAmount=0.00;
  this.purchaseorder.totalAmount=0.00;
}
GetAllProjectList(subsidiaryId:any)
{
  this.httpService.GetById('/masters-ws/project/get-by-subsidiary-id?subsidiaryId=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      
      this.ProjectList=[];
      for(let x=0;x<res.length;x++)
      {
        this.ProjectList.push({
          "id":res[x].id,
          "name":res[x].name
        })
      }
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );
//  var obj={
//    filters:{   
//    },
//    pageNumber: 0,
//    pageSize: 1000,
//    sortColumn: "p.id",
//    sortOrder: "asc"
// }
// this.httpService.Insert("/project/get/all",obj)
// .subscribe(res => {
//  this.ProjectList=res.list;
//  });
}
Loadpr()
{
  if(this.purchaseorder.poType=="PR Based")
  {
    this.PRList=[];
    this.SelectedPRList=[];
    this.purchaseorder.purchaseOrderItems=[];
    this.purchaseorder.department=undefined;
    this.purchaseorder.amount=0.00;
    this.purchaseorder.taxAmount=0.00;
    this.purchaseorder.totalAmount=0.00;
    this.GetPRList();
  }

 
  //this.projectname=event.originalEvent.currentTarget.ariaLabel;
}

loaddepttoline(event:any)
{    
  this.departmentname=event.originalEvent.currentTarget.ariaLabel;

   for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
  {
    
    this.purchaseorder.purchaseOrderItems[i].department=event.originalEvent.currentTarget.ariaLabel;
    this.purchaseorder.purchaseOrderItems[i].departmentId=this.purchaseorder.departmentId;
   }
  

}

loaddepartment()
{
          let department:any;
          let isdepartment:boolean=false;
          department=this.purchaseorder.purchaseOrderItems[0].department;
          for(let i=0;i<this.purchaseorder.purchaseOrderItems.length;i++)
          { 
            if(department==this.purchaseorder.purchaseOrderItems[i].department)
            {
               isdepartment=false;
            }
            else
            {
               isdepartment=true;
               break;
            }
          }
          if(isdepartment)
          {
            this.purchaseorder.department="All";
            this.purchaseorder.departmentId=0;
          }
          else
          {
            this.purchaseorder.department=this.purchaseorder.purchaseOrderItems[0].department;
            this.purchaseorder.departmentId=this.purchaseorder.purchaseOrderItems[0].departmentId;
          }
          isdepartment=false;
}

}
