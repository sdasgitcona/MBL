import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PurchaseOrderAddEditComponent } from './purchase-order-add-edit/purchase-order-add-edit.component';
import { PurchaseOrderApprovalComponent } from './purchase-order-approval/purchase-order-approval.component';
import { PurchaseOrderListComponent } from './purchase-order-list/purchase-order-list.component';
const routes: Routes = [
  {
    path: '',
    component: PurchaseOrderListComponent,
  },
  {
    path: 'list',
    component: PurchaseOrderListComponent,
  },
  {
    path: 'list/:status',
    component: PurchaseOrderListComponent,
  },
  {
    path: 'list/:status/:id',
    component: PurchaseOrderListComponent,
  },
  {
    path: 'action/:action/:id',
    component: PurchaseOrderAddEditComponent,
  },
  {
    path: 'action/:action',
    component: PurchaseOrderAddEditComponent,
  },
  {
    path: 'po-approval',
    component: PurchaseOrderApprovalComponent,
  },
  {
    path: 'po-approval/:status',
    component: PurchaseOrderApprovalComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PurchaseOrderRoutingModule { }
