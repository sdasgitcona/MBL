export class PurchaseOrder1 {
    id: number;
    subsidiaryId: number;
    itemline: Item1[] = [];
}

export class Item1 {
    id: number;
    itemname:string;
    itemdescription:string;
    nsinternalid:string;
    accountcode:string
    uom:string;
    quantity:string;
    rate:string;
    amount:string;
    taxgroup:string;
    taxamount:string;
    totalamt:string;
    receivebydate:string;
    prnumber:string;
    shiptolocation:string;
    department:string;
    memo:string

}
export class Item {
    id?: any;
    poNumber?: string;
    poId?: number;
    itemId?: number;
    quantity?: any;
    rate?: any;
    amount?: any;
    taxGroupId?: any;
    taxAmount?: any;
    totalTaxAmount?:any;
    receivedByDate?: any;
    prNumber?: string;
    prId?:any;
    shipToLocationId?: number;
    shipToLocation?: string;
    department: string;
    departmentId?: number;
    memo?: string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    itemName?: any;
    itemDescription?: any;
    accountCode?: number;
    itemUom?: any;
    itemIntegratedId?: any;
    deleted?: boolean;
    totalAmount?: any;
    unbilledQuantity?:any;
    remainQuantity?:any;
    status?:string;
    billQuantity?: any;

}
export class PrItems {
    id?: any;
    prId?: any;
    prNumber: string;
    itemId: number;
    itemDescription: string;
    quantity: number;
    rate: number;
    memo?: any;
    integratedId?: any;
    estimatedAmount?: any;
    receivedDate: Date;
    poNumber?: any;
    createdDate?: any;
    createdBy?: any;
    lastModifiedDate?: any;
    lastModifiedBy?: any;
    itemName: string;
    itemUom: string;
    department: string;
    accountId: number;
    deleted: boolean;
    prLocationName:any
}
export class QAItems {
    id: number;
    qaId?: any;
    qaNumber: string;
    clientQaNumber?: any;
    recievedDate: Date;
    generalSupplier?: any;
    approvedSupplier?: any;
    itemId: number;
    currency?: any;
    quantity: number;
    uom: string;
    exchangeRate?: any;
    ratePerUnit: number;
    actualRate: number;
    expectedDate?: any;
    leadTime?: any;
    prNumber?: any;
    prLocationId?: any;
    poRef?: any;
    createdDate?: any;
    createdBy?: any;
    lastModifiedDate?: any;
    lastModifiedBy?: any;
    prLocation?: any;
    itemName: string;
    itemDescription: string;
    integratedId?: any;
    accountCode?: number;
    deleted: boolean;
    processedPo: boolean;
    awarded: boolean;
}
export class supplierCurrency {
    id: number;
    supplierId: number;
    subsidiaryId: number;
    currency: string;
    supplierCurrency: string;
    createdDate?: any;
    createdBy?: any;
    lastModifiedDate?: any;
    lastModifiedBy?: any;
    subsidiaryName: string;
    deleted: boolean;
    preferredCurrency: boolean;
}
export class PurchaseOrder {
    id?: number;
    poNumber?: string;
    subsidiaryId?: number;
    poType?: string="PR Based";
    locationId?: any;
    location?: string;
   // prNumber: any;
    prId?:any;
    qaNumber?: any;
    qaId?:any;
    supplierId?: number;
    supplierNametoshow?: string;
    originalSupplierId?: number;
    poDate?: any;
    rejectedComments?: any;
    paymentTerm?: string;
    matchType?: string;
    currency?: string;
   // projectId?:number;
    exchangeRate?: any;
    poStatus?: string;
    memo?: string;
    netsuiteId?: string;
    approvedBy?: any;
    nextApprover?: any;
    nextApproverRole?: any;
    nextApproverLevel?: any;
    approverPreferenceId?: any;
    approverSequenceId?: any;
    approverMaxLevel?: any;
    noteToApprover?: any;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    subsidiaryName?: any;
    supplierName?: any;
    locationName?: any;
    totalValue?: any;
    purchaseOrderItems: Item[] = [];
    revision?: number;
    deleted?: boolean;
    approvalRoutingActive?: boolean;
    supplierUpdatable?: boolean;
    isSupplierAll?: boolean;
    billTo?:any;
    shipTo?:any;
    trn?:any;
    amount?:any;
    taxAmount?:any;
    totalAmount?:any;
     // for approval
     selected?:boolean;
     NewrejectComments?: any;
     prNumbers?:any;
     isAdminRole?:boolean;
  isApprovalButtonShowHide?: any;
  isAdminForSave?:boolean;
  comments?:any;
  requestor?:any;
     //isApprovalButtonShowHide: any;
     department?:any;
     departmentId?:number;
     projectId?:any;
       
}

export class POPrs{
    id?: number;            
    quotationId?:number;
    quotationNumber?:string;
    prNumber?:any;
    prLocationId?:number;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted?:boolean;
    name?:any;
    prId?:any;
}

export class PurchaseOrderFilter{
    subsidiaryId?: any;
    supplierId?: any;
    type?:any;
    name?:any;
    projectName?:any;
    location?:any;
    status?:any;
    fromDate?:any;
    toDate?:any;
    requestor?:any;
    recent?:any;
    unApproved?:any;
}
// For CSV
export class file_upliad
{
  file:File;
}
export class RequesterList {
    id?: number;
    fullName?: any;
}

  // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: POFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class POFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}

export class send_for_approval_object
{
  id?:number;
  base64?:any;
  currentApproverId?:number;//employee id of admin and superadmin, do not send it for normal users.
}
