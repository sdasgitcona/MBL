import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { PurchaseOrder,send_for_approval_object } from '../model/purchase-order-module';
import { PoReportComponent } from '../../reports/po-report/po-report.component';

@Component({
  selector: 'app-purchase-order-approval',
  templateUrl: './purchase-order-approval.component.html',
  styleUrls: ['./purchase-order-approval.component.scss']
})
export class PurchaseOrderApprovalComponent implements OnInit {
  columns: any[];
  departments: any[] = [];
  send_for_approval_object_:send_for_approval_object[]=[];
  poApprovalList: PurchaseOrder[] = [];
  poSelectedApproval: PurchaseOrder = new PurchaseOrder();
  totalRecords: number = 0;
  loading: boolean = false;
  AllSelected: boolean = false;
  isRejectPressed: boolean = true;
  approvalRoutingActive: boolean = false;
  approverRoleList: [{ id?: number; name?: string; }];
  SubsidiaryId: any;
  roleId: any;
  empID: number;
  userRoleId: number;
  url:any;
  userId: number;
  RetloginDetails: any;
  showloader: boolean = false;
  @ViewChild('dt') dt: Table;
  RetRoleDetails: any;
  IsLoggerAdmin:any;
  visibleSaveButton:boolean;
  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService,private poReport: PoReportComponent) { }

  ngOnInit(): void {
    if (localStorage.getItem("LoggerDTLS") == null) {
      this.router.navigate(['/login']);
    }
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    //--Login Details
    const logDetails: any = localStorage.getItem("LoggerDTLS");
    const LoggerId = JSON.parse(logDetails);
    this.empID = LoggerId.employeeId;
    const retLoggerDetails: any = localStorage.getItem("LoggerDTLS");
    var logger_Dtls = JSON.parse(retLoggerDetails);
    this.userId = logger_Dtls.id;
    // For Role ID
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails = role_Dtls;
    
    this.IsLoggerAdmin=role_Dtls[0].selectedAccess;
    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "PO Approval") {
        this.userRoleId = role_Dtls[0].rolePermissions[i].roleId
      }
    }
    // End For Role ID
    this.loadPOApproval();

    
   
  }


  loadPOApproval() {
    let ReqData;
    let ReqParam;
    let ReqDataa;
    let ReqParama;
    let reqUrl:any='';
    //if (this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null) //--User:Super Admin
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      ReqData = this.RetRoleDetails[0].accountId;
      ReqParam = 'accountId';
      reqUrl='/procure-ws/po/get-po-appoval?' + ReqParam + '=' + ReqData;
    }
    //else if ((this.RetRoleDetails[0].selectedAccess == 'ADMIN' || this.RetRoleDetails[0].selectedAccess == 'ADMIN_APPROVER') && this.RetRoleDetails[0].subsidiaryId != null) //--User:Admin
    else if(this.RetloginDetails.userType=='ENDUSER')
    {
      if(this.RetRoleDetails[0].selectedAccess == 'APPROVER')
      {
        ReqData = this.empID;
        ReqParam = 'userId';
        ReqDataa=this.RetRoleDetails[0].subsidiaryId;
        ReqParama = 'subsidiaryId';
        reqUrl='/procure-ws/po/get-po-appoval?'+ReqParam+'=' + ReqData+'&' +ReqParama+'=' + ReqDataa;
      }
      else
      {
        ReqData = this.RetRoleDetails[0].subsidiaryId;
        ReqParam = 'subsidiaryId';
        reqUrl='/procure-ws/po/get-po-appoval?' + ReqParam + '=' + ReqData;
      }
     
    }
    else //--User:Others
    {
      ReqData = this.empID;
      ReqParam = 'userId'
      reqUrl='/procure-ws/po/get-po-appoval?' + ReqParam + '=' + ReqData;
    }
    try {
      this.showloader = true;
      //this.HttpService.GetAll('/procure-ws/po/get-po-appoval?' + ReqParam + '=' + ReqData, this.RetloginDetails.token).subscribe(
        this.HttpService.GetAll(reqUrl, this.RetloginDetails.token).subscribe(
        //this.HttpService.GetAll('/procure-ws/po/get-po-appoval?userId='+this.empID,this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.length > 0) {
              for (let i = 0; i < res.length; i++) {
                this.NextApproverLov(res[i].subsidiaryId)
              }
              this.poApprovalList = res;
              for (let k = 0; k < this.poApprovalList.length; k++) {
                this.poApprovalList[k].nextApprover = Number(this.poApprovalList[k].nextApprover);
                //this.poApprovalList[k].nextApproverRole= this.poApprovalList;
                this.poApprovalList[k].nextApproverRole = this.RetRoleDetails[0].name;
                //this.poApprovalList[k].isAdminRole = (this.RetRoleDetails[0].selectedAccess == "ADMIN" || this.RetRoleDetails[0].selectedAccess == "ADMIN_APPROVER") ? false : true;
                this.poApprovalList[k].isAdminRole =(this.IsLoggerAdmin=="ADMIN" || this.IsLoggerAdmin=="ADMIN_APPROVER")?true:false
                this.poApprovalList[k].isAdminForSave=true;
                this.poApprovalList[k].nextApprover=Number(this.poApprovalList[k].nextApprover)
              }

              // setTimeout(() => {
              //   this.NextApproverLov(this.poApprovalList[0].subsidiaryId)
              // }, 250);
             
              this.showloader = false;
              //this.poApprovalList = res;          
              this.totalRecords = res.length;
              this.SubsidiaryId = this.poApprovalList[0]?.subsidiaryId;
              //this.NextApproverLov();

            } else {
              this.poApprovalList = [];
              this.totalRecords = res.length;
              this.showloader = false;
            }
            this.loading = false;
          }
        },
        (error) => {
          this.showAlert(error);
          this.loading = false;
          this.showloader = false;
        }
      );
    } catch (err) {
      this.showAlert(err);
    }
  }

  navigateToAdd() {
    this.router.navigate(['/main/supplier/update']);
  }

  globalSearch(event: any) {
    this.dt.filterGlobal(event.target.value, 'contains')
  }
  approvePO() {
    try {
      this.showloader = true;
      this.isRejectPressed = false
      this.send_for_approval_object_=[];
      this.poApprovalList.map((data: PurchaseOrder) => {
        if (data.selected) {
          this.DownloadReport(data.poNumber,'pr_app_button'); 
          setTimeout(() => { 

            if(this.RetloginDetails.userType=='SUPERADMIN')
            {
              this.send_for_approval_object_.push({
                id:data.id,
                base64: this.poReport.base64,
                currentApproverId:this.empID
              })
            }
            else if(this.RetloginDetails.userType=='ENDUSER')
            {
               if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
               {
                      this.send_for_approval_object_.push({
                        id:data.id,
                        base64: this.poReport.base64,
                        currentApproverId:this.empID
                      })
               }
               else{
                      this.send_for_approval_object_.push({
                        id:data.id,
                        base64: this.poReport.base64,
                        //currentApproverId:this.empID
                      })
               }

           
            }
  
          
           
           },350);
        }
      })
      setTimeout(() => { 
       
        this.HttpService.Insert('/procure-ws/po/approve-all-po', this.send_for_approval_object_, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
              if (res.messageCode) {
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );
                this.showloader = false;
              } else {
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Purchase Order successfully approved'
                );
                this.loadPOApproval();
                this.showloader = false;
              }
            }
            // this.loading = false;
          },
          (error) => {
            this.showAlert(error);
            this.showloader = false;
            // this.loading = false;
          }
        );
      },500);
       
      
    } catch (err) {
      this.showAlert(err);
      this.showloader = false;
    }
  }
  DownloadReport(prNumber:any,type:any){                      //pr pdf changes 140823
    this.showloader=true;
  
  this.poReport.exportPdf(prNumber,type);  //pr pdf changes 140823
  

  //window.open(this.HttpService.ReportUrl+"/run?__report=report/purchase_order.rptdesign&__format=pdf&po_number="+poNumber,'_blank')
  }
  rejectPO() {
    try {
      if (this.isRejectPressed) {
        var rejectList: any = [];
        var isrejectComments: boolean = false
        this.poApprovalList.map((data: PurchaseOrder) => {
          if (data.selected) {
            if (data.NewrejectComments) {
              rejectList.push({ id: data.id, rejectedComments: data.NewrejectComments })
              isrejectComments = true;
              this.isRejectPressed = true

            } else {
              this.toastService.addSingle(
                'error',
                'Error',
                'Please enter Reject Comments'
              );
              // alert("Please enter rejectComments");
              isrejectComments = false;
              this.isRejectPressed = true
              return;
            }
          }
        })
        if (isrejectComments) {
          this.showloader = true;
          this.HttpService.Insert('/procure-ws/po/reject-all-pos', rejectList, this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else {
                if (res.messageCode) {
                  this.isRejectPressed = true
                  this.toastService.addSingle(
                    'error',
                    'Error',
                    res.errorMessage
                  );
                  this.showloader = false;
                } else {
                  this.toastService.addSingle(
                    'success',
                    'Success',
                    'Reject selected Purchases Order!'
                  );
                  this.loadPOApproval();
                  this.showloader = false;
                }
                this.isRejectPressed = true;
                this.showloader = false;
              }
            },
            (error) => {
              this.showAlert(error);
              this.showloader = false;
            }
          );
        }
      } else {
        this.isRejectPressed = true;
      }
    } catch (err) {
      this.showAlert(err);
    }
  }

  approveIndividual(mainId:any,poNumber:any)
  {
    try {
      this.showloader = true;
      this.isRejectPressed = false
      this.send_for_approval_object_=[];
      this.DownloadReport(poNumber,'pr_app_button'); 

      setTimeout(() => { 

        
        if(this.RetloginDetails.userType=='SUPERADMIN')
        {
          this.send_for_approval_object_.push({
            id:mainId,
            base64: this.poReport.base64,
            currentApproverId:this.empID
          })
        }
        else if(this.RetloginDetails.userType=='ENDUSER')
        {
          if(this.RetRoleDetails[0].selectedAccess=="ADMIN"|| this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
          {
                  this.send_for_approval_object_.push({
                    id:mainId,
                    base64: this.poReport.base64,
                    currentApproverId:this.empID
                  })

          }
          else{
                    this.send_for_approval_object_.push({
                      id:mainId,
                      base64: this.poReport.base64,
                      //currentApproverId:this.empID
                    })
          }

         
        }

        this.HttpService.Insert('/procure-ws/po/approve-all-po', this.send_for_approval_object_, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );

            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Purchase Order successfully approved'
              );
              this.loadPOApproval();
            }
            // this.loading = false;
          },
          (error) => {
            this.showAlert(error);
          }
        );

      },500);



      //if (approveList.length > 0) {
       
          //this.HttpService.Insert('/procure-ws/pr/approve-all-prs',approveList,this.RetloginDetails.token).subscribe(
          
     // }
    } catch (err) {
    }
  }
  rejectIndividual(mainId:any,rejectComments:any,RowNo:any)
  {
    try {
      this.poApprovalList[RowNo].selected=true;
      this.isRejectPressed=true;

      if( rejectComments==undefined)
      {
        this.showAlert("Please enter Reject Comments");
        return true;
      }

      if (this.isRejectPressed) {
        var rejectList: any = [];
        var isrejectComments: boolean = false;
        rejectList.push({ id: mainId, rejectedComments: rejectComments })
              isrejectComments = true;
              //this.isRejectPressed = true
              
        if (isrejectComments) {
          this.showloader = true;
            //this.HttpService.Insert('/procure-ws/pr/reject-all-prs',rejectList,this.RetloginDetails.token).subscribe(
              this.HttpService.Insert('/procure-ws/po/reject-all-pos', rejectList, this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else if (res.messageCode) {
                this.showloader = false;
                this.isRejectPressed = true
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );
                this.poApprovalList[RowNo].selected=false;
                this.isRejectPressed=true;
                isrejectComments=false;
                this.poApprovalList[RowNo].NewrejectComments=undefined;
              }
              else {
                this.showloader = false;
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Reject selected Purchases Order!'
                );
                this.loadPOApproval();
              }
              this.isRejectPressed = true
              // this.loading = false;
            },
            (error) => {
              this.showAlert(error);
            }
          );
        }
      } else {
        this.showAlert("Please enter Reject Comments");
        this.isRejectPressed = true;
        this.showloader = false;
      }
    } catch (err) {
      this.showAlert(err);
    }
  }

  onAllSelectChange(event: any) {
    if (event.checked) {
      this.poApprovalList.map((data: PurchaseOrder) => {
        data.selected = true;
        this.isRejectPressed = true
        //this.approvalRoutingActive=true;
      })
    }
    else {
      this.poApprovalList.map((data: PurchaseOrder) => {
        data.selected = false;
        this.isRejectPressed = true;
        //this.approvalRoutingActive=false;

      })
    }
  }
  onSelectChange(event: any, routingStatus: any) {
    if (!event.checked && this.AllSelected) {
      this.AllSelected = false;
      // this.approvalRoutingActive=routingStatus;
    }
    this.isRejectPressed = true

  }
  viewSupplier(id: any) {
    const url = this.router.serializeUrl(
      this.router.createUrlTree(["/main/supplier/action/view/" + id])
    );
    this.isRejectPressed = false
    window.open(url)
  }
  NextApproverLov(subId: any) {
    try {
      if(this.RetloginDetails.userType=='SUPERADMIN'){
        this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + subId + '&formName=PO Approval';

       }
       else if(this.RetloginDetails.userType=='ENDUSER')
       {
         if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
         {
                this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + subId + '&formName=PO Approval';
         }
         else{
                this.url='/masters-ws/employee/get-by-role-subsidiary?roleId=' + this.userRoleId + '&subsidiaryId=' + subId + '&formName=PO Approval';
         }
        
       }



      this.HttpService.GetAll( this.url, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.length > 0) {
              this.approverRoleList = res;
              // this.totalRecords = res.length;
            } else {
              this.approverRoleList = [{}];
            }
            this.loading = false;
          }
        },
        (error) => {
          this.showAlert(error);
          this.loading = false;
        }
      );
    } catch (err) {
      this.showAlert(err);
    }
  }
  OnChangeNextApprover(mainId: any, ApproverId: any) {
    try {
      this.HttpService.GetAll('/procure-ws/po/update-next-approver?poId=' + mainId + '&approverId=' + ApproverId, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res > 0) {

            } else {

            }
          }
        },
        (error) => {
          this.showAlert(error);
        }
      );
    } catch (err) {
      this.showAlert(err);
    }
  }
  OnChangeVisibleButton(row:any,)
  {
   if(this.IsLoggerAdmin=="ADMIN")
   {
      if(this.poApprovalList[row].selected)
      {
        this.poApprovalList[row].isAdminForSave=false;
        this.visibleSaveButton=true;
      }
   }
  }
  onApproverSave() {
    try {
      let selectedId;
      let selectedapprover;
      for(let x=0;x<this.poApprovalList.length;x++)
      {
        if(this.poApprovalList[x].selected)
      {
        selectedId=this.poApprovalList[x].id;
        selectedapprover=this.poApprovalList[x].nextApprover
        break;
      }
      }
      //this.HttpService.GetAll('/masters-ws/employee/get-by-role-subsidiary?roleId=' + this.userRoleId + '&subsidiaryId=' + subId, this.RetloginDetails.token)
      this.HttpService.GetAll(`/procure-ws/po/update-next-approver?poId=${selectedId}&approverId=${selectedapprover}`, this.RetloginDetails.token)
      .subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          } else if (res == true) {
            this.showloader = false;
            this.toastService.addSingle(
              'success',
              'Success',
              'saved selected Purchase Order!'
            );
            window.location.reload();
            //this.loadSuppliersApproval();
          } 
        },
        (error) => {
        }
      );
    } catch (err) {
    }
  }
  cancel()
  {
    window.location.reload();
  }
  showAlert(AlertMSG: any) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
}