export class LoginDetails{
    username?:string;
    password?:string;
    email?:string;
    type?:string;
    subsidiaryId?:number;
   
}

export class Subsidiary{
   id:Number;
   Name:string;

}