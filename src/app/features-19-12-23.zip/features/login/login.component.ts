
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import{LoginDetails,Subsidiary} from '../login/model/login-details';
import { UserIdleService } from 'angular-user-idle';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})


export class LoginComponent implements OnInit {
  loginDetails:LoginDetails=new LoginDetails();
  LoggerDetails:any;
  showloader:boolean=false;
  RetloginDetails:any;
  visible: boolean;
  cities: Subsidiary[]=[];
  selectedCity: Subsidiary;
  //cities: { name: string; code: string; }[];
  subsidiarysection: boolean = false;
  loginsection: boolean = true;
  selectedSubsidiaryId:any;
  constructor(private router: Router,private httpService: CommonHttpService,
    private toastService: ToastService,private userIdle: UserIdleService) {}

  ngOnInit(): void {



   localStorage.clear();
     //Start watching for user inactivity.
     this.userIdle.startWatching();
    
     // Start watching when user idle is starting.
     this.userIdle.onTimerStart().subscribe(count => console.log(count));
     
     // Start watch when time is up.
     this.userIdle.onTimeout().subscribe(() => console.log('Time is up!'));
  }
  
  DummyLogin() {
    this.router.navigate(['/main']);
  }
  UserLogin()
  {
    if(this.loginDetails.username == undefined)
    {
      this.showAlert("Please enter User Name");
      return false;
    }
    else if(this.loginDetails.password == undefined)
    {
      this.showAlert("Please enter Password");
      return false;
    }

  this.showloader=true; 
    this.httpService.Insert('/setup-ws/api/auth/signin', this.loginDetails).subscribe(
      (res) => {
        if (res && res.id > 0) {
          localStorage.clear();
          localStorage.setItem("LoggerDTLS", JSON.stringify(res));
          const LDetails:any=localStorage.getItem("LoggerDTLS");
          this.RetloginDetails = JSON.parse(LDetails);
          //this.GetAllSubsidiaryList()
          setTimeout(() => this.getRoleDetails(res.roles), 100);
          
        } else {
          this.showAlert("incorrect Credentials");
          this.showloader=false; 
        }
      },
      (error) => {
        this.showAlert(error);
        this.showloader=false; 
      },
      () => {
        this.showloader=false; 
      }
    );
  }
 
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  stop() {
    this.userIdle.stopTimer();
  }

  stopWatching() {
    this.userIdle.stopWatching();
  }

  startWatching() {
    this.userIdle.startWatching();
  }

  restart() {
    this.userIdle.resetTimer();
  }
  getRoleDetails(roleIds:any)
  {
    
    this.httpService.Insert('/masters-ws/roles/get-by-ids',roleIds,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res != undefined)
        {
       localStorage.setItem("RoleDTLS", JSON.stringify(res.sort((a:any,b:any) => a.id - b.id)));
       if (localStorage.getItem("AllRoleList") == null) {
        localStorage.setItem("AllRoleList", JSON.stringify(res.sort((a: any, b: any) => a.id - b.id)));
      }
      //this.router.navigate(['/main/dashboard']);
      const role_Dtls: any = localStorage.getItem("RoleDTLS");
          const parsedRld = JSON.parse(role_Dtls);
          if(parsedRld.length>=2)
          {
            this.cities=[];
            for(let i=0;i<parsedRld.length;i++)
            {
              this.cities.push({
                Name:parsedRld[i].subsidiaryName,
                id:parsedRld[i].subsidiaryId
              })
            }
            
            //this.visible = true;
            //this.visible = true;
            this.subsidiarysection = true;
            this.loginsection = false;
            //this.loginDetails.subsidiaryId=parsedRld[0].subsidiaryId;
          }
          else
          {
            // if(this.RetloginDetails.userType=='ROOTAMIN'){
            //     this.router.navigate(['/main/dashboard/product_dashboard']);
            // } else if (this.RetloginDetails.userType=='SUPERADMIN'){ //|| this.RetloginDetails.userType=='ROOTADMIN'
            //     this.router.navigate(['/main/dashboard/cfo_dashboard']);
            // } else {
            //     this.router.navigate(['/main/dashboard']);
            // }
            if (this.RetloginDetails.userType=='SUPERADMIN'){
              this.router.navigate(['/main/dashboard/cfo_dashboard']);
           
            } 
            else if(this.RetloginDetails.userType=='ROOTADMIN'){
              this.router.navigate(['/main/dashboard/product_dashboard']);
           
            }
            else {
              this.router.navigate(['/main/dashboard']);
             
            }
          }
          // {
          //   if (parsedRld[0].subsidiaryId == null) { 
          //     this.router.navigate(['/main/dashboard/cfo_dashboard']);
          //   } else {
          //     this.router.navigate(['/main/dashboard']);
          //   }
          // }
        }
        else
        {
          alert("No Data Found Against Role");
        }
      },
      (error) => {
        this.showAlert(error);
      }
    );
  }

  forgotPWD(){
    if(this.loginDetails.username == undefined)
    {
      this.showAlert("Please enter User Name");
      return false;
    }
    if(localStorage.length >1)
    {localStorage.removeItem("LoggerUserName");}
    localStorage.setItem("LoggerUserName", this.loginDetails.username);
    this.router.navigate(['forgot']);
  } 

  GetAllSubsidiaryList() {
    this.httpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token)
      .subscribe(res => {
       if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
       else
       {
        //Success:Do your code 
       }
      });
  }

  showDialog() {
    this.visible = true;
  }


  setsubsidiary_login(Name:any)
  {
      

    //alert(Name.originalEvent.currentTarget.ariaLabel);
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);

    role_Dtls[0].subsidiaryId=this.loginDetails.subsidiaryId;
    role_Dtls[0].subsidiaryName=Name.originalEvent.currentTarget.ariaLabel
    localStorage.setItem("RoleDTLS", JSON.stringify(role_Dtls));


    //alert(this.loginDetails.subsidiaryId);


  }
  subsidiarybasedlogin(subsidiary:any)
  {
    const role_Dtls: any = localStorage.getItem("RoleDTLS");
    const parsedRld = JSON.parse(role_Dtls);


    // if (this.RetloginDetails.userType=='SUPERADMIN' || this.RetloginDetails.userType=='ROOTADMIN'){
    //   this.router.navigate(['/main/dashboard/cfo_dashboard']);
    // }else if (this.RetloginDetails.userType=='ENDUSER'){
      
    //     const tempRoleList:any=[]
    //     for (let x=0;x<parsedRld.length;x++)
    //     {
    //       if(parsedRld[x].subsidiaryId == this.selectedSubsidiaryId)
    //       {
    //         if (localStorage.getItem("RoleDTLS") != null) {
    //           localStorage.removeItem("RoleDTLS");
    //         }
    //         tempRoleList.push(parsedRld[x]);
    //         localStorage.setItem("RoleDTLS", JSON.stringify(tempRoleList));
    //         this.router.navigate(['/main/dashboard']);
    //         break;
    //       }
    //   }
    // }
    if (parsedRld[0].subsidiaryId == null) {
      this.router.navigate(['/main/dashboard/cfo_dashboard']);
    } else {
      const tempRoleList:any=[]
      for (let x=0;x<parsedRld.length;x++)
      {
        if(parsedRld[x].subsidiaryId == this.selectedSubsidiaryId)
        {
          if (localStorage.getItem("RoleDTLS") != null) {
            localStorage.removeItem("RoleDTLS");
          }
          tempRoleList.push(parsedRld[x]);
          localStorage.setItem("RoleDTLS", JSON.stringify(tempRoleList));
          this.router.navigate(['/main/dashboard']);
          break;
        }
      }
     
    }
  }
  getSelectedSubsidiary(SelectedSubsidiaryId:any)
  {
    this.selectedSubsidiaryId=SelectedSubsidiaryId.value;
  }
  backButton(){
    this.loginsection = true;
    this.subsidiarysection = false;
  }
}
