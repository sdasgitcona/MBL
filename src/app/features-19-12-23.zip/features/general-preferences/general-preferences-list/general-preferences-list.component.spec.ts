import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GeneralPreferencesListComponent } from './general-preferences-list.component';

describe('GeneralPreferencesListComponent', () => {
  let component: GeneralPreferencesListComponent;
  let fixture: ComponentFixture<GeneralPreferencesListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GeneralPreferencesListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GeneralPreferencesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
