import { bootstrapApplication } from "@angular/platform-browser";

export class generalpreferences {
            id: number;
            subsidiaryId:number;
            createdDate?: Date;
            createdBy?: string;
            lastModifiedDate?: Date;
            lastModifiedBy?: string;
            //accountingPreference: string;
           // costingPreference: string;
            //numberingPreference: string;
           // approvalRoutingPreference: string;
           // otherPreference: string;
            accountingPreferences:accountingPreferences={};
            costingPreferences:costingPreferences={};
            numberingPreferences:numberingPreferences[]=[];
            approvalRoutingPreferences:approvalRoutingPreferences[]=[];
            otherPreferences:otherPreferences[] = [];
            subsidiaryName: string;
            costingMethod: string;
            active: boolean;
            deleted: boolean;

}

export class accountingPreferences
{
    id?: number;
    preferenceId?: number;
    purchaseDiscountAccount?: number;
    defaultExpenseAccount?: number;
    defaultInventoryAccount?:  number;
    defaultPrepaymentAccount?: number;
    defaultPayableAccount?:  number;
    defaultPayableAccountEmployee?:  number;
    defaultPrepaymentAccountEmployee?:  number;
    grnAccrualAccount?:  number;
    defaultVendorReturnAccount?: number;
    defaultExchangeRateVarienceAccount?: number;
    defaultCostofGoodsSoldAccount?: number;
    defaultIncomeAccount?:  number;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    active?: boolean;
    deleted?: boolean;
}
export class costingPreferences
{
        id?: number;
        preferenceId?: number;
        costingMethod?: string;
        createdDate?: Date;
        createdBy?: string;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        deleted?: boolean
}
export class numberingPreferences{
        id?: number;
        preferenceId?: number;
        masterName?: string;
        masterPrefix?: string;
        masterMaxDigit?: number;
        masterStartsWith?: any;
        masterCurrentNumber?: any;
        createdDate?: Date;
        createdBy?: string;
        lastModifiedDate?: Date;
        lastModifiedBy?: string;
        deleted?: boolean;
        editModeNPDisable?:boolean;
}

export class approvalRoutingPreferences{
    id?: number;
    preferenceId?: number;
    formType?:  string;
    formName?:  string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted?: boolean;
    routingActive?: boolean=true;
}

export class otherPreferences
{
    id?: number;
    preferenceId?: number;
    formType?: string;
    formName?: string;
    createdDate?: Date;
    createdBy?: string;
    lastModifiedDate?: Date;
    lastModifiedBy?: string;
    deleted?: boolean;
    preferenceActive?: boolean;
    daysIntervel?:any;
}

export class generalpreferencessave {
    id:number;
    subsidiaryId:number;
    accountingPreferences:accountingPreference={};
    costingPreferences:costingPreference={};
    numberingPreferences:numberingPreference[]=[];
    approvalRoutingPreferences:approvalRoutingPreference[]=[];
    otherPreferences:otherPreference[] = [];
    subsidiaryName: string;
    costingMethod: string;
    active: boolean;
    deleted: boolean;

}
export class accountingPreference{
    id?:number;
    purchaseDiscountAccount?: number;
    defaultExpenseAccount?: number;
    defaultInventoryAccount?: number;
    defaultPrepaymentAccount?: number;
    defaultPayableAccount?: number;
    grnAccrualAccount?: number;
    defaultVendorReturnAccount?: number;
    defaultPayableAccountEmployee?:  number;
    defaultPrepaymentAccountEmployee?:  number;
    defaultExchangeRateVarienceAccount?: number;
    defaultCostofGoodsSoldAccount?: number;
    defaultIncomeAccount?: number;
    active?: boolean;
    deleted?: boolean;

}
export class costingPreference
{
id?:number;
costingMethod?: String;
deleted?: Boolean;
}
export class numberingPreference{
    id?:number;
    masterName?:string;
    masterPrefix?:string;
    masterMaxDigit?: number;
    masterCurrentNumber?: number;
    masterStartsWith?: number;
    deleted?: boolean
}
export class approvalRoutingPreference{
        id?:number;
        formType?: string;
        formName?: string;
        deleted?: boolean
        routingActive?: boolean
}
export class otherPreference{
    id?:number;
    formType?: string;
    formName?: string;
    preferenceActive?: boolean;
    daysIntervel?:any;
}

