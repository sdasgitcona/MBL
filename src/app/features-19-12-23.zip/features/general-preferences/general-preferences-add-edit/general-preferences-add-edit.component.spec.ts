import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GeneralPreferencesAddEditComponent } from './general-preferences-add-edit.component';

describe('GeneralPreferencesAddEditComponent', () => {
  let component: GeneralPreferencesAddEditComponent;
  let fixture: ComponentFixture<GeneralPreferencesAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GeneralPreferencesAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GeneralPreferencesAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
