import { asNativeElements, Component, OnDestroy, OnInit, ViewChild, } from '@angular/core';
import { FormGroup, FormControl, FormArray } from '@angular/forms'
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch } from '../../supplier/model/supplier-model';
import { approvalRoutingPreferences, generalpreferences,generalpreferencessave,numberingPreferences } from '../model/general-preferences-model';
import { ToastService } from 'src/app/core/services/toast.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { any } from '@amcharts/amcharts5/.internal/core/util/Array';
@Component({
  selector: 'app-general-preferences-add-edit',
  templateUrl: './general-preferences-add-edit.component.html',
  styleUrls: ['./general-preferences-add-edit.component.scss']
})
export class GeneralPreferencesAddEditComponent implements OnInit {
  generalpreferencesId: number = 0;
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  role: any;
  addressData: any;
  PurchaseDiscountAccount=[];
  DefaultExpenseAccount=[];
  DefaultInventoryAccount=[];
  DefaultPrepaymentAccount=[];
  DefaultEmpPrepaymentAccount=[];
  DefaultEmpPayableAccount=[];
  DefaultPayableAccount=[];
  GRNAccrualAccount=[];
  DefaultVendorReturnAccount=[];
  DefaultExchangeRateVarienceAccount=[];
  DefaultCostofGoodsSoldAccount=[];
  DefaultIncomeAccount=[];
  SubsideryObject=[];
  CostingMethod:any;
  approvalRouting:approvalRoutingPreferences[]=[];
  numberingPreferences:numberingPreferences[]=[]; 
  generalpreferencesHistoryList: HistoryModel[] = [];
  Subsidiarylist: any[] = [];
  maxInputNumber:number;
  showloader: boolean=false;
  RetloginDetails: any;

  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  isviewEditable:boolean=true;
  editModeNPDisable:boolean;
  // For Role Base Access
  RetRoleDetails:any;
  constructor(private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
    private HttpService: CommonHttpService) {
      this.CostingMethod = [{id:'Average',value:'Average'}];
     }
    generalpreferences: generalpreferences = new generalpreferences();
    generalpreferencessave: generalpreferencessave = new generalpreferencessave();
    
    approvalrouting=[];
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;

 const LDetails:any=localStorage.getItem("LoggerDTLS");
 this.RetloginDetails = JSON.parse(LDetails)

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "General Preference")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access
   
    this.GetAllSubsidiaryList();
   
      this.generalpreferences.numberingPreferences.push({masterName:"Supplier Master",masterPrefix:""});
      this.generalpreferences.numberingPreferences.push({masterName:"Employee Master",masterPrefix:""});
      
      this.generalpreferences.approvalRoutingPreferences.push(
      {formType:"Master",formName:"Supplier",routingActive:false},
      {formType:"Transaction",formName:"Purchase Requisition",routingActive:false},
      {formType:"Transaction",formName:"Purchase Order",routingActive:false},
      {formType:"Transaction",formName:"AP Invoice",routingActive:false},
      {formType:"Transaction",formName:"Make Payment",routingActive:false},
      {formType:"Transaction",formName:"Return to Supplier",routingActive:false},
      //{formType:"Transaction",formName:"Debit Note",routingActive:false},
      {formType:"Transaction",formName:"Debit Note",routingActive:false},
      {formType:"Transaction",formName:"Advance Payment",routingActive:false},

      );

      this.generalpreferences.otherPreferences.push({formType:"Make Payment",formName:"Cross Currency Bank Payment",preferenceActive:false, daysIntervel:10});


      this.generalpreferences.approvalRoutingPreferences




    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.generalpreferencesId = +params['id']; // (+) converts string 'id' to a number
            this.GetAllSubsidiaryList(); 
            this.GetGeneralPreferencesbyId();
            this.LoadHistory();
            this.generalpreferencessave.id= this.generalpreferencesId;

          }
          this.generalpreferences.numberingPreferences[0].editModeNPDisable=false;
          this.generalpreferences.numberingPreferences[1].editModeNPDisable=false;
          this.assignMode(params['action']);
          //this.GetAccountType('Income',this.generalpreferences.subsidiaryId);
         // this.GetAccountType('Expense',this.generalpreferences.subsidiaryId);
         // this.GetAccountType('Assets',this.generalpreferences.subsidiaryId);
          //this.GetAccountType('Asset');
        //  this.GetAccountType('Liability',this.generalpreferences.subsidiaryId);
          //this.GetAccountType('Liability',this.generalpreferences.subsidiaryId);
          //this.GetAccountType('Liability');
          //this.GetAccountType('Expense');
          //this.GetAccountType('Income');
          //this.GetAccountType('Expense');
          //this.GetAccountType('Income');
        
        } else {
          console.log('cannot get params');
        }
      },
      (error) => {
        console.log('add');
      }
    );
  }

  clearGeneralPreferencesData()
  {
    this.router.navigate(['/main/general-preferences/list']);
   /* this.generalpreferences = new generalpreferences();
    if(this.editMode==true || this.viewMode==true)
    {
      this.router.navigate(['/main/general-preferences/list']);
    }*/
   
  }

 /* GetSubsideryList() {
   
    this.HttpService.GetAll(GlobalConstants.URL_SUPPLIER_GET_ALL_LOV).subscribe(
      (res) => {
        console.log(res);
        //this.Subsidiarylist = res.list;
        this.SubsideryObject=res;
      },
      (error) => {
        console.log(error);
      }
    );
  }*/
  getAllSubsidiaryList()
  {
   
    this.Subsidiarylist=[];
    this.generalpreferences.subsidiaryId=0;
    this.GetAllSubsidiaryList();
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        //this.generalpreferences.employeeNumber = '';
        //var addedAddress = new Employeeaddresses();
        //this.employee.employeeAddresses.push(addedAddress);
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;

      default:
        break;
    }
  }
  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 4) {
      this.LoadHistory();
     // this.displayAddressDialog = false;
    }
  }
  GetAccountType(type: string,id:number) {
   
    this.httpService.GetAll('/masters-ws/account/get-account-by-subsidiary?subsidiaryId='+id+'&type=' + type ,this.RetloginDetails.token).subscribe(
      (res) => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
            //console.log(res);
            if (type == 'Income') {
              this.PurchaseDiscountAccount = res;
              this.DefaultExchangeRateVarienceAccount= res;
              this.DefaultIncomeAccount= res;
            } 
            else if(type == 'Expense')
            {
              this.DefaultExpenseAccount = res;
              this.DefaultVendorReturnAccount= res;
              this.DefaultCostofGoodsSoldAccount= res;
            }
            else if(type == 'Assets')
            {
              this.DefaultEmpPrepaymentAccount=res;
              this.DefaultInventoryAccount = res;
              this.DefaultPrepaymentAccount = res;
            }
            else if(type == 'Liability')
            {
              this.DefaultPayableAccount = res;
              this.GRNAccrualAccount = res;
              this.DefaultEmpPayableAccount=res;
            }
            else if(type == 'Average')
            {
              this.CostingMethod = res;
            
            }
        }


     



      },
      (error) => {
       // console.log(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
  }
  getAllPurchaseDiscountAccountReloadList()
  {
    this.GetAccountType('Income',this.generalpreferences.subsidiaryId);
    this.PurchaseDiscountAccount=[];
  }
  getAllDefaultExpenseAccountReloadList()
  {
    this.GetAccountType('Expense',this.generalpreferences.subsidiaryId);
    this.DefaultExpenseAccount=[];
  }
  getAllDefaultInventoryAccountReloadList()
  {
    this.GetAccountType('Assets',this.generalpreferences.subsidiaryId);
    this.DefaultInventoryAccount=[];
  }
  getAllDefaultPrepaymentAccountReloadList()
  {
    this.GetAccountType('Assets',this.generalpreferences.subsidiaryId);
    this.DefaultPrepaymentAccount=[];
  }
  getAllDefaultPayableAccountReloadList()
  {
    this.GetAccountType('Liability',this.generalpreferences.subsidiaryId);
    this.DefaultPayableAccount=[];
  }
  getAllGRNAccrualAccountReloadList()
  {
    this.GetAccountType('Liability',this.generalpreferences.subsidiaryId);
    this.GRNAccrualAccount=[];
  }
  getAllDefaultVendorReturnAccountReloadList()
  {
    this.GetAccountType('Expense',this.generalpreferences.subsidiaryId);
    this.DefaultVendorReturnAccount=[];
  }
  getAllDefaultExchangeRateVarienceAccountReloadList()
  {
    this.GetAccountType('Income',this.generalpreferences.subsidiaryId);
    this.DefaultExchangeRateVarienceAccount=[];

  }
  getAllDefaultCostofGoodsSoldAccountReloadList()
  {
    this.GetAccountType('Expense',this.generalpreferences.subsidiaryId);
    this.DefaultCostofGoodsSoldAccount=[];
  }
  getAllDefaultIncomeAccountReloadList()
  {
    this.GetAccountType('Income',this.generalpreferences.subsidiaryId);
    this.DefaultIncomeAccount=[];
  }
  getAllCostingMethodReloadList()
  {
    this.GetAccountType('Average',this.generalpreferences.subsidiaryId);
    this.CostingMethod=[];
  }
  getAllDefaultEmpPayableAccountReloadList()
  {
    this.GetAccountType('Liability',this.generalpreferences.subsidiaryId);
     this.DefaultEmpPayableAccount=[];
  }
  getAllDefaultEmployeeprepaymentReloadList()
  {
    this.GetAccountType('Assets',this.generalpreferences.subsidiaryId);
    this.DefaultEmpPrepaymentAccount=[];
  }
  
  GetGeneralPreferencesbyId() {
    
    this.httpService
      .GetById('/setup-ws/preference/get?id=' + this.generalpreferencesId, this.generalpreferencesId ,this.RetloginDetails.token)
      .subscribe((res) => {
        
          //For Auth
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
          else
          {
            //console.log(res);
                
            this.GetAccountType('Income',res.subsidiaryId);
            this.GetAccountType('Expense',res.subsidiaryId);
            this.GetAccountType('Assets',res.subsidiaryId);
            this.GetAccountType('Liability',res.subsidiaryId);
            this.generalpreferences = res;
          // for(let x=0;x<this.generalpreferences.numberingPreferences.length;x++)
            //{
            
            if(this.generalpreferences.numberingPreferences[0].masterStartsWith != this.generalpreferences.numberingPreferences[0].masterCurrentNumber)
            {
              this.generalpreferences.numberingPreferences[0].editModeNPDisable=true;
            }
            else
            {
              this.generalpreferences.numberingPreferences[0].editModeNPDisable=false;
            }

            if(this.generalpreferences.numberingPreferences[1].masterStartsWith != this.generalpreferences.numberingPreferences[1].masterCurrentNumber)
            {
              this.generalpreferences.numberingPreferences[1].editModeNPDisable=true;
            }
            else
            {
              this.generalpreferences.numberingPreferences[1].editModeNPDisable=false;
            }

            if(this.viewMode)
            {
              this.generalpreferences.numberingPreferences[0].editModeNPDisable=true;
              this.generalpreferences.numberingPreferences[1].editModeNPDisable=true;
            }
          // }

          
            //this.approvalRouting=res.approvalRoutingPreferences;
          // this.numberingPreferences=res.numberingPreferences;
          }
      });
  }
  GetAllSubsidiaryList(){
      this.Subsidiarylist=[];
      // if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
      if(this.RetloginDetails.userType=='SUPERADMIN')
      {
        this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
         { this.Subsidiarylist=res;
        }
        },
        (error) => {
          alert(error);
         },
         ()=>{
         }
      );
      }else if(this.RetloginDetails.userType=='ENDUSER'){
        this.Subsidiarylist.push({
          "id":this.RetRoleDetails[0].subsidiaryId,
          "name":this.RetRoleDetails[0].subsidiaryName
        });
      }
   }

   saveGeneralPreferences() {

    if(this.generalpreferences.subsidiaryId==undefined)
    {
      this.showAlert("Select Subsidiary");
       return;
    }
    if(this.generalpreferences.costingPreferences.costingMethod ==undefined)
    {
      this.showAlert("Select Costing Method");
      return false;
    }
    for(let i=0;i<this.generalpreferences.numberingPreferences.length;i++)
    {
      if(this.generalpreferences.numberingPreferences[i].masterPrefix == undefined || this.generalpreferences.numberingPreferences[i].masterPrefix == "")
      {
        //this.showAlert("Enter Prefix" +" For: " + this.generalpreferences.numberingPreferences[i].masterName);
        this.showAlert("Enter Numbering Preference");
        return false;
      }
      else  if(this.generalpreferences.numberingPreferences[i].masterMaxDigit == undefined)
      {
        //this.showAlert("Enter Max Digit" +" For: " + this.generalpreferences.numberingPreferences[i].masterName);
        this.showAlert("Enter Numbering Preference");
        return false;
      }
      else  if(this.generalpreferences.numberingPreferences[i].masterStartsWith == undefined)
      {
        //this.showAlert("Enter Start With number" +" For: " + this.generalpreferences.numberingPreferences[i].masterName);
        this.showAlert("Enter Numbering Preference");
        return false;
      }
    }
  
    
   this.generalpreferencessave.subsidiaryId=this.generalpreferences.subsidiaryId;
   this.generalpreferencessave.subsidiaryName=this.generalpreferences.subsidiaryName;
   this.generalpreferencessave.costingMethod=this.generalpreferences.costingMethod;
   this.generalpreferencessave.active=this.generalpreferences.active;
   this.generalpreferencessave.deleted=this.generalpreferences.deleted;
   this.generalpreferencessave.accountingPreferences.id=this.generalpreferences.accountingPreferences.id;
   this.generalpreferencessave.accountingPreferences.purchaseDiscountAccount=this.generalpreferences.accountingPreferences.purchaseDiscountAccount;
   this.generalpreferencessave.accountingPreferences.defaultExpenseAccount=this.generalpreferences.accountingPreferences.defaultExpenseAccount;
   this.generalpreferencessave.accountingPreferences.defaultInventoryAccount=this.generalpreferences.accountingPreferences.defaultInventoryAccount;
   this.generalpreferencessave.accountingPreferences.defaultPrepaymentAccount=this.generalpreferences.accountingPreferences.defaultPrepaymentAccount;
   this.generalpreferencessave.accountingPreferences.defaultPayableAccount=this.generalpreferences.accountingPreferences.defaultPayableAccount;
   this.generalpreferencessave.accountingPreferences.grnAccrualAccount=this.generalpreferences.accountingPreferences.grnAccrualAccount;
   this.generalpreferencessave.accountingPreferences.defaultVendorReturnAccount=this.generalpreferences.accountingPreferences.defaultVendorReturnAccount;
   this.generalpreferencessave.accountingPreferences.defaultExchangeRateVarienceAccount=this.generalpreferences.accountingPreferences.defaultExchangeRateVarienceAccount;
   this.generalpreferencessave.accountingPreferences.defaultCostofGoodsSoldAccount=this.generalpreferences.accountingPreferences.defaultCostofGoodsSoldAccount;
   this.generalpreferencessave.accountingPreferences.defaultIncomeAccount=this.generalpreferences.accountingPreferences.defaultIncomeAccount;
   this.generalpreferencessave.accountingPreferences.defaultPayableAccountEmployee=this.generalpreferences.accountingPreferences.defaultPayableAccountEmployee;
   this.generalpreferencessave.accountingPreferences.defaultPrepaymentAccountEmployee=this.generalpreferences.accountingPreferences.defaultPrepaymentAccountEmployee;
   this.generalpreferencessave.accountingPreferences.active=this.generalpreferences.accountingPreferences.active;
   this.generalpreferencessave.accountingPreferences.deleted=this.generalpreferences.accountingPreferences.deleted;
   this.generalpreferencessave.costingPreferences.costingMethod=this.generalpreferences.costingPreferences.costingMethod;
   this.generalpreferencessave.costingPreferences.deleted=this.generalpreferences.costingPreferences.deleted;
   this.generalpreferencessave.costingPreferences.id=this.generalpreferences.costingPreferences.id;
   this.generalpreferencessave.numberingPreferences=[];
   for(let i=0;i<this.generalpreferences.numberingPreferences.length;i++)
   {
    this.generalpreferencessave.numberingPreferences.push({
      masterName:this.generalpreferences.numberingPreferences[i].masterName,
      masterPrefix:this.generalpreferences.numberingPreferences[i].masterPrefix,
      masterMaxDigit:this.generalpreferences.numberingPreferences[i].masterMaxDigit,
      deleted:this.generalpreferences.numberingPreferences[i].deleted,id:this.generalpreferences.numberingPreferences[i].id,
      masterStartsWith:this.generalpreferences.numberingPreferences[i].masterStartsWith,
      masterCurrentNumber:this.generalpreferences.numberingPreferences[i].masterCurrentNumber

    })
   }

   for(let j=0;j<this.generalpreferences.approvalRoutingPreferences.length;j++)
   {
    this.generalpreferencessave.approvalRoutingPreferences.push({formName:this.generalpreferences.approvalRoutingPreferences[j].formName,
      formType:this.generalpreferences.approvalRoutingPreferences[j].formType,
      deleted:this.generalpreferences.approvalRoutingPreferences[j].deleted,
      routingActive:this.generalpreferences.approvalRoutingPreferences[j].routingActive,
      id:this.generalpreferences.approvalRoutingPreferences[j].id
    })

   }

   for(let k=0;k<this.generalpreferences.otherPreferences.length;k++)
   {
    this.generalpreferencessave.otherPreferences.push({formName:this.generalpreferences.otherPreferences[k].formName,
      formType:this.generalpreferences.otherPreferences[k].formType,
      preferenceActive:this.generalpreferences.otherPreferences[k].preferenceActive,
      daysIntervel:this.generalpreferences.otherPreferences[k].daysIntervel,
      id:this.generalpreferences.otherPreferences[k].id
    })

  }

  // if(this.generalpreferences.otherPreferences[0].daysIntervel == undefined || this.generalpreferences.otherPreferences[0].daysIntervel == "")
  // {
  //   this.showAlert("Please enter Aging Interval !");
  // }
  
  //For Save API Call
if(this.addMode){
  this.generalpreferences.createdBy=this.RetloginDetails.username;this.generalpreferences.lastModifiedBy=this.RetloginDetails.username
  }
 else if(!this.addMode){
  this.generalpreferences.lastModifiedBy=this.RetloginDetails.username
  }
  this.showloader=true;
    this.httpService.Insert('/setup-ws/preference/save', this.generalpreferencessave ,this.RetloginDetails.token).subscribe(
      (res) => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          if (res && res.id > 0) {
            //this.saveAddress();
            this.showSuccess();
            this.showloader=false;
            // alert('Data saved successfully');

            
            if(this.addMode){
              this.router.navigate(['/main/general-preferences/action', 'view',res.id]);
            } else {
              this.router.navigate(['/main/general-preferences/list']);
            }
            
          } else {
            this.showloader=false;
            this.showError();
            // alert('!! Something went wrong');
          }
        }
      },
      (error) => {
        this.showloader=false;
        this.showAlert(error);
      },
      () => {}
    );
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'General Preferences Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving General Preferences!'
    );
  }
  showErrorSub() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving General Preferences!'
    );
  }
  LoadHistory() {
   
    if (this.generalpreferencesHistoryList.length == 0)
      this.httpService
        .GetById(
          `/setup-ws/preference/get/history?preferenceId=${this.generalpreferencesId}&pageSize=10000`,
          this.generalpreferencesId ,this.RetloginDetails.token
        )
        .subscribe((res) => {
          //For Auth
              if(res.status == 401)
              { this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if(res.status == 404)
              { this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
            else
            {
              //console.log(res);
              this.generalpreferencesHistoryList = res;
            }

          
        });
  }

  loadlov()
  {
    this.GetAccountType('Income',this.generalpreferences.subsidiaryId);
    this.GetAccountType('Expense',this.generalpreferences.subsidiaryId);
    this.GetAccountType('Assets',this.generalpreferences.subsidiaryId);
    //this.GetAccountType('Asset');
    this.GetAccountType('Liability',this.generalpreferences.subsidiaryId);

  }
 NumberOnly(event:any):boolean{
  const charCode=(event.which)? event.which:event.keyCode;
  if(charCode > 31 && (charCode <48 || charCode >57))
  {
    return false;
  }
  return true;
 }
  checkforlength(event:any,RowIndex:number)
  {
    var NoStart=this.generalpreferences.numberingPreferences[RowIndex].masterStartsWith?.toString().length;
    var MaxNo=this.generalpreferences.numberingPreferences[RowIndex].masterMaxDigit;
    if( Number(NoStart) > Number(MaxNo) )
    {
      this.showAlert("You cannot enter more than your Max Digit");
      let str = NoStart.toString();
      this.generalpreferences.numberingPreferences[RowIndex].masterStartsWith =str.slice(0, -1);
      //this.maxInputNumber=Number(MaxNo);
    }
   //let num:any=this.generalpreferences.numberingPreferences[RowIndex].masterStartsWith?.toString;   
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }



}
