import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {  GeneralPreferencesListComponent } from './general-preferences-list/general-preferences-list.component';
import {  GeneralPreferencesAddEditComponent } from './general-preferences-add-edit/general-preferences-add-edit.component';
const routes: Routes = [
  {
    path: '',
    component: GeneralPreferencesListComponent,
  },
  {
    path: 'list',
    component: GeneralPreferencesListComponent,
  },
  {
    path: 'action/:action/:id',
    component: GeneralPreferencesAddEditComponent,
  },
  {
    path: 'action/:action',
    component: GeneralPreferencesAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GeneralPreferencesRoutingModule { }
