import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PaymentTermAddEditComponent } from './payment-term-add-edit/payment-term-add-edit.component';

const routes: Routes = [
  {
    path: '',
    component: PaymentTermAddEditComponent,
  },
  {
    path: 'list',
    component: PaymentTermAddEditComponent,
  },
  {
    path: 'action/:action/:id',
    component: PaymentTermAddEditComponent,
  },
  {
    path: 'action/:action',
    component: PaymentTermAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PaymentTermRoutingModule { }
