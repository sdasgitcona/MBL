import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PaymentTermRoutingModule } from './payment-term-routing.module';
import { PaymentTermAddEditComponent } from './payment-term-add-edit/payment-term-add-edit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { CheckboxModule } from 'primeng/checkbox';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { FieldsetModule } from 'primeng/fieldset';
import { InputSwitchModule } from 'primeng/inputswitch';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';
import { PanelModule } from 'primeng/panel';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { TabMenuModule } from 'primeng/tabmenu';
import { TabViewModule } from 'primeng/tabview';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { SharedComponentsModule } from 'src/app/shared/shared-components/shared-components.module';
import { CardModule } from 'primeng/card';

@NgModule({
  declarations: [
    PaymentTermAddEditComponent
  ],
  imports: [
    CommonModule,
    PaymentTermRoutingModule,
    PanelModule,
    TableModule,
    TabMenuModule,
    TabViewModule,
    SharedComponentsModule,
    DialogModule,
    ButtonModule,
    DropdownModule,
    InputTextModule,
    FormsModule,
    CheckboxModule,
    ReactiveFormsModule,
    ToggleButtonModule,
    MultiSelectModule,
    CalendarModule,
    FieldsetModule,
    InputSwitchModule,
    ProgressSpinnerModule,
    CardModule,
  ]
})
export class PaymentTermModule { }
