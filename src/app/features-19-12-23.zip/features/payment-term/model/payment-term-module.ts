// export class Currency {
//     id: number;
//     line: Currencyline[] = [];
//     createdBy:string;
//     lastModifiedBy:string;
// }

// export class Currencyline {
//     id: number;
//     name:string;
//     code:string;
//     symbol:string;
//     inactive:boolean=true;

// }

export class PaymentTrem {
    id: number;
    line: PaymentTremLine[] = [];
    createdBy: string;
    lastModifiedBy: string;
}

export class PaymentTremLine {
    // id: number;
    // name:string;
    // code:string;
    // symbol:string;
    // inactive:boolean=true;
    // name: string;
    // description: string;
    // accountId: any;
    // effectiveFrom: any;
    // effectiveTo: any;
    // createdDate: any;
    // createdBy: any;
    // lastUpdated: any;
    // lastModifiedBy: any;
    // deleted: boolean = false;

    id: any;
    name: any;
    description: any;
    accountId: any;
    effectiveFrom: any;
    effectiveTo: any;
    createdDate: any;
    oracleEbsId: any;
    createdBy: any;
    lastUpdated: any;
    lastModifiedBy: any;
    deleted: boolean = false;
    showDetele: boolean = true;
    // showAction: boolean = false;

}