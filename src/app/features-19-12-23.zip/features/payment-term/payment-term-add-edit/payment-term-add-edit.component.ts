import { Component, ElementRef, OnInit, ViewChild, LOCALE_ID, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { PaymentTrem, PaymentTremLine } from '../model/payment-term-module';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { Table } from 'primeng/table';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-payment-term-add-edit',
  templateUrl: './payment-term-add-edit.component.html',
  styleUrls: ['./payment-term-add-edit.component.scss']
})
export class PaymentTermAddEditComponent implements OnInit {
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  showloader: boolean = false;
  role: any;
  PaymentTremModel: PaymentTremLine = new PaymentTremLine();
  PaymentTremLineModel: PaymentTremLine[] = [];
  PaymentTrem: PaymentTrem = new PaymentTrem();
  RetloginDetails: any;
  accountIdOption: any[] = [];
  @ViewChild('dt') dt: Table;
  constructor(
    private httpService: CommonHttpService,
    private router: Router,
    private toastService: ToastService,
    @Inject(LOCALE_ID) public locale: string
  ) { }

  ngOnInit(): void {
    if (localStorage.getItem("LoggerDTLS") == null) {
      this.router.navigate(['/login']);
    }
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    this.accountIdOption.push(this.RetloginDetails.accountId)
    this.PaymentTremModel.accountId = this.accountIdOption[0];
    this.getAllPaymentTerms()
    this.addPaymentTrem()
  }

  addPaymentTrem() {

    if (
      this.PaymentTremLineModel.length > 0 &&
      this.PaymentTremLineModel[length - 1] == new PaymentTremLine()
    ) {
      return;
    }
    this.PaymentTremLineModel.push(new PaymentTremLine());

  }

  checkDate(rowIndex: any) {
    const formattedFrom = this.PaymentTremLineModel[rowIndex].effectiveFrom && formatDate(this.PaymentTremLineModel[rowIndex].effectiveFrom, 'yyyy-MM-dd', this.locale);
    const formattedTo = this.PaymentTremLineModel[rowIndex].effectiveTo && formatDate(this.PaymentTremLineModel[rowIndex].effectiveTo, 'yyyy-MM-dd', this.locale);

    if (formattedFrom && formattedTo && formattedFrom > formattedTo) {
      this.showAlert("Effective To Date Must be Greater or Equal to Effective From Date");
      setTimeout(() => {
        this.PaymentTremLineModel[rowIndex].effectiveTo=null
      }, 100);
    }   
  }

  savePaymentTrem() {
    for (let i = 0; i < this.PaymentTremLineModel.length; i++) {
      if (this.PaymentTremLineModel[i].name == undefined) {
        this.showAlert("Please Enter The Name");
        return;
      }
      if (this.PaymentTremLineModel[i].effectiveFrom == undefined) {
        this.showAlert("Please Enter Effective From Date");
        return;
      }
      this.PaymentTremLineModel[i].accountId = this.accountIdOption[0];
    }
    for(let i=0; i<this.PaymentTremLineModel.length; i++){
      this.PaymentTremLineModel[i].effectiveFrom = formatDate(this.PaymentTremLineModel[i].effectiveFrom,'yyyy-MM-dd' ,this.locale);

    // Check if effectiveFrom is greater than effectiveTo
    if(this.PaymentTremLineModel[i].effectiveTo){
      this.PaymentTremLineModel[i].effectiveTo = formatDate(this.PaymentTremLineModel[i].effectiveTo,'yyyy-MM-dd' ,this.locale);
    }
    }
    this.httpService.Insert("/setup-ws/payment-term/save", this.PaymentTremLineModel, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res !== undefined) {
            if (this.addMode) {
              this.PaymentTremModel.createdBy = this.RetloginDetails.username;
              this.PaymentTremModel.lastModifiedBy = this.RetloginDetails.username
            }
            else if (!this.addMode) {
              this.PaymentTremModel.lastModifiedBy = this.RetloginDetails.username
            }
            this.showSuccess();
            this.router.navigate(['/main/dashboard']);

          } else {
            this.shownError();
          }
        }
      },

        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });

  }

  getAllPaymentTerms() {
    this.httpService.GetAll(`/setup-ws/payment-term/get/all?accountId=` + this.RetloginDetails.accountId, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res) {

            this.PaymentTremLineModel = res;
            for (let i = 0; i < this.PaymentTremLineModel.length; i++) {
              this.PaymentTremLineModel[i].effectiveFrom = this.PaymentTremLineModel[i].effectiveFrom != null ? new Date(this.PaymentTremLineModel[i].effectiveFrom) : "";
              this.PaymentTremLineModel[i].effectiveTo = this.PaymentTremLineModel[i].effectiveTo != null ? new Date(this.PaymentTremLineModel[i].effectiveTo) : "";
            }

          } else {
            this.PaymentTremLineModel=[];

          }
        }
      },
        error => {
          // console.log(error);
          this.PaymentTremLineModel = [];
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }

  deletePaymentTerm(index: any) {
    this.PaymentTremLineModel[index].deleted = true;
    this.savePaymentTrem();
    setTimeout(() => {
      window.location.reload();
    }, 250);
  }

  cancel(){
    this.router.navigate(['/main/dashboard']);
  }

  globalSearch(event: any) {
    this.dt.filterGlobal(event.target.value, 'contains')
  }

  onInputChange(): void {
    // Remove special characters and update the inputValue
    for (let i = 0; i < this.PaymentTremLineModel.length; i++) {
      this.PaymentTremLineModel[i].name = this.PaymentTremLineModel[i].name.replace(/,/g, ' ');
    }
  }


  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Data Saved Successfully!'
    );
  }

  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  shownError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Data!'
    );
  }

}
