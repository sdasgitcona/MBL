import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentTermAddEditComponent } from './payment-term-add-edit.component';

describe('PaymentTermAddEditComponent', () => {
  let component: PaymentTermAddEditComponent;
  let fixture: ComponentFixture<PaymentTermAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentTermAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentTermAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
