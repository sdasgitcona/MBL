export class UserCreation{

    employeeId:number;
    email:any;
    accountId:string;
    userSubsidiaries:userSubsidiaries[]=[];
    SubsidiaryId:number;
    name:any;
    active:boolean=true;
    subsidiaryname:any;
    rolename:any;
    userType:any;
    superadmin:boolean=false;
    status:any
}

export class userSubsidiaries{
    subsidiaryId?:number;
    roleId?:number;
    deleted?:boolean=false;
    active?:boolean=true;
    roles:roles[]=[];
    viewdelete?:boolean=true;

}

export class roles{
    id:number;
    name:string;
}

export class BaseSearch {
    filters: SupplierFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }
  
  //this class holds the custom filter values at component level.
  export class SupplierFilter {
    subsidiary: string = '';
    vendorname: string = '';
    vendornumber: string = '';
    vendortype: string = '';
    pan: string = '';
    active: string = '';
  }

   // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: UserCreationFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class UserCreationFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}