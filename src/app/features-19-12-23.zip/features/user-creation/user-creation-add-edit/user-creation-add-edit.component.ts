import { Component, OnInit } from '@angular/core';
import { flush } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { UserCreation,userSubsidiaries,roles } from '../model/user-creation-model';

@Component({
  selector: 'app-user-creation-add-edit',
  templateUrl: './user-creation-add-edit.component.html',
  styleUrls: ['./user-creation-add-edit.component.scss']
})
export class UserCreationAddEditComponent implements OnInit {

  constructor(private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,) {
      this.usertype = [{id:'ENDUSER',value:'ENDUSER'},{id:'SUPERADMIN',value:'SUPERADMIN'}];
     }
  usercreation:UserCreation=new UserCreation();
  viewMode: boolean = false;
  itcdis :boolean = false;
  addMode: boolean = false;
  vatMode: boolean = false;
  tdsMode: boolean = false;
  editMode: boolean = false;
  showloader: boolean=false;
  perrole_Id:any;
  usertype:any;
  Roles:roles[]=[];
  subsidiarylist:any[]=[];
  rolelist:any[]=[];
  Employeelist:any[]=[];
  UserCreationId: number = 0;
  isviewEditable:boolean=true;
  ishiddenbutton:boolean=false;
  user_subsidiary_sadmin:userSubsidiaries[]=[];
  ishiddensuperadmin:boolean=false;
  private subscription: any;
  isdisabledcontrols:boolean=false;
  selectedSubsidiary: userSubsidiaries = new userSubsidiaries();
  RetRoleDetails:any;
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;

  // For Role Base Access
  RetloginDetails: any;
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;
 const LDetails: any = localStorage.getItem("LoggerDTLS");
 this.RetloginDetails = JSON.parse(LDetails);
 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   
 }
// End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.UserCreationId = +params['id']; // (+) converts string 'id' to a number
            this.GetUserCreationbyId();
           
          }
          
          this.assignMode(params['action']);       
          this.GetEmployeeList();
          this.GetSubsideryList();
          this.addAccessableSubsidiary();
          
        } else {
          console.log('cannot get params');
        }
      },
      (error) => {
        console.log('add');
      }
    );
   
    this.usercreation.userType="ENDUSER";
  }


  clearusercreation()
  {
    this.router.navigate(['/main/user-creation/list']);
    /*if(this.addMode){
      this.usercreation = new UserCreation();
     
    }
  
    else{
     
    }*/
  }

  saveusercreation()
  {
             
    this.showloader=true;
    this.usercreation.accountId=this.RetRoleDetails[0].accountId;
    //this.usercreation.active=true;

    if(this.RetloginDetails.userType='ENDUSER' && this.editMode==true)
    //if(this.RetRoleDetails[0].accountId != null && this.RetRoleDetails[0].subsidiaryId != null && this.editMode==true)
    {
         /*if(this.usercreation.userSubsidiaries[0].roleId!= this.perrole_Id)
         {
            this.usercreation.userSubsidiaries.push(
            {
              roleId: this.usercreation.userSubsidiaries[0].roleId,
              subsidiaryId:this.usercreation.userSubsidiaries[0].subsidiaryId,
              roles:this.Roles
            }
          )
          this.usercreation.userSubsidiaries[0].deleted=true;
          this.usercreation.userSubsidiaries[0].roleId=this.perrole_Id;  

           
         }*/
         for(let i=0;i<this.user_subsidiary_sadmin.length;i++)
         {
              if(this.user_subsidiary_sadmin[i].roleId!=this.usercreation.userSubsidiaries[i].roleId)
              {
               this.usercreation.userSubsidiaries.push(
                 {
                   roleId: this.usercreation.userSubsidiaries[i].roleId,
                   subsidiaryId:this.usercreation.userSubsidiaries[i].subsidiaryId,
                   roles:this.Roles,
                   active:this.usercreation.userSubsidiaries[i].active
                 }
               ) 
               this.usercreation.userSubsidiaries[i].roleId=this.user_subsidiary_sadmin[i].roleId;
               this.usercreation.userSubsidiaries[i].deleted=true;
   
   
   
              }
         }
    }
    else if(this.RetloginDetails.userType=='SUPERADMIN' && this.editMode==true)
    {
      for(let i=0;i<this.user_subsidiary_sadmin.length;i++)
      {
           if(this.user_subsidiary_sadmin[i].roleId!=this.usercreation.userSubsidiaries[i].roleId)
           {
            this.usercreation.userSubsidiaries.push(
              {
                roleId: this.usercreation.userSubsidiaries[i].roleId,
                subsidiaryId:this.usercreation.userSubsidiaries[i].subsidiaryId,
                roles:this.Roles,
                active:this.usercreation.userSubsidiaries[i].active
              }
            ) 
            this.usercreation.userSubsidiaries[i].roleId=this.user_subsidiary_sadmin[i].roleId;
            this.usercreation.userSubsidiaries[i].deleted=true;



           }
      }
    }
    this.httpService.Insert('/setup-ws/user/save', this.usercreation,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
       else  if (res && res.id > 0) {
          this.showloader=false;
          this.showSuccess();
        if(this.addMode){
          this.router.navigate(['/main/user-creation/action', 'view',res.id]);
        } else {
          this.router.navigate(['/main/user-creation/list']);
        }
        } else {
          this.showloader=false;
          this.showError();
        }
      },
      (error) => {
        this.showloader=false;
        this.showAlert(error);
      },
      () => {}
    );





  }
  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 0) {
     // this.LoadHistory();
    }
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;

      default:
        break;
    }
  }
 
  GetEmployeeList()
  {
    this.Employeelist=[];
    if(this.RetloginDetails.userType=='SUPERADMIN')
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
     
      this.httpService.GetAll('/masters-ws/employee/get-lov-by-account-or-subsidiary?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
         {
          console.log(res);
          this.Employeelist=res;
        
        }
        },
        (error) => {},
         ()=>{}
      );
    }
    else if(this.RetloginDetails.userType=='ENDUSER')
    {
      this.httpService.GetAll('/masters-ws/employee/get-lov-by-account-or-subsidiary?subsidiaryId='+this.RetRoleDetails[0].subsidiaryId,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else
         {
          console.log(res);
          this.Employeelist=res;
        }
        },
        (error) => {},
         ()=>{}
      );
  
    }

  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  loademail()
  {
    this.httpService.GetAll('/masters-ws/employee/get?id='+this.usercreation.employeeId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       {
        console.log(res);
        this.usercreation.email=res.employeeContact.email;
      
      }
      },
      (error) => {
  
       },
       ()=>{
  ;
       }
    );



  }
  deleteAccessableSubsidiary(rowindex:any)
  {
    if(this.editMode){
      //this.usercreation.userSubsidiaries[rowindex].deleted=true;
      this.usercreation.userSubsidiaries.splice(rowindex, 1);
      }else{
    if (rowindex >= 0) this.usercreation.userSubsidiaries.splice(rowindex, 1);
    }
  }
  addAccessableSubsidiary()
  {
    if (
      this.usercreation.userSubsidiaries.length > 0 &&
      this.usercreation.userSubsidiaries[length - 1] == new userSubsidiaries()
    ) {
      return;
    }
    this.usercreation.userSubsidiaries.push(new userSubsidiaries());
   
  }

  GetSubsideryList() {
    this.subsidiarylist=[];
    if(this.RetloginDetails.userType=='SUPERADMIN')
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.ishiddensuperadmin=false;
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       {
         this.subsidiarylist=res;
         this.ishiddenbutton=false;
      
      }
      },
      (error) => {
  
       },
       ()=>{

       }
     );
    }else if(this.RetloginDetails.userType=='ENDUSER')
    {
      this.ishiddensuperadmin=true;
      this.subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
      this.ishiddenbutton=true;
     // this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
     // this.resetBaseSearch();
    }

  }
  loadroles(rowindex:any)
  {

    var user_sub=this.usercreation.userSubsidiaries.filter(x=>x.subsidiaryId==this.usercreation.userSubsidiaries[rowindex].subsidiaryId);

    if(user_sub.length>=2)
    {
      this.showAlert("Subsidiary Already In List");
      this.usercreation.userSubsidiaries[rowindex].subsidiaryId=0;
      return;
    }
  
    this.httpService.GetAll('/masters-ws/roles/get-roles-by-subsidiary-employee?subsidiaryId='+this.usercreation.userSubsidiaries[rowindex].subsidiaryId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       {
        this.Roles=[];
         for(let i=0;i<res.length;i++)
         {
          this.Roles.push(
            {
              id:res[i].id,
              name:res[i].name
              
            }
          )
         }
         this.usercreation.userSubsidiaries[rowindex].roles=this.Roles;
      
      }
      },
      (error) => {
  
       },
       ()=>{

       }
    );
  }

  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'User-Creation Saved Successfully!'
    );
  }

  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving User-Creaation!'
    );
  }

  GetUserCreationbyId(): void {
    this.httpService.GetById("/setup-ws/user/get?id="+this.UserCreationId, this.UserCreationId, this.RetloginDetails.token)
      .subscribe(res => {
        if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
         else if(res.errorMessage){
          this.showAlert(res.errorMessage)
         }else{
          this.usercreation=res;
          if(this.usercreation.userType=="SUPERADMIN")
          {
            this.usercreation.superadmin=true;
          }
          this.usercreation.userType=res.userType;
          
          for(let i=0;i<this.usercreation.userSubsidiaries.length;i++)
          {

            this.usercreation.userSubsidiaries[i].viewdelete=false;

            this.httpService.GetAll('/masters-ws/roles/get-roles-by-subsidiary-employee?subsidiaryId='+this.usercreation.userSubsidiaries[i].subsidiaryId,this.RetloginDetails.token).subscribe(
              (res) => {
                if(res.status == 401)
               { this.showAlert("Unauthorized Access !");
                 this.router.navigate(['/login']);
               }
               else if(res.status == 404)
               { this.showAlert("Wrong/Invalid Token!");
                  this.router.navigate(['/login']);
                }
                else
               {
                this.Roles=[];
                 for(let i=0;i<res.length;i++)
                 {
                  this.Roles.push(
                    {
                      id:res[i].id,
                      name:res[i].name
                      
                    }
                  )
                 }
                 this.usercreation.userSubsidiaries[i].roles=this.Roles;
              
              }
              },
              (error) => {
          
               },
               ()=>{
        
               }
            );

          }
          if(this.RetloginDetails.userType='ENDUSER')
          //if(this.RetRoleDetails[0].accountId != null && this.RetRoleDetails[0].subsidiaryId != null && this.editMode==true)
          {
            //this.perrole_Id=this.usercreation.userSubsidiaries[0].roleId;
            for(let i=0;i<this.usercreation.userSubsidiaries.length;i++)
            {
              this.user_subsidiary_sadmin.push(
                {
                  roleId:this.usercreation.userSubsidiaries[i].roleId,
                  roles:this.Roles
                }
              )
            }
            
          }
          else if(this.RetloginDetails.userType=='SUPERADMIN')
          {
           // this.user_subsidiary_sadmin=this.usercreation.userSubsidiaries;
           for(let i=0;i<this.usercreation.userSubsidiaries.length;i++)
           {
             this.user_subsidiary_sadmin.push(
               {
                 roleId:this.usercreation.userSubsidiaries[i].roleId,
                 roles:this.Roles
               }
             )
           }
          }


       }
      },
      error => {
       this.showAlert(error);
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });

     
  }

  chkusertype()
{
  if(this.usercreation.userType=="SUPERADMIN")
  {

    this.usercreation.userSubsidiaries[0].subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
    this.loadroles(0);
    this.usercreation.userSubsidiaries[0].roleId=this.RetRoleDetails[0].rolePermissions[0].roleId;
    this.usercreation.userSubsidiaries[0].viewdelete=false;
    this.isdisabledcontrols=true;
  }
  else
  {
    this.isdisabledcontrols=false;
    this.usercreation.userSubsidiaries[0].subsidiaryId=undefined;
    this.usercreation.userSubsidiaries[0].roleId=undefined;
    this.usercreation.userSubsidiaries[0].viewdelete=true;
  }
}

}
