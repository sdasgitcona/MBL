import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserCreationAddEditComponent } from './user-creation-add-edit.component';

describe('UserCreationAddEditComponent', () => {
  let component: UserCreationAddEditComponent;
  let fixture: ComponentFixture<UserCreationAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserCreationAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserCreationAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
