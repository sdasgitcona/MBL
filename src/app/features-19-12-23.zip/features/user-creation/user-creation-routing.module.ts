import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserCreationAddEditComponent } from './user-creation-add-edit/user-creation-add-edit.component';
import { UserCreationListComponent } from './user-creation-list/user-creation-list.component';

const routes: Routes = [
  {
    path: '',
    component: UserCreationListComponent,
  },
  {
    path: 'list',
    component: UserCreationListComponent,
  },
  {
    path: 'action/:action/:id',
    component: UserCreationAddEditComponent,
  },
  {
    path: 'action/:action',
    component: UserCreationAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserCreationRoutingModule { }
