import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { Supplier, SubsidiaryEntry, BaseSearch, file_upliad, BaseSearchPdf } from '../model/supplier-model';
import { ToastService } from 'src/app/core/services/toast.service';
import { SupplierService } from '../service/supplier.service';
import * as FileSaver from 'file-saver';


import { FileUploadModule } from 'primeng/fileupload';
declare let $: any;

import { PrimeNGConfig } from 'primeng/api';
import { HttpHeaderResponse, HttpHeaders } from '@angular/common/http';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-supplier-list',
  templateUrl: './supplier-list.component.html',
  styleUrls: ['./supplier-list.component.scss'],
})
export class SupplierListComponent implements OnInit {
  columns: any[];
  departments: any[] = [];

  supplierList: Supplier[] = [];
  selectedSupplier: Supplier = new Supplier();
  Subsidiarylist: SubsidiaryEntry[] = [];
  VenderNameList: Supplier[] = [];
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  supplier: Supplier = new Supplier();
  vendorTypeOptions: any;
  newevent: any;
  statusOption: any;
  SubsideryObject: any = [];
  Vendorlist: any[] = [];
  VendorNumberlist: any[] = [];
  file: File;
  status: any[] = [];
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  // For Role Base Access
  displayModal: boolean;
  file_upload: file_upliad = new file_upliad();
  RetloginDetails: any;
  RetRoleDetails: any;
  SubIdList: any = [];
  showloader: boolean;
  notEditable: boolean = true;
  ApprovalButtonShowHide: Number = 0;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  supplierListPrint: any[] = [];
  issubsidiaryhidden: boolean = false;
  issubsidiarydisable: boolean = false;
  filterStatus: any;
  subId: any;
  CFOSubsidiaryId: any = [];
  CFOSubsidiaryIdList: any = [];
  constructor(
    private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private supplierService: SupplierService,
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService
  ) {
    this.statusOption = [{id:'Active',name:"Active"},{id:'Inactive',name:"Inactive"}];
    this.status = ['Draft', 'Pending Approval', 'Partially Approved', 'Approved', 'Rejected'];

  }

  ngOnInit(): void {
    if (localStorage.getItem("LoggerDTLS") == null) {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails = role_Dtls;
    //this.supplier.accountId=role_Dtls[0].accountId;

    // Get Subsidiary Id for CFO Dashboard from LocalStorage
    const GetCfoSubsidiaryId: any = localStorage.getItem("CFOSelectedSubId");
    this.CFOSubsidiaryIdList = JSON.parse(GetCfoSubsidiaryId);

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Supplier") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
      }
    }
    // End For Role Base Access

    this.GetSubsideryList();
    // this.GetAllVendor();
    // this.GetAllVendorList();
    //this.GetAllNumberList();
    this.primengConfig.ripple = true;
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
      { field: 'id', header: 'Internal ID' },
      { field: 'subsidiaryName', header: 'Subsidiary' },
      { field: 'name', header: 'Vendor Name' },
      { field: 'vendorNumber', header: 'Vendor Number' },
      { field: 'vendorType', header: 'Type' },
      { field: 'access', header: 'Give Access' },
      { field: 'approvalStatus', header: 'Approval Status' },
      { field: 'active', header: 'Status' },
      // { field: 'contactName', header: 'Contact Person' },
      // { field: 'contactNumber', header: 'Phone Number' },
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
    this.vendorTypeOptions = [{ id: 'Company', value: 'Company' }, { id: 'Individual', value: 'Individual' }];

    // For Getting Filtered Data from Dashboard
    let subsidyList: any = [];
    subsidyList.push(this.supplier.subsidiaryId);
    this.activatedRoute.params.subscribe((params) => {
      if (params) {
        if (params['status']) {
          this.filterStatus = params['status']
          this.subId = params['id'];
          if (this.filterStatus == 'Recent') {
            let subIdList = this.subId.split(",").map(Number);
            this.CFOSubsidiaryId.push(subIdList);
            if (subIdList.length > 1) {
              let subIdList = this.subId.split(",").map(Number);
              this.CFOSubsidiaryId.push(subIdList);
              setTimeout(() => {
                this.baseSearch.filters = {
                  subsidiaryId: this.CFOSubsidiaryId[0],
                  recentlyCreated:this.supplier.recent = true
                }
                this.baseSearch.pageNumber = -1;
                this.loadSuppliers(this.newevent);

              }, 500);
            } else {
              setTimeout(() => {
                this.baseSearch.filters = {
                  subsidiaryId: this.CFOSubsidiaryId[0],
                  recentlyCreated:this.supplier.recent = true
                }
                this.baseSearch.pageNumber = -1;
                this.loadSuppliers(this.newevent);

              }, 500);
            }
          } else {
            this.baseSearch.filters = {
              subsidiaryId: subsidyList,
              status: "active",
            }
            this.baseSearch.pageNumber = -1;
            this.loadSuppliers(this.newevent);
          }
        }
      }
    });
    // For Getting Filtered Data from Dashboard
  }

  resetBaseSearch() {
    this.baseSearch.filters = { subsidiaryId: this.SubIdList };
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.SUPPLIER_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.DESCENDING;
    this.loadSuppliers(this.newevent);
  }

  /* Start Fetch Subsidery list from api */
  GetSubsideryList() {
    this.SubsideryObject = [];
    if (this.RetloginDetails.userType == 'SUPERADMIN')
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId=' + this.RetRoleDetails[0].accountId, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.SubsideryObject = res;
            for (let x = 0; x < this.SubsideryObject.length; x++) {
              this.SubIdList.push(this.SubsideryObject[x].id);
            }
            this.issubsidiaryhidden = false;
            this.issubsidiarydisable = false;
          }
        },
        (error) => {
          alert(error);
        },
        () => {

          if (localStorage.getItem("SupplierFilters") != null) {
            const LocDetails: any = localStorage.getItem("SupplierFilters");
            let RetLocDetails = JSON.parse(LocDetails);
            this.baseSearch = RetLocDetails;
            let searcheData: any = RetLocDetails;
            this.supplier.subsidiaryId = searcheData.filters.subsidiaryId[0];
            this.supplier.name = searcheData.filters.name;
            this.supplier.vendorNumber = searcheData.filters.number;
            this.supplier.vendorType = searcheData.filters.type;
            this.supplier.approvalStatus = searcheData.filters.approvalStatus;
            this.supplier.active = searcheData.filters.status == "active"?true:false;
            this.loadSuppliers(this.newevent);
            this.GetSupplierList(this.RetRoleDetails[0].subsidiaryId)
            localStorage.removeItem("SupplierFilters");
          }
          else { this.resetBaseSearch(); }
        }
      );
    } else if (this.RetloginDetails.userType == 'ENDUSER') {
      this.SubsideryObject.push({
        "id": this.RetRoleDetails[0].subsidiaryId,
        "name": this.RetRoleDetails[0].subsidiaryName
      });
      this.supplier.subsidiaryId = this.RetRoleDetails[0].subsidiaryId;
      this.GetSupplierList(this.RetRoleDetails[0].subsidiaryId)
      this.issubsidiaryhidden = true;
      this.issubsidiarydisable = true;
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      if (localStorage.getItem("SupplierFilters") != null) {
        const LocDetails: any = localStorage.getItem("SupplierFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch = RetLocDetails;
        let searcheData: any = RetLocDetails;
        this.supplier.name = searcheData.filters.name;
        this.supplier.vendorNumber = searcheData.filters.number;
        this.supplier.vendorType = searcheData.filters.type;
        this.supplier.approvalStatus = searcheData.filters.approvalStatus;
        this.supplier.active = searcheData.filters.status == "active" ? true : false;
        this.loadSuppliers(this.newevent);

        localStorage.removeItem("SupplierFilters");
      }
      else { this.resetBaseSearch(); }
    }
  }

  loadSuppliers(event: any) {
    try {
      //   if(JSON.stringify(event.filters) === '{}' && this.SubIdList.length >0)
      //  { this.baseSearch.filters={
      //     subsidiaryId: this.SubIdList
      //   }}
      this.newevent = event
      this.loading = true;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1) ? 0 : (event.first / event.rows);
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
      // this.baseSearch.sortColumn = event.sortField
      //   ? 's.' + event.sortField
      //   : GlobalConstants.SUPPLIER_TABLE_SORT_COLUMN;
      this.baseSearch.sortColumn = event.sortField
        ? event.sortField
        : GlobalConstants.SUPPLIER_TABLE_SORT_COLUMN;

      this.baseSearch.sortOrder =
        event.sortOrder == 1
          ? GlobalConstants.DESCENDING
          : GlobalConstants.ASCENDING;
      if (this.SubIdList.length == 0) {
        return;
      }

      this.HttpService.Insert('/masters-ws/supplier/get/all', this.baseSearch, this.RetloginDetails.token).subscribe(
        (response) => {
          if (response.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (response.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else if (response && response.list.length > 0) {
            this.supplierList = response.list;

            for (let x = 0; x < this.supplierList.length; x++) {
              if (this.supplierList[x].approvalStatus == 'Pending Approval' || this.supplierList[x].approvalStatus == 'Partially Approved') {
                this.notEditable = false;
              }
            }
            for (let x = 0; x < this.supplierList.length; x++) {
              if (this.supplierList[x].approvalStatus == 'Pending Approval' || this.supplierList[x].approvalStatus == 'Processed' || this.supplierList[x].approvalStatus == 'Partially Processed' || this.supplierList[x].approvalStatus == 'Approved' || this.supplierList[x].approvalStatus == 'Closed' || this.supplierList[x].approvalStatus == 'Partially Approved' || this.supplierList[x].active == false) //Send Approval Mode
              {
                this.supplierList[x].isApprovalButtonShowHide = 0;
                //this.ApprovalButtonShowHide=0;
              }
              else {
                this.supplierList[x].isApprovalButtonShowHide = 1;
                //this.ApprovalButtonShowHide=1;
              }
            }

            // if(this.baseSearch.filters && (Object.keys(this.baseSearch.filters).length === 0)){
            // this.VenderNameList = res.list;
            // }
            this.totalRecords = response.totalRecords;
          } else {
            this.supplierList = [];
          }
          this.loading = false;
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {
    }
  }

  navigateToAdd() {
    this.router.navigate(['/main/supplier/update']);
  }
  navigateToAddViewEdit(
    action: string,
    selectedSupplier: Supplier = new Supplier()
  ) {
    let supplierId = null;
    if (selectedSupplier?.id) {
      supplierId = selectedSupplier.id;
      this.router.navigate(['/main/supplier/action', action, supplierId]);
    } else {
      this.router.navigate(['/main/supplier/action', action]);
    }
  }

  // exportPdf() {
  //   import("jspdf").then(jsPDF => {
  //       import("jspdf-autotable").then(x => {
  //           const doc = new jsPDF.default();
  //           (doc as any).autoTable(this.exportColumns, this.supplierList);
  //           doc.save('supplier.pdf');
  //       })
  //   })
  // }

  /* Start fetch filter list of supplier from api */
  findby(event: any) {
    let subsidyList: any = [];
    subsidyList.push(this.supplier.subsidiaryId);

    this.baseSearch.filters = {
      subsidiaryId: subsidyList,
      //subsidiaryName: this.supplier.subsidiaryId,
      name: this.supplier.name,
      number: this.supplier.vendorNumber,
      type: this.supplier.vendorType,
      status: this.supplier.active ? "active" : "inactive",
      pan: this.supplier.pan,
      approvalStatus: this.supplier.approvalStatus,
      recentlyCreated:this.supplier.recent
      //active:(this.supplier.active)
    }
    this.baseSearch.pageNumber = -1;
    this.loadSuppliers(this.newevent);
  }

  /* End filter list of supplier from api */
  GetAllVendor() {
    try {
      var obj = {
        filters: {},
        pageNumber: 0,
        pageSize: 1000,
        sortColumn: "s.id",
        sortOrder: "asc"
      }
      this.HttpService.Insert('/masters-ws/supplier/get/all', obj, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else if (res && res.list.length > 0) {
            this.VenderNameList = res.list;
          } else {
            this.VenderNameList = [];
          }
        },
        (error) => {
        }
      );
    } catch (err) {
    }
  }


  GetAllVendorList() {
    var obj = {
      filters: {},
      "pageNumber": 0,
      "pageSize": 1000,
      "sortColumn": "s.id",
      "sortOrder": "asc"
    }
    this.HttpService.Insert("/masters-ws/supplier/get/all", obj, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else { this.Vendorlist = res.list; }
      });
  }

  GetAllNumberList() {
    var obj = {
      filters: {},
      "pageNumber": 0,
      "pageSize": 1000,
      "sortColumn": "s.id",
      "sortOrder": "asc"
    }
    this.HttpService.Insert("/masters-ws/supplier/get/all", obj, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else { this.VendorNumberlist = res.list.filter((x: any) => x.vendorNumber != ""); }
      });
  }

  // CSV UPLOAD
  csvUploadDownload() {
    this.displayModal = true;
  }

  @ViewChild('attachments') attachment: any;

  fileList: File[] = [];
  listOfFiles: any[] = [];
  isLoading = false;

  uploadFile(event: any) {
    const httpOptions = {
      headers: new HttpHeaders({
        //"Content-Type": "multipart/form-data" 
        "mimeType": "multipart/form-data",
        "Content-Type": "false"
      })
    };

    // this.fileList[0] = this.file;
    //this.file = event.target.files[0];
    //let fileElement:any;
    //fileElement =document.getElementById('file_');
    //this.file = fileElement.files[0]

    const formData: FormData = new FormData();
    //this.file=event.currentTarget.files[0];
    if (this.file) {
      // formData.set('file', this.file);
      formData.append('file', this.file, this.file.name);
      this.showloader = true;
      // Array.from(this.fileList).forEach(f => formData.append('file', this.file))
      
      //this.HttpService.uploadFile_("/masters-ws/supplier/upload",formData,{responseType: 'arraybuffer'},this.RetloginDetails.token)
      this.HttpService.uploadFile_("/masters-ws/supplier/upload?subsidiaryId=" + this.RetRoleDetails[0].subsidiaryId, formData, { responseType: 'blob' }, this.RetloginDetails.token)
        .subscribe(res => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {

            this.executeSaveAs(res)
            if (res.error) {
              this.toastService.addSingle(
                'error',
                'Error',
                res.error.errorMessage
              );
            }
            else {

              this.toastService.addSingle(
                'success',
                'Success',
                'File uploaded Successfully!'
              );
              window.location.reload();
            }
          }
          this.showloader = false;
        },
          (error) => {
            if (error.status == 200) {
              this.toastService.addSingle(
                'success',
                'Success',
                'File uploaded Successfully!'
              );
              window.location.reload();
            }
            else { this.showAlert(error.message); }
            this.executeSaveAs(error.error.text);
            //this.showAlert(error.error.error);
            this.showloader = false;
          },
          () => {

            // 'onCompleted' callback.
            // No errors, route to new page here
          });
    }
    else {
      this.showAlert("No Attachment Found !")
    }
  }

  onFileChanged(event: any) {
    this.isLoading = true;
    this.file = event.target.files[0];
    this.listOfFiles = []
    //this.listOfFiles.push(this.file .name);
    this.listOfFiles.push({ subsidiary: this.RetRoleDetails[0].subsidiaryName, file: this.file.name });

    //this.fileList = event.target.files[0];
    // for (var i = 0; i <= event.target.files.length - 1; i++) {
    //   var selectedFile = event.target.files[i];
    //   if (this.listOfFiles.indexOf(selectedFile.name) === -1) {
    //     this.fileList.push(selectedFile);
    //     this.listOfFiles.push(selectedFile.name);
    //   }
    // }
    this.isLoading = false;
    //this.attachment.nativeElement.value = '';
  }
  
  // onFileChanged1(event: any) {
  //   this.file = event.target.files[0];
  //   this.HttpService.uploadFile("/masters-ws/supplier/upload", this.file, this.RetloginDetails.token)
  //     .subscribe(res => {
  //       if (res.status == 401) {
  //         this.showAlert("Unauthorized Access !");
  //         this.router.navigate(['/login']);
  //       }
  //       else if (res.status == 404) {
  //         this.showAlert("Wrong/Invalid Token!");
  //         this.router.navigate(['/login']);
  //       }
  //       else if (res.error) {
  //         this.toastService.addSingle(
  //           'error',
  //           'Error',
  //           res.error.errorMessage
  //         );
  //       }
  //       else {
  //         this.toastService.addSingle(
  //           'success',
  //           'Success',
  //           'File uploaded Successfully!'
  //         );
  //         window.location.reload();
  //       }
  //     },
        // error => {
        // },
        // () => {

          // 'onCompleted' callback.
          // No errors, route to new page here
  //       });
  // }


  removeSelectedFile(index: number) {
    // Delete the item from fileNames list
    this.listOfFiles.splice(index, 1);
    // delete file from FileList
    this.fileList.splice(index, 1);
  }
  executeSaveAs(content: any) {
    // let blob = new Blob([content], {'type': "application/octet-stream"});
    saveAs(content, "supplier Master.xlsx"); // This is from https://github.com/eligrey/FileSaver.js
  };


  DownloadTemplete() {
    this.HttpService.downloadFile("/masters-ws/supplier/download-template", this.RetloginDetails.token)
      .subscribe(res => {
        saveAs(res, 'Supplier Master.xlsx');
        //this.executeSaveAs(res);
        //let blob = new Blob([res], {'type': "application/octet-stream"});
        //window.open(res)
      });

    //window.open(this.HttpService.baseUrl+"/masters-ws/supplier/download-template")
    // this.HttpService
    //   .GetByResponseType('/supplier/download-template','blob')
    //   .subscribe((res) => {
    //     var reader = new FileReader;

    //     reader.onload = function() {
    //       var blobAsDataUrl = reader.result;
    //     };

    //     reader.readAsDataURL(res);   
    //   });
  }

  Reset() {
    if (this.RetloginDetails.userType == 'SUPERADMIN') {
      this.supplier.subsidiaryName = undefined;
    }
    this.supplier.name = undefined;
    this.supplier.vendorNumber = undefined;
    this.supplier.vendorType = undefined;
    this.supplier.active = true;
    //.findby("");
    this.resetBaseSearch();
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  selfApproval(id: any) {
    let action: string;
    this.showloader = true;
    this.HttpService
      .GetById('/masters-ws/supplier/self-approve?supplierId=' + id, id, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          // this.pr = res;
          if (res == true) {
            this.toastService.addSingle(
              'success',
              'Success',
              'Supplier Approved Successfully!'
            );
            this.showloader = false;
            window.location.reload();
          } else {
            this.showAlert(res.errorMessage);
            this.showloader = false;
            //this.router.navigate(['/main/purchases-requisition/action', action, this.prId]);
          }
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending Supplier for Approval!'
          );
          this.showloader = false;
        }
      );
  }
  selfApproval_delete() {
    this.showloader = true;
    this.HttpService
      .GetById('/masters-ws/supplier/self-approve?supplierId=' + this.supplier.id, this.supplier.id, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else if (res == true) {
          this.toastService.addSingle(
            'success',
            'Success',
            'Supplier Approved Successfully!'
          );

          this.showloader = false;
          window.location.reload();
        } else {
          this.showAlert(res.errorMessage);
          this.showloader = false;
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            error
          );
          this.showloader = false;
        }

      );
  }
  sendForApproval(id: any) {
    let action: string;
    this.showloader = true;
    this.HttpService
      .GetById('/masters-ws/supplier/send-for-approval?supplierId=' + id, id, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {

          // this.pr = res;
          if (res == true) {
            this.toastService.addSingle(
              'success',
              'Success',
              'Supplier Sent for Approval Successfully!'
            );
            this.showloader = false;
            window.location.reload();
          } else {
            this.showAlert(res.errorMessage);
            this.showloader = false;
            //this.router.navigate(['/main/purchases-requisition/action', 'view',this.prId]);
            //this.router.navigate(['/main/purchases-requisition/list']);

            // [routerLink]="['/main/purchases-requisition/action/view', item.id]

          }
        }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending Supplier for Approval!'
          );
          this.showloader = false;
        });
  }



  //List Export option Start

  //Start PDF

  exportPdf() {
    import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
        const doc = new jsPDF.default();
        //this.= this.employeeExport;
        //this.employeelist=[];
        (doc as any).autoTable(this.exportColumns, this.supplierListPrint);
        doc.save('supplier.pdf');
      })
    })
  }

  //End PDF
  generatePDFData(exportType: any) {
    this.newevent = event;
    this.baseSearchPdf.pageSize = this.totalRecords;
    this.baseSearchPdf.sortColumn = GlobalConstants.SUPPLIER_TABLE_SORT_COLUMN;
    this.baseSearchPdf.filters = { subsidiaryId: this.SubIdList };

    this.HttpService.Insert('/masters-ws/supplier/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //this.employeelistPrint = [];
          this.supplierListPrint = [];
          if (res && res.list.length > 0) {
            var RetData = res.list;
            for (let i = 0; i < RetData.length; i++) {
              if (RetData[i].id == undefined) {
                RetData[i].id = "";
              }
              if (exportType == 'PDF') {
                this.supplierListPrint.push({
                  'id': RetData[i].id,
                  'subsidiaryName': RetData[i].subsidiaryName,
                  'name': RetData[i].name,
                  'vendorNumber': RetData[i].vendorNumber,
                  'vendorType': RetData[i].vendorType,
                  'access': RetData[i].access,
                  'approvalStatus': RetData[i].approvalStatus,
                  'active': RetData[i].active,
                });
              }
              else {
                this.supplierListPrint.push({
                  'Id': RetData[i].id,
                  'Subsidiary Name': RetData[i].subsidiaryName,
                  'Supplier Name': RetData[i].name,
                  'Supplier Number': RetData[i].vendorNumber,
                  'Type': RetData[i].vendorType,
                  'Give Access': RetData[i].access,
                  'Approval Status': RetData[i].approvalStatus,
                  'Status': RetData[i].active,
                });
              }

            }
          }
          if (exportType == 'PDF') { this.exportPdf(); }
        }
      }
    );
  }
  //Start Excel
  exportExcel() {
    this.showloader = true
    this.generatePDFData('');

    setTimeout(() => {
      this.exportExcelData()
    }, 250);
  }
  exportExcelData() {
    if (this.supplierListPrint.length > 0) {
      import('xlsx').then((xlsx) => {
        const worksheet = xlsx.utils.json_to_sheet(this.supplierListPrint);
        const workbook = {
          Sheets: { data: worksheet },
          SheetNames: ['data']
        };
        const excelBuffer: any = xlsx.write(workbook, {
          bookType: 'csv',
          type: 'array',
        });
        this.saveAsExcelFile(excelBuffer, 'supplier');
        this.showloader = false;
      });
    }
  }
  saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.csv';
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE,
    });
    FileSaver.saveAs(
      data, fileName + EXCEL_EXTENSION
      //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
    );
  }
  //End Excel 
  //List Export option End

  GetSupplierList(subId: any) {
    this.HttpService
      .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + subId, subId, this.RetloginDetails.token)
      .subscribe((res) => {

        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.Vendorlist = res;

        }


      });
    // this.HttpService
    //   .GetAll('/supplier/get-suppliers')
    //   .subscribe((res) => {
    //     this.supplierlist = res;

    //   });
  }

  editview(actionType: any, mainId: any) {
    if (localStorage.getItem("SupplierFilters") != null) {
      localStorage.removeItem("SupplierFilters");
    }
    localStorage.setItem("SupplierFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/supplier/action', actionType, mainId, 0]);
  }

  onRowSelect(event: any) {
    let supplierlist= event.data.id;
    this.router.navigate(['/main/supplier/action/view', supplierlist, 0]);
  }
}

