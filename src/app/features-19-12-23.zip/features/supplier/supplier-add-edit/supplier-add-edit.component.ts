import {
  asNativeElements,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TimeScale } from 'chart.js';
import { MenuItem } from 'primeng/api';
import { concat } from 'rxjs';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { AddressComponent } from 'src/app/shared/shared-components/address/address.component';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import {
  Account,
  SubsidiaryEntry,
  Supplier,
  SupplierAccess,
  SupplierAddress,
  SupplierContact,attachment,
  supplierRole,SupSubsidiary,supplierApprovalModel
} from '../model/supplier-model';
import { SupplierService } from '../service/supplier.service';
import { HttpHeaderResponse, HttpHeaders } from '@angular/common/http';
import { saveAs } from 'file-saver';
@Component({
  selector: 'app-supplier-add-edit',
  templateUrl: './supplier-add-edit.component.html',
  styleUrls: ['./supplier-add-edit.component.scss'],
})
export class SupplierAddEditComponent implements OnInit, OnDestroy {
  supplier: Supplier = new Supplier();
  supplierAccess = new SupplierAccess();
  selectedSupplierContact: SupplierContact = new SupplierContact();
  selectedSupplierAddress: SupplierAddress = new SupplierAddress();
  sup: supplierApprovalModel =new supplierApprovalModel();
  LiabilityAccountlist: Account[] = [];
  PreAccountlist: Account[] = [];
  Subsidiarylist: SubsidiaryEntry[] = [];
  totalSupplierContacts: number = 0;
  totalSupplierAddresses: number = 0;
  supplierSubsidiaryCurrency:SupSubsidiary[] = [];
  supplierId: number = 0;
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  accessMode:boolean=false;
  approveMode:boolean=false;
  showHistory:boolean=false;
  accessHidden1:boolean=true;
  accessHidden:boolean=false;
  file_attachment:attachment[]=[];
  showloader:boolean=false;
  role: any;
  empID: number;
  addressData: any;
  displayAddressDialog: boolean = false;
  url:any;
  supplierHistoryList: HistoryModel[] = [];

  vendorTypeOptions: any;
  natureofsupply:any;
  paymentTermOptions: any;
  approvalStatusOptions: any;
  roleOptions: supplierRole[] = [];
  registrationTypeOptions: any;
  checked: boolean;
  NotViewMode:boolean;
  currency: [{ id?: number; name?: string; code?: string; }];
  Suppliercurrency: [{ id?: number; name?: string; code?: string; }];
  ispasswordmatch:boolean
  selectedIndex:any
  SubsideryObject:any=[];
  isReloadSub:boolean;
  supplierRolesCopy: supplierRole[] = [];
  subsidiaryDisabled:boolean=false;
  ApprovalButtonShowHide:Number=0;
  url1:any;
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   isviewEditable:boolean=true;
   // For Role Base Access
   RetloginDetails:any;
    RetAccountId:any;
    RetRoleDetails:any
    listURL:any;
    isviewapprovereject:boolean=false;
    chkId:any;
    display: boolean = false;
    Chktooltip:boolean=false;
    Currencylist:any[]=[];
  @ViewChild(AddressComponent) addressComponent: AddressComponent;
  isAppSequenceVisivble:boolean=false;
  appSequencelist:any=[];

  constructor(
    private supplierService: SupplierService,
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
 
    private toastService: ToastService
  )
 
  {
    this.vendorTypeOptions = [
      { name: 'Company', code: 'Company' },
      { name: 'Individual', code: 'Individual' },
    ];
    this.natureofsupply = [
      { name: 'Service', code: 'Service' },
      { name: 'Goods', code: 'Goods' },
      { name: 'Both', code: 'Both' }
    ];
    this.paymentTermOptions = [
      { name: '15 Days', code: '15 Days' },
      { name: '30 Days', code: '30 Days' },
      { name: '60 Days', code: '60 Days' },
      { name: '90 Days', code: '90 Days' },
      { name: 'DUE UPON RECEIPT', code: 'DUE UPON RECEIPT'},
    ];
    this.paymentTermOptions = ['15 Days', '30 Days', '60 Days', '90 Days', 'DUE UPON RECEIPT'];
    // this.approvalStatusOptions = [
    //   { name: 'Pending Approval', code: 'Pending Approval' },
    //   { name: 'Approved', code: 'Approved' },
    // ];
    //this.approvalStatusOptions = ['Pending Approval', 'Approved'];
    this.approvalStatusOptions = [];
    // let role1 = new SupplierRole();
    // role1.roleId = '1';
    // role1.roleName = 'Role-1';
    // let role2 = new SupplierRole();
    // role2.roleId = '2';
    // role2.roleName = 'Role-2';
    //this.roleOptions.push(role1, role2);


    this.registrationTypeOptions = [
      { registrationType: 'Registered', roleId: 'Registered' },
      { registrationType: 'Unregistered', roleId: 'Unregistered' },
      { registrationType: 'Overseas', roleId: 'Overseas' },
    ];


  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;

 const LDetails:any=localStorage.getItem("LoggerDTLS");
 this.RetloginDetails = JSON.parse(LDetails);
 const LoggerId = JSON.parse(LDetails);
 this.empID = LoggerId.employeeId;
 
 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Supplier")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access


    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.supplierId = +params['id']; // (+) converts string 'id' to a number
            this.GetSupplierbyId();
            //this.getfilebyId();
            //this.loadLov();
          }
          if (params['chkid']) {
            this.chkId = +params['chkid'];
           }

          this.assignMode(params['action']);
          this.url1="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAyVBMVEX////7+/u2MS78/Pz+/v79/f34nyr6+vqzMS7znCq1LSr47++xEQq8SUezHxuwCwC0JSHSkI/kwMDiurnBXlz4mxjz5OTUmJf4nSSyGhW0KCX4mhKvHhr+9+20KSb3mAD4qUf+8ODt0dD4pDPs1NTcpqW5ODXCXFr816/9+vX5tWX7y5rGcG67Qj/frKvoxsXPgoHHamj95Mr5r1b6vnz8377958/80qX4pz/5rFC9R0X26OjLgX/MeHe+VFL56tf5uXD2voX4xo/Js7uSAAAec0lEQVR4nM1dC1viOhMOtBUEZEEsFhAQvIIXvK+7ruL6/3/U12SSNPemBfd8POc5y7rTZCaZybxzSUUBIp+gEsGXSiUkf4aVCvwgqqgkASXxodVIQkayZVoHm3lP1hwCIhttbatMRx5ra52a/dh/V3x2UJtFFzB/MQxTl2Az9GbaYwetu1KEttwOOqbOmcW+9w4VtdtVTdvB/KkLqah5bbd0yJSywXwVLWWDsqL5KHetgCF47HYRActMLdOWU+4SdgU72P99ijY6+ouz+c9skDBy2x4OzlAurcEG/b2Zyua/tMHofdCo1wfXNTftZjuo0X7LLJWaabf7vzvVer1e7dyceiKZzQQU5Cuz96kqFXQTt4MJEbBabbRuUVTKTSALrYNNXwE3VtHgblClAqYfqqmebmIjROmexeRgykG1/kdbELBe76RnqlvAUm5CZzNwP7mJmxBoI9TrTCQB69VG++wboZrE5ve7CRTdtRpUwM55h0k6uG4iqw16KI8vm9/vJkBDYeMG3eZhu0q3kmrqtnbQRvvdUC1AvcmECjhp99IfrYZDqquNzplZwM2hmkD7zVAtrNy1mOm195qYFtUuYE+xpt7XUCnlKcCm8uSWI3rUJ9JgARuDu5CNe9hu0FOHeH+gLRUu5R8VeUuz2SxovzGkAoKGMtpVfQK2WG0cndmm3sxNMNryAubrCQq7gwYImO5VX6RFTXL6kH8i3n/LUE2gRU4V3chNoLdMivadQks0lRpj5zyLqAq5CU9E+V1QDa2qE3ZmEg1VOVpVh9QYG4Nb+swWInqNdsPUltUG0eFRgyE0oqE6bfOgzTBO+70mC7jFxMM3uYnmxRHjfvAemGmj8JDYKYmoUk3dKlTLaL8Hqs2H9KysN45uHbTz6tAQUW3HTXBay9JsZIOHdAOrLIaw0qaayiOq92bu1GXYVJ4sBdWUiL52f0SZ5nGgAxQctjR73Z4NcgG3GtGnGlpn3vw2hxb7qzlBBQSY/zhz+7YCbHJamWnP81eiVZk+y2IHhshy0hvN+zaPqN5ZRLUFNwEkyLj35SP62v0gy1Q0LbTacIctbVW2mHjYavHl9Dzz4vl50cxWVg0eUbVvc5gu6s22CtXOBnrM4FV8od6f6Co+nUpBNQvtFt1E7XpQpQIO7pvISYu0iD49U6kxChHVNhDl9iL605sOFbDROkQFBGQR1YSfwZ3bvKmLsCkvTXmodpsiMBBweD5HkW3cILANx3Eqjqjua1tLPMjilrbB2nuLxkJEQ60cNZs1eTgBi6aaOpAiqq0gSvlvpW3w9HeHstYYHKLIRru63jv/fb2yH+BCRNVhZ/GGiFL6W+niy217QgUcDufW+mDzfjBpNBpDYZO1gJfHJNX60XUkT12KzYqBkcJQjWgoCNi+aFoFXE2G9CQZTlY2pkPQVMh8VE+3gih9lsapov29DhWwMega3A+lPRxUeVK/ignN8WC6EudDpvHtM34ylUeUG/bJBKg3nFABJ8NVlhNUaIUoiXi99kXfGtGLERWrUW2AKDcrvqDojobpKdMfTSttisokAdPl6PQYxtartjRHRyKqU8vU3mxu5CZSDaUJ31SjuvZZuj8Y2Bny0KraugvMAqbjEk2lpY7bDRGlZRl9bDCAohkREGuoTU9w3puhuev++4BtZWfv1Dp182AgRFThJukN+uMSNhhGfxiz1fbem5W21xhyNHcWQrUbuJ+kPi+yMd1tqTWqUmyGMtNFbJBpKDka/1hpSe2QIuoUp2AS6FiAEIvFkDrTaFXnEVXrrCybUOUuE9EjtN9hCd/JsGedhVa3iTSptlHL+8Pd+vBmbhZQiajS2L9Mw0JIPX4ZN9Fts+Ouvde30CJwJdS33XI0F2YGnEa8h/apDwc8oko1tWxUVyr72vxgCd/qgByJRrwU3mVI+qaf1SZSkrc93rnQPmha67QrIat1li2cL5uqgOqT9vN31eYJ307PRksCRgp22u+RWnzp8gN2ONm3TS1FVMRmiyf/yriJ7oCZUYdoqGkZoxSOMyyAvbu0g7BM9CRJSVrd0LK2UkR1c1rkqJCr3EVsUID/rbuaZZYUjmdgJ12GUNlBnFzAPo+RXLxZp54PeUTVZjWqQjUi6W8eyr2aZOXbWwttQDWUgJ3BXWTrsjjjeQFcIo4sUzcP+JJSnFqkRmQT0Krch0xDq1RDDbNE4VmLhUCTSc8c0ZPhTs87GYhTon++KyFUUyGiwjWqIjWi0Pxjq3Jj2E85GrzXFAF55qd5nYGdj76WVUPC+dakIK7KQJwpokeQ+adu9RZK1y42BQErZgFtxZf5OQticTHMJmC6MUzAVjcyCsjhV3ogtXj0hVNslqxa84Ln0tssovJsqTOdv9YgVoeKup4IxSSI5fOS6jiC5sCcp1k1D8VqyikOqp462RR3UBIwT7mbYklCW0ZGm1IxtWsfvCHk0dJcuePeh4E4fVcCnKXih9etp4oGph/b9n5+09FKEvosENhhRqqQFvZoD0jBXZuDODK2OWVBvAvw0H6vhZ4COvra5JUWShLnp8hGSw+9lJHJZC6RuGr0AcQpAoiz2JVgJoyJ/ODYeopKT2Ld4yWJGrLQCo7rCAoX/jdfunwFh0OaiTM4b6YiOKK6NQoolyb5J89NzLOSBA5aGdMKLWugyfS4SDslNTPSvUFAnDG9IdWomj4XdBQBzTZ41uYlieo8S+YqtF22gaRwYRHQHqWjNwbi6gTE2WgPf4g1KtWk9XPTIqC497hoxgw81dDATPv2wdsTju5VLOCZsTwkIA4PMxn0UGBhel7nERU78uw76NPXRhAmDWKzkoTK/X6noQZyJW6+zM873CH94d38soDpYt7LXX9OAaMcG0QQA0FJojoXYjyJNrrjrpKXN0s1OjK8x0GcaTFINZX1jafTBQ4BgxwbJPd4WDsvLkmYad/2jrT2BEO45JFMSEHcDx5V4ljJQrvCERXNLDPnbAuQXCoqRemp/66ZVbTHD/pJhzcZlmsNicRMnADitIhejKju5YhKvcdpV9EAs04FHFZXyHJJGWMuhgX2NCxQ6OYLTF1LVZ4dyhTEGdIboRBR3ZxaVZR/DCoaUrgIIXjTxhFGI1TA1ntNHa5Q1z2v2vYGWWfqmZk2HW6VRVQks+wpYBalY22pUqDbtXKEa6P2KL1kOyW/ocFAnJm2ecFqVA0eCtgE1GwwYuuYDjFsrKSjX6AVqvc41FU3eYNLygKI6zAQp9MKERXgVMNdavlvPIitCSUJjC9Ml5RDsXrfugtCdaVLCchoMwjIQJzh8GI4ld2jMh0VyGSDtKxLo/TQbAgpmOuwhDbW0EATcKObL+jtQkiFWOs+zQtWNSDeX9+HyGzp7awksY8sS1MjoS7YyofVVlBRGxRcSpYpnbR6WblbTTy0GZriEVVeX1uqobwkcdG3CTg/l6v3mjPapIOFDpcF3RmIMyTgedBNe/6VhdP2/o2XJOqtbmAWMKKhLnGVjX204Q5aUY8E4swN/ziiuuBuDScA1XFVjvYbvCQx6Fk4Ij2vzFWmGooM3raEiuqoJwNxdQBxloi+m9UoU++vYgz5b39a7ATrfJBF08/fiHWDsur9hh2E7j4ZyMTxdjILMBIiqh9nRgHp3r/xkkQV5+KR0YNGWU/P8Hxl2pWt3nypiXHL3DKcVKMiPf9mAYUbZXCPJ6/eleINk4BbuqTMuM+OdiinmiL6UI2o5L42Km5XK0kYdlDoVx4cGpne+s0XekUMOo0OsnK3ArbnPKKidX8+HJ2leZHdkniPFAG5DXaF2xFzZNrkbV5S5rRdXu7OQJwWLqURFetKYnEXGZfOsjpXO3QNO9jP7mJBn7PfyVjkFLUsxj4/SqptAHGGrFrlMOvVIakGUUARGfTVZWRD9Krck4AebMsGPW6+qCDOpM4RmreHVJ1JZwQZTo1D2teBsjRsllDwJJCMKeTbitigoUYkXskkmThzPEi6/uRuejzLPLsl0cnqyIqA/SxdSG8LGvIGxSP6fBvkw4mVkz9aOoh9ob6MlHlYyuHQcEtCO2R6DfU2k2sHt3NJWaXlIA7fiesb2VTwCOEUbh3ByvBbEuosoeB2z/tGkq1BNTttSMupVQbiTLRiRNXA1dR51VCSUKFa/zcH+Ud/mCfZyE2UbackkWsG4rSIHmgP+X4cHaB3voO4W4XNIiv3LX9BQGPYs630plDN015rd8ItsLnCA1+MFQNnwz6q/aZuYthE5mWsvPN04dGe1ZN8l5vQD6TeEfdZAOIMWZheh2IXbIinNH4c/kGMe2kHT/EJRu30j9VWvueSsvFQZvf8WZrTkKToU7/WwTLhvC+sSIuBbUnAW37hatLo8TXYKKu2+V3qbnYDabLK2sVZorC2B7vc2CMeP0TvNB8x0VMWzWvejIzThZvArxJQzV4AFUDcUVehDdAdzaMdgUdJ/7uBrO7kI1I4gutokC7s1kIb099vg+rb0QQQVycvhRHDJUUp8ac/ZB0OSNrBsx+sYomVIfDOdRZROwNU82jlqoQMxNUBxHEzqYTUCOtsc8mnR0P7VvZ+igA6Y1h/xJvWtLFZVm0LL7IlWJMegXesYlKJajeQgWh8kMdhjIqiuUTtSLoQYHrrkKyazEgpqFYmA2dp5RIjWpaJwyTvUG6ptt9gOPbkb2gum+zV6I9pOpbY4FwPq/+9mzCUu8M/LDVfJyAOk9zSzGJrnw8HD7wN4fztvBMBIQUJAg7eHGr3T6CaRCIgStTk76ACEFdBp1TAdpcPx57sUSiXooAK7W2hWt5qRhvt4BagmimiJ0dFK2OTgLjKOaRXhwcRZ5NvOWuHGfTpxSr2ZKupnaIbFUC3+CLbZitjE3fVn10z1/6WDceeDKIPCEyqNwftqiBgKqFpcPjyz6CaJaJvCQJiG6Otqi2p65M/2QT56w3eJ0gdZ1OZ5d9E9B4CphLSBiMG4kBAYoTy21vgyf2BuCL1zscNnErNnJX+V1BNT1lgCTH8zJL6JBN/gPQdhCG6R8KWD67RHlmaVtMyy3YF1FXU+CJbiTaVkABsdrEBchfVpjgceZLv5wFvDyQpjj0S+LaappX+jteOGWlNboJ9AW+RShiR7kJaYZtLwyFxV6Jmg9ZcoDNmjwTHrab7kPG3wS1ANZGHIOAShlmHKK41yGxKs6x+gOkBzttr0LN0S9HENqCauBiIS4g/tWvcadQ5UDVeWRr8dlFWeOIS6k0I/7WboLTg8amEpLmnca4F/eqT98OjD4piuYQ8di5jg9txE+aWOvD4ICG0i7fmGpvqk81JN2CMcC2VSbZ9ipayQUJLPD5oKdDWehmtXCPNngyb2SxEQubx/4OsmkOdgZb5Q9Ni2ASU9GSvkXn8f1B8KWaDVEJ6ltqnds4ievz/H6gm0PKz1JH8k59UOMo8/rcVX8rbIBI9vsP8jT9mswgef0uHDMqjLeRSAskfWqd2YCt+lv4/QTWxD1WW0AKiHJaeefwtRfQoj7aIDWJayePbvJn1rA51j1/KBr/zV9OIHt86tUtPJH/4fwPVBFrB4zvM3zGL6A//C6img22FNvP4jhqRmSOYhfhDKmGRIHajj4+bYFNzj5+7gxZL3yOFNSJhERtEp71yn1MYF1nG1TWjSXozsT/UdpCzKcmtMp15/ELFF9T90cafo6N2O+eL9IMf3SI2iPODzY/zdmeSSug2f7shcI9f7He+oC67qZHl+aQvdcOX9H+dbjEBMW3t9PBicIPUHZQsye6MuLcICxZfup0yAmIJC9hgthh99W3F6m8ls+5K5vELuolup4yARELkGtcydagKKLPpULtsD3MFlI/zbqeMgFhCKqALquWiRJVN+9IEisf3x6Jd6C8adnw/Q0lChw0ybdJfg2rHIw4BZY9foPjSJS8sGb4f+n7eSamLSujCuLP1w3P6eXhZj+XFsKNEJ9Oyx/eHal2yJ23WzJv/WZFGNJDQcndp8XC1PInjEfnE6Zf4+OlyXcuxQWR7ews1BMHjF4FqTMJ9S5MV0uxqn7SeEQl1AaMwWF/9mo7iZHcHPrvkS5LEo+TzcozciNLMNB1c9PgFAl7qD1MJfXHrPmng7XRNAoazr+NUOibXjvwlGcXLy0XoPgvtiJd7/GIRPZXwSHuDl/Xo3z9SPT6nfVjGWDyLgGQv492vcSEBs8Ibjw8LRvTg8amEHhF9KiE9S1U38fA6SsxyZV/SP+Pp08yKKO27Inh8fwHJLODx2/sWWg2dYDsECWUVfXkcCWIQw4PPFFslFx2TxPHXODKzaRewpuS8/ZNO4PHb+2ZaPXakEg6ZxwfaxdMoyQRMRtOTz6vLh/UYf9bPP78e42mqv7uMJN69NLNpFbASKR7fP6IHj48l9Iz+ZQmB9jnlmXGfxDtPz+TQZMc12a/Zz8ckzrR4tByb2FSYlkJlyeMXiOjB4+Oz1DOiJxIyj09oo6dpQgVM4pO/L5ap0eLyMY6ZUSbxMzdGm4DySosevwgg5N7CN6u2Tzw+vKmE8DD7FVP9S0bHP8dONmd/45ht9vQrUGnNT1IPKnh8Hxvkl5RBwsG+noq25G9Ij0TnPmK0LzvMwEYnl+wZK5to/HfKdDVehgqtk+nM4xfKVmd7mEfLhsMef/IRMNrnKRUwia+QvSErawoOx0viVbDjeB2rtKYqJH2Se/yCWTXZ43uEQKnHbwybjKPLKfUBo+VMtytLVu35JKbGmIoo0brqUqrH9y2ASh7fI7ONPT60MWHayxEImEwvi1hHuo0U47yOI5HW6CbgSdXjexdfRI/vkyROtZTcKwAVZQKerJ14RJs6vJpS33K8EGm1vc9guuLx/Ysvgsf3Kr6g/dYF4+iFqmj8uChcFnlOwBiTY4nWsTSSxy9QfMk8vmfxZf8He0PmLIFDZrQ00eZF9GtyBqf45tMuoBQqix6/SAG0O6Qe37f40usyR/+LCvjpFNBap51Rzzj6yZPEzqUx9bV52JUQAeerKCFZsTchPIGjj907aI/o0ZoC8tELCxnJk7YCqKuvzbErmT/0sEEpmniewiHzaBTQdFSo44YvMaDU10VGYl8aR1+bq1Cj+EP/AuhiJ4FT1HjI6FMHi5eZNi51NvETpzXU6Jly2/va3AVQyR86br6o3D9BNDH1dBPB4ng6etJohVHI1KEdQOt9bZ41etEfFqgPvkC8OzI6ep3NVMAE4x72L5z2GLDNL7oYhkOGcWTta8srgBJ/SCUsUKN/JAFvsnTaoCDgIzG5eBnJtOlpA4fNJUSTjvPX1teW2yfTJTcWiYQ+ArKcDGxhMva0wV/0TCEHr1THuBoREV/FCNHsQc19bfk1+szjF6nnv4KOXnkKeByz/A0WUaZ9JcnH0aUgoHlXpL62AjdfuMcv0ifzQIBzcuKIJkw7CIq6kI+KB+J10rG4gJajX/D4RW6+ZB6/QJ9MuCTWM3r2CWSYDfIs1FJZjGNi0tNnirutNXpTX5tHn0zm8fNVlG/lLIawoGYXsGbeQQjtZVqqEI/M49t2Rahy+6topHl8jx0Mwi84GC+jIjaYvJ6w0H4p0kbBL6IR8QwHfvaqht7X5tknI3t8HwErxLft7JxoSSeTm/jFBRzPaDSRihgKvy+MIJv0hz+Rawf1vjbflmbJ4/sIWENrwlHypArochMJXo8Z09V4mRlQhMZAQgCuA1+qVW7fawWix/e4+YLHvSJJz1jNi+pRnaCisOHr3YTa4pPI5ifZ23gmeHwD02qV2wnVgBEynODxPdwEGfcXlM8UAY1QLVNRQhuuWWnqRKQF/JC5RPOuKFVuS0Svc5R5fC8bTMddkNwFKKkTbI9/KQJGiyUcNrs4sM8WY7yzK6i97egv29fGPb7hQNJtMCIrTgoPz8bhrDZIhltCUn83ScbiPoSPCcm7hU6mpSq3P/wSYny/HUSpGRIPrSVzVQFVFRUE3JlJbEbEssmQjl0RqtxF2imtVW57n8wS1+gxynJF9JKbQFRFmYAnsoAVrBb4hH1wCShWuf3cBCGp2arcjlauE2I0n55Qje9gqOygeFSMp+SAvXTBr8xbFGxpVj0+ctDCFwA0V4ZkgqcNygISNmMSWl25dkXra/OwQaGvjXp8uagJA9On2ZcAQGkashazwUeLDQKbBH2neuHT14ZyBTT1tXVu3/p5H/Jmh0oAiGb0oCYTLFANGW1QPSo+iW0/brmvDWahfW2dVqs1GLTgY/zy4x4Jp8Jo7djBXBXVjoq/BAm8Ktsjq53s8T1VFLEqt9h2aOlM7HRhalyN2dkdje0CHmsCPuYIGIK7OHHuiqnKbYVqwizdoZ+A1c4hjAv1JpDQC6pFodVNMDapQ9x1CWjpa1N30NbX5tFbiiXE4z4DpBmLO6hn1YRDZuFwE4xNQULr0V+sry17jVG34ycg6fNCREICk8fmpHoJG8RsQriy62Raq3J72CAm6bYnE/xb1BuTCXyZmL80jugb1B7iXUBYxja5om6CsvlFHOKJ62Q09bWpAhozcGcXB36fC9ojBOWU6dp0SQ7NRgXdBMvuJ1Asdahdkb42DbcW+ITBOqZ5NlMyAQ5aO1SzIcol8fhLx28lK9LXVvr2GTA9plkVlkyQkn+fSQGoJkx9QmoET86XzKl9bZTprVxSlmkhlfilCohJwlfQNqqimQ3a3ARD1dNdlotCVrVT+tqctBsJCGl4UhjVcmMz0icTQ3Cca4OZgBQJPitMy6ok5LyL2KC9+OI+FXZiaQ2o2l1CaT55caqo5s2iZ3Z6mQWEWTJ/6OcmirgUeTFAjOnMcHB8QgN7MnoJPd0EGTd8gohsgYy7kvW1VW19baXfZWGkXY+o0WgCLk5Y6n70gnKhmjD1K8nTPIZOpoUq9yYq6nEg1UgckBqidvSDOUG68DEfqvFxSci5iw8vhyr59LUVyd9YFyMd/xNEHMs2mP7Tz5gLuJPkuQlh3J8E0YweMo4MK61WuQvYVaEdxCSkzkCyKkDLI4RlwgXc8bVB/OWRtB5hJ+pY6eJ9beUExMONyZJTfyGq3UgTMMdNwNTrEaH9ROxj7pPx7WvzKr64dhABxoI6gyTgy1QRMHZEE8K4X6TlhHpDIyNF+to8iy9OAam/iP8qdvUzzgRMkniaPLmhGh13Ae20yYIJaFE76e0tZdxEgQuSC1ojG8uBDK3YYOni18/LmXk4DVFCDj3+QrbfSlamr628DZIvrAj8FIpqtwDUHU9PPi/X7D2z+RhjAThoOkMb9LUVeu1YnoriGcdgcdOZSPsySpLRaPlzvUD6L+2yJx6+CA5KIycytQN+OfraHMtYzE1kJE9wnC5F2q/pr6uH0Htq+mUGQG+6JpfQHX0yBfraNrNB2OQxnA7k/GO060WYN5y+trRxJfkMpb42w97797WVdvT0C5B8xdAzJLR9BVaNtyf/aJfCTryGaoQmYIG+tnIRvZVkzFoOHC+ezq8RASLFjofXRSQBJaY9+9o228FsbSO6+KMr63rl22C4eAUd3WEKLi+N/KRfX9uGbkK0DlqSnz6baX0O8OATtjCDMxIjRfratgHV1KkBnZKA3qmi9vx0+JcaIWtRqNgEJH+43te2SURvSt0DyfMUUhZp+JCzGOapwy8QMKGN7EBiZzrra9tuRO84GQHZ7CTxuoCb4H3Q4RdcDNpNRNxgP389+tq24yayqYNgGVMeX/IWQz9kAqqi1JAdAlKOMn/IHCJnhK0B81d6w79OW7HSikyHr/TuEomGvW4/sAkWn0zAnyKJw66ohAPt7S1FmC4mID5tXmm3Iblo4G/+aPZKtz/+kmhdT4I/rA9+/IvPHeMhFZG6/uM1X6Zc60gDzMQoIDItIxtir2Go+ZV6uY6ThL6+v8d+Jc74mOVmEvD9HjY4W7KM1dQsoKuv7d8IWK122G+Kj6CoTdIQr89iqc0G1RZf/A0Lsg0i5e0taqi81/h3AtbrjUafM/05YpfVp8cPTA9tbC6u+ItdkuRZppXf3qLt/V7jHwpYrU7O3/jUP/kbMXZGx+QdNNas2lfCr+PHr1L8zCTJ62tzyiV88SDJoR3eNNkvaEdrdjLiV2LsfD6PeaTAJY1C/N6IUcwzVaOnhUkSR6B1M2AvxDO9Ik/5F/1LcdpBnf5et9SbLp6mCXtzScr87uPVA9lKLun6+ek1Ft79Ee8wsC3vtquNBP1XH0Ay618jIVOaxKNpfPz59yr9fD0tT6YjeDUPf3vGX5Y6VHRxk3rDlqCaHbdeHo/kpH6Cs4rpJxHe6wIH0uc6tAxnnWXbxRf/KD1bjGhxeTK1vSIqEzCeLtehtYHSxvS3R/T2HZRpnx/j2CVgMkq+Zii0Tm0T8JvCpULvWma06YEZjxLTVibJ6OTzeeGcOm+W74zofWnTH8wun16nxP7osZOQg+fxC85XF5s5TPuoaJRHu5mAnGT8cHn1+fh6gsuCx8unn888meqc+n++Nsgd59CCVQAAAABJRU5ErkJggg==";
          if(params['action']== "approval")
          {
            this.listURL="/main/supplier/supplier-approval";
          }
          else
          {
            this.listURL='/main/supplier/list';
          }
          //this.GetSubsideryListLov();
          this.GetSubsideryList();
          this.GetCurrencyList();
          this.addSupplierContact();
          this.GetAllCurrencyList();
          if(this.addMode){
            var SubsidiaryDT:SupSubsidiary =new SupSubsidiary();
            SubsidiaryDT.preferredCurrency=this.supplier.supplierSubsidiary.length ==0?true:false;
            this.supplier.supplierSubsidiary.push(SubsidiaryDT);
          }
          this.supplier.supplierAddresses[0].defaultBilling=true;
          this.supplier.supplierAddresses[0].defaultShipping=true;
          this.vendorTypeOptions = [
            { name: 'Company', code: 'Company' },
            { name: 'Individual', code: 'Individual' },
          ];
        } else {
          this.listURL='/main/supplier/list';
         }
      },
      (error) => {
       }
    );

    this.totalSupplierContacts = this.supplier.supplierContacts.length;
    this.totalSupplierAddresses = this.supplier.supplierAddresses.length;
    this.supplier.supplierSubsidiary.length;
  }

  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.approveMode=false;
        this.NotViewMode=true;
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        this.showHistory=false;
        this.supplier.vendorNumber = '';
        var addedAddress = new SupplierAddress();
        this.supplier.supplierAddresses.push(addedAddress);
        break;
      case 'edit':
        this.NotViewMode=true;
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.showHistory=true;
        this.approveMode=false;
        break;
      case 'view':
        this.NotViewMode=false;
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.showHistory=true;
        this.approveMode=false;
        break;
case 'approval':
        this.NotViewMode=false;
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.showHistory=true;
        this.approveMode=true;
  break;
      default:
        break;
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  GetSupplierbyId1() {
    this.httpService
      .GetById('/masters-ws/supplier/get?id=' + this.supplierId, this.supplierId,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
    {   this.supplier = res;
        if (this.supplier.supplierAccess == null) {
          this.supplier.supplierAccess = this.supplierAccess;
        } else {
          if (
            this.supplier.supplierAccess.supplierRoles &&
            this.supplier.supplierAccess.supplierRoles.length > 0
          ) {
            if (this.viewMode) {
              var rolelist = this.supplier.supplierAccess.supplierRoles.map(
                (x) => x.roleName
              );
              this.role = rolelist.join(',');
            } else {
              let copiedValue = JSON.parse(
                JSON.stringify(this.supplier.supplierAccess.supplierRoles)
              );
              //this.supplier.supplierAccess.supplierRoles = [];
              this.supplierRolesCopy=[];
              copiedValue.forEach((element: any) => {
                let item = this.roleOptions.find(
                  (o) => o.roleId == element.roleId
                );
                if (item) {
                  let role = new supplierRole();
                  role.roleId = item.roleId;
                  role.roleName = item.roleName;
                  //this.supplier.supplierAccess.supplierRoles?.push(role);
                  this.supplierRolesCopy?.push(role);
                }
              });
            }
          }
        }}
      });
  }

  GetSupplierbyId() {
    this.httpService
      .GetById('/masters-ws/supplier/get?id=' + this.supplierId, this.supplierId,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
         else{
          if(this.chkId==1)
          {
            this.isviewapprovereject=true;
          }

        if( res.approvalStatus=='Pending Approval' || res.approvalStatus=='Processed' || res.approvalStatus=='Partially Processed' ||res.approvalStatus=='Approved' || res.approvalStatus=='Closed' || res.approvalStatus=='Partially Approved') //Send Approval Mode
        {
        this.ApprovalButtonShowHide=0;
        }
        else{
          this.ApprovalButtonShowHide=1;
        }
        if(res.approvalStatus=='Pending Approval' || res.approvalStatus == 'Partially Approved')
        {
          this.isviewEditable=false
        }
        
        let subid:any=res.supplierSubsidiary[0].subsidiaryId;
  
         this.GetAccountType('Liability',subid);
         this.GetAccountType('Assets',subid);
         this.GetAllRoleList(subid);
         setTimeout(() => this.LoadRolesByInterval(res), 150);
         this.file_attachment=[];

          for(let i=0;i<res.supplierAttachmentDetails.length;i++){
         
          this.file_attachment.push({
            remarks:res.supplierAttachmentDetails[i].remarks=="undefined"?"":res.supplierAttachmentDetails[i].remarks,
            filename:res.supplierAttachmentDetails[i].attachName,
            download:true
          })

        }
       
      }
      });
     
  }

  LoadRolesByInterval(Retsupplier:Supplier)
  {
      this.supplier = Retsupplier;
      this.supplier.supplierAccounting.asOnDate = new Date(this.supplier.supplierAccounting.asOnDate)
      this.appSequencelist=[];
      //this.appSequencelist= this.supplier.approvers;
      this.appSequencelist=this.supplier.approvers;
      let nextApprover=this.supplier.nextApprover;
      let isNextApproverFound:Boolean=false;
      if(this.appSequencelist != null)
   {   for(let x=0;x<this.appSequencelist.length;x++)
      {
        let status='';
        if (this.appSequencelist[x].id == nextApprover)
        {
          isNextApproverFound=true;
          status='current';//this.appSequencelist[x]['status']=;
        }
        else
        {
          if(isNextApproverFound)
          {
            status='pending';
            //this.appSequencelist[x]['status']='pending';
          }else{
            status='approved';
            //this.appSequencelist[x]['status']='approved';
          }
        }
        this.appSequencelist[x]['status']=status;
      }}
      this.supplier.supplierContacts=Retsupplier.supplierContacts!=null ?Retsupplier.supplierContacts: []
      this.supplier.supplierAccess.password=null;
      if (
        this.supplier.supplierAccess.supplierRoles &&
        this.supplier.supplierAccess.supplierRoles.length > 0) {
        if (this.viewMode) {
          var rolelist = this.supplier.supplierAccess.supplierRoles.map(
            (x) => x.roleName
          );
          this.role = rolelist.join(',');
        } else {
          let copiedValue = JSON.parse(
            JSON.stringify(this.supplier.supplierAccess.supplierRoles)
          );
          //this.supplier.supplierAccess.supplierRoles = [];
          this.supplierRolesCopy=[];
          copiedValue.forEach((element: any) => {
            let item = this.roleOptions.find(
              (o) => o.roleId == element.roleId
            );
            if (item) {
              let role = new supplierRole();
              role.roleId = item.roleId;
              role.roleName = item.roleName;
              //this.supplier.supplierAccess.supplierRoles?.push(role);
              this.supplierRolesCopy?.push(role);
            }
          });
        }
      }
  }
  /* Start Fetch Account type list from api */
  GetAccountType(type: string,id:number) {
    let defaultLiability:any;
    let defaultPreAccount:any;
    this.httpService.GetAll('/masters-ws/account/get-account-by-subsidiary?subsidiaryId='+id+'&type=' + type+'&formName=Supplier',this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
      { if (type == 'Liability') {
        this.LiabilityAccountlist =[];
          this.LiabilityAccountlist = res;
          for(let x=0;x<res.length;x++)
          {
            if(res[x].default)
            {
              defaultLiability=res[x].id;
            }
          }
        }
         if (type == 'Assets') {
          this.PreAccountlist =[];
          this.PreAccountlist = res;
          for(let x=0;x<res.length;x++)
          {
            if(res[x].default)
            {
              defaultPreAccount=res[x].id;
            }
          }
        }}
      },
      (error) => {
      },
      () => {
        if(this.addMode)
        {
          if(type == 'Liability'){this.supplier.supplierAccounting.liabilityAccountId=defaultLiability}
          if (type == 'Assets'){this.supplier.supplierAccounting.prepaymentAccountId=defaultPreAccount}
        }
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
  }
  /* End Fetch Account type list from api */

  // Fetching Role by Subsidiary
  GetAllRoleList(SubsidiaryId:any)
  {
    try {
      //this.httpService.GetById('/roles/get-roles-by-subsidiary?subsidiaryId=' + SubsidiaryId, SubsidiaryId).subscribe(
        this.httpService.GetAll('/masters-ws/roles/get-roles-by-subsidiary?subsidiaryId='+SubsidiaryId + '&accessType=' + "VENDOR",this.RetloginDetails.token).subscribe(
        
     // Insert('/get-roles-by-subsidiary?subsidiaryId',obj)
        (res) => {
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
             this.router.navigate(['/login']);
           }
         else if (res && res.length > 0) {
            this.roleOptions=[];
            //this.roleOptions = res;
            res.map((x: any, i: any) => {
              if(x.active)
              {
                this.roleOptions.push({ "roleId": x.id, "roleName": x.name })
              }

            });
          } else {
            this.roleOptions = [];
          }
        },
        (error) => {
        }
      );
    } catch (err) {
    }
  }
   // End Fetching Role by Subsidiary

  GetSubsideryList() {
    //if(this.RetRoleDetails[0].selectedAccess == 'ADMIN')
    if(this.RetloginDetails.userType=='SUPERADMIN')
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    //this.httpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
       else {this.SubsideryObject=res;this.isReloadSub=false; }
        // this.GetSubsideryListLov();
      },
      (error) => {
       this.isReloadSub=false;

      }
    );
  }else if(this.RetloginDetails.userType=='ENDUSER')
  {
    this.SubsideryObject.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });
  }
  }

  GetSubsideryListLov() {
    this.httpService.GetAll(GlobalConstants.URL_SUBSIDIARY_GET_ALL_LOV,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
       else {this.SubsideryObject=res;}
      },
      (error) => {
      }
    );
  }
  /* End Fetch Subsidery list from api */

  /* Start fetching History details */
  LoadHistory() {
    if (this.supplierHistoryList.length == 0)
      this.httpService
        .GetById(
          `/masters-ws/supplier/get/history?id=${this.supplierId}&pageSize=100`,
          this.supplierId,this.RetloginDetails.token
        )
        .subscribe((res) => {
          if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else  if(res.status == 500)
        {
          this.showAlert("Error Occoured");
        }
        else
        {  this.supplierHistoryList = res;}
        });
  }
  /* End fetching History details */

  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 6) {
      this.LoadHistory();
      this.displayAddressDialog = false;
    }
  }

  addSupplierContact() {
    if (
      this.supplier.supplierContacts.length > 0 &&
      this.supplier.supplierContacts[length - 1] == new SupplierContact()
    ) {
      return;
    }
    this.supplier.supplierContacts.push(new SupplierContact());
    this.supplier.supplierContacts[0].primaryContact=true;
  }
//--Add New Row Of Subsidiary
addSupplierSubsidiary() {
 if (
    this.supplier.supplierSubsidiary.length > 0 &&
    this.supplier.supplierSubsidiary[length - 1] == new SupSubsidiary()
  ) {
    return;
  }
  var SubsidiaryData:SupSubsidiary =new SupSubsidiary();
  SubsidiaryData.subsidiaryId=this.supplier.supplierSubsidiary.length !==0?this.supplier.supplierSubsidiary[0].subsidiaryId:0;
  SubsidiaryData.currency=this.supplier.supplierSubsidiary.length !==0?this.supplier.supplierSubsidiary[0].currency:'';
  SubsidiaryData.preferredCurrency=this.supplier.supplierSubsidiary.length ==0?true:false;
  this.subsidiaryDisabled=this.supplier.supplierSubsidiary.length ==0?false:true;;
  //("subsidiaryId":this.supplier.supplierSubsidiary[this.supplier.supplierSubsidiary.length +1].subsidiaryId)
  this.supplier.supplierSubsidiary.push(SubsidiaryData);
}
  editSupplierContactsDialog(contactToEdit: SupplierContact) {}

  deleteSupplierContact(contactToDelete: SupplierContact) {
    let index = this.findIndexForContact(
      contactToDelete,
      this.supplier.supplierContacts
    );
    if (index >= 0) this.supplier.supplierContacts.splice(index, 1);
  }

  handleToggleEvent(event: any) {
    event.originalEvent.cancelBubble = true;
  }

  findIndexForContact(
    contact: SupplierContact,
    contactList: SupplierContact[]
  ): number {
    return contactList.findIndex(
      (o) =>
        o.altContactNumber == contact.altContactNumber &&
        o.contactNumber == contact.contactNumber &&
        o.fax == contact.fax &&
        o.supplierId == contact.supplierId &&
        o.fax == contact.fax
    );
  }

  handleSubsidiaryChange(event: any,index:number) {
    this.httpService.GetById(GlobalConstants.URL_CURRENCY_GET_BY_SUBSIDIARY + '?id=' + event.value, event.value,this.RetloginDetails.token).subscribe( 
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.supplier.supplierSubsidiary[index].currency=res.currency;}
         },
         (error) => {
         }
       );
       this.loadLov();

    // let subs = this.Subsidiarylist.find((x) => x.id == event.value);
    // if (subs) {
    //   this.supplier.supplierSubsidiary[0].currency = RetCurrency;
    //   this.GetAllRoleList(event.value);
    // }

   

  }
  loadLov()
{
  let subid:any=this.supplier.supplierSubsidiary[0].subsidiaryId;
  this.GetAccountType('Liability',subid);
  this.GetAccountType('Assets',subid);
  this.GetAllRoleList(subid);
  //this.GetVendorNo(subid);
}
//--Get Currency By Subsidiary
GetCurrencyBySubsidiary(subsidiaryId:number)
{
  this.httpService.GetById(GlobalConstants.URL_CURRENCY_GET_BY_SUBSIDIARY + '?id=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
    (res) => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
      {return res.currency;}
       },
       (error) => {
       }
     );
}

  //Not required as of now..
  // Need to check with API team for existing issue --> adding roles with same ids again - in update flow.
  handleRolesChange(event: any) {}

  openSupplierAddressDialog() {
    this.selectedIndex=-1;
    this.selectedSupplierAddress = new SupplierAddress();
    this.displayAddressDialog = true;
  }

  editSupplierAddressDialog(addressToEdit: SupplierAddress) {
    if (addressToEdit.country && addressToEdit.state) {
      this.selectedSupplierAddress = addressToEdit;
      this.addressComponent.GetStateListByString(addressToEdit.country);
      this.addressComponent.GetCityListByString(addressToEdit.state);
      this.displayAddressDialog = true;
    }
  }

  deleteSupplierAddress(addressToDelete: SupplierAddress) {
    let addressIndexToDelete = this.supplier.supplierAddresses.findIndex(
      (o) =>
        o.address1 == addressToDelete.address1 &&
        o.address2 == addressToDelete.address2 &&
        o.city == addressToDelete.city &&
        o.state == addressToDelete.state &&
        o.country == addressToDelete.country &&
        o.pin == addressToDelete.pin
    );
    if (addressIndexToDelete >= 0) {
      this.supplier.supplierAddresses.splice(addressIndexToDelete, 1);
    }
  }

  onAddressSave(addedAddress: SupplierAddress) {
    addedAddress.zipcode = addedAddress.pin;
    if (addedAddress.country && addedAddress.state  && addedAddress.city && addedAddress.address1) {
    if(this.selectedIndex !=-1){

    }else{
      this.supplier.supplierAddresses.push(addedAddress);
    }
    this.displayAddressDialog = false;
  }
  }

  onAddressCancel(event: any) {
   // this.displayAddressDialog = false;
  //  if(this.selectedIndex !=-1){
  //   if (this.supplier.supplierAddresses[this.selectedIndex].country &&this.supplier.supplierAddresses[this.selectedIndex].state && this.supplier.supplierAddresses[this.selectedIndex].city ) {
  //     this.displayAddressDialog = false;
  //   }
  // }else{
    this.displayAddressDialog = false;
  //}
  }

  saveSupplier22() {
    if (this.supplier.supplierAccess.supplierRoles && this.supplier.supplierAccess.supplierRoles.length > 0) {
      var output = this.supplier.supplierAccess.supplierRoles?.filter(
        (val, i) => {
          var t = !this.supplierRolesCopy.find(NewArrayobj => NewArrayobj.roleId == val.roleId)
          if (t == false) {
            val.deleted = false;
          } else {
            val.deleted = true;
            if (!val.id) {
              this.supplier.supplierAccess.supplierRoles?.splice(i, 1);
            }
          }
        }
      );
      var output1 = this.supplierRolesCopy.filter(
        val => !this.supplier.supplierAccess.supplierRoles?.find(myArrayobj => myArrayobj.roleId == val.roleId));
        output1.map(x => {
        this.supplier.supplierAccess.supplierRoles?.push({ roleId: x.roleId, roleName: x.roleName })
      })
    } 
    else {
      this.supplierRolesCopy.map((x, i) => {
        if(this.supplier.supplierAccess.supplierRoles){
          this.supplier.supplierAccess.supplierRoles.push({ roleId: x.roleId, roleName: x.roleName })
        }else{
          this.supplier.supplierAccess.supplierRoles=[];
          this.supplier.supplierAccess.supplierRoles.push({ roleId: x.roleId, roleName: x.roleName })
        }
      })
    }

    this.httpService.Insert('/masters-ws/supplier/save', this.supplier,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
        else if (res && res.id > 0) {
          //this.saveAddress();
          this.showSuccess();
         this.router.navigate(['/main/supplier/list']);
        } else {
          this.showError();
         }
      },
      (error) => {
       this.showAlert(error);
      },
      () => {}
    );
  }
  saveSupplier1() {
    if(this.supplier.name !== undefined && this.supplier.vendorType !==undefined && this.supplier.pan !== undefined
      && this.supplier.supplierAccounting.liabilityAccountId !== undefined
      && this.supplier.supplierAccounting.liabilityAccountId !== undefined)
      {
    this.httpService.Insert('/masters-ws/supplier/save', this.supplier,this.RetloginDetails.token).subscribe(
      (res) => {if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
        else if (res && res.id > 0) {
          //this.saveAddress();
          this.showSuccess();
           this.router.navigate(['/main/supplier/list']);
        } else {
          this.showError();
        }
      },
      (error) => {
       this.showAlert(error);
      },
      () => {}
    );
      }
      else{
        if (this.supplier.name == undefined)
        {
          this.showAlert('Enter Vendor Name !');
        }
        else if (this.supplier.vendorType == undefined)
        {
          this.showAlert('Select Vendor Type !');
        }
        else if (this.supplier.pan == undefined)
        {
          this.showAlert('Enter PAN Number !');
        }
        
        else if (this.supplier.supplierAccounting.liabilityAccountId == undefined)
        {
          this.showAlert('Select Liability Account !');
        }
        else if (this.supplier.supplierAccounting.prepaymentAccountId == undefined)
        {
          this.showAlert('Select Prepayment Account !');
        }
      }
  }
  saveSupplier() {
    //--New
    if (this.supplierRolesCopy.length > 0) {
      this.supplier.supplierAccess.supplierRoles?.filter(
        (val: any, i: any) => {
          var t = !this.supplierRolesCopy.find((NewArrayobj: any) => NewArrayobj.roleId == val.roleId)
           if (t == false) {
            val.deleted = false;
          } else {
            val.deleted = true;
            if (!val.roleId) {
              this.supplier.supplierAccess.supplierRoles?.splice(i, 1);
            }
          }
        }
      );
      var output3 = this.supplierRolesCopy.filter(
        (val: any) => !this.supplier.supplierAccess.supplierRoles?.find((myArrayobj: any) => myArrayobj.roleId == val.roleId));
        output3.map((x: any) => {
        this.supplier.supplierAccess.supplierRoles?.push({ roleId: x.roleId, roleName: x.roleName })
      })
    }
    else {
      this.supplierRolesCopy.map((x, i) => {
        this.supplier.supplierAccess.supplierRoles?.push({ roleId: x.roleId, roleName: x.roleName })
      })
    }

    if(this.supplier.name !== undefined && this.supplier.vendorType !==undefined && this.supplier.natureOfSupply !==undefined
      && this.supplier.supplierSubsidiary[0].subsidiaryId !== undefined 
      && this.supplier.supplierAddresses[0].country !== undefined && this.supplier.supplierAddresses[0].state !== undefined && this.supplier.supplierAddresses[0].city !== undefined && this.supplier.supplierAddresses[0].address1 !== undefined)
      {
        let  registrationnumber=true;
    
        this.supplier.supplierAddresses.map((address:SupplierAddress,index:any)=>{
          if(this.supplier.supplierAddresses.length ==1 && !address.country && !address.state && !address.city && !address.address1 ){
            //registrationnumber=false;
            return true;
          }
          /*if( address.defaultBilling == false &&  address.defaultShipping == false)
          {
            this.showAlert(' Please select One Default Billing & One Default Shipping ')
            registrationnumber=false;
            return false;
            
          }*/
          if(address.registrationType == undefined)
          {
            this.showAlert(' Please select Registration Type')
            registrationnumber=false;
            return false;
          }
          if(address.registrationType==='Registered' && (address.taxRegistrationNumber===null || address.taxRegistrationNumber==="" || typeof address.taxRegistrationNumber ==='undefined')  ){
            registrationnumber=false;
            this.showAlert('Please enter Tax Registration Number')
           return false;
          }
          else if(address.registrationType==='Unregistered'){
            registrationnumber=true;
          }
        });
       if(this.supplier.supplierAccess.access==true)
        {
          if(this.supplier.supplierAccess.supplierRoles.length == 0)
            {
              this.showAlert('Please select Role');
              return;
            }
               // if(this.editMode==false && this.supplier.supplierAccess.password==undefined || this.editMode==false && this.supplier.supplierAccess.password=="")
               // {
              //    this.showError_Password();
                 /// return;
               // }
                // if(this.editMode==false && this.supplier.supplierAccess.confirmpassword==undefined || this.editMode==false && this.supplier.supplierAccess.confirmpassword=="")
                // {
                //   this.showError_cnfPassword();
                //   return;
                // }
               // if(this.supplier.supplierAccess.password && (this.supplier.supplierAccess.confirmpassword==undefined ||  this.supplier.supplierAccess.confirmpassword==""))
               // {
            //      this.showError_cnfPassword();
               //   return;
               // }
              //  if(this.editMode==false && this.supplier.supplierAccess.confirmpassword!=this.supplier.supplierAccess.password)
               // {
               //   this.showErrorPassword();
               //   return;
               // }
                //this.supplier.supplierAccess.password = this.editMode==true?null: this.supplier.supplierAccess.password;
        }
        else
        {
          this.supplier.supplierAccess.access=false;
          this.supplier.supplierAccess.accessMail="";
          this.supplier.supplierAccess.password=null;
          this.supplier.supplierAccess.deleted=false;
          this.supplier.supplierAccess.supplierRoles=[];
        }
        let active = this.supplier.supplierSubsidiary.find((x) => x.preferredCurrency);
        if (typeof active ==='undefined') {
          registrationnumber=false;
          this.toastService.addSingle(
            'error',
            'Error',
            'Atleast one Preferred Currency'
          );
          return true;
        }
        // for (let i = 0; i < this.supplier.supplierSubsidiary.length; i++) {
        //   if (this.supplier.supplierSubsidiary[i].currency) {
        //      this.supplier.supplierSubsidiary[i].supplierCurrency="";
        //     this.showAlert("Same Supplier Currency can't be added");
        //     return
        //   }
        // }
        if(registrationnumber){
          if(this.addMode){
            this.supplier.createdBy=this.RetloginDetails.username;this.supplier.lastModifiedBy=this.RetloginDetails.username
            }
           else if(!this.addMode){
            this.supplier.lastModifiedBy=this.RetloginDetails.username
            }

            for(let i=0;i<this.supplier.supplierContacts.length;i++)
            {
              if(this.supplier.supplierContacts[i].primaryContact)
              {
                if(this.supplier.supplierContacts[i].name==undefined || this.supplier.supplierContacts[i].name=="")
                {
                  this.showAlert("Please input Contact Name");
                  return;
                }
                if(this.supplier.supplierContacts[i].contactNumber==undefined || this.supplier.supplierContacts[i].contactNumber=="")
                {
                  this.showAlert("Please input Contact Number");
                  return;
                }
              }
                   
            }
          this.showloader=true;
    this.httpService.Insert('/masters-ws/supplier/save', this.supplier,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
       else  if (res && res.id > 0) {
         // alert(res.id);
                
          //Array.from(this.fileList).forEach(file => { 


          // });

          const httpOptions = {
            headers: new HttpHeaders({
              "mimeType": "multipart/form-data",
              "Content-Type": "false"
            })
          };
          const formData = new FormData();

          var file=this.fileList;
    

          for(let i=0;i<file.length;i++)
          {
            
         
          formData.append('file',file[i]);
          formData.append('supplierId', res.id);
          formData.append('remarks', this.file_attachment[i].remarks=="undefined"?"":this.file_attachment[i].remarks);
                  
          this.httpService.uploadFile("/masters-ws/supplier/save/file", formData, this.RetloginDetails.token)
            .subscribe(res => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else {
               
                if (res.error) {
                  this.toastService.addSingle(
                    'error',
                    'Error',
                    res.error.errorMessage
                  );
                }
                else {
                  
                  this.toastService.addSingle(
                    'success',
                    'Success',
                    'File uploaded Successfully!'
                  );
                  //window.location.reload();
                }
              }
            },
              error => {
                this.showAlert(error);
              },
              () => { });

            }



          this.showloader=false;
          this.showSuccess();
          if(this.addMode){
            this.router.navigate(['/main/supplier/action', 'view',res.id,0]);
          } else {
            this.router.navigate(['/main/supplier/list']);
          }
        } else {
          this.showloader=false;
          this.showError();
        }
      },
      (error) => {
        this.showloader=false;
        this.showAlert(error);
      },
      () => {}
    );
  }
}
else{
  if (this.supplier.name == undefined)
  {
   
    this.showAlert('Please enter Supplier Name !');
  }
  else if (this.supplier.vendorType == undefined)
  {
    this.showAlert('Please select Supplier Type !');
  }
  else if (this.supplier.natureOfSupply == undefined)
  {
    this.showAlert('Please select Nature of Supply!');
  }
   else if (this.supplier.supplierSubsidiary[0].subsidiaryId == undefined)
  {
    this.showAlert('Please select Subsidiary !');
  }
  else if(this.supplier.supplierAddresses[0].country == undefined || this.supplier.supplierAddresses[0].address1 == undefined)
  {
    this.showAlert('Please enter Address !');
  }
  else if (this.supplier.supplierAddresses[0].country== undefined)
  {
    this.showAlert('Please select Country !');
  }
  else if (this.supplier.supplierAddresses[0].state== undefined)
  {
    this.showAlert('Please select State !');
  }
  else if (this.supplier.supplierAddresses[0].city== undefined)
  {
    this.showAlert('Please select City !');
  }
  else if(this.supplier.supplierAddresses[0].address1== undefined)
  {
    this.showAlert('Please enter Address !');
  }
  // else if(this.supplier.supplierContacts[0].name == undefined)
  // {
  //   this.showAlert('Please enter Contact Name !');
  // }
  this.supplier.supplierAddresses.map((address:SupplierAddress,index:any)=>{
    if(address.registrationType==='Registered' && (address.taxRegistrationNumber===null || address.taxRegistrationNumber==="" || typeof address.taxRegistrationNumber ==='undefined')  ){
      this.showAlert('Please enter Registration number')
     return false;
    }
  });
}
  }

  GetAllCurrencyList(){
    this.httpService.GetAll("/setup-ws/currency/get/all",this.RetloginDetails.token)
    .subscribe(res => {

      //For Auth
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        { this.Currencylist=res;}
      });
   }
   reloadCurrencylist()
   {
    this.supplier.supplierAccounting.currency="";
    this.GetAllCurrencyList();
   }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Supplier Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving Supplier!'
    );
  }
  showCSTMAlert(AlertMSG:string,AlertType:string,Alert:string) {
    this.toastService.addSingle(
      AlertType,
      Alert,
      AlertMSG
    );
  }
  clearSupplierData() {
    this.router.navigate(['/main/supplier/list']);
  }

  showError_Password() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter Password!'
    );
  }
  showError_cnfPassword() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter Confirm Password!'
    );
  }
  showErrorAccess() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please Provide Access!'
    );
  }
  showErrorPassword() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Password and Confirm Password not matched!'
    );
  }
  showError_Accessmail() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Please enter Access Mail!'
    );
  }
  


  checked2: boolean = true;
  // inactive:boolean = true;
  /* Start Reload subsidery */
reloadSubidery(){
  //$('.refsubsidery').addClass('fa-spin');
  this.isReloadSub=true;

  this.supplier.supplierSubsidiary[0].subsidiaryId=0;
  this.supplier.supplierSubsidiary[0].currency=""
  this.GetSubsideryList();

}
/* End Reload subsidery */

/* End Reload subsidery */
deleteSupplierContactrowlevel(index: number) {

 // if (index >= 0) this.supplier.supplierContacts.splice(index, 1);
 if(this.editMode){
  this.supplier.supplierContacts[index].deleted=true;
  }else{
if (index >= 0) this.supplier.supplierContacts.splice(index, 1);
}

}
 /* Start Fetch Currency list from api */
 GetCurrencyList(): any {
  this.httpService.GetAll("/setup-ws/currency/get/all",this.RetloginDetails.token)
    .subscribe(res => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else {this.Suppliercurrency = res;}
    },
      error => {
      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      });
}
/* End Fetch Currency list from api */

//--Toogle Radio Button
ActiveSubsidiaryOnlyOne(event:any,Index:any)
{
  event.originalEvent.cancelBubble = true;
  this.supplier.supplierSubsidiary.map(function (val:any,i:any){
    if(event.checked && Index!=i){
      val.preferredCurrency=false;
    }
  });
}


MatchPassword(event:any){
  if(this.supplier.supplierAccess.password===event.target.value){
    this.ispasswordmatch=false
  }
  else{
    if(!this.supplier.supplierAccess.password)
    this.ispasswordmatch=false
    else if(!event.target.value)
    this.ispasswordmatch=false
    else
    this.ispasswordmatch=true

  }
}
//--Delete Supplier Address
deleteSupplierAddressrowlevel(index: number) {
  if(this.editMode){
    this.supplier.supplierAddresses[index].deleted=true;
    }else{
  if (index >= 0) {
    this.supplier.supplierAddresses.splice(index, 1);
  }
}
}
//--Delete Supplier Subsidiary
deleteSupplierSubsidiaryrowlevel(index: number) {
  if(this.editMode && this.supplier.supplierSubsidiary[index].id){
    this.supplier.supplierSubsidiary[index].preferredCurrency=false;
    this.supplier.supplierSubsidiary[index].deleted=true;

   // this.supplier.supplierSubsidiary.splice(index, 1);
    }else{
  if (index >= 0) {
    this.supplier.supplierSubsidiary.splice(index, 1);
  }
}
}
editSupplierAddressDialogrowlevel(index:any) {
  this.selectedIndex=index;
  this.selectedSupplierAddress=this.supplier.supplierAddresses[index];
  if (this.supplier.supplierAddresses[index].country ) {
    this.addressComponent.GetStateListByString(this.selectedSupplierAddress.country as string);
  }
  if (this.supplier.supplierAddresses[index].state) {
    this.addressComponent.GetCityListByString(this.selectedSupplierAddress.state as string);
  }
  this.displayAddressDialog = true;
}
handleToggleprimerycontact(event: any,index:any) {
  event.originalEvent.cancelBubble = true;
  this.supplier.supplierContacts.map(function (val:any,i:any){
    if(event.checked && index!=i){
      val.primaryContact=false;
    }
  })
}
handleToggleRegtype(event: any,index:any) {
  if(event.target.value=="Unregistered"){
    this.supplier.supplierAddresses[index].taxRegistrationNumber="";
  }
}
handleToggleDBilling(event: any,index:any) {
  event.originalEvent.cancelBubble = true;
  this.supplier.supplierAddresses.map(function (val:any,i:any){
    if(event.checked && index!=i){
      val.defaultBilling=false;
    }
  })
}
handleToggleDShipping(event: any,index:any) {
  event.originalEvent.cancelBubble = true;
  this.supplier.supplierAddresses.map(function (val:any,i:any){
    if(event.checked && index!=i){
      val.defaultShipping=false;
    }
  })
}



reloadLiability()
{
  this.LiabilityAccountlist=[];
  let subid:any=this.supplier.supplierSubsidiary[0].subsidiaryId;
  this.GetAccountType('Liability',subid);
}
reloadPrepayment()
{
  
  this.PreAccountlist =[];
  let subid:any=this.supplier.supplierSubsidiary[0].subsidiaryId;
  this.GetAccountType('Assets',subid);
}

checkmail()
{
  if(this.supplier.supplierAccess.access==true)
  {
      this.accessMode=true;
      this.accessHidden1=false;
      this.accessHidden=true;
  }
  else{
    this.accessMode=false;
    this.accessHidden=false;
    this.accessHidden1=true;
    this.getAllRoleReloadList();
    this.supplier.supplierAccess.accessMail=undefined;

  }
}

//--Get Supplier ID
GetVendorNo(subsideryId:any){
  this.httpService.GetAllResponseText(`/setup-ws/preference/get-preference-number?subsidiaryId=${subsideryId}&masterName=Supplier Master`,this.RetloginDetails.token)
 // this.HttpService.GetAll("/preference/get-preference-number?subsidiaryId=" +SubsidiaryEvent +"&masterName=" + "Employee Master")
  .subscribe(res => {
    if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else 
 {   var Data=res;
    if(Data.includes("messageCode"))
    {
      this.showAlert("Preference configuration is not found against subsidiary & Master");
      this.supplier.vendorNumber="";
      return false;
    }
else{
  this.supplier.vendorNumber=res;
}}
    },
    (error) => {
      this.showAlert(error);
    });
 }
 @ViewChild('attachments') attachment: any;

  fileList: File[] = [];
  listOfFiles: any[] = [];
  isLoading = false;

  onFileChanged(event: any,index: number) {
    this.isLoading = true;
    for (var i = 0; i <= event.target.files.length - 1; i++) {
      var selectedFile = event.target.files[i];
      if (this.listOfFiles.indexOf(selectedFile.name) === -1) {
        this.fileList.push(selectedFile);
        this.listOfFiles.push(selectedFile.name);
        this.file_attachment[index].filename=selectedFile.name;
      }
    }

    this.isLoading = false;

    //this.attachment.nativeElement.value = '';
  }

  removeSelectedFile(index: number) {
    // Delete the item from fileNames list
    this.listOfFiles.splice(index, 1);
    // delete file from FileList
    this.fileList.splice(index, 1);
  }
  fnCheckSCurrency(EventItemId: any,RowIndex:any)
  {
    
    let chksupp:boolean;
    if(this.editMode)
    {
      this.httpService.GetAll(`/procure-ws/po/is-supplier-currency-updatable?supplierId=`+this.supplierId,this.RetloginDetails.token)
      // this.HttpService.GetAll("/preference/get-preference-number?subsidiaryId=" +SubsidiaryEvent +"&masterName=" + "Employee Master")
       .subscribe(res => {
         if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
               this.router.navigate(['/login']);
             }
             else 
            {
              if(res==true)
              {
                    this.showAlert("Supplier currency in used");
                    this.httpService
                    .GetById('/masters-ws/supplier/get?id=' + this.supplierId, this.supplierId,this.RetloginDetails.token)
                    .subscribe((res) => {
                      if(res.status == 401)
                      { this.showAlert("Unauthorized Access !");
                        this.router.navigate(['/login']);
                      }
                      else if(res.status == 404)
                      { this.showAlert("Wrong/Invalid Token!");
                         this.router.navigate(['/login']);
                       }
                       else{
                        this.supplier.supplierSubsidiary[RowIndex].supplierCurrency =res.supplierSubsidiary[RowIndex].supplierCurrency;
                        return;
                    }
                    });
                    

               }
            }
         },
         (error) => {
           this.showAlert(error);
         });
    }

    for (let i = 0; i < this.supplier.supplierSubsidiary.length; i++) {
        if (this.supplier.supplierSubsidiary[i].supplierCurrency == EventItemId.value && i !== RowIndex) {
           this.supplier.supplierSubsidiary[RowIndex].supplierCurrency="";
          this.showAlert("Same Supplier Currency can't be added");
          return
        }
      }
  }

  selfApproval() {
    this.showloader=true;
    this.httpService
      .GetById('/masters-ws/supplier/self-approve?supplierId=' + this.supplier.id, this.supplier.id,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
       else if (res == true) {
        this.toastService.addSingle(
          'success',
          'Success',
          'Supplier Approved Successfully!'
        );
        
        this.showloader=false;
        window.location.reload();
       } else {
        this.showAlert(res.errorMessage);
        this.showloader=false;
      }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            error
          );
          this.showloader=false;
        }

      );
  }

    //Send Approval
    sendForApproval(SupplierId:number)
    {
      if(SupplierId == 0)
      {
        this.showAlert("No Supplier Id found");
      }
      this.httpService
      .GetById('/masters-ws/supplier/send-for-approval?supplierId=' + SupplierId, SupplierId,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
         { this.showAlert("Unauthorized Access !");
           this.router.navigate(['/login']);
         }
         else if(res.status == 404)
         { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else if (res == true) {
          this.showCSTMAlert("Approval send Successfully","success","Success");
          window.location.reload();
        } else {
          this.showAlert(res.errorMessage);
        }
      },
      (error) => {
        this.showAlert(error);
      },
      () => {}
      );
      
    }

  getAllRoleReloadList()
  {
    
    this.GetAllRoleList(this.supplier.supplierSubsidiary[0].subsidiaryId);
    this.roleOptions=[];
    this.supplierRolesCopy=[];
  }

  deleteattachment(index:number){
      if(this.editMode){
      this.file_attachment[index].deleted=true;
      
      }else{
    if (index >= 0) this.file_attachment.splice(index, 1);
    }

  }

  addattachment()
  {
 
    if (this.file_attachment.length > 0 && this.file_attachment[length - 1] == new attachment() ) 
  
    {
      
      return;
    }
  
    this.file_attachment.push(new attachment());
  }



  downloadattachment(rowIndex:any,filename:string)
  {
    const value = parseInt(rowIndex)+1;
    //row:number=parseInt(rowIndex+1);

    this.httpService.downloadFile('/masters-ws/supplier/get/attachment?supplierId=' + this.supplierId +'&slNo='+value, this.RetloginDetails.token)
    .subscribe(res => {
      saveAs(res, filename);
      //this.executeSaveAs(res);
      //let blob = new Blob([res], {'type': "application/octet-stream"});
      //window.open(res)
    });




  }

  approveSupplierIndividual(mainId:any)
  {
    try {
      var approveList: any = [];
      approveList.push(mainId);

      if (approveList.length > 0) {
        this.showloader = true;

        if(this.RetloginDetails.userType=='SUPERADMIN'){
          this.url='/masters-ws/supplier/approve-all-supplier?currentApproverId=' + this.empID;
  
         }
         else if(this.RetloginDetails.userType=='ENDUSER')
         {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                this.url='/masters-ws/supplier/approve-all-supplier?currentApproverId=' + this.empID;
              }
              else
              {
                this.url='/masters-ws/supplier/approve-all-supplier'
              }
        
         }

        this.httpService.Insert(this.url, approveList, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );

            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Approve selected supplier!'
              );
              this.router.navigate([this.listURL]);
            }
            // this.loading = false;
          },
          (error:any) => {
            this.showAlert(error);
            this.showloader = false;
          }
        );
      }
    } catch (err) {
    }
  }




  hidepopup()
{
  this.display=false;
}
Opendialog()
{
  this.display=true;
}

funreject()
{
 
  try { 
    if(this.sup.comments=="" || this.sup.comments==undefined)
    {
         this.showAlert("Please enter Comments !");
         return;

    }
    else
    {
      var rejectList:any=[];
      var isrejectComments:boolean=false   
      rejectList.push({id:this.supplierId,rejectComments:this.sup.comments})
     
        this.showloader = true;
      this.httpService.Insert('/masters-ws/supplier/reject-all-supplier',rejectList,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
  
          if (res.messageCode) {
           this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
            this.showloader = false;
            this.display=false;
          } else {
            this.toastService.addSingle(
              'success',
              'Success',
              'Reject selected Supplier!'
            );
            this.display=false;
            this.showloader = false;
            this.router.navigate(['/main/supplier/supplier-approval']);
          }
          
         // this.loading = false;
        }
        },
        (error) => {
          this.display=false;
          this.showAlert(error);
          this.showloader = false;
         // this.loading = false;
        }
      );
    }
   
    
    
 
  } catch (err:any) {
    this.showAlert(err);
    this.showloader = false;
  }
}

OpenAppSequence()
{
  this.isAppSequenceVisivble=true;
}

onRowSelect(event: any) {
  let supplierId = event.data.id;
  
  this.router.navigate(['/main/supplier/action/view',supplierId]);
}

}
