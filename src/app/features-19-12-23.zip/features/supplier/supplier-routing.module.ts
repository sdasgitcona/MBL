import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SupplierAddEditComponent } from './supplier-add-edit/supplier-add-edit.component';
import { SupplierApprovalComponent } from './supplier-approval/supplier-approval.component';
import { SupplierListComponent } from './supplier-list/supplier-list.component';
import { SupplierComponent } from './supplier.component';

const routes: Routes = [
  {
    path: '',
    component: SupplierComponent,
  },
  {
    path: 'list',
    component: SupplierListComponent,
  },
  {
    path: 'list/:status',
    component: SupplierListComponent,
  },
  {
    path: 'list/:status/:id',
    component: SupplierListComponent,
  },
  {
    path: 'action/:action/:id/:chkid',
    component: SupplierAddEditComponent,
  },
  {
    path: 'action/:action',
    component: SupplierAddEditComponent,
  },
  {
    path: 'supplier-approval',
    component: SupplierApprovalComponent,
  },
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SupplierRoutingModule {}
