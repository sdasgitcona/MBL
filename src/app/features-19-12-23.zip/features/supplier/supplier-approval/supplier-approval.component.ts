import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { Table } from 'primeng/table';
import { supplierApprovalModel } from '../model/supplier-model';
import { ToastService } from 'src/app/core/services/toast.service';

@Component({
  selector: 'app-supplier-approval',
  templateUrl: './supplier-approval.component.html',
  styleUrls: ['./supplier-approval.component.scss']
})
export class SupplierApprovalComponent implements OnInit {

  columns: any[];
  departments: any[] = [];
  url:any;
  supplierApprovalList: supplierApprovalModel[] = [];
  selectedSupplierApproval: supplierApprovalModel = new supplierApprovalModel();
  totalRecords: number = 0;
  loading: boolean = false;
  AllSelected: boolean = false;
  isRejectPressed: boolean = true;
  approvalRoutingActive: boolean = false;
  approverRoleList: [{ id?: number; name?: string; }];
  SubsidiaryId: any;
  roleId: any;
  empID: number;
  userRoleId: number;
  showloader: boolean = false;
  RetloginDetails: any;
  RetRoleDetails:any;
  IsLoggerAdmin:any;
  @ViewChild('dt') dt: Table;
  visibleSaveButton:boolean;

  constructor(
    private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService

  ) {

  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const logDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(logDetails);
    this.empID = this.RetloginDetails.employeeId;
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    this.IsLoggerAdmin=role_Dtls[0].selectedAccess;
    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Supplier Approval") {
        this.userRoleId = role_Dtls[0].rolePermissions[i].roleId
      }
    }
    // End For Role Base Access
    this.loadSuppliersApproval()
  }

  loadSuppliersApproval() {
    try {
      let ReqData;
      let ReqParam;
      let ReqDataa;
      let ReqParama;
      let reqUrl:any='';
      //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null) //--User:Super Admin
      if(this.RetloginDetails.userType=='SUPERADMIN')
      {
        ReqData=this.RetRoleDetails[0].accountId;
        ReqParam='accountId';
        reqUrl='/masters-ws/supplier/get-supplier-appoval?'+ReqParam+'=' + ReqData;
      }
      //else if((this.RetRoleDetails[0].selectedAccess == 'ADMIN'|| this.RetRoleDetails[0].selectedAccess == 'ADMIN_APPROVER') && this.RetRoleDetails[0].subsidiaryId != null) //--User:Admin
      else if(this.RetloginDetails.userType=='ENDUSER')
      {
        if( this.RetRoleDetails[0].selectedAccess == 'APPROVER')
        {
          ReqData=this.empID;
          ReqParam='userId';
          ReqDataa=this.RetRoleDetails[0].subsidiaryId;
          ReqParama = 'subsidiaryId';
          reqUrl='/masters-ws/supplier/get-supplier-appoval?'+ReqParam+'=' + ReqData+'&' +ReqParama+'=' + ReqDataa;
        }
        else
        {
          ReqData=this.RetRoleDetails[0].subsidiaryId;
          ReqParam='subsidiaryId';
          reqUrl='/masters-ws/supplier/get-supplier-appoval?'+ReqParam+'=' + ReqData;
        }
      }
      else //--User:Others
      {
        ReqData=this.empID;
        ReqParam='userId'
        reqUrl='/masters-ws/supplier/get-supplier-appoval?'+ReqParam+'=' + ReqData;
      }
         this.HttpService.GetAll(reqUrl, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else if (res && res.length > 0) {
            this.NextApproverLov(res[0].subsidiaryId);
            this.supplierApprovalList = res;
            // this.approverRoleList.push({
            //   id:
            // })
            for (let k = 0; k < this.supplierApprovalList.length; k++) {
              this.supplierApprovalList[k].nextApproverRole = this.RetRoleDetails[0].name;
              this.supplierApprovalList[k].nextApprover=Number(this.supplierApprovalList[k].nextApprover);
            }
            this.totalRecords = res.length;
            this.SubsidiaryId = this.supplierApprovalList[0]?.subsidiaryId;
            this.supplierApprovalList.map((data:supplierApprovalModel)=>{
             // data.isAdminRole=(this.IsLoggerAdmin=="ADMIN" || this.IsLoggerAdmin=="ADMIN_APPROVER")?false:true;
              data.isAdminRole=(this.IsLoggerAdmin=="ADMIN" || this.IsLoggerAdmin=="ADMIN_APPROVER")?true:false;

            data.isAdminForSave=true;
            data.nextApprover=Number(data.nextApprover)
            })

          
            //this.supplierApprovalList[0].isAdminRole=this.IsLoggerAdmin=="ADMIN"?false:true;
            
          } else {
            this.supplierApprovalList = [];
            this.totalRecords = res.length;

          }
          this.loading = false;
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {
    }
  }
  NextApproverLov(SubsidiaryId:any) {
    try {

      if(this.RetloginDetails.userType=='SUPERADMIN')
      {
         this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + SubsidiaryId + '&formName=Supplier Approval';
      }else if(this.RetloginDetails.userType=='ENDUSER'){

          if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
          {
            this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + SubsidiaryId + '&formName=Supplier Approval';
          }
          else{
            this.url='/masters-ws/employee/get-by-role-subsidiary?roleId=' + this.userRoleId + '&subsidiaryId=' + SubsidiaryId + '&formName=Supplier Approval';
          }


       
      }
      this.HttpService.GetAll(this.url, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else if (res && res.length > 0) {
            this.approverRoleList = res;
            //this.totalRecords = res.length;
          } else {
            this.approverRoleList = [{}];
            //this.totalRecords = res.length;

          }
          this.loading = false;
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {
    }
  }
  navigateToAdd() {
    this.router.navigate(['/main/supplier/update']);
  }
  // navigateToAddViewEdit(
  //   action: string,
  //   selectedSupplier: Supplier = new Supplier()
  // ) {
  //   let supplierId = null;
  //   if (selectedSupplier?.id) {
  //     supplierId = selectedSupplier.id;
  //     this.router.navigate(['/main/supplier/action', action, supplierId]);
  //   } else {
  //     this.router.navigate(['/main/supplier/action', action]);
  //   }
  // }
  globalSearch(event: any) {
    this.dt.filterGlobal(event.target.value, 'contains')
  }
  approveSupplier() {
    try {
      this.isRejectPressed = false
      var approveList: any = [];
      this.supplierApprovalList.map((data: supplierApprovalModel) => {
        if (data.selected) {
          approveList.push(data.id)
        }
      })

      let supplierApproval_URL=this.IsLoggerAdmin ?'/masters-ws/supplier/approve-all-supplier?currentApproverId='+this.empID: '/masters-ws/supplier/approve-all-supplier'
      if (approveList.length > 0) {
        this.showloader = true;
        this.HttpService.Insert(supplierApproval_URL, approveList, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );

            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Approve selected supplier!'
              );
              this.loadSuppliersApproval();
            }
            // this.loading = false;
          },
          (error) => {
          }
        );
      }
    } catch (err) {
    }
  }
  rejectSupplier() {
    try {
      if (this.isRejectPressed) {
        var rejectList: any = [];
        var isrejectComments: boolean = false
        this.supplierApprovalList.map((data: supplierApprovalModel) => {
          if (data.selected) {
            if (data.NewrejectComments) {
              rejectList.push({ id: data.id, rejectComments: data.NewrejectComments })
              isrejectComments = true;
              this.isRejectPressed = true

            } else {
              this.toastService.addSingle(
                'error',
                'Error',
                'Please enter Reject Comments'
              );
              isrejectComments = false;
              this.isRejectPressed = true
              return;
            }
          }
        })
        if (isrejectComments) {
          this.showloader = true;
          this.HttpService.Insert('/masters-ws/supplier/reject-all-supplier', rejectList, this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else if (res.messageCode) {
                this.showloader = false;
                this.isRejectPressed = true
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );

              }
              else {
                this.showloader = false;
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Reject selected supplier!'
                );
                this.loadSuppliersApproval();
              }
              this.isRejectPressed = true
            },
            (error) => {
            }
          );
        }
      } else {
        this.toastService.addSingle(
          'error',
          'Error',
          'Please enter Reject Comments'
        );
        this.isRejectPressed = true;
        this.showloader = false;
      }
    } catch (err) {
    }
  }

  approveSupplierIndividual(mainId:any)
  {
    try {
      this.isRejectPressed = false
      var approveList: any = [];
      approveList.push(mainId);
      // this.supplierApprovalList.map((data: supplierApprovalModel) => {
      //   if (data.selected) {
      //     approveList.push(mainId)
      //   }
      // })
      let supplierApproval_URL=this.IsLoggerAdmin ?'/masters-ws/supplier/approve-all-supplier?currentApproverId='+this.empID: '/masters-ws/supplier/approve-all-supplier'
      if (approveList.length > 0) {
        this.showloader = true;
        this.HttpService.Insert(supplierApproval_URL, approveList, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );

            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Approve selected supplier!'
              );
              this.loadSuppliersApproval();
            }
            // this.loading = false;
          },
          (error) => {
          }
        );
      }
    } catch (err) {
    }
  }
  rejectSupplierIndividual(mainId:any,rejectComments:any,RowNo:any)
  {
    try {
      this.supplierApprovalList[RowNo].selected=true;
      this.isRejectPressed=true;

      if(rejectComments==undefined)
      {
        this.showAlert("Please enter Reject Comments");
        return true;
      }

      if (this.isRejectPressed) {
        var rejectList: any = [];
        var isrejectComments: boolean = false;

              rejectList.push({ id: mainId, rejectComments: rejectComments })
              isrejectComments = true;
              this.isRejectPressed = true
              
        // this.supplierApprovalList.map((data: supplierApprovalModel) => {
        //   if (data.selected) {
        //     if (data.NewrejectComments) {
        //       rejectList.push({ id: data.id, rejectComments: data.NewrejectComments })
        //       isrejectComments = true;
        //       this.isRejectPressed = true

        //     } else {
        //       this.toastService.addSingle(
        //         'error',
        //         'Error',
        //         'Please enter Reject Comments'
        //       );
        //       isrejectComments = false;
        //       this.isRejectPressed = true
        //       return;
        //     }
        //   }
        // })
        if (isrejectComments) {
          this.showloader = true;
          this.HttpService.Insert('/masters-ws/supplier/reject-all-supplier', rejectList, this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else if (res.messageCode) {
                this.showloader = false;
                this.isRejectPressed = true
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );

              }
              else {
                this.showloader = false;
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Reject selected supplier!'
                );
                this.loadSuppliersApproval();
              }
              this.isRejectPressed = true
              // this.loading = false;
            },
            (error) => {
            }
          );
        }
      } else {
        this.showAlert("Please enter Reject Comments");
        this.isRejectPressed = true;
        this.showloader = false;
      }
    } catch (err) {
    }
  }

  onAllSelectChange(event: any) {
    if (event.checked) {
      this.supplierApprovalList.map((data: supplierApprovalModel) => {
        data.selected = true;
        this.isRejectPressed = true
        //this.approvalRoutingActive=true;
      })
    }
    else {
      this.supplierApprovalList.map((data: supplierApprovalModel) => {
        data.selected = false;
        this.isRejectPressed = true;
        // this.approvalRoutingActive=false;

      })
    }
  }
  onSelectChange(event: any, routingStatus: any) {
    if (!event.checked && this.AllSelected) {
      this.AllSelected = false;
      //this.approvalRoutingActive=routingStatus;
    }
    this.isRejectPressed = true

  }
  viewSupplier(id: any) {
    const url = this.router.serializeUrl(
      this.router.createUrlTree(["/main/supplier/action/view/" + id])
    );
    this.isRejectPressed = false
    window.open(url)
  }

  OnChangeNextApprover(supplierId: any, approverId: any) {
    try {
      this.HttpService.GetAll(`/masters-ws/supplier/update-next-approver?supplierId=${supplierId}&approverId=${approverId}`, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          } else if (res && res > 0) {
          } else {
          }
        },
        (error) => {
        }
      );
    } catch (err) {
    }
  }

  OnChangeVisibleButton(row:any,)
  {
   if(this.IsLoggerAdmin=="ADMIN")
   {
      if(this.supplierApprovalList[row].selected)
      {
        this.supplierApprovalList[row].isAdminForSave=false;
        this.visibleSaveButton=true;
      }
   }
  }
  onApproverSave() {
    try {
      let selectedSupplier;
      let selectedapprover;
      for(let x=0;x<this.supplierApprovalList.length;x++)
      {
        if(this.supplierApprovalList[x].selected)
      {
        selectedSupplier=this.supplierApprovalList[x].id;
        selectedapprover=this.supplierApprovalList[x].nextApprover
        break;
      }
      }
      this.HttpService.GetAll(`/masters-ws/supplier/update-next-approver?supplierId=${selectedSupplier}&approverId=${selectedapprover}`, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          } else if (res == true) {
            this.showloader = false;
            this.toastService.addSingle(
              'success',
              'Success',
              'saved selected supplier!'
            );
            window.location.reload();
            //this.loadSuppliersApproval();
          } 
        },
        (error) => {
        }
      );
    } catch (err) {
    }
  }
  cancel()
  {
    window.location.reload();
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
}
