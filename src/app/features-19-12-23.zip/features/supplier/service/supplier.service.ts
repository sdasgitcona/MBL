import { Injectable } from '@angular/core';
import { Supplier } from '../model/supplier-model';

@Injectable({
  providedIn: 'root',
})
export class SupplierService {
  private shareSupplierData: Supplier = new Supplier();
  constructor() {}
  setSupplier(data: Supplier) {
    this.shareSupplierData = data;
  }

  getSupplier(): Supplier {
    return this.shareSupplierData;
  }
}
