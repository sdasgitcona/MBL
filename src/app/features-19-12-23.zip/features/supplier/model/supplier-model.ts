export class SupplierContact {
  supplierId?: number;
  id?: number;
  name?: string;
  contactNumber?: string;
  altContactNumber?: string;
  email?: string;
  web?: string;
  fax?: string;
  createdDate?: Date;
  createdBy?: string;
  lastModifiedDate?: Date;
  lastModifiedBy?: string;
  primaryContact?: boolean;
  deleted?: boolean;
}

export class SupplierSubsidiary {
  id?: number;
  supplierId?: number;
  subsidiaryId?: number;
  currency?: string;
  createdDate?: any;
  createdBy?: any;
  lastModifiedDate?: any;
  lastModifiedBy?: any;
  subsidiaryName?: string;
  deleted?: boolean;
  supplierCurrency?:string;
}

export class SupplierAccounting {
  id?: number;
  supplierId?: number;
  liabilityAccountId?: number;
  prepaymentAccountId?: number;
  createdDate?: Date;
  createdBy?: string;
  lastModifiedDate?: Date;
  lastModifiedBy?: string;
  deleted?: boolean;
  currency?:any;
  asOnDate?:any;
  openingBalance?:any;
}

export class SupplierAddress {
  id?: number;
  supplierId?: number;
  address1?: string;
  address2?: string;
  city?: string;
  state?: string;
  country?: string;
  pin?: string;
  taxRegistrationNumber?: string;
  registrationType?: string;
  defaultBilling?: boolean;
  defaultShipping?: boolean;
  createdDate?: Date;
  createdBy?: string;
  lastModifiedDate?: Date;
  lastModifiedBy?: string;
  deleted?: boolean;
  zipcode?: string;
  addressCode?: string;
  isdisablecountry?:boolean;
}

export class supplierRole {
  id?: number;
  supplierId?: number;
  roleId?: any;
  roleName?: string;
  createdDate?: Date;
  createdBy?: string;
  lastModifiedDate?: Date;
  lastModifiedBy?: string;
  deleted?: boolean;
  name?: string;
}

export class SupplierAccess {
  id?: number;
  supplierId?: number;
  access?: boolean;
  accessMail?:string;
  password?: any;
  confirmpassword?: string;
  supplierRoles: supplierRole [] = [];
  createdDate?: Date;
  createdBy?: string;
  lastModifiedDate?: Date;
  lastModifiedBy?: string;
  deleted?: boolean;
}

export class Supplier {
  id?: number;
  name?: string;
  legalName?: string;
  paymentTerm?: string;
  vendorNumber?: string;
  vendorType?: string;
  pan?: string;
  approvalStatus?: string;
  recent?: any;
  createdDate?: Date;
  createdBy?: string;
  lastModifiedDate?: Date;
  lastModifiedBy?: string;
  supplierContacts: SupplierContact[] = [];
  supplierSubsidiary:SupSubsidiary[] = [];
  //supplierSubsidiary: SupplierSubsidiary = {};
  supplierAccounting: SupplierAccounting = {};
  supplierAddresses: SupplierAddress[] = [];
  supplierAccess: SupplierAccess={
    supplierRoles: []
  };
  active?: boolean = true;
  deleted?: boolean;
  inactive?: boolean;
  subsidiaryName?: string;
  subsidiaryId?: number;
  contactName?: string;
  contactNumber?: string;
  invoiceMail?: string;
  accessMail?: string;
  uin?:string;
  natureOfSupply?:string;
  approvalRoutingActive?:boolean;
  accountId:string;
  integratedId?: any;
  isApprovalButtonShowHide: any;
  approvers:approvers []=[];
  nextApprover:any;

}
export class approvers{
  id?:any;
  name?:any;
}
export class SupSubsidiary{
  subsidiaryId?: number;
  currency?: string;
  supplierCurrency?: string;
  preferredCurrency?: boolean;
  deleted?:boolean;
  id?:any;
}

export class SubsidiaryEntry {
  id?: number;
  name?: string;
  legalName?: string;
  parentCompany?: string;
  country?: string;
  email?: string;
  website?: string;
  language?: string;
  currency?: string;
  fiscalCalender?: string;
  pan?: string;
  cin?: string;
  tan?: string;
  isActive: boolean = true;
  integrated_id?: string;
  integratedId?: any;
  createdBy?: string;
  lastModifiedBy?: string;
  //subsidiaryAddress: Array<SubsidiaryAddress> ;
  //subsidiaryAddress: [SubsidiaryAddress]=[] ;
  subsidiaryAddresses: SubsidiaryAddress[] = [];
  logo?: string;
  logoMetadata?: string;
  inactive: boolean = true;
}
export class SubsidiaryAddress {
  subsidiaryId?: number;
  country?: string;
  attention?: string;
  address?: string;
  phone?: number;
  address1?: string;
  address2?: string;
  city?: string;
  state?: string;
  zipcode?: string;
  registrationType?: string;
  registrationCode?: string;
  inactive?: boolean = false;
}

export class Account {
  id?: string;
  description?: string;
  type?: string;
  code?: string;
}

// Base seach model for Supplier
export class BaseSearch {
  filters: SupplierFilter | {} = {};
  pageNumber: number = 0;
  pageSize: number = 0;
  sortColumn: string = '';
  sortOrder: string = '';
}

  // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: SupplierFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class SupplierFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}

//

/* Model of Approval Process Supplier */
export class supplierApprovalModel {
  id: number;
  externalId?: any;
  name: string;
  legalName?: any;
  paymentTerm?: any;
  vendorNumber: string;
  vendorType: string;
  uin?: any;
  approvalStatus: string;
  rejectComments?: any;
  natureOfSupply?: any;
  uniqueNumber?: any;
  invoiceMail?: any;
  tdsWitholding?: any;
  approvedBy: string;
  nextApprover: any;
  nextApproverRole: string;
  nextApproverLevel?: any;
  approverPreferenceId?: any;
  approverSequenceId?: any;
  approverMaxLevel?: any;
  noteToApprover?: any;
  activeDate?: any;
  createdDate?: any;
  createdBy?: any;
  lastModifiedDate?: any;
  lastModifiedBy?: any;
  supplierContacts?: any;
  supplierSubsidiary?: any;
  supplierAccounting?: any;
  supplierAddresses?: any;
  supplierAccess?: any;
  access: boolean;
  subsidiaryName: string;
  subsidiaryId: number;
  contactName?: any;
  contactNumber?: any;
  currency?: any;
  hasError: boolean;
  active: boolean;
  deleted: boolean;
  approvalRoutingActive: boolean;
  selected:boolean;
  NewrejectComments?: any;
  isAdminRole?:boolean;
  isAdminForSave?:boolean=true;
  comments:any;
}
/* Model of Approval Process Supplier */
export class file_upliad
{
  file:File;
}

export class attachment{
 filename?:string;
 remarks?:any;
 deleted?:boolean;
 file?:File;
 download?:boolean;
}