import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApprovedPageComponent } from './approved-page/approved-page.component';
import { RejectPageComponent } from './reject-page/reject-page.component';

const routes: Routes = [
  {path: 'approved', component: ApprovedPageComponent},
  {path: 'reject', component:RejectPageComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MailApprovalRoutingModule { }
