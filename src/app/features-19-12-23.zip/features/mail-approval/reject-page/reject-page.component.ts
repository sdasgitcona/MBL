import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';

@Component({
  selector: 'app-reject-page',
  templateUrl: './reject-page.component.html',
  styleUrls: ['./reject-page.component.scss']
})
export class RejectPageComponent implements OnInit {

  display: boolean = false;
  Chktooltip:boolean=false;
  showloader:boolean=true;
  approverId: any;
  rejectId: any;
  formName: any;
  rejectComment: any;
  isSuccess: boolean = false;
  ErrorMessage: string;
  hardcodeMsg: string;
  ReqUrl:any;

  constructor(
    private activatedRoute: ActivatedRoute,
    private httpService: CommonHttpService,
    private router: Router,
    private toastService: ToastService
  ) { }

  ngOnInit(): void {
    this.showloader = true;
    this.activatedRoute.queryParams.subscribe((params) => {
      this.approverId = params['approverId'];
      this.rejectId = params['id'];
      this.rejectComment = params['rejectComment']
      this.formName = params['form'];
    });
    
   // this.rejectFn(this.approverId, this.rejectId, this.form, this.rejectComment);

   if(this.formName =='Supplier'){
      this.ReqUrl='/masters-ws/supplier/reject-supplier?id='+ this.rejectId+'&approverId='+this.approverId+'&form='+this.formName+'&rejectComment='+this.rejectComment;
    }
    if(this.formName =='Purchase Requisition'){
      this.ReqUrl='/procure-ws/pr/reject-pr?id='+ this.rejectId+'&approverId='+this.approverId+'&form='+this.formName+'&rejectComment='+this.rejectComment;
    }
    if(this.formName =='Purchase Order'){
      this.ReqUrl='/procure-ws/po/reject-po?id='+ this.rejectId+'&approverId='+this.approverId+'&form='+this.formName+'&rejectComment='+this.rejectComment;
    }
    //
    if(this.formName =='Advance Payment'){
      this.ReqUrl='/finance-ws/advance/reject-advance-payment?id='+ this.rejectId+'&approverId='+this.approverId+'&form='+this.formName+'&rejectComment='+this.rejectComment;
    }
    if(this.formName =='Make Payment'){
      this.ReqUrl='/finance-ws/payment/reject-make-payment?id='+ this.rejectId+'&approverId='+this.approverId+'&form='+this.formName+'&rejectComment='+this.rejectComment;
    }
    if(this.formName =='AP Invoice'){
      this.ReqUrl='/finance-ws/invoice/reject-invoice?id='+ this.rejectId+'&approverId='+this.approverId+'&form='+this.formName+'&rejectComment='+this.rejectComment;
    }
    if(this.formName =='Debit Note'){
      this.ReqUrl='/finance-ws/debitNote/reject-debit-notes?id='+ this.rejectId+'&approverId='+this.approverId+'&form='+this.formName+'&rejectComment='+this.rejectComment;
    }

    this.httpService.GetAll(this.ReqUrl)
      .subscribe(res => {
        if(res == true)
        {
          this.showloader = false;
          this.isSuccess = true;
          this.hardcodeMsg='';
          if(this.formName == 'Supplier')
          {
            this.showSuccessAlert('Reject selected Supplier!');
          } else
          if(this.formName == 'Purchase Requisition')
          {
            this.showSuccessAlert('Reject selected Purchase Requisition!');
          } else
          if(this.formName == 'Purchase Order')
          {
            this.showSuccessAlert('Reject selected Purchase Order!');
          }
          //
          else
          if(this.formName == 'Advance Payment')
          {
            this.showSuccessAlert('Reject selected Advance Payment!');
          } else
          if(this.formName == 'Make Payment')
          {
            this.showSuccessAlert('Reject selected Make Payment!');
          } else
          if(this.formName == 'AP invoice')
          {
            this.showSuccessAlert('Reject selected AP invoice!');
          }
        }
        else if (res.messageCode) {
          
          this.ErrorMessage =res.errorMessage;
          this.hardcodeMsg='Sorry, Error occurred !';
          //alert(this.ErrorMessage);
          this.isSuccess = false;
            this.showloader = false;
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
        }else if(res.error.errorMessage !="")
        {
          this.isSuccess = false;
          this.showloader = false;
          this.ErrorMessage =res.error.errorMessage
          this.hardcodeMsg='Sorry, Error occurred !';
          this.toastService.addSingle(
            'error',
            'Error',
            res.error.errorMessage
          );
        }
      },
      (error) => {
      }
        );
    
  }


  // rejectFn(approverId: any, rejectId: any, form: any, rejectComment:any) {
  //   if (this.formName = 'Supplier'){
  //     this.httpService.GetAll(`/masters-ws/supplier/reject-supplier?id=${rejectId}&approverId=${approverId}&rejectComment=${rejectComment}`)
  //     .subscribe(res => {
  //       if(res == true)
  //       {
  //         this.showloader = false;
  //         this.isSuccess = true;
  //         this.toastService.addSingle(
  //           'success',
  //           'Success',
  //           'Reject selected supplier!'
  //         );
  //       }
  //       else if (res.messageCode) {
  //         this.ErrorMessage =res.errorMessage
  //         alert(this.ErrorMessage);
  //         this.isSuccess = false;
  //           this.showloader = false;
  //           this.toastService.addSingle(
  //             'error',
  //             'Error',
  //             res.errorMessage
  //           );
  //       }else if(res.error.errorMessage !="")
  //       {
  //         this.isSuccess = false;
  //         this.showloader = false;
  //         this.ErrorMessage =res.error.errorMessage
  //         this.toastService.addSingle(
  //           'error',
  //           'Error',
  //           res.error.errorMessage
  //         );
  //       }
  //     },
  //     (error) => {
  //     }
  //       );
  //   }
    
  // }


  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  showSuccessAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'success',
      'Success',
      AlertMSG
    );
  }
  
  hidepopup()
    {
      this.display=false;
    }

  funreject()
    {
      this.display=false;
    }
}
