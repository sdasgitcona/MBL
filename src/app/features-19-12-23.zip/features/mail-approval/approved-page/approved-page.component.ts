import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';

@Component({
  selector: 'app-approved-page',
  templateUrl: './approved-page.component.html',
  styleUrls: ['./approved-page.component.scss']
})
export class ApprovedPageComponent implements OnInit {

  showloader:boolean;
  approverId: any;
  approveId: any;
  // form: any;
  formName:any;
  isSuccess: boolean = false;
  ErrorMessage: string;
  ReqUrl:any;
  hardcodeMsg: string;

  constructor( 
    private activatedRoute: ActivatedRoute,
    private httpService: CommonHttpService,
    private router: Router,
    private toastService: ToastService
    ) { }

  ngOnInit(): void {
    this.showloader = true;
    this.activatedRoute.queryParams.subscribe((params) => {
      this.approverId = params['approverId'];
      this.approveId = params['id'];
      this.formName = params['form'];
    });
    
    this.approveFn(this.approverId, this.approveId, this.formName);

   
  }
  
  

  approveFn(approverId: any, approveId: any, formName: any) {
    let that = this;
    //
    if(this.formName =='Supplier'){
      this.ReqUrl='/masters-ws/supplier/approve-supplier?id='+ approveId+'&approverId='+approverId+'&form='+formName;
    }
    if(this.formName =='Purchase Requisition'){
      this.ReqUrl='/procure-ws/pr/approve-pr?id='+ approveId+'&approverId='+approverId+'&form='+formName;
    }
    if(this.formName =='Purchase Order'){
      this.ReqUrl='/procure-ws/po/approve-po?id='+ approveId+'&approverId='+approverId+'&form='+formName;
    }
    //
    if(this.formName =='Advance Payment'){
      this.ReqUrl='/finance-ws/advance/approve-advance-payment?id='+ approveId+'&approverId='+approverId+'&form='+formName;
    }
    if(this.formName =='Make Payment'){
      this.ReqUrl='/finance-ws/payment/approve-make-payment?id='+ approveId+'&approverId='+approverId+'&form='+formName;
    }
    if(this.formName =='AP Invoice'){
      this.ReqUrl='/finance-ws/invoice/approve-invoice?id='+ approveId+'&approverId='+approverId+'&form='+formName;
    }
    if(this.formName =='Debit Note'){
      this.ReqUrl='/finance-ws/debitNote/approve-debit-notes?id='+ approveId+'&approverId='+approverId+'&form='+formName;
    }
 //

      //this.httpService.GetAll(`/masters-ws/supplier/approve-supplier?id=${approveId}&approverId=${approverId}&form=${formName}`)
      this.httpService.GetAll(this.ReqUrl)
      .subscribe(res => {
        if (res.messageCode) {
          this.ErrorMessage =res.errorMessage;
          this.hardcodeMsg='Sorry, Error occurred !';
          this.isSuccess = false;
            this.showloader = false;
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
        }else {
          this.hardcodeMsg=' ';
          this.showloader = false;
          this.isSuccess = true;

          if(this.formName == 'Supplier')
          {
            this.showSuccessAlert('Approve selected Supplier!');
          } else
          if(this.formName == 'Purchase Requisition')
          {
            this.showSuccessAlert('Approve selected Purchase Requisition!');
          } else
          if(this.formName == 'Purchase Order')
          {
            this.showSuccessAlert('Approve selected Purchase Order!');
          }
          //
          else
          if(this.formName == 'Advance Payment')
          {
            this.showSuccessAlert('Approve selected Advance Payment!');
          }
          else
          if(this.formName == 'Make Payment')
          {
            this.showSuccessAlert('Approve selected Make Payment!');
          }
          else
          if(this.formName == 'AP invoice')
          {
            this.showSuccessAlert('Approve selected AP invoice!');
          }
         
        }
      },
        (error) => {
        }
    );   
  }

  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  showSuccessAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'success',
      'Success',
      AlertMSG
    );
  }

}


