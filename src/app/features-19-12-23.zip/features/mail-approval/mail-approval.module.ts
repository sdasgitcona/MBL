import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardModule } from 'primeng/card';
import { DividerModule } from 'primeng/divider';
import { DialogModule } from 'primeng/dialog';
import { Button, ButtonModule } from 'primeng/button';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

import { MailApprovalRoutingModule } from './mail-approval-routing.module';
import { ApprovedPageComponent } from './approved-page/approved-page.component';
import { RejectPageComponent } from './reject-page/reject-page.component';



@NgModule({
  declarations: [
    ApprovedPageComponent,
    RejectPageComponent
  ],
  imports: [
    CommonModule,
    MailApprovalRoutingModule,
    CardModule,
    DividerModule,
    DialogModule,
    ButtonModule,
    ProgressSpinnerModule
  ]
})
export class MailApprovalModule { }
