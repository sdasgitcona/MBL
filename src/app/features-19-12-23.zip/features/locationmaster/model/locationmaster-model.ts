export class SubsidiaryEntry {
    id?: number;
    name?: string;
    legalName?: string;
    parentCompany?: string;
    country?: string;
    email?: string;
    website?: string;
    language?: string;
    currency?: string;
    fiscalCalender?: string;
    pan?: string;
    cin?: string;
    tan?: string;
    isActive: boolean = true;
    integrated_id?: string;
    createdBy?: string;
    lastModifiedBy?: string;
    logo?: string;
    logoMetadata?: string;
    inactive: boolean = true;
  }

 // Base seach model for Supplier
export class BaseSearch {
  filters: TblFilter | {} = {};
  pageNumber: number = 0;
  pageSize: number = 0;
  sortColumn: string = '';
  sortOrder: string = '';
}

export class TblFilter {
    subsidiary: string = '';
    vendorname: string = '';
    vendornumber: string = '';
    vendortype: string = '';
    pan: string = '';
    active: string = '';
  }
  export class locations{
    id?:number;
    locationName?:string;
    parentLocationId?:number;
    subsidiaryId?:number;
    locationType?:string;
    effectiveFrom?:any  ;
    effectiveTo?:any;
    deleted?:boolean;
    locationAddress: locationAddress = {};
    locationAddresses: locationAddress[] = [];
    subsidiaryName?:string;
    parentLocationName?:string;
    active?:boolean=false;
    parentLocation?:boolean=false;
    createdBy: string;
    lastModifiedBy:string;
    integratedId:any;
    }
    
    export class locationAddress{
        id?:number;
        locationId?:number;
        country?:string="";
        phone?:number;
        address1?:string="";
        address2?:string="";
        city?:string="";
        state?:string="";
        pin?:string="";
        createdDate?:Date;
        createdBy?:string;
        lastModifiedDate?:Date;
        lastModifiedBy?:string;
        deleted?:boolean;
        zipcode?:string;
      
  supplierId?: number;
  taxRegistrationNumber?: string;
  registrationType?: string;
  defaultBilling?: boolean;
  defaultShipping?: boolean;
  
    }
    export class locationFilter{
      subsidiaryId?:number;
      effectiveFrom:any;
      effectiveTo:any;
      name:any;
    }
    
  // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: LocationFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class LocationFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}