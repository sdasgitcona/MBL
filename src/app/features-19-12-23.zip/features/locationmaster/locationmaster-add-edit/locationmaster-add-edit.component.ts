import { Component,OnDestroy,OnInit,ViewChild, } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { concat } from 'rxjs';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { AddressComponent } from 'src/app/shared/shared-components/address/address.component';
import { BaseSearch,locations,locationAddress } from '../model/locationmaster-model';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
//import { DatePipe } from '@angular/common';
declare let $: any;
@Component({
  selector: 'app-locationmaster-add-edit',
  templateUrl: './locationmaster-add-edit.component.html',
  styleUrls: ['./locationmaster-add-edit.component.scss']
})
export class LocationmasterAddEditComponent implements OnInit {

  defaultDate = new Date();
  value: Date;
  location: locations = new locations();
  locationobj=new locations();
  locationaddress=new locationAddress();
  selectedLocationAddress:  locationAddress = new locationAddress();
  Subsidiarylist:any[]=[];
  Parentlocations:any[]=[];
  historyviewmodel:HistoryModel[] = [];
  id:any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  IsVisibleMode: boolean = false;
  VisibleMode: boolean = false;
 LocationTypeOptions: any;
 displayAddressDialog: boolean = false;
 private subscription: any;
 LocationId: number = 0;
 selectedIndex:any;
 showloader:boolean=false;
 urlHome:any;
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  isviewEditable:boolean=true;
  RetRoleDetails:any;
  SubIdList:any=[];
  // For Role Base Access

 @ViewChild(AddressComponent) addressComponent: AddressComponent;
  RetloginDetails: any;

  constructor( private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
    //private datepipe: DatePipe
    ) { 
      this.LocationTypeOptions = [
        { name: 'Stockable', code: 'Stockable' },
        { name: 'Non Stockable', code: 'Non Stockable' },
      ];
    }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;
 const LDetails:any=localStorage.getItem("LoggerDTLS");
this.RetloginDetails = JSON.parse(LDetails);

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Location")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.LocationId = +params['id']; // (+) converts string 'id' to a number
            this.GetLocationbyId();
            this.LoadHistory();
            this.displayAddressDialog = false;
          }
          this.assignMode(params['action']);

          this.GetSubsideryList();
          this.urlHome="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAyVBMVEX////7+/u2MS78/Pz+/v79/f34nyr6+vqzMS7znCq1LSr47++xEQq8SUezHxuwCwC0JSHSkI/kwMDiurnBXlz4mxjz5OTUmJf4nSSyGhW0KCX4mhKvHhr+9+20KSb3mAD4qUf+8ODt0dD4pDPs1NTcpqW5ODXCXFr816/9+vX5tWX7y5rGcG67Qj/frKvoxsXPgoHHamj95Mr5r1b6vnz8377958/80qX4pz/5rFC9R0X26OjLgX/MeHe+VFL56tf5uXD2voX4xo/Js7uSAAAec0lEQVR4nM1dC1viOhMOtBUEZEEsFhAQvIIXvK+7ruL6/3/U12SSNPemBfd8POc5y7rTZCaZybxzSUUBIp+gEsGXSiUkf4aVCvwgqqgkASXxodVIQkayZVoHm3lP1hwCIhttbatMRx5ra52a/dh/V3x2UJtFFzB/MQxTl2Az9GbaYwetu1KEttwOOqbOmcW+9w4VtdtVTdvB/KkLqah5bbd0yJSywXwVLWWDsqL5KHetgCF47HYRActMLdOWU+4SdgU72P99ijY6+ouz+c9skDBy2x4OzlAurcEG/b2Zyua/tMHofdCo1wfXNTftZjuo0X7LLJWaabf7vzvVer1e7dyceiKZzQQU5Cuz96kqFXQTt4MJEbBabbRuUVTKTSALrYNNXwE3VtHgblClAqYfqqmebmIjROmexeRgykG1/kdbELBe76RnqlvAUm5CZzNwP7mJmxBoI9TrTCQB69VG++wboZrE5ve7CRTdtRpUwM55h0k6uG4iqw16KI8vm9/vJkBDYeMG3eZhu0q3kmrqtnbQRvvdUC1AvcmECjhp99IfrYZDqquNzplZwM2hmkD7zVAtrNy1mOm195qYFtUuYE+xpt7XUCnlKcCm8uSWI3rUJ9JgARuDu5CNe9hu0FOHeH+gLRUu5R8VeUuz2SxovzGkAoKGMtpVfQK2WG0cndmm3sxNMNryAubrCQq7gwYImO5VX6RFTXL6kH8i3n/LUE2gRU4V3chNoLdMivadQks0lRpj5zyLqAq5CU9E+V1QDa2qE3ZmEg1VOVpVh9QYG4Nb+swWInqNdsPUltUG0eFRgyE0oqE6bfOgzTBO+70mC7jFxMM3uYnmxRHjfvAemGmj8JDYKYmoUk3dKlTLaL8Hqs2H9KysN45uHbTz6tAQUW3HTXBay9JsZIOHdAOrLIaw0qaayiOq92bu1GXYVJ4sBdWUiL52f0SZ5nGgAxQctjR73Z4NcgG3GtGnGlpn3vw2hxb7qzlBBQSY/zhz+7YCbHJamWnP81eiVZk+y2IHhshy0hvN+zaPqN5ZRLUFNwEkyLj35SP62v0gy1Q0LbTacIctbVW2mHjYavHl9Dzz4vl50cxWVg0eUbVvc5gu6s22CtXOBnrM4FV8od6f6Co+nUpBNQvtFt1E7XpQpQIO7pvISYu0iD49U6kxChHVNhDl9iL605sOFbDROkQFBGQR1YSfwZ3bvKmLsCkvTXmodpsiMBBweD5HkW3cILANx3Eqjqjua1tLPMjilrbB2nuLxkJEQ60cNZs1eTgBi6aaOpAiqq0gSvlvpW3w9HeHstYYHKLIRru63jv/fb2yH+BCRNVhZ/GGiFL6W+niy217QgUcDufW+mDzfjBpNBpDYZO1gJfHJNX60XUkT12KzYqBkcJQjWgoCNi+aFoFXE2G9CQZTlY2pkPQVMh8VE+3gih9lsapov29DhWwMega3A+lPRxUeVK/ignN8WC6EudDpvHtM34ylUeUG/bJBKg3nFABJ8NVlhNUaIUoiXi99kXfGtGLERWrUW2AKDcrvqDojobpKdMfTSttisokAdPl6PQYxtartjRHRyKqU8vU3mxu5CZSDaUJ31SjuvZZuj8Y2Bny0KraugvMAqbjEk2lpY7bDRGlZRl9bDCAohkREGuoTU9w3puhuev++4BtZWfv1Dp182AgRFThJukN+uMSNhhGfxiz1fbem5W21xhyNHcWQrUbuJ+kPi+yMd1tqTWqUmyGMtNFbJBpKDka/1hpSe2QIuoUp2AS6FiAEIvFkDrTaFXnEVXrrCybUOUuE9EjtN9hCd/JsGedhVa3iTSptlHL+8Pd+vBmbhZQiajS2L9Mw0JIPX4ZN9Fts+Ouvde30CJwJdS33XI0F2YGnEa8h/apDwc8oko1tWxUVyr72vxgCd/qgByJRrwU3mVI+qaf1SZSkrc93rnQPmha67QrIat1li2cL5uqgOqT9vN31eYJ307PRksCRgp22u+RWnzp8gN2ONm3TS1FVMRmiyf/yriJ7oCZUYdoqGkZoxSOMyyAvbu0g7BM9CRJSVrd0LK2UkR1c1rkqJCr3EVsUID/rbuaZZYUjmdgJ12GUNlBnFzAPo+RXLxZp54PeUTVZjWqQjUi6W8eyr2aZOXbWwttQDWUgJ3BXWTrsjjjeQFcIo4sUzcP+JJSnFqkRmQT0Krch0xDq1RDDbNE4VmLhUCTSc8c0ZPhTs87GYhTon++KyFUUyGiwjWqIjWi0Pxjq3Jj2E85GrzXFAF55qd5nYGdj76WVUPC+dakIK7KQJwpokeQ+adu9RZK1y42BQErZgFtxZf5OQticTHMJmC6MUzAVjcyCsjhV3ogtXj0hVNslqxa84Ln0tssovJsqTOdv9YgVoeKup4IxSSI5fOS6jiC5sCcp1k1D8VqyikOqp462RR3UBIwT7mbYklCW0ZGm1IxtWsfvCHk0dJcuePeh4E4fVcCnKXih9etp4oGph/b9n5+09FKEvosENhhRqqQFvZoD0jBXZuDODK2OWVBvAvw0H6vhZ4COvra5JUWShLnp8hGSw+9lJHJZC6RuGr0AcQpAoiz2JVgJoyJ/ODYeopKT2Ld4yWJGrLQCo7rCAoX/jdfunwFh0OaiTM4b6YiOKK6NQoolyb5J89NzLOSBA5aGdMKLWugyfS4SDslNTPSvUFAnDG9IdWomj4XdBQBzTZ41uYlieo8S+YqtF22gaRwYRHQHqWjNwbi6gTE2WgPf4g1KtWk9XPTIqC497hoxgw81dDATPv2wdsTju5VLOCZsTwkIA4PMxn0UGBhel7nERU78uw76NPXRhAmDWKzkoTK/X6noQZyJW6+zM873CH94d38soDpYt7LXX9OAaMcG0QQA0FJojoXYjyJNrrjrpKXN0s1OjK8x0GcaTFINZX1jafTBQ4BgxwbJPd4WDsvLkmYad/2jrT2BEO45JFMSEHcDx5V4ljJQrvCERXNLDPnbAuQXCoqRemp/66ZVbTHD/pJhzcZlmsNicRMnADitIhejKju5YhKvcdpV9EAs04FHFZXyHJJGWMuhgX2NCxQ6OYLTF1LVZ4dyhTEGdIboRBR3ZxaVZR/DCoaUrgIIXjTxhFGI1TA1ntNHa5Q1z2v2vYGWWfqmZk2HW6VRVQks+wpYBalY22pUqDbtXKEa6P2KL1kOyW/ocFAnJm2ecFqVA0eCtgE1GwwYuuYDjFsrKSjX6AVqvc41FU3eYNLygKI6zAQp9MKERXgVMNdavlvPIitCSUJjC9Ml5RDsXrfugtCdaVLCchoMwjIQJzh8GI4ld2jMh0VyGSDtKxLo/TQbAgpmOuwhDbW0EATcKObL+jtQkiFWOs+zQtWNSDeX9+HyGzp7awksY8sS1MjoS7YyofVVlBRGxRcSpYpnbR6WblbTTy0GZriEVVeX1uqobwkcdG3CTg/l6v3mjPapIOFDpcF3RmIMyTgedBNe/6VhdP2/o2XJOqtbmAWMKKhLnGVjX204Q5aUY8E4swN/ziiuuBuDScA1XFVjvYbvCQx6Fk4Ij2vzFWmGooM3raEiuqoJwNxdQBxloi+m9UoU++vYgz5b39a7ATrfJBF08/fiHWDsur9hh2E7j4ZyMTxdjILMBIiqh9nRgHp3r/xkkQV5+KR0YNGWU/P8Hxl2pWt3nypiXHL3DKcVKMiPf9mAYUbZXCPJ6/eleINk4BbuqTMuM+OdiinmiL6UI2o5L42Km5XK0kYdlDoVx4cGpne+s0XekUMOo0OsnK3ArbnPKKidX8+HJ2leZHdkniPFAG5DXaF2xFzZNrkbV5S5rRdXu7OQJwWLqURFetKYnEXGZfOsjpXO3QNO9jP7mJBn7PfyVjkFLUsxj4/SqptAHGGrFrlMOvVIakGUUARGfTVZWRD9Krck4AebMsGPW6+qCDOpM4RmreHVJ1JZwQZTo1D2teBsjRsllDwJJCMKeTbitigoUYkXskkmThzPEi6/uRuejzLPLsl0cnqyIqA/SxdSG8LGvIGxSP6fBvkw4mVkz9aOoh9ob6MlHlYyuHQcEtCO2R6DfU2k2sHt3NJWaXlIA7fiesb2VTwCOEUbh3ByvBbEuosoeB2z/tGkq1BNTttSMupVQbiTLRiRNXA1dR51VCSUKFa/zcH+Ud/mCfZyE2UbackkWsG4rSIHmgP+X4cHaB3voO4W4XNIiv3LX9BQGPYs630plDN015rd8ItsLnCA1+MFQNnwz6q/aZuYthE5mWsvPN04dGe1ZN8l5vQD6TeEfdZAOIMWZheh2IXbIinNH4c/kGMe2kHT/EJRu30j9VWvueSsvFQZvf8WZrTkKToU7/WwTLhvC+sSIuBbUnAW37hatLo8TXYKKu2+V3qbnYDabLK2sVZorC2B7vc2CMeP0TvNB8x0VMWzWvejIzThZvArxJQzV4AFUDcUVehDdAdzaMdgUdJ/7uBrO7kI1I4gutokC7s1kIb099vg+rb0QQQVycvhRHDJUUp8ac/ZB0OSNrBsx+sYomVIfDOdRZROwNU82jlqoQMxNUBxHEzqYTUCOtsc8mnR0P7VvZ+igA6Y1h/xJvWtLFZVm0LL7IlWJMegXesYlKJajeQgWh8kMdhjIqiuUTtSLoQYHrrkKyazEgpqFYmA2dp5RIjWpaJwyTvUG6ptt9gOPbkb2gum+zV6I9pOpbY4FwPq/+9mzCUu8M/LDVfJyAOk9zSzGJrnw8HD7wN4fztvBMBIQUJAg7eHGr3T6CaRCIgStTk76ACEFdBp1TAdpcPx57sUSiXooAK7W2hWt5qRhvt4BagmimiJ0dFK2OTgLjKOaRXhwcRZ5NvOWuHGfTpxSr2ZKupnaIbFUC3+CLbZitjE3fVn10z1/6WDceeDKIPCEyqNwftqiBgKqFpcPjyz6CaJaJvCQJiG6Otqi2p65M/2QT56w3eJ0gdZ1OZ5d9E9B4CphLSBiMG4kBAYoTy21vgyf2BuCL1zscNnErNnJX+V1BNT1lgCTH8zJL6JBN/gPQdhCG6R8KWD67RHlmaVtMyy3YF1FXU+CJbiTaVkABsdrEBchfVpjgceZLv5wFvDyQpjj0S+LaappX+jteOGWlNboJ9AW+RShiR7kJaYZtLwyFxV6Jmg9ZcoDNmjwTHrab7kPG3wS1ANZGHIOAShlmHKK41yGxKs6x+gOkBzttr0LN0S9HENqCauBiIS4g/tWvcadQ5UDVeWRr8dlFWeOIS6k0I/7WboLTg8amEpLmnca4F/eqT98OjD4piuYQ8di5jg9txE+aWOvD4ICG0i7fmGpvqk81JN2CMcC2VSbZ9ipayQUJLPD5oKdDWehmtXCPNngyb2SxEQubx/4OsmkOdgZb5Q9Ni2ASU9GSvkXn8f1B8KWaDVEJ6ltqnds4ievz/H6gm0PKz1JH8k59UOMo8/rcVX8rbIBI9vsP8jT9mswgef0uHDMqjLeRSAskfWqd2YCt+lv4/QTWxD1WW0AKiHJaeefwtRfQoj7aIDWJayePbvJn1rA51j1/KBr/zV9OIHt86tUtPJH/4fwPVBFrB4zvM3zGL6A//C6img22FNvP4jhqRmSOYhfhDKmGRIHajj4+bYFNzj5+7gxZL3yOFNSJhERtEp71yn1MYF1nG1TWjSXozsT/UdpCzKcmtMp15/ELFF9T90cafo6N2O+eL9IMf3SI2iPODzY/zdmeSSug2f7shcI9f7He+oC67qZHl+aQvdcOX9H+dbjEBMW3t9PBicIPUHZQsye6MuLcICxZfup0yAmIJC9hgthh99W3F6m8ls+5K5vELuolup4yARELkGtcydagKKLPpULtsD3MFlI/zbqeMgFhCKqALquWiRJVN+9IEisf3x6Jd6C8adnw/Q0lChw0ybdJfg2rHIw4BZY9foPjSJS8sGb4f+n7eSamLSujCuLP1w3P6eXhZj+XFsKNEJ9Oyx/eHal2yJ23WzJv/WZFGNJDQcndp8XC1PInjEfnE6Zf4+OlyXcuxQWR7ews1BMHjF4FqTMJ9S5MV0uxqn7SeEQl1AaMwWF/9mo7iZHcHPrvkS5LEo+TzcozciNLMNB1c9PgFAl7qD1MJfXHrPmng7XRNAoazr+NUOibXjvwlGcXLy0XoPgvtiJd7/GIRPZXwSHuDl/Xo3z9SPT6nfVjGWDyLgGQv492vcSEBs8Ibjw8LRvTg8amEHhF9KiE9S1U38fA6SsxyZV/SP+Pp08yKKO27Inh8fwHJLODx2/sWWg2dYDsECWUVfXkcCWIQw4PPFFslFx2TxPHXODKzaRewpuS8/ZNO4PHb+2ZaPXakEg6ZxwfaxdMoyQRMRtOTz6vLh/UYf9bPP78e42mqv7uMJN69NLNpFbASKR7fP6IHj48l9Iz+ZQmB9jnlmXGfxDtPz+TQZMc12a/Zz8ckzrR4tByb2FSYlkJlyeMXiOjB4+Oz1DOiJxIyj09oo6dpQgVM4pO/L5ap0eLyMY6ZUSbxMzdGm4DySosevwgg5N7CN6u2Tzw+vKmE8DD7FVP9S0bHP8dONmd/45ht9vQrUGnNT1IPKnh8Hxvkl5RBwsG+noq25G9Ij0TnPmK0LzvMwEYnl+wZK5to/HfKdDVehgqtk+nM4xfKVmd7mEfLhsMef/IRMNrnKRUwia+QvSErawoOx0viVbDjeB2rtKYqJH2Se/yCWTXZ43uEQKnHbwybjKPLKfUBo+VMtytLVu35JKbGmIoo0brqUqrH9y2ASh7fI7ONPT60MWHayxEImEwvi1hHuo0U47yOI5HW6CbgSdXjexdfRI/vkyROtZTcKwAVZQKerJ14RJs6vJpS33K8EGm1vc9guuLx/Ysvgsf3Kr6g/dYF4+iFqmj8uChcFnlOwBiTY4nWsTSSxy9QfMk8vmfxZf8He0PmLIFDZrQ00eZF9GtyBqf45tMuoBQqix6/SAG0O6Qe37f40usyR/+LCvjpFNBap51Rzzj6yZPEzqUx9bV52JUQAeerKCFZsTchPIGjj907aI/o0ZoC8tELCxnJk7YCqKuvzbErmT/0sEEpmniewiHzaBTQdFSo44YvMaDU10VGYl8aR1+bq1Cj+EP/AuhiJ4FT1HjI6FMHi5eZNi51NvETpzXU6Jly2/va3AVQyR86br6o3D9BNDH1dBPB4ng6etJohVHI1KEdQOt9bZ41etEfFqgPvkC8OzI6ep3NVMAE4x72L5z2GLDNL7oYhkOGcWTta8srgBJ/SCUsUKN/JAFvsnTaoCDgIzG5eBnJtOlpA4fNJUSTjvPX1teW2yfTJTcWiYQ+ArKcDGxhMva0wV/0TCEHr1THuBoREV/FCNHsQc19bfk1+szjF6nnv4KOXnkKeByz/A0WUaZ9JcnH0aUgoHlXpL62AjdfuMcv0ifzQIBzcuKIJkw7CIq6kI+KB+J10rG4gJajX/D4RW6+ZB6/QJ9MuCTWM3r2CWSYDfIs1FJZjGNi0tNnirutNXpTX5tHn0zm8fNVlG/lLIawoGYXsGbeQQjtZVqqEI/M49t2Rahy+6topHl8jx0Mwi84GC+jIjaYvJ6w0H4p0kbBL6IR8QwHfvaqht7X5tknI3t8HwErxLft7JxoSSeTm/jFBRzPaDSRihgKvy+MIJv0hz+Rawf1vjbflmbJ4/sIWENrwlHypArochMJXo8Z09V4mRlQhMZAQgCuA1+qVW7fawWix/e4+YLHvSJJz1jNi+pRnaCisOHr3YTa4pPI5ifZ23gmeHwD02qV2wnVgBEynODxPdwEGfcXlM8UAY1QLVNRQhuuWWnqRKQF/JC5RPOuKFVuS0Svc5R5fC8bTMddkNwFKKkTbI9/KQJGiyUcNrs4sM8WY7yzK6i97egv29fGPb7hQNJtMCIrTgoPz8bhrDZIhltCUn83ScbiPoSPCcm7hU6mpSq3P/wSYny/HUSpGRIPrSVzVQFVFRUE3JlJbEbEssmQjl0RqtxF2imtVW57n8wS1+gxynJF9JKbQFRFmYAnsoAVrBb4hH1wCShWuf3cBCGp2arcjlauE2I0n55Qje9gqOygeFSMp+SAvXTBr8xbFGxpVj0+ctDCFwA0V4ZkgqcNygISNmMSWl25dkXra/OwQaGvjXp8uagJA9On2ZcAQGkashazwUeLDQKbBH2neuHT14ZyBTT1tXVu3/p5H/Jmh0oAiGb0oCYTLFANGW1QPSo+iW0/brmvDWahfW2dVqs1GLTgY/zy4x4Jp8Jo7djBXBXVjoq/BAm8Ktsjq53s8T1VFLEqt9h2aOlM7HRhalyN2dkdje0CHmsCPuYIGIK7OHHuiqnKbYVqwizdoZ+A1c4hjAv1JpDQC6pFodVNMDapQ9x1CWjpa1N30NbX5tFbiiXE4z4DpBmLO6hn1YRDZuFwE4xNQULr0V+sry17jVG34ycg6fNCREICk8fmpHoJG8RsQriy62Raq3J72CAm6bYnE/xb1BuTCXyZmL80jugb1B7iXUBYxja5om6CsvlFHOKJ62Q09bWpAhozcGcXB36fC9ojBOWU6dp0SQ7NRgXdBMvuJ1Asdahdkb42DbcW+ITBOqZ5NlMyAQ5aO1SzIcol8fhLx28lK9LXVvr2GTA9plkVlkyQkn+fSQGoJkx9QmoET86XzKl9bZTprVxSlmkhlfilCohJwlfQNqqimQ3a3ARD1dNdlotCVrVT+tqctBsJCGl4UhjVcmMz0icTQ3Cca4OZgBQJPitMy6ok5LyL2KC9+OI+FXZiaQ2o2l1CaT55caqo5s2iZ3Z6mQWEWTJ/6OcmirgUeTFAjOnMcHB8QgN7MnoJPd0EGTd8gohsgYy7kvW1VW19baXfZWGkXY+o0WgCLk5Y6n70gnKhmjD1K8nTPIZOpoUq9yYq6nEg1UgckBqidvSDOUG68DEfqvFxSci5iw8vhyr59LUVyd9YFyMd/xNEHMs2mP7Tz5gLuJPkuQlh3J8E0YweMo4MK61WuQvYVaEdxCSkzkCyKkDLI4RlwgXc8bVB/OWRtB5hJ+pY6eJ9beUExMONyZJTfyGq3UgTMMdNwNTrEaH9ROxj7pPx7WvzKr64dhABxoI6gyTgy1QRMHZEE8K4X6TlhHpDIyNF+to8iy9OAam/iP8qdvUzzgRMkniaPLmhGh13Ae20yYIJaFE76e0tZdxEgQuSC1ojG8uBDK3YYOni18/LmXk4DVFCDj3+QrbfSlamr628DZIvrAj8FIpqtwDUHU9PPi/X7D2z+RhjAThoOkMb9LUVeu1YnoriGcdgcdOZSPsySpLRaPlzvUD6L+2yJx6+CA5KIycytQN+OfraHMtYzE1kJE9wnC5F2q/pr6uH0Htq+mUGQG+6JpfQHX0yBfraNrNB2OQxnA7k/GO060WYN5y+trRxJfkMpb42w97797WVdvT0C5B8xdAzJLR9BVaNtyf/aJfCTryGaoQmYIG+tnIRvZVkzFoOHC+ezq8RASLFjofXRSQBJaY9+9o228FsbSO6+KMr63rl22C4eAUd3WEKLi+N/KRfX9uGbkK0DlqSnz6baX0O8OATtjCDMxIjRfratgHV1KkBnZKA3qmi9vx0+JcaIWtRqNgEJH+43te2SURvSt0DyfMUUhZp+JCzGOapwy8QMKGN7EBiZzrra9tuRO84GQHZ7CTxuoCb4H3Q4RdcDNpNRNxgP389+tq24yayqYNgGVMeX/IWQz9kAqqi1JAdAlKOMn/IHCJnhK0B81d6w79OW7HSikyHr/TuEomGvW4/sAkWn0zAnyKJw66ohAPt7S1FmC4mID5tXmm3Iblo4G/+aPZKtz/+kmhdT4I/rA9+/IvPHeMhFZG6/uM1X6Zc60gDzMQoIDItIxtir2Go+ZV6uY6ThL6+v8d+Jc74mOVmEvD9HjY4W7KM1dQsoKuv7d8IWK122G+Kj6CoTdIQr89iqc0G1RZf/A0Lsg0i5e0taqi81/h3AtbrjUafM/05YpfVp8cPTA9tbC6u+ItdkuRZppXf3qLt/V7jHwpYrU7O3/jUP/kbMXZGx+QdNNas2lfCr+PHr1L8zCTJ62tzyiV88SDJoR3eNNkvaEdrdjLiV2LsfD6PeaTAJY1C/N6IUcwzVaOnhUkSR6B1M2AvxDO9Ik/5F/1LcdpBnf5et9SbLp6mCXtzScr87uPVA9lKLun6+ek1Ft79Ee8wsC3vtquNBP1XH0Ay618jIVOaxKNpfPz59yr9fD0tT6YjeDUPf3vGX5Y6VHRxk3rDlqCaHbdeHo/kpH6Cs4rpJxHe6wIH0uc6tAxnnWXbxRf/KD1bjGhxeTK1vSIqEzCeLtehtYHSxvS3R/T2HZRpnx/j2CVgMkq+Zii0Tm0T8JvCpULvWma06YEZjxLTVibJ6OTzeeGcOm+W74zofWnTH8wun16nxP7osZOQg+fxC85XF5s5TPuoaJRHu5mAnGT8cHn1+fh6gsuCx8unn888meqc+n++Nsgd59CCVQAAAABJRU5ErkJggg==";
         
        } else {
         
        }
      },
      (error) => {
       
      }
    );

  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        this.IsVisibleMode=false;
        this.VisibleMode=true;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.IsVisibleMode=true;
        this.VisibleMode=false;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = true;
        this.IsVisibleMode=false;
        this.VisibleMode=false;
        break;

      default:
        break;
    }
  }
  GetSubsideryList() {
    this.Subsidiarylist=[];

  if(this.RetloginDetails.userType=='SUPERADMIN') //this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null
  {
    //this.httpService.GetAll('/setup-ws/subsidiary/get/all' ,this.RetloginDetails.token).subscribe(
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(  
    (res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.Subsidiarylist = res;
        //this.GetParentLocationList(this.locationobj.subsidiaryId);
        } 
      },
      (error) => {
      
      }
    );
  }else if(this.RetloginDetails.userType=='ENDUSER'){
    this.Subsidiarylist.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });
    //this.locationobj.subsidiaryId= this.Subsidiarylist[0].id;
  }
  }
  GetReloadSubsideryList()
  {
  this.locationobj.subsidiaryId=0;
  this.GetSubsideryList();
  this.locationobj.parentLocationId=undefined;
  this.Parentlocations=[];
  }
  GetLocationbyId() {
    this.httpService
      .GetById('/masters-ws/location/get?id=' + this.LocationId, this.LocationId ,this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
           this.locationobj=res;
          this.OnloadParentLocationList(this.locationobj.subsidiaryId);
            this.locationobj.locationAddress.zipcode=this.locationobj.locationAddress.pin;
            this.locationobj.effectiveFrom=new Date(this.locationobj.effectiveFrom);
            this.locationobj.effectiveTo=(this.locationobj.effectiveTo) == null?'':new Date(this.locationobj.effectiveTo);
           

        
          //let newDate = new Date(this.locationobj.effectiveTo!);
          //this.locationobj.effectiveTo =this.datepipe.transform(new Date(this.locationobj.effectiveTo!), 'yyyy-MM-dd') || this.locationobj.effectiveTo;
          //this.locationobj.effectiveFrom =this.datepipe.transform(new Date(this.locationobj.effectiveFrom!), 'yyyy-MM-dd') || this.locationobj.effectiveFrom;
          //this.viewMode=true; 
        }

       
       
      });
  }

  SaveLoactionMaster(){
    this.showloader=true;
    if( this.locationobj.subsidiaryId !== undefined && this.locationobj.locationName !== undefined && this.locationobj.locationAddress.address1 !== undefined &&
      this.locationobj.locationType !== undefined && this.locationobj.effectiveFrom !== undefined)
      {

        if(this.locationobj.effectiveTo != undefined || this.locationobj.effectiveTo != "")
        {
          if (this.locationobj.effectiveFrom > this.locationobj.effectiveFrom)
          {
            this.showloader=false;
            this.showAlert('Effective To date must be greater than Effective From Date !'); 
            return false;  
          }
        }
    
        //For Save API Call
if(this.addMode){
  this.locationobj.createdBy=this.RetloginDetails.username;this.locationobj.lastModifiedBy=this.RetloginDetails.username
  }
 else if(!this.addMode){
  this.locationobj.lastModifiedBy=this.RetloginDetails.username
  }

    this.httpService.Insert("/masters-ws/location/save",this.locationobj ,this.RetloginDetails.token)
    .subscribe(res => {

      //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.locationobj=res;
      if(res.id>0){
        this.showloader=false;
        //this.saveAddress();
        this.showSuccess();
        //window.location.reload();
        if(this.addMode){
          this.router.navigate(['/main/locationmaster/action', 'view',res.id]);
        }else{
          this.router.navigate(['/main/locationmaster/list']);
        }
      }
      else{
        this.showloader=false;
        this.showError();
      }
        }

      
      },(error) => {
        this.showloader=false;
        this.showAlert(error);
       },
      );
    }
  else
  {
    
    if (this.locationobj.subsidiaryId == undefined)
    {
      this.showloader=false;
      this.showAlert('Select Subsidiary !');
    }
    else if (this.locationobj.locationName == undefined || this.locationobj.locationName =="")
    {
      this.showloader=false;
      this.showAlert('Enter Location Name !');
    }
    else if (this.locationobj.locationAddress.address1 == undefined)
    {
      this.showloader=false;
      this.showAlert('Enter Address !');
    }
    else if (this.locationobj.locationType == undefined)
    {
      this.showloader=false;
      this.showAlert('Select Location Type !');        
    }
    else if (this.locationobj.effectiveFrom == undefined)
    {
      this.showloader=false;
      this.showAlert('Enter Effective From Date !');   
    }
  }
  }
  openLocationAddressDialog() {
    this.selectedLocationAddress = new locationAddress();
    this.displayAddressDialog = true;
  }
  clearData() {
      this.router.navigate(['/main/locationmaster/list']);
  }
  onAddressSave(addedAddress: locationAddress) {
    if(addedAddress.country != "" && addedAddress.state != "" && addedAddress.city !="" && addedAddress.address1 !=""){
    if(addedAddress.country)
    addedAddress.zipcode = addedAddress.pin;
    if(this.selectedIndex !== undefined){

    }else{
      this.locationobj.locationAddress == null;
      this.locationobj.locationAddress=addedAddress;
      this.IsVisibleMode=true;
      this.VisibleMode=false;
    }
    this.displayAddressDialog = false;
}
else
{
  if(addedAddress.country == "")
  this.showAlert('Select Country');
  else if(addedAddress.state == "")
  this.showAlert('Select State');
  else if(addedAddress.city == "")
  this.showAlert('Select City');
  else if(addedAddress.address1 == "")
  this.showAlert('Enter Address');
}
  }
  onAddressCancel(event: any) {
    this.displayAddressDialog = false;
  }
  GetParentLocationList(SubsideryId:any){
    this.Parentlocations=[];
    this.httpService.GetAll("/masters-ws/location/get-parent-location-names?subsidiaryId="+SubsideryId.value ,this.RetloginDetails.token)
    .subscribe(res => {
      //For Auth
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
          else
          {
            for(let i=0;i<res.length;i++)
      {
        if(res[i].effectiveTo == null && res[i].parentLocation == true)
      {
        this.Parentlocations.push({
          "locationName":res[i].locationName,
          "id":res[i].id
        });

      }
      // else
      // {
      //   this.Parentlocations.push({
      //     "locationName":"Dummy Data",
      //     "id":1
      //   })
      // }
      }
      //this.Parentlocations=res;
          }

      
      }, error => {
      },
       () => {
         // 'onCompleted' callback.
         // No errors, route to new page here
       });
  }
  GetReloadParentList()
  {
    this.locationobj.parentLocationId=undefined;
    this.OnloadParentLocationList(this.locationobj.subsidiaryId);
  }
   OnloadParentLocationList(SubsideryId:any){
    this.Parentlocations=[];
    this.httpService.GetAll("/masters-ws/location/get-parent-location-names?subsidiaryId="+SubsideryId ,this.RetloginDetails.token)
    .subscribe(res => {
      //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          for(let i=0;i<res.length;i++)
      {
        if(res[i].effectiveTo == null && res[i].parentLocation == true)
      {
        this.Parentlocations.push({
          "locationName":res[i].locationName,
          "id":res[i].id
        });

      }
      // else
      // {
      //   this.Parentlocations.push({
      //     "locationName":"Dummy Data",
      //     "id":1
      //   })
      // }
      }
        }

      
      }, error => {
       },
       () => {

       });
  }
   handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == undefined) {
      this.LoadHistory();
      this.displayAddressDialog = false;
    }
  }
  editAddressDialogrowlevel(index:any) {
    this.selectedIndex=index;
    this.selectedLocationAddress=this.locationobj.locationAddress;
    this.addressComponent.GetStateListByString(this.selectedLocationAddress.country as string);
    this.addressComponent.GetCityListByString(this.selectedLocationAddress.state as string);
    this.displayAddressDialog = true;
  }
  /* Start fetching History details */
  LoadHistory() {
    if (this.historyviewmodel.length == 0)
      this.httpService
        .GetById(
          `/masters-ws/location/get/history?id=${this.LocationId}&pageSize=100`,
          this.LocationId ,this.RetloginDetails.token
        )
        .subscribe((res) => {
          //For Auth
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
          else
          {this.historyviewmodel = res;}
         
        });
  }
  //--Parent Location Enable/Disable
  IsParentDIsable:boolean;
  fnParentEnableDisable(){
    // if(this.locationobj.active)
    // {
    //  this.IsParentDIsable=true;
    // }
    // else
    // {
    //   this.IsParentDIsable=false;
    // }
  }
  /* End fetching History details */
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Data Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving!'
    );
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
  checkefectivedate(){
    if(new Date(this.locationobj.effectiveFrom)>new Date(this.locationobj.effectiveTo)){
      
      this.toastService.addSingle(
        'error',
        'Alert',
        "Effective To date must be greater than Effective From Date"
      );
      setTimeout(() => {
        this.locationobj.effectiveTo=null
      }, 100);
    }
  }
}
