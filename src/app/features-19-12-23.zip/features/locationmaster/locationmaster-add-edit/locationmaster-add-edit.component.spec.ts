import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationmasterAddEditComponent } from './locationmaster-add-edit.component';

describe('LocationmasterAddEditComponent', () => {
  let component: LocationmasterAddEditComponent;
  let fixture: ComponentFixture<LocationmasterAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LocationmasterAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LocationmasterAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
