import { Component, OnInit,LOCALE_ID, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch,locations,locationFilter,BaseSearchPdf } from '../model/locationmaster-model';
import { PrimeNGConfig } from 'primeng/api';
import {formatDate } from '@angular/common';
import * as FileSaver from 'file-saver';
import { debitNote } from '../../debit-note/model/debit-note-model';
declare let $: any;
@Component({
  selector: 'app-locationmaster-list',
  templateUrl: './locationmaster-list.component.html',
  styleUrls: ['./locationmaster-list.component.scss']
})
export class LocationmasterListComponent implements OnInit {
  columns: any[];
  departments: any[] = [];
  locationslist:locations[]=[];
  selectedList: locations = new locations();
  Subsidiarylist: any[] = [];
  totalRecords: number = 0;
  SubIdList:any=[];
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  showloader:boolean=false;
 baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
 LocationPrint: any[] = [];
  newevent:any;
  LocationSearch:locationFilter=new locationFilter();
  RetRoleDetails:any;
  issubsidiaryhidden:boolean=false;
  issubsidiarydisable:boolean=false;
  // For Role Base Access
     isEditable:boolean;
     isCreatetable:boolean;
     isViewtable:boolean;
  RetloginDetails: any;
     // For Role Base Access

  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService,@Inject(LOCALE_ID) public locale: string) { }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
     const retDetails:any = localStorage.getItem("RoleDTLS");
     var role_Dtls = JSON.parse(retDetails);
     this.RetRoleDetails=role_Dtls;
     const LDetails:any=localStorage.getItem("LoggerDTLS");
      this.RetloginDetails = JSON.parse(LDetails);

 
     for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
     {
       if(role_Dtls[0].rolePermissions[i].accessPoint == "Location")
       {
         this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
         this.isEditable=role_Dtls[0].rolePermissions[i].edit;
         this.isViewtable=role_Dtls[0].rolePermissions[i].view;
       }
     }
 // End For Role Base Access

    this.GetSubsideryList();
    //this.resetBaseSearch();
    this.primengConfig.ripple = true;
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
      { field: 'Id', header: 'Internal Id' },
      { field: 'Subsidiary', header: 'Subsidiary' },
      { field: 'Location Name', header: 'Location Name' },
      { field: 'Parent Location', header: 'Parent Location' },
      { field: 'Location Type', header: 'Location Type' },
      { field: 'Effective from', header: 'Effective from' },
      { field: 'Effective to', header: 'Effective to' }
     ];

     //this._selectedColumns = this.cols;
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }

  GetSubsideryList_old() {
    this.HttpService.GetAll('/setup-ws/subsidiary/get/all' ,this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {this.Subsidiarylist = res.list;}

        
      },
      (error) => {
       
      }
    );
  }

  GetSubsideryList() {
    this.Subsidiarylist=[];
  
    if(this.RetloginDetails.userType=='SUPERADMIN') //this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist=res;
        for(let x=0;x<this.Subsidiarylist.length;x++)
       { 
        this.SubIdList.push(this.Subsidiarylist[x].id);
      }
      this.issubsidiaryhidden=false;
      this.issubsidiarydisable=false;
      }
      },
      (error) => {
        alert(error);
       },

       () => {
        if(localStorage.getItem("LocationFilters") != null)
        {const LocDetails:any =localStorage.getItem("LocationFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.LocationSearch.subsidiaryId=searcheData.filters.subsidiaryId[0];
        this.LocationSearch.name=searcheData.filters.name;
        this.LocationSearch.effectiveFrom=searcheData.filters.effectiveFrom != undefined ? new Date(searcheData.filters.effectiveFrom ):undefined;
        this.LocationSearch.effectiveTo=searcheData.filters.effectiveTo != undefined ? new Date(searcheData.filters.effectiveTo ):undefined;
        this.loadLocationList(this.newevent);
        localStorage.removeItem("LocationFilters");
        }
        else
       { this.resetBaseSearch();}
      }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.LocationSearch.subsidiaryId= this.Subsidiarylist[0].id;
      this.issubsidiaryhidden=true;
      this.issubsidiarydisable=true;
      if(localStorage.getItem("LocationFilters") != null)
      {const LocDetails:any =localStorage.getItem("LocationFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.LocationSearch.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.LocationSearch.name=searcheData.filters.name;
      this.LocationSearch.effectiveFrom=searcheData.filters.effectiveFrom != undefined ? new Date(searcheData.filters.effectiveFrom ):undefined;
      this.LocationSearch.effectiveTo=searcheData.filters.effectiveTo != undefined ? new Date(searcheData.filters.effectiveTo ):undefined;
      this.loadLocationList(this.newevent);
      localStorage.removeItem("LocationFilters");
      }
      else
     { this.resetBaseSearch();}
    }
  }

  getAllSubsidiaryReloadList()
  {
    this.LocationSearch.subsidiaryId=undefined;
    this.GetSubsideryList();
  }
  loadLocationList(event: any) {
    try {
      debugger
      this.loading = true;
      this.newevent=event
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
      this.baseSearch.sortColumn = event.sortField
        ?  event.sortField
        : GlobalConstants.LOCATION_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder ==-1
          ? GlobalConstants.ASCENDING 
          : GlobalConstants.DESCENDING;
          if(this.SubIdList.length==0 && this.RetloginDetails.userType!='ROOTADMIN'){return;}
         // this.HttpService.Insert('/pr/get/all', this.baseSearchPr).subscribe(
      this.HttpService.Insert('/masters-ws/location/get/all',this.baseSearch ,this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
          else
          {
            if (res && res.list.length > 0) {
              this.locationslist = res.list;
              this.totalRecords =res.totalRecords;// res.totalRecords;
            } else {
              this.locationslist = [];
            }
            this.loading = false;
          }

         
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {
     
    }
  }
  findby(event: any){

  
    let subsidyList:any=[];
    subsidyList.push(this.LocationSearch.subsidiaryId);
    let Fdays:any = new Date(this.LocationSearch.effectiveFrom).getUTCDate();
    let Fmonths:any = new Date(this.LocationSearch.effectiveFrom).getUTCMonth()+1;
    let Fyear:any = new Date(this.LocationSearch.effectiveFrom).getUTCFullYear();

    let Tdays:any = new Date(this.LocationSearch.effectiveTo).getUTCDate();
    let Tmonths:any = new Date(this.LocationSearch.effectiveTo).getUTCMonth()+1;
    let Tyear:any = new Date(this.LocationSearch.effectiveTo).getUTCFullYear();


    this.baseSearch.filters={
      subsidiaryId:subsidyList, 
      effectiveFrom: this.LocationSearch.effectiveFrom !== undefined ? (Fyear + '-' + (Fmonths.toString().length ==1?"0"+Fmonths:Fmonths) + '-' + (Fdays.toString().length ==1?"0"+Fdays:Fdays)) :null,
      effectiveTo:this.LocationSearch.effectiveTo !== undefined ? (Tyear + '-' + (Tmonths.toString().length ==1?"0"+Tmonths:Tmonths) + '-' + (Tdays.toString().length ==1?"0"+Tdays:Tdays)) :null,
      name:this.LocationSearch.name
      } 

    this.baseSearch.pageNumber=-1;
    this.loadLocationList(this.newevent);
    }
    Reset()
{
  if(this.RetloginDetails.userType=='SUPERADMIN')
  {
    this.LocationSearch.subsidiaryId=undefined;
  }
  this.LocationSearch.name=undefined;
  this.LocationSearch.effectiveFrom=undefined;
  this.LocationSearch.effectiveTo=undefined;
  
  this.findby("");
}
  navigateToAddViewEdit(
    action: string,
    selectedList: locations = new locations()
  ) {
    let locationId = null;
    if (selectedList?.id) {
      locationId = selectedList.id;
      this.router.navigate(['/main/locationmaster/action', action, locationId]);
    } else {
      this.router.navigate(['/main/locationmaster/action', action]);
    }
   }
 /* exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.locationslist);
            doc.save('Location.pdf');
        })
    })
}*/

showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}
resetBaseSearch() {
  this.baseSearch.filters = {subsidiaryId: this.SubIdList};
  this.baseSearch.pageNumber = 0;
  this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
  this.baseSearch.sortColumn = GlobalConstants.TAX_RATE_TABLE_SORT_COLUMN;
  this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
  this.loadLocationList(this.newevent);
}

editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("LocationFilters") != null)
    {
      localStorage.removeItem("LocationFilters");
    }
    localStorage.setItem("LocationFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/locationmaster/action', actionType, mainId]);
   }

    /***((Export Excel)) */
    generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.LOCATION_TABLE_SORT_COLUMN;
      this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
  
      this.HttpService.Insert('/masters-ws/location/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.LocationPrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {

                if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){ 

                       this.LocationPrint.push({
                    'Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'Location Name':  RetData[i].locationName,
                    'Parent Location': RetData[i].parentLocationName,
                    'Location Type': RetData[i].locationType,
                    'Effective from': RetData[i].effectiveFrom!=null?formatDate(RetData[i].effectiveFrom, 'dd-MM-yyyy' ,this.locale):"",  
                    'Effective to': RetData[i].effectiveTo!=null?formatDate(RetData[i].effectiveTo, 'dd-MM-yyyy' ,this.locale):"", 
               
                    // 
                    
                });
              }
                else{
                  this.LocationPrint.push({
                    'Internal Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'Location Name':  RetData[i].locationName,
                    'Parent Location': RetData[i].parentLocationName,
                    'Location Type': RetData[i].locationType,
                    'Effective from':formatDate(RetData[i].effectiveFrom, 'dd-MM-yyyy' ,this.locale),  
                    'Effective to': RetData[i].effectiveTo!=null?formatDate(RetData[i].effectiveTo, 'dd-MM-yyyy' ,this.locale):"", 
               });
                }
  
              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    exportPdf() {
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          //this.= this.employeeExport;
          //this.employeelist=[];
          (doc as any).autoTable(this.exportColumns, this.LocationPrint);
          doc.save('location.pdf');
        })
      })
    }
  
  //End PDF
  
  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');
  
   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.LocationPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.LocationPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'location');
           this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
  //End Excel 
    //List Export option End
  
     /********Export excel */
     onRowSelect(event: any) {
      let locationId = event.data.id;
      this.router.navigate(['/main/locationmaster/action/view',locationId]);
    }
  

}
