import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LocationmasterAddEditComponent } from './locationmaster-add-edit/locationmaster-add-edit.component';
import { LocationmasterListComponent } from './locationmaster-list/locationmaster-list.component';
import { LocationmasterModule } from './locationmaster.module';

const routes: Routes = [
  {
    path: 'list',
    component: LocationmasterListComponent,
  },
  {
    path: 'action/:action/:id',
    component: LocationmasterAddEditComponent,
  },
  {
    path: 'action/:action',
    component: LocationmasterAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LocationmasterRoutingModule { }
