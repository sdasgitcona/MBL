export class BankMasterModule {
    id:number;
    subsidiaryId?: number;
    subsidiaryName:string;
    name:string;
    branch:string;
    address:string;
    accountNumber:string;
    accountType:string;
    currency:string;
    branchCode:string;
    ifscCode:string;
    iban:string;
    swiftCode:string;
    sortCode:string;
    micrCode:string
    glBank:any;
    glBankId: number;
    glExchange:any;
    glExchangeId: number;
    effectiveFrom:any;
    effectiveTo:any;
    status:string;
    active:boolean=true;
    Isactive:string;
    purchasable:boolean=true;
    inventoryType:string;
    bankPaymentInstruments: BankPaymentInstruments[] = [];
    createdBy:string;
    lastModifiedBy:string;
    glBankCode:any;
  }
  export class BankPaymentInstruments{
    id?:number;
    bankId?:number;
    type?:string;
    documentName?:string;
    documentNumberFrom?:string
    documentNumberTo?:string;
    effctiveFrom?:any;
    effctiveTo?:any;
    active?:boolean=true;
    deleted?:boolean=false;
  }
  export class CommonDropDownValue {
    id: number;
    name:string;
  }
  // Base seach model for Supplier
export class BaseSearch {
    filters: TblFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }
  export class TblFilter {
    subsidiaryName: string = '';
    name: string = '';
    active: string = '';
  }
  export class SubIdList{
    id:number;
    name:string;
   
  }

   // Base seach model for Supplier
   export class BaseSearchPdf {
    filters: BankmasterFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class BankmasterFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}
