import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BankmasterAddEditComponent } from './bankmaster-add-edit.component';

describe('BankmasterAddEditComponent', () => {
  let component: BankmasterAddEditComponent;
  let fixture: ComponentFixture<BankmasterAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BankmasterAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BankmasterAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
