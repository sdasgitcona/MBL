import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { BankMasterModule, BankPaymentInstruments, BaseSearch } from '../model/bankmaster-model';
declare let $: any;

@Component({
  selector: 'app-bankmaster-add-edit',
  templateUrl: './bankmaster-add-edit.component.html',
  styleUrls: ['./bankmaster-add-edit.component.scss']
})
export class BankmasterAddEditComponent implements OnInit {
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  private subscription: any;
  bankHistoryList: HistoryModel[] = [];
  bankId: number = 0;
  Subsidiarylist: any[] = [];
  BankMasterData: BankMasterModule = new BankMasterModule();
  totalPaymentsRow: number = 0;
  selectedBankPayment: BankPaymentInstruments = new BankPaymentInstruments();
  AccountTypeOptions: any;
  PaymentTypeOptions: any;
  CurrencyList: any[];
  AccountCodeList: any[];
  GLCodeList: any[];
  showloader: boolean = false;
  RetloginDetails: any;
  RetRoleDetails:any;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  isviewEditable: boolean = true;
  // For Role Base Access

  constructor(private HttpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,) {
    this.AccountTypeOptions = [
      { name: 'CA', code: 'CA' },
      { name: 'SB', code: 'SB' },
    ];
    this.PaymentTypeOptions = [
      { name: 'CHEQUE', code: 'CHEQUE' },
      { name: 'NEFT', code: 'NEFT' },
    ];
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Bank") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
        if (this.isEditable == false)
          this.isviewEditable = false;
      }
    }
    // End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.bankId = +params['id']; // (+) converts string 'id' to a number
            this.GetBankMasterDatabyId();
            this.LoadHistory();
          }
          this.assignMode(params['action']);
          this.GetSubsideryList();
          this.getAll_CurrencyList();
          this.GetAllAccountCodeList();
        } else {

        }
      },
      (error) => {

      }
    );
    this.totalPaymentsRow = this.BankMasterData.bankPaymentInstruments.length;
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = true;
        break;

      default:
        break;
    }
  }
  addNewRow() {
    // if (
    //   this.BankMasterData.bankPaymentInstruments.length > 0 &&
    //   this.BankMasterData.bankPaymentInstruments[length - 1] == new BankPaymentInstruments()
    // ) {
    //   return;
    // }
    this.BankMasterData.bankPaymentInstruments.push(new BankPaymentInstruments());
  }
  deleteSupplierContact(contactToDelete: BankPaymentInstruments) {
    let index = this.findIndexForContact(
      contactToDelete,
      this.BankMasterData.bankPaymentInstruments
    );
    if (index >= 0) this.BankMasterData.bankPaymentInstruments.splice(index, 1);
  }
  findIndexForContact(
    contact: BankPaymentInstruments,
    contactList: BankPaymentInstruments[]
  ): number {
    return contactList.findIndex(
      (o) =>
        o.type == contact.type &&
        o.documentName == contact.documentName &&
        o.documentNumberFrom == contact.documentNumberFrom &&
        o.documentNumberTo == contact.documentNumberTo &&
        o.effctiveFrom == contact.effctiveFrom &&
        o.effctiveTo == contact.effctiveTo
    );
  }
  //GL Account Code List
  GetAllAccountCodeList() {
    var obj = {
      filters: {
        "code": "",
        "type": "",
        "status": "",
        "subsidiaryName": []
      },
      pageNumber: 0,
      pageSize: 200,
      sortColumn: "description",
      sortOrder: "asc"
    }
    this.HttpService.Insert("/masters-ws/account/get/all", obj, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //this.AccountCodeList=res.list;
        }
      });
  }
  loadAccountDataBySubsidiary() {
    this.GetGLAccountList();
    this.GetGainExpnseAccountList();
  }

  GetGLAccountList() {
    let subsideryId = this.BankMasterData.subsidiaryId;
    //this.HttpService.GetAll(`/account/get-account-by-subsidiary?subsidiaryId=${subsideryId}&type=` + "Bank").subscribe(
    this.HttpService.GetAll(`/masters-ws/account/get-account-by-subsidiary-and-currency?subsidiaryId=${subsideryId}&type=` + "Bank" + "&currency=" + this.BankMasterData.currency, this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.AccountCodeList = res;
        }
      },
      (error) => {

      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
  }
  GetGainExpnseAccountList() {
    let subsideryId = this.BankMasterData.subsidiaryId;
    //this.HttpService.GetAll(`/account/get-account-by-subsidiary-and-currency?subsidiaryId=${subsideryId}&type=` + "Expense,Income"+"&currency=" +this.BankMasterData.currency).subscribe(
    this.HttpService.GetAll(`/masters-ws/account/get-account-by-subsidiary?subsidiaryId=${subsideryId}&type=` + "Expense,Income", this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.GLCodeList = res;
        }
      },
      (error) => {

      },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
  }
  Reload_AccountCodeList() {
    this.BankMasterData.glBank = undefined;
    this.GetGLAccountList();
  }
  Reload_ExchangeAccountList() {
    this.BankMasterData.glExchange = undefined;
    this.GetGainExpnseAccountList();
  }
  GetBankMasterDatabyId() {
    this.HttpService
      .GetById('/masters-ws/bank/get?id=' + this.bankId, this.bankId, this.RetloginDetails.token)
      .subscribe((res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.BankMasterData = res;
          this.GetGLAccountList();
          this.GetGainExpnseAccountList();
          this.BankMasterData.effectiveFrom = (this.BankMasterData.effectiveFrom) == null || (this.BankMasterData.effectiveFrom) == "" ? '' : new Date(this.BankMasterData.effectiveFrom);
          this.BankMasterData.effectiveTo = (this.BankMasterData.effectiveTo) == null || (this.BankMasterData.effectiveTo) == "" ? '' : new Date(this.BankMasterData.effectiveTo);

          for (let i = 0; i < this.BankMasterData.bankPaymentInstruments.length; i++) {
            this.BankMasterData.bankPaymentInstruments[i].effctiveFrom = (this.BankMasterData.bankPaymentInstruments[i].effctiveFrom) == null || (this.BankMasterData.bankPaymentInstruments[i].effctiveFrom) == "" ? '' : new Date(this.BankMasterData.bankPaymentInstruments[i].effctiveFrom);
            this.BankMasterData.bankPaymentInstruments[i].effctiveTo = (this.BankMasterData.bankPaymentInstruments[i].effctiveTo) == null || (this.BankMasterData.bankPaymentInstruments[i].effctiveTo) == "" ? '' : new Date(this.BankMasterData.bankPaymentInstruments[i].effctiveTo);
          }
        }
      });
  }
  GetSubsideryList_old() {
    this.HttpService.GetAll('/setup-ws/subsidiary/get/all', this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.Subsidiarylist = res.list;
        }
      },
      (error) => {

      }
    );
  }
  GetSubsideryList() {
    this.Subsidiarylist=[];
  
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist=res;

      }
      },
      (error) => {
        
       },
       ()=>{

       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
     
    }
  }
  getAllSubsidiaryReloadList() {
    //$('.refsubsidery').addClass('fa-spin');
    this.BankMasterData.subsidiaryId = 0;
    this.GetSubsideryList();
    this.BankMasterData.currency = '';
    this.AccountCodeList = [];
    this.BankMasterData.glBank = undefined;
    // $('.refsubsidery').removeClass('fa-spin');
  }
  //Currency List
  getAll_CurrencyList() {
    this.HttpService.GetAll("/setup-ws/currency/get/all", this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.CurrencyList = res;
        }
      });
  }
  Reload_CurrencyList() {
    this.BankMasterData.currency = '';
    this.AccountCodeList = [];
    this.BankMasterData.glBank = undefined;
    this.getAll_CurrencyList();
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  /* Start fetching History details */
  LoadHistory() {
    if (this.bankHistoryList.length == 0)
      this.HttpService
        .GetById(
          `/masters-ws/bank/get/history?id=${this.bankId}&pageSize=100`,
          this.bankId, this.RetloginDetails.token
        )
        .subscribe((res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.bankHistoryList = res;
          }
        });
  }
  /* End fetching History details */
  //Event for Tab change
  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 0) {
      this.LoadHistory();
    }
  }
  //Save and edit bank details
  saveBankMaster() {
    this.showloader = true;
    if (this.BankMasterData.subsidiaryId !== undefined && this.BankMasterData.name !== undefined && this.BankMasterData.branch !== undefined &&
      this.BankMasterData.accountNumber !== undefined && this.BankMasterData.accountType !== undefined && this.BankMasterData.currency !== undefined
    ) {

      if (this.BankMasterData.branch == undefined || this.BankMasterData.branch == "") {
        this.showAlert('Enter Branch Name !');
        this.showloader = false;
        return false;
      }
      if (this.BankMasterData.accountNumber == undefined || this.BankMasterData.accountNumber == "") {
        this.showAlert('Enter Account Number !');
        this.showloader = false;
        return false;
      }
      if (this.BankMasterData.glBank == undefined || this.BankMasterData.glBank == "") {
        this.showAlert('Select GL Account !');
        this.showloader = false;
        return false;
      }
      if (this.BankMasterData.effectiveFrom == undefined || this.BankMasterData.effectiveFrom == null) {
        this.showAlert('Enter Effective From Date !');
        this.showloader = false;
        return false;
      }
      if (this.BankMasterData.effectiveTo != undefined || this.BankMasterData.effectiveTo != null) {
        if (new Date(this.BankMasterData.effectiveFrom) >= new Date(this.BankMasterData.effectiveTo)) {
          this.showAlert("Effective To must be greater than Effective From");
          this.showloader = false;
          return;
        }
      }
      // for (let i = 0; i < this.BankMasterData.bankPaymentInstruments.length; i++) {
      //   if (this.BankMasterData.bankPaymentInstruments[i].type == undefined && this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
      //     this.showAlert("Select Payment Type Row: " + (i + 1));
      //     this.showloader = false;
      //     return false;
      //   }
      //   else if (this.BankMasterData.bankPaymentInstruments[i].documentName == undefined || this.BankMasterData.bankPaymentInstruments[i].documentName == "" && this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
      //     this.showAlert("Enter Doc Name of Row: " + (i + 1));
      //     this.showloader = false;
      //     return false;
      //   }
      //   else if (this.BankMasterData.bankPaymentInstruments[i].documentNumberFrom == undefined || this.BankMasterData.bankPaymentInstruments[i].documentNumberFrom == "" && this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
      //     this.showAlert("Enter Doc Number From of Row: " + (i + 1));
      //     this.showloader = false;
      //     return false;
      //   }
      //   else if (this.BankMasterData.bankPaymentInstruments[i].effctiveTo != undefined || this.BankMasterData.bankPaymentInstruments[i].effctiveTo != null && this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
      //     if (this.BankMasterData.bankPaymentInstruments[i].effctiveFrom == undefined || this.BankMasterData.bankPaymentInstruments[i].effctiveFrom == null || this.BankMasterData.bankPaymentInstruments[i].effctiveFrom == "" && this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
      //       this.showAlert('Enter Effective From Date of Row: ' + (i + 1));
      //       this.showloader = false;
      //       return false;
      //     }
      //     else if (new Date(this.BankMasterData.bankPaymentInstruments[i].effctiveFrom) >= new Date(this.BankMasterData.bankPaymentInstruments[i].effctiveTo) && this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
      //       this.showAlert("Effective To must be greater than Effective From of Row: " + (i + 1));
      //       this.showloader = false;
      //       return;
      //     }
      //   }
      // }
      for (let i = 0; i < this.BankMasterData.bankPaymentInstruments.length; i++) {
        if (this.BankMasterData.bankPaymentInstruments[i].type == undefined && this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
          this.showAlert("Select Payment Type Row: " + (i + 1));
          this.showloader = false;
          return false;
        }
        else if ((this.BankMasterData.bankPaymentInstruments[i].documentName == undefined || this.BankMasterData.bankPaymentInstruments[i].documentName == "" )&& this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
          this.showAlert("Enter Doc Name of Row: " + (i + 1));
          this.showloader = false;
          return false;
        }
        else if ((this.BankMasterData.bankPaymentInstruments[i].documentNumberFrom == undefined || this.BankMasterData.bankPaymentInstruments[i].documentNumberFrom == "" )&& this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
          this.showAlert("Enter Doc Number From of Row: " + (i + 1));
          this.showloader = false;
          return false;
        }
        else if (this.BankMasterData.bankPaymentInstruments[i].effctiveTo != undefined || this.BankMasterData.bankPaymentInstruments[i].effctiveTo != null && this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
          if (this.BankMasterData.bankPaymentInstruments[i].effctiveFrom == undefined || this.BankMasterData.bankPaymentInstruments[i].effctiveFrom == null || this.BankMasterData.bankPaymentInstruments[i].effctiveFrom == "" && this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
            this.showAlert('Enter Effective From Date of Row: ' + (i + 1));
            this.showloader = false;
            return false;
          }
          else if (new Date(this.BankMasterData.bankPaymentInstruments[i].effctiveFrom) >= new Date(this.BankMasterData.bankPaymentInstruments[i].effctiveTo) && this.BankMasterData.bankPaymentInstruments[i].deleted!=true) {
            this.showAlert("Effective To must be greater than Effective From of Row: " + (i + 1));
            this.showloader = false;
            return;
          }
        }
      }
      let SplittedData=this.BankMasterData.glBank.split('-')
      this.BankMasterData.glBankCode=SplittedData[0];
      if (this.addMode) {
        this.BankMasterData.createdBy = this.RetloginDetails.username; this.BankMasterData.lastModifiedBy = this.RetloginDetails.username
      }
      else if (!this.addMode) {
        this.BankMasterData.lastModifiedBy = this.RetloginDetails.username
      }
      this.HttpService.Insert('/masters-ws/bank/save', this.BankMasterData, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.id > 0) {
              this.showloader = false;
              //this.saveAddress();
              this.showSuccess();
              if(this.addMode){
                this.router.navigate(['/main/bankmaster/action', 'view',res.id]);
              }else{
                this.router.navigate(['/main/bankmaster/list']);
              }
            } else {
              this.showloader = false;
              this.showError();

            }
          }
        },
        (error) => {
          this.showloader = false;
          this.showAlert(error);
        },
        () => { }
      );
    }
    else {
      if (this.BankMasterData.subsidiaryId == undefined) {
        this.showAlert('Select Subsidiary !');
        this.showloader = false;
      }
      else if (this.BankMasterData.name == undefined || this.BankMasterData.name == "") {
        this.showAlert('Enter Bank Name !');
        this.showloader = false;
      }
      else if (this.BankMasterData.branch == undefined || this.BankMasterData.branch == "") {
        this.showAlert('Enter Branch Name !');
        this.showloader = false;
      }
      else if (this.BankMasterData.accountNumber == undefined || this.BankMasterData.accountNumber == "") {
        this.showAlert('Enter Account Number !');
        this.showloader = false;
      }
      else if (this.BankMasterData.accountType == undefined) {
        this.showAlert('Select Account Type !');
        this.showloader = false;
      }
      else if (this.BankMasterData.currency == undefined) {
        this.showAlert('Select Currency !');
        this.showloader = false;
      }
      else if (this.BankMasterData.glBank == undefined) {
        this.showAlert('Select GL Account !');
        this.showloader = false;
      }

    }
  }
  //Reset the form
  clearData() {
      this.router.navigate(['/main/bankmaster/list']);
  }
  handleToggleprimerycontact(event: any, index: any) {
    event.originalEvent.cancelBubble = true;
    this.BankMasterData.bankPaymentInstruments.map(function (val: any, i: any) {
      if (event.checked && index != i) {
        val.primaryContact = false;
      }
    })
  }
  deleterowlevel(index: number) {


    if (this.addMode) {
      if (index >= 0) this.BankMasterData.bankPaymentInstruments.splice(index, 1);
    }
    else {
      this.BankMasterData.bankPaymentInstruments[index].deleted = true;
    }
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Data Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving!'
    );
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

}
