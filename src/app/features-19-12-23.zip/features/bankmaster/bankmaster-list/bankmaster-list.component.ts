import { Component, OnInit,LOCALE_ID, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BankMasterModule, BankPaymentInstruments, BaseSearch,BaseSearchPdf } from '../model/bankmaster-model';
import { PrimeNGConfig } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import {formatDate } from '@angular/common';
import * as FileSaver from 'file-saver';
@Component({
  selector: 'app-bankmaster-list',
  templateUrl: './bankmaster-list.component.html',
  styleUrls: ['./bankmaster-list.component.scss']
})
export class BankmasterListComponent implements OnInit {

  //Declare Variables
  bankDetails: BankMasterModule = new BankMasterModule();
  selectedBankList: BankMasterModule = new BankMasterModule();
  retBankDataList: BankMasterModule[] = [];
  columns: any[];
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  Subsidiarylist: any[] = [];
  BankList: any[];
  showloader: boolean = false;
  issubsidiaryhidden:boolean=false;
  issubsidiarydisable:boolean=false;
  CurrencyList:any[];
 baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
 BankPrint: any[] = [];
  newevent: any;
  activeOption:any;
  SubIdList:any=[];
  RetRoleDetails:any;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  // For Role Base Access
  AccountTypeOptions:any;
  RetloginDetails: any;


  SubSidiarylist: BankMasterModule[] = [];
bankmaster: any;
statusOption: any[];

  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private toastService: ToastService,
    private HttpService: CommonHttpService, private primengConfig: PrimeNGConfig,@Inject(LOCALE_ID) public locale: string) 
    { 
      this.statusOption = [{id:'Active',name:"Active"},{id:'Inactive',name:"Inactive"}];
    }
   
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Bank") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
      }
    }
    // End For Role Base Access

    this.GetSubsideryList();
    this.getAll_CurrencyList();
    //this.GetAllBankList();
    this.primengConfig.ripple = true;
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
      { field: 'Id', header: 'Sl No' },
      { field: 'Subsidiaries', header: 'Internal ID' },
      { field: 'Bank Name', header: 'Subsidiaries' },
      { field: 'Branch Name', header: 'Bank Name' },
      { field: 'Account Number', header: 'Branch Name' },
      { field: 'Currency', header: 'Account Number' },
      { field: 'Status', header: 'Account Type' },
    ];
    this.AccountTypeOptions = [
      { name: 'CA', code: 'CA' },
      { name: 'SB', code: 'SB' },
    ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }
  navigateToAddViewEdit(
    action: string,
    selectedBankList: BankMasterModule = new BankMasterModule()
  ) {
    let BankId = null;
    if (selectedBankList?.id) {
      BankId = selectedBankList.id;
      this.router.navigate(['/main/bankmaster/action', action, BankId]);
    } else {
      this.router.navigate(['/main/bankmaster/action', action]);
    }

  }
  //Lazy load Get All Bank
  loadBankList(event: any) {
    try {
      this.newevent = event
      this.loading = true;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
      this.baseSearch.pageSize = event.rows;
      this.baseSearch.sortColumn = event.sortField
        ? event.sortField
        : GlobalConstants.BANKMASTER_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
          if(this.SubIdList.length==0 && this.RetloginDetails.userType!='ROOTADMIN'){return;}
      this.HttpService.Insert('/masters-ws/bank/get/all', this.baseSearch, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.list.length > 0) {
              this.retBankDataList = res.list;
              if (this.baseSearch.filters && (Object.keys(this.baseSearch.filters).length === 0)) {
                this.SubSidiarylist = res.list;
              }
              this.totalRecords = res.totalRecords;
            } else {
              this.retBankDataList = [];
            }
            this.loading = false;
          }
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {

    }
  }
  //List page search function
  findby(event: any) {
    let subsidyList:any=[];
    subsidyList.push(this.bankDetails.subsidiaryId);
    //alert(this.bankDetails.accountType);
    //alert(this.bankDetails.currency);
    this.baseSearch.filters = {
      subsidiaryId: subsidyList,
      name: this.bankDetails.name,
      status: this.bankDetails.active == true ? 'true' : 'false',//this.bankDetails.active == false ? "":this.bankDetails.active== true?"ACTIVE":"INACTIVE"
      accountType:this.bankDetails.accountType,
      currency:this.bankDetails.currency
    }
    this.baseSearch.pageNumber=-1;
    this.loadBankList(this.newevent);
  }
  //Get allSubsidiary for lov
  GetSubsideryList_old() {
    this.HttpService.GetAll('/setup-ws/subsidiary/get/all', this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.Subsidiarylist = res.list;
        }
      },
      (error) => {
      }
    );
  }
  GetSubsideryList() {
    this.Subsidiarylist=[];
  
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist=res;
        for(let x=0;x<this.Subsidiarylist.length;x++)
       { 
        this.SubIdList.push(this.Subsidiarylist[x].id);
      }
      this.issubsidiaryhidden=false;
      this.issubsidiarydisable=false;
      }
      },
      (error) => {
        alert(error);
       },
       () => {
        if(localStorage.getItem("BankFilters") != null)
        {const LocDetails:any =localStorage.getItem("BankFilters");
        let RetLocDetails = JSON.parse(LocDetails);
        this.baseSearch=RetLocDetails;
        let searcheData:any = RetLocDetails;
        this.bankDetails.subsidiaryId=searcheData.filters.subsidiaryId[0];
        this.bankDetails.name=searcheData.filters.name;
        this.bankDetails.active=searcheData.filters.status=="true"?true:false;
        this.loadBankList(this.newevent);
        localStorage.removeItem("BankFilters");
        }
        else
       { this.resetBaseSearch();}
      }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
      this.bankDetails.subsidiaryId= this.Subsidiarylist[0].id;
      this.GetAllBankList(this.Subsidiarylist[0].id);
      this.issubsidiaryhidden=true;
      this.issubsidiarydisable=true;
      if(localStorage.getItem("BankFilters") != null)
      {const LocDetails:any =localStorage.getItem("BankFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.bankDetails.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.bankDetails.name=searcheData.filters.name;
      this.bankDetails.active=searcheData.filters.status=="true"?true:false;
      this.loadBankList(this.newevent);
      localStorage.removeItem("BankFilters");
      }
      else
     { this.resetBaseSearch();}
    }
  }

  //Reload Subsidiary lov
  getAllSubsidiaryReloadList() {
    //$('.refsubsidery').addClass('fa-spin');
    this.bankDetails.subsidiaryName = '';
    this.GetSubsideryList();
    // $('.refsubsidery').removeClass('fa-spin');
  }
  GetAllBankList(subsidiaryId:any) {
    this.HttpService.GetById("/masters-ws/bank/get-by-subsidiary-id?subsidiaryId="+ subsidiaryId,subsidiaryId, this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.BankList = res;
        }
      });
  }

  //set search criteria
  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.BANKMASTER_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadBankList(this.newevent);
  }
  //Export pdf function
 /* exportPdf() {
    import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
        const doc = new jsPDF.default();
        (doc as any).autoTable(this.exportColumns, this.retBankDataList);
        doc.save('Bank.pdf');
      })
    })
  }*/
  //reset in list page
  Reset() {
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
    this.bankDetails.subsidiaryId = undefined;
    }
    else if(this.RetloginDetails.userType=='ENDUSER')
    {
      this.GetAllBankList(this.bankDetails.subsidiaryId)
    }
    this.bankDetails.name = "";
    this.bankDetails.active = true;
    this.BankList=[];
    this.resetBaseSearch();
  }

  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("BankFilters") != null)
    {
      localStorage.removeItem("BankFilters");
    }
    localStorage.setItem("BankFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/bankmaster/action', actionType, mainId]);
   }


   /***((Export Excel)) */
   generatePDFData(exportType:any){
    this.newevent = event;
    this.baseSearchPdf.pageSize = this.totalRecords;
    this.baseSearchPdf.sortColumn =GlobalConstants.BANKMASTER_TABLE_SORT_COLUMN;
    this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};

    this.HttpService.Insert('/masters-ws/bank/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          //this.employeelistPrint = [];
          this.BankPrint = [];
          if (res && res.list.length > 0) {
            var RetData = res.list;
            for (let i = 0; i < RetData.length; i++) {

              if (RetData[i].id == undefined) {
                RetData[i].id = "";
              }
              if(exportType == 'PDF'){ 
    
                this.BankPrint.push({
                  'Id': RetData[i].id,    
                  'Subsidiaries':RetData[i].subsidiaryName, 
                  'Bank Name':  RetData[i].name,
                  'Branch Name': RetData[i].branch,
                  'Account Number': RetData[i].accountNumber,
                  'Currency': RetData[i].currency, 
                  'Status': RetData[i].active,
              
                  // 
                  
              });
            }
              else{
                this.BankPrint.push({
                  'Internal Id': RetData[i].id,    
                  'Subsidiaries':RetData[i].subsidiaryName, 
                  'Bank Name':  RetData[i].name,
                  'Branch Name': RetData[i].branch,
                  'Account Number': RetData[i].accountNumber,
                  'Currency': RetData[i].currency, 
                  'Status': RetData[i].active,
                });
              }

            }
          }
          if(exportType == 'PDF')
          {this.exportPdf();}
        }
      }
    );
  }
  exportPdf() {
    import("jspdf").then(jsPDF => {
      import("jspdf-autotable").then(x => {
        const doc = new jsPDF.default();
        //this.= this.employeeExport;
        //this.employeelist=[];
        (doc as any).autoTable(this.exportColumns, this.BankPrint);
        doc.save('Bank.pdf');
      })
    })
  }

//End PDF

//Start Excel
exportExcel() {
  this.showloader=true
  this.generatePDFData('');

 setTimeout(() => {
  this.exportExcelData()
 }, 250);
  }
  exportExcelData()
  {
    if(this.BankPrint.length >0)
    { import('xlsx').then((xlsx) => {
         const worksheet = xlsx.utils.json_to_sheet(this.BankPrint);
         const workbook = { 
             Sheets: { data: worksheet }, 
             SheetNames: ['data'] 
         };
         const excelBuffer: any = xlsx.write(workbook, {
             bookType: 'csv',
             type: 'array',
         });
         this.saveAsExcelFile(excelBuffer, 'Bank');
         this.showloader=false;
     });}
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
      let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
      let EXCEL_EXTENSION = '.csv';
      const data: Blob = new Blob([buffer], {
          type: EXCEL_TYPE,
      });
      FileSaver.saveAs(
          data, fileName + EXCEL_EXTENSION
          //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
      );
  }
//End Excel 
  //List Export option End

   /********Export excel */
   getAll_CurrencyList() {
    this.HttpService.GetAll("/setup-ws/currency/get/all", this.RetloginDetails.token)
      .subscribe(res => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.CurrencyList = res;
        }
      });
  }


  onRowSelect(event: any) {
    let BankId = event.data.id;
    
    this.router.navigate(['/main/bankmaster/action/view',BankId]);
  }
}
