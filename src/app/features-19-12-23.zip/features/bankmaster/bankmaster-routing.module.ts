import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BankmasterListComponent } from './bankmaster-list/bankmaster-list.component';
import { BankmasterAddEditComponent } from './bankmaster-add-edit/bankmaster-add-edit.component';
import { BankmasterModule } from './bankmaster.module';
const routes: Routes = [
  {
    path: 'list',
    component: BankmasterListComponent,
  },
  {
    path: 'action/:action/:id',
    component: BankmasterAddEditComponent,
  },
  {
    path: 'action/:action',
    component: BankmasterAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BankmasterRoutingModule { }
