export class fiscalCalendarModule {
    id?:any;
    name?: string;
    yearName?: string;
    startMonth?:string;
    endMonth?:string;
    subsidiaryId?:number;
    subsidiaryName?: string;
    fiscalCalanderAccounting?: string;
    fiscalCalender?: boolean;
    taxCalender?: boolean;
    internalID?: any;
    status?: string;
}
export class fiscalCalendarSaveModule {
    id:number;
    name: string;
    startMonth:string;
    endMonth:string;
    subsidiaryId:number;
    fiscalCalender: boolean;
    taxCalender: boolean;
    active: boolean=true;
    fiscalCalanderAccounting: fiscalCalanderAccounting[]=[];
    createdBy:string;
    lastModifiedBy:string;
    accountId:any;
}
export class fiscalCalanderAccounting {
    id?:number;
    yearName?: string;
    yearCompleted?:boolean;
    startYear?:any;
    endYear?:any;
    month?:string;
    fromDate?:string;
    toDate?:string;
    lock?:any;
    periodOpen?: any=false;
    periodClose?: any=false;
    fiscalId?:number;
    openClose?: boolean;
    disableColumn?: boolean=false;
    disableStartColumn?: boolean=true;
    disableIsPeriodClose?: boolean=true;
}
export class BaseSearch {
    filters: TblFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }
  export class TblFilter {
    subsidiaryName: string = '';
    name: string = '';
    active: string = '';
  }

    // Base seach model for Supplier
    export class BaseSearchPdf {
        filters: FiscalCalenderFilter | {} = {};
        pageNumber: number = 0;
        pageSize: number = 0;
        sortColumn: string = '';
        sortOrder: string = '';
      }
    
    //this class holds the custom filter values at component level.
    export class FiscalCalenderFilter {
      subsidiary: string = '';
      vendorname: string = '';
      vendornumber: string = '';
      vendortype: string = '';
      pan: string = '';
      active: string = '';
    }
    