import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FiscalCalenderAddEditComponent } from './fiscal-calender-add-edit.component';

describe('FiscalCalenderAddEditComponent', () => {
  let component: FiscalCalenderAddEditComponent;
  let fixture: ComponentFixture<FiscalCalenderAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FiscalCalenderAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FiscalCalenderAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
