import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BaseSearch, fiscalCalendarModule, fiscalCalendarSaveModule, fiscalCalanderAccounting } from '../model/fiscal-calender-model';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { PrimeNGConfig } from 'primeng/api';
import { ToastService } from 'src/app/core/services/toast.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
@Component({
  selector: 'app-fiscal-calender-add-edit',
  templateUrl: './fiscal-calender-add-edit.component.html',
  styleUrls: ['./fiscal-calender-add-edit.component.scss']
})
export class FiscalCalenderAddEditComponent implements OnInit {
  TABsubsidiary: any[];
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  closeMode: boolean = false;
  specialMode: boolean = true;
  NewRowFiscalYR: boolean = false;
  Subsidiarylist: any[] = [];
  private subscription: any;
  fiscalCalendarSaveModule = new fiscalCalendarSaveModule();
  fCalanderAccounting: fiscalCalanderAccounting[] = [];
  DistinctCalander: fiscalCalanderAccounting[] = [];
  ParentCalender: fiscalCalanderAccounting[] = [];
  FullCalender: fiscalCalanderAccounting[] = [];
  fiscalHistoryList: HistoryModel[] = [];
  mainId: number = 0;
  FirstFiscalMonth: any[];
  selectedCalender = new fiscalCalanderAccounting();
  selectedIndex: any;
  showloader: boolean = false;
  RetloginDetails: any;
  RetRoleDetails:any;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  isviewEditable: boolean = true;
  // For Role Base Access
  newYearVisible:boolean=true;
  constructor(private routeStateService: RouteStateService, private activatedRoute: ActivatedRoute,
    private router: Router, private toastService: ToastService,
    private HttpService: CommonHttpService, private primengConfig: PrimeNGConfig) {
    this.FirstFiscalMonth = [
      { name: 'January', code: 'January' },
      { name: 'February', code: 'February' },
      { name: 'March', code: 'March' },
      { name: 'April', code: 'April' },
      { name: 'May', code: 'May' },
      { name: 'June', code: 'June' },
      { name: 'July', code: 'July' },
      { name: 'August', code: 'August' },
      { name: 'September', code: 'September' },
      { name: 'October', code: 'October' },
      { name: 'November', code: 'November' },
      { name: 'December', code: 'December' },
    ];
    this.TABsubsidiary = [
      { brand: 'Apple' }
    ];

  }

  ngOnInit(): void {

    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails=role_Dtls;
    const LDetails:any=localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);

    this.fiscalCalendarSaveModule.accountId=this.RetRoleDetails[0].accountId;

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "Fiscal Calendar") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
        if (this.isEditable == false)
          this.isviewEditable = false;
      }
    }
    // End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.mainId = +params['id']; // (+) converts string 'id' to a number
            this.GetMasterDatabyId();
            //this.LoadHistory();
          }
          this.assignMode(params['action']);
          this.GetSubsideryList();
        } else {
          //console.log('cannot get params');
        }
      },
      (error) => {
        //console.log('add');
      });
    //this.DistinctCalander=[];
    this.fiscalCalendarSaveModule.fiscalCalanderAccounting.push(new fiscalCalanderAccounting());
    this.DistinctCalander.push(new fiscalCalanderAccounting());
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        this.closeMode = true;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.closeMode = false;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.closeMode = false;
        break;

      default:
        break;
    }
  }
  //--[Edit Mode]: Get Fiscal All Data By Id
  GetMasterDatabyId() {
    this.HttpService.GetById("/setup-ws/fiscal-calender/get?id=" + this.mainId, this.mainId ,this.RetloginDetails.token)
      .subscribe(res => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.fiscalCalendarSaveModule = res;
            if (this.fiscalCalendarSaveModule.fiscalCalanderAccounting.length > 0) {
              let DistinctValue = this.fiscalCalendarSaveModule.fiscalCalanderAccounting.filter((thing, i, arr) => arr.findIndex(t => t.startYear === thing.startYear && t.endYear === thing.endYear) === i);
              this.DistinctCalander = [];
              for (let i = 0; i < DistinctValue.length; i++) {
                //DistinctValue[i].startYear=new Date(DistinctValue[i].startYear);
                //DistinctValue[i].endYear= DistinctValue[i].endYear;
                DistinctValue[i].openClose = false;
                DistinctValue[i].disableStartColumn = false;
                this.DistinctCalander.push(DistinctValue[i]);
              }
              this.fiscalCalendarSaveModule.fiscalCalanderAccounting = [];
            }
        }
        //console.log(res);
        


      });
  }
  GetPreviousMonth() {
    if (this.fiscalCalendarSaveModule.startMonth != undefined) {
      let monthNumber: any = this.getmonthNumber(this.fiscalCalendarSaveModule.startMonth);
      monthNumber = monthNumber == 1 ? 11 : monthNumber - 2; //If January Then Index 11 else endex -2
      var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      var RetData = months[monthNumber];
      this.fiscalCalendarSaveModule.endMonth = RetData;

      for (let k = 0; k < this.DistinctCalander.length; k++) {
        if(this.DistinctCalander[k].startYear != undefined)
        {
          if (this.getmonthNumber(this.fiscalCalendarSaveModule.startMonth) == 1) {
          this.DistinctCalander[k].endYear = new Date(this.DistinctCalander[k].startYear).getFullYear()
        }
        else {
          this.DistinctCalander[k].endYear = new Date(this.DistinctCalander[k].startYear).getFullYear() + 1;
        }
        this.DistinctCalander[k].openClose=false;
        this.fiscalCalendarSaveModule.fiscalCalanderAccounting=[];
      }
      }

    }
  }
  getmonthNumber(MonthName: any) {
    var monthNo;
    if (MonthName == "January") {
      monthNo = 1;
    }
    else if (MonthName == "February") {
      monthNo = 2;
    }
    else if (MonthName == "March") {
      monthNo = 3;
    }
    else if (MonthName == "April") {
      monthNo = 4;
    }
    else if (MonthName == "May") {
      monthNo = 5;
    }
    else if (MonthName == "June") {
      monthNo = 6;
    }
    else if (MonthName == "July") {
      monthNo = 7;
    }
    else if (MonthName == "August") {
      monthNo = 8;
    }
    else if (MonthName == "September") {
      monthNo = 9;
    }
    else if (MonthName == "October") {
      monthNo = 10;
    }
    else if (MonthName == "November") {
      monthNo = 11;
    }
    else if (MonthName == "December") {
      monthNo = 12;
    }

    return monthNo;
  }

  GetSubsideryList_old() {
    this.HttpService.GetAll('/setup-ws/subsidiary/get/all',this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
  if(res.status == 401)
  { this.showAlert("Unauthorized Access !");
    this.router.navigate(['/login']);
  }
  else if(res.status == 404)
  { this.showAlert("Wrong/Invalid Token!");
     this.router.navigate(['/login']);
   }
else
{this.Subsidiarylist = res.list;}
        
      },
      (error) => {
        //console.log(error);
      }
    );
  }

  GetSubsideryList() {
    this.Subsidiarylist=[];
  
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN' )
    {
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       { this.Subsidiarylist=res;
       
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
       
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
   
    }
  }
  getAllSubsidiaryReloadList() {
    this.fiscalCalendarSaveModule.subsidiaryId = 0;
    this.GetSubsideryList();
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  /* Start fetching History details */
  LoadHistory() {
    if (this.fiscalHistoryList.length == 0)
      this.HttpService
        .GetById(
          `/setup-ws/fiscal-calender/get/history?id=${this.mainId}&pageSize=10000`,
          this.mainId,this.RetloginDetails.token
        )
        .subscribe((res) => {

          //For Auth
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
          else
          {  this.fiscalHistoryList = res;}


          // console.log(res);
        
        });
  }
  /* End fetching History details */

  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 1) {
      this.LoadHistory();
    }
  }
  clearData() {
    this.router.navigate(['/main/fiscalcalendar/list']);
    /*if (this.closeMode) {
      this.fiscalCalendarSaveModule = new fiscalCalendarSaveModule();
      this.DistinctCalander[0].yearName = "";
      this.DistinctCalander[0].startYear = "";
      this.DistinctCalander[0].endYear = "";
      this.DistinctCalander[0].openClose = false;
    } else {
      this.router.navigate(['/main/fiscalcalendar/list']);
    }*/
  }
  //--Save And Update Full Data
  saveData() {
    if (this.fiscalCalendarSaveModule.name != undefined && this.fiscalCalendarSaveModule.startMonth != undefined
      && this.fiscalCalendarSaveModule.endMonth != undefined && this.DistinctCalander[0].endYear != undefined) {
      //let DistinctValue2= this.DistinctCalander.filter((thing, i, arr)=> arr.findIndex(t=>t.openClose === thing.openClose)===i);
      let DistinctValue = this.DistinctCalander.filter((data) => data.openClose == true);
      if (DistinctValue.length == 0) {
        this.showAlert('No Calendar List Found!');
        return false;
      }
      else {
        if (this.editMode == false && DistinctValue[0].yearName == undefined || this.editMode == true && DistinctValue[0].yearName == "") {
          this.showAlert('Enter Fiscal Year Name !');
          return false;
        }
      }
      for (let i = 0; i < this.fiscalCalendarSaveModule.fiscalCalanderAccounting.length; i++) {

        if(this.fiscalCalendarSaveModule.fiscalCalanderAccounting[i].lock== false && this.fiscalCalendarSaveModule.fiscalCalanderAccounting[i].periodOpen== false && this.fiscalCalendarSaveModule.fiscalCalanderAccounting[i].periodClose== false)
        {
          this.showAlert('Please turn on either Lock, Open or Close for the month - ' + this.fiscalCalendarSaveModule.fiscalCalanderAccounting[i].month);
          return false;
        }
        this.fiscalCalendarSaveModule.fiscalCalanderAccounting[i].fiscalId = this.fiscalCalendarSaveModule.id;
        this.fiscalCalendarSaveModule.fiscalCalanderAccounting[i].yearName = DistinctValue[0].yearName;
        this.fiscalCalendarSaveModule.fiscalCalanderAccounting[i].startYear = new Date(DistinctValue[0].startYear).getFullYear();
        this.fiscalCalendarSaveModule.fiscalCalanderAccounting[i].endYear = DistinctValue[0].endYear;
      }

      //For Save API Call
        if(this.addMode){
          this.fiscalCalendarSaveModule.createdBy=this.RetloginDetails.username;this.fiscalCalendarSaveModule.lastModifiedBy=this.RetloginDetails.username
          }
        else if(!this.addMode){
          this.fiscalCalendarSaveModule.lastModifiedBy=this.RetloginDetails.username
          }
    this.showloader=true;
     this.HttpService.Insert('/setup-ws/fiscal-calender/save', this.fiscalCalendarSaveModule,this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
          else
          {
            if (res && res.id > 0) {
              this.showSuccess();

              if(this.addMode){
                this.router.navigate(['/main/fiscalcalendar/action', 'view',res.id]);
              } else {
                this.router.navigate(['/main/fiscalcalendar/list']);
              }
    

              
            } else {
              this.showError();
            }
          }
          this.showloader=false;
        },
        (error) => {
          //console.log('error-' + error);
          this.showAlert(error);
        },
        () => { }
      );
    }
    else {
      if (this.fiscalCalendarSaveModule.name == undefined || this.fiscalCalendarSaveModule.name == "") {
        this.showAlert('Enter Name !');
      }
      else if (this.fiscalCalendarSaveModule.startMonth == undefined || this.fiscalCalendarSaveModule.startMonth == "") {
        this.showAlert('Select Start Month !');
      }
      else if (this.fiscalCalendarSaveModule.endMonth == undefined || this.fiscalCalendarSaveModule.endMonth == "") {
        this.showAlert('Select End Month !');
      }
      else if (this.DistinctCalander[0].endYear == undefined || this.DistinctCalander[0].endYear == "") {
        this.showAlert('No Calendar Found!');
      }
    }
  }
  fnShowNextYear(date: any, index: any) {

    this.selectedCalender = this.DistinctCalander[index];//this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index];
    //if(this.selectedCalender.openClose == undefined){
    if (this.fiscalCalendarSaveModule.endMonth != undefined && this.DistinctCalander[index].startYear != undefined) {

      for(let j=0;j<this.DistinctCalander.length;j++)
      {
        let InputDate=new Date(this.DistinctCalander[index].startYear).getFullYear()
      if(j !== index && InputDate== this.DistinctCalander[j].startYear)
      {
        this.showAlert("Same Year not allowed !");

        this.DistinctCalander[index].startYear=undefined;
        this.DistinctCalander[index].startYear="";
        this.DistinctCalander[index].endYear=undefined;
        this.DistinctCalander[index].endYear="";
       return false;
      }
      else if(j !== index && this.DistinctCalander[j].endYear > InputDate)
      {
        this.showAlert("Selected Year must be greater than previous end year !");
        this.DistinctCalander[index].startYear=undefined;
        this.DistinctCalander[index].startYear="";
        this.DistinctCalander[index].endYear=undefined;
        this.DistinctCalander[index].endYear="";
        return false;
      }
      }

      if (this.fiscalCalendarSaveModule.endMonth == "December") {
        this.DistinctCalander[index].startYear = new Date(this.DistinctCalander[index].startYear);
        this.DistinctCalander[index].endYear = new Date(this.DistinctCalander[index].startYear).getFullYear();
      }
      else {
        this.DistinctCalander[index].endYear = new Date(this.DistinctCalander[index].startYear).getFullYear() + 1;
        this.DistinctCalander[index].startYear = new Date(this.DistinctCalander[index].startYear);
      }
      this.DistinctCalander[index].disableStartColumn = true;
    }
    else {
      this.showAlert('Select Start Month !');
    }
    //} 
  }
  //--Generate 12 Months Calender
  fnCreate12Months(data: fiscalCalanderAccounting, Index: any, FiscalId: any, event: any) {
    if (this.DistinctCalander[Index].openClose == true && this.DistinctCalander[Index].endYear != undefined || this.DistinctCalander[Index].openClose == true && this.DistinctCalander[Index].endYear != "") {
      if (this.DistinctCalander[Index].endYear == undefined || this.DistinctCalander[Index].endYear == "") {
        this.DistinctCalander[Index].openClose = false;
        this.showAlert("Enter Start & End Year For Generate Calendar");
        return false;
      }
      if (this.DistinctCalander[Index].startYear == undefined || this.DistinctCalander[Index].startYear == "")
      {
        this.showAlert("Enter Start Year For Generate Calendar");
        this.DistinctCalander[Index].openClose;
        return false;
      }
        
      // if(this.DistinctCalander[Index].openClose == true)
      // {
      //   this.DistinctCalander[Index].disableStartColumn=true;
      // }
      // else
      // {
      //     this.DistinctCalander[Index].disableStartColumn=false;
      // }
      event.originalEvent.cancelBubble = true;
      this.DistinctCalander.map(function (val: any, i: any) {
        if (event.checked && Index != i) {
          val.openClose = false;
        }
      });
      if (FiscalId != null) {
        this.HttpService.GetById("/setup-ws/fiscal-calender/get?id=" + FiscalId, FiscalId,this.RetloginDetails.token)
          .subscribe(res => {

            //For Auth
                if(res.status == 401)
                { this.showAlert("Unauthorized Access !");
                  this.router.navigate(['/login']);
                }
                else if(res.status == 404)
                { this.showAlert("Wrong/Invalid Token!");
                  this.router.navigate(['/login']);
                }
              else
              {
                this.fiscalCalendarSaveModule.fiscalCalanderAccounting = [];
                  this.fiscalCalendarSaveModule.fiscalCalanderAccounting = res.fiscalCalanderAccounting.filter((data: any) => data.startYear == this.DistinctCalander[Index].startYear && data.endYear == this.DistinctCalander[Index].endYear).sort((a: any, b: any) => a.id - b.id);
                  // for (let i = 0; i < this.fiscalCalendarSaveModule.fiscalCalanderAccounting.length; i++) {
                  //   if (this.fiscalCalendarSaveModule.fiscalCalanderAccounting[i].periodClose == true) {
                  //     this.fiscalCalendarSaveModule.fiscalCalanderAccounting[i].disableIsPeriodClose = true;
                  //   }
                  // }
              }


            //this.fiscalCalendarSaveModule=res;
            



            //this.fiscalCalendarSaveModule.fiscalCalanderAccounting= this.fiscalCalendarSaveModule.fiscalCalanderAccounting.sort((data:any) =>data.id);
          });
      }
      else {
        let Month: Array<string> = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        //let date: Array<string> = ['28','29','30','31'];

        var StartMonth = this.fiscalCalendarSaveModule.startMonth;
        let StartMonthNo: any = this.getmonthNumber(this.fiscalCalendarSaveModule.startMonth);
        var EndMonth = this.fiscalCalendarSaveModule.endMonth;
        let EndMonthNo: any = this.getmonthNumber(this.fiscalCalendarSaveModule.endMonth);
        var startyear = EndMonth != "December" ? this.DistinctCalander[Index].endYear - 1 : this.DistinctCalander[Index].endYear;// new Date(this.DistinctCalander[Index].endYear).getFullYear()-1 ;
        //var startyear=this.DistinctCalander[Index].endYear -1;// new Date(this.DistinctCalander[Index].endYear).getFullYear()-1 ;
        var endyear = this.DistinctCalander[Index].endYear;//new Date(this.DistinctCalander[Index].endYear).getFullYear();

        this.fiscalCalendarSaveModule.fiscalCalanderAccounting = [];
        for (let i = 0; i < 12; i++) {
          if (i == 0) {
            StartMonthNo;
          }
          else {
            if (StartMonthNo > 12) {
              StartMonthNo = 1;
              startyear = endyear;
            }
          }
          var daysInMonth = this.getDaysInMonth(startyear, StartMonthNo);
          StartMonthNo = StartMonthNo.toString().length == 1 ? "0" + StartMonthNo : StartMonthNo;
          this.fiscalCalendarSaveModule.fiscalCalanderAccounting.push(
            {
              month: Month[StartMonthNo - 1] + "-" + startyear,
              fromDate: "" + startyear + "-" + StartMonthNo + "-" + "01",
              toDate: "" + startyear + "-" + StartMonthNo + "-" + daysInMonth,
              lock: true,
              periodOpen: false,
              periodClose: false
            });
          StartMonthNo++;
        }
      }

    }
    else {
      if (this.DistinctCalander[Index].endYear == undefined) {
        this.showAlert("Enter Start & End Year For Generate Calendar");
      }
      this.DistinctCalander[Index].openClose = false;
      this.fiscalCalendarSaveModule.fiscalCalanderAccounting = [];
    }
  }
  handleToggleprimerycontact(event: any, index: any) {
    event.originalEvent.cancelBubble = true;
    this.DistinctCalander.map(function (val: any, i: any) {
      if (event.checked && index != i) {
        val.openClose = false;
      }
    })
  }
  getDaysInMonth(year: any, month: any) {
    return new Date(year, month, 0).getDate();
  }
  addNewYear() {
    this.DistinctCalander.push({
      startYear: "",
      endYear: "",
      yearName: "",
      disableStartColumn: true
    });
   this.newYearVisible=false;
  }
  fnLockOnChange(index: any,event:any) {
    this.selectedIndex = index;
    this.selectedCalender = this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index];
    if(index > 0 && this.selectedCalender.lock == false &&  this.fiscalCalendarSaveModule.fiscalCalanderAccounting[(index-1)].lock == true)
    {
      this.showAlert("Previous month ["+ this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].month+ "] period need be open");
      event.originalEvent.target.closed=true;
      this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].lock=true
      //return false;
    }

    //  if (this.selectedCalender.lock == false ) {
    //   this.selectedCalender.periodOpen = true;
    //   this.selectedCalender.disableColumn = true;
    // }
    // else {

    //   this.selectedCalender.periodOpen = false;
    //   this.selectedCalender.periodClose = false;
    //   this.selectedCalender.disableColumn = false;
    // }
  }
  fnPeriodOpenChange(index: any) {
    this.selectedIndex = index;

    if(index >0 && this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodOpen == true)
    {
      if(this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].periodOpen == false && this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].periodClose == false)// || Object.keys(this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].periodOpen).length === 0)
    //if((this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodClose == true || Object.keys(this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodClose).length === 0) &&  (this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].periodClose == true || Object.keys(this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].periodClose).length === 0) &&  this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].lock == false)
    {
      this.showAlert("Previous month ["+ this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].month+ "] period need be open or closed");
      this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodClose ={};
      this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodOpen={};
      this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodOpen =true;
  
      this.fiscalCalendarSaveModule.fiscalCalanderAccounting.map((data,row)=>{
        if(index == row){data.periodOpen={};}
      })
      return false;
    }
    else
    {
      this.selectedCalender = this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index];
      if (this.selectedCalender.periodOpen == true) {
        this.selectedCalender.periodClose = false
      }
      else {
        this.selectedCalender.periodClose = true;
      }
    }
    }
    else
    {
      
      this.selectedCalender = this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index];
      if (this.selectedCalender.periodOpen == true) {
        this.selectedCalender.periodClose = false
      }
      else if(index > 0 && this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].periodClose == false) {
        this.selectedCalender.periodClose = false;
        this.showAlert("Previous month ["+ this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].month+ "] period need be closed");
        this.selectedCalender.periodOpen = true;
      }
      else
      {
        this.selectedCalender.periodClose = true;
      }
      return false;
    }

  }
  fnPeriodCloseChange(index: any) {
    this.selectedIndex = index;

    if(index >0)
    {
    if(this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodClose == true &&  this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].periodClose == false && this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].lock == false)
    {
      this.showAlert("Previous month ["+ this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].month+ "] period need be closed");
      this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodClose ={};
      return false;
    }
    else
    {
      this.selectedCalender = this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index];
      if (this.selectedCalender.periodClose == true) {
        this.selectedCalender.periodOpen = false
      }
      else {
        this.selectedCalender.periodOpen = true;
      }
    }
    }
    else
    {
      //return false;
      this.selectedCalender = this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index];
      if (this.selectedCalender.periodClose == true) {
        this.selectedCalender.periodOpen = false
      }
      else {
        this.selectedCalender.periodOpen = true;
      }
    }
   
  }

//--Test
fnPeriodOpenChange2(index: any) {
  this.selectedIndex = index;

  if(index >0 && this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodOpen == true && this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].periodOpen == false)
  {
  // if((this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodClose == true || Object.keys(this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodClose).length === 0) &&  (this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].periodClose == false || Object.keys(this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].periodClose).length === 0) &&  this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].lock == false)
  // {
    this.showAlert("Previous month ["+ this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].month+ "] period need be Opened");
    this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodOpen={};
    return false;
  // }
  }
  else
  {
    this.selectedCalender = this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index];
    if (this.selectedCalender.periodOpen == true) {
      this.selectedCalender.periodClose = false
    }
    else {
      this.selectedCalender.periodClose = true;
    }
    return false;
  }

  this.selectedCalender = this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index];
  if (this.selectedCalender.periodOpen == true) {
    this.selectedCalender.periodClose = false
    //this.selectedCalender.disableColumn =true;
  }
  else {
    //this.selectedCalender.periodOpen =false;
    this.selectedCalender.periodClose = true;
    //this.selectedCalender.disableColumn =false;
  }
}
fnPeriodCloseChange2(index: any) {
  this.selectedIndex = index;

  if(index >0)
  {
  if(this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodClose == true &&  this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].periodClose == false && this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].lock == false)
  {
    this.showAlert("Previous month ["+ this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index-1].month+ "] period need be closed");
    this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index].periodClose ={};
    return false;
  }
  else
  {
    this.selectedCalender = this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index];
    if (this.selectedCalender.periodClose == true) {
      this.selectedCalender.periodOpen = false
    }
    else {
      this.selectedCalender.periodOpen = true;
    }
  }
  }
  else
  {
    //return false;
    this.selectedCalender = this.fiscalCalendarSaveModule.fiscalCalanderAccounting[index];
    if (this.selectedCalender.periodClose == true) {
      this.selectedCalender.periodOpen = false
    }
    else {
      this.selectedCalender.periodOpen = true;
    }
  }
 
}
//--End


  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Data Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving!'
    );
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
}
