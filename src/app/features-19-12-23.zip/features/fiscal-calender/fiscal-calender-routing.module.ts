import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FiscalCalenderListComponent } from './fiscal-calender-list/fiscal-calender-list.component';
import { FiscalCalenderAddEditComponent } from './fiscal-calender-add-edit/fiscal-calender-add-edit.component';
const routes: Routes = [
  {
    path: 'list',
    component: FiscalCalenderListComponent,
  },
  {
    path: 'action/:action/:id',
    component: FiscalCalenderAddEditComponent,
  },
  {
    path: 'action/:action',
    component: FiscalCalenderAddEditComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FiscalCalenderRoutingModule { }
