import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FiscalCalenderListComponent } from './fiscal-calender-list.component';

describe('FiscalCalenderListComponent', () => {
  let component: FiscalCalenderListComponent;
  let fixture: ComponentFixture<FiscalCalenderListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FiscalCalenderListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FiscalCalenderListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
