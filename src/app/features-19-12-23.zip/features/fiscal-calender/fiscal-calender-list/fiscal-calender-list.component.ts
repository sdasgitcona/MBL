import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {BaseSearch, fiscalCalendarModule,BaseSearchPdf} from '../model/fiscal-calender-model';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { PrimeNGConfig } from 'primeng/api';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-fiscal-calender-list',
  templateUrl: './fiscal-calender-list.component.html',
  styleUrls: ['./fiscal-calender-list.component.scss']
})
export class FiscalCalenderListComponent implements OnInit {
  baseSearch: BaseSearch = new BaseSearch();
  selectedBankList: fiscalCalendarModule = new fiscalCalendarModule();
  columns: any[];
  exportColumns: any[];
  totalRecords: number = 0;
  loading: boolean = false;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  FiscalCalenderPrint: any[] = [];
  retTableData:fiscalCalendarModule[]=[];
  newevent:any;
  RetloginDetails: any;
  RetRoleDetails:any;
   // For Role Base Access
   isEditable:boolean;
   isCreatetable:boolean;
   isViewtable:boolean;
   // For Role Base Access
   showloader: boolean = false;
  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,
    private toastService: ToastService,) { }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
     const retDetails:any = localStorage.getItem("RoleDTLS");
     var role_Dtls = JSON.parse(retDetails);
     this.RetRoleDetails=role_Dtls;
      const LDetails:any=localStorage.getItem("LoggerDTLS");
      this.RetloginDetails = JSON.parse(LDetails);
 
     for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
     {
       if(role_Dtls[0].rolePermissions[i].accessPoint == "Fiscal Calendar")
       {
         this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
         this.isEditable=role_Dtls[0].rolePermissions[i].edit;
         this.isViewtable=role_Dtls[0].rolePermissions[i].view;
       }
     }
 // End For Role Base Access
   this.resetBaseSearch();
    this.primengConfig.ripple = true;
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
      
      { field: 'Id', header: 'Internal ID' },
      { field: 'Name', header: 'Subsidiary' },
      { field: 'First Month', header: 'Name' },
      { field: 'Last Month', header: 'Year' },
      { field: 'Status', header: 'Status' },
     ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }
  navigateToAddViewEdit(
    action: string,
    selectedList: fiscalCalendarModule = new fiscalCalendarModule()
  ) {
    let mainId = null;
    if (selectedList?.id) {
      mainId = selectedList.id;
      this.router.navigate(['/main/fiscalcalendar/action', action, mainId]);
    } else {
      this.router.navigate(['/main/fiscalcalendar/action', action]);
    }
    console.log('Action is ' + action);
  }
  loadList(event: any) {
    try {
      this.newevent=event
      this.loading = true;
      this.baseSearch.pageNumber = event.first / event.rows;
      this.baseSearch.pageSize = event.rows;
        this.baseSearch.sortColumn = event.sortField
        ?  event.sortField
        : GlobalConstants.FISCAL_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
      this.HttpService.Insert('/setup-ws/fiscal-calender/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(
        (res) => {
          
          //For Auth
              if(res.status == 401)
              { this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if(res.status == 404)
              { this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
            else
            {
              if (res && res.list.length > 0) {
                this.retTableData = res.list;
                this.retTableData = this.retTableData.filter((item, i, arr) => arr.findIndex((t) => t.id=== item.id) === i); 
                if(this.baseSearch.filters && (Object.keys(this.baseSearch.filters).length === 0)){
                  this.retTableData = res.list;
                  //this.retTableData=this.retTableData.map(item => item.id).filter((value, index, self) => self.indexOf(value) === index);
                
                  //--Distinct List
                  this.retTableData = this.retTableData.filter((item, i, arr) => arr.findIndex((t) => t.id=== item.id) === i);  
                }
              
                this.totalRecords = res.totalRecords;
              } else {
                this.retTableData=[] ;
              }
              this.loading = false;
            }
        },
        (error) => {
          //console.log(error);
          this.loading = false;
        }
      );
    } catch (err) {
      //console.log(err);
    }
  }
    resetBaseSearch() {


      if(this.RetloginDetails.userType=='ROOTADMIN'){
        this.baseSearch.filters = {accountId:this.RetRoleDetails[0].accountId,roleId:this.RetRoleDetails[0].id};
        this.baseSearch.pageNumber = 0;
        this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
        this.baseSearch.sortColumn = GlobalConstants.FISCAL_TABLE_SORT_COLUMN;
        this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
        this.loadList(this.newevent);
      }
      else{
        this.baseSearch.filters = {accountId:this.RetRoleDetails[0].accountId};
        this.baseSearch.pageNumber = 0;
        this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
        this.baseSearch.sortColumn = GlobalConstants.FISCAL_TABLE_SORT_COLUMN;
        this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
        this.loadList(this.newevent);
      }

    
    }
  /*  exportPdf() {
      import("jspdf").then(jsPDF => {
          import("jspdf-autotable").then(x => {
              const doc = new jsPDF.default();
              (doc as any).autoTable(this.exportColumns, this.retTableData);
              doc.save('FiscalCalendar.pdf');
          })
      })
  }*/
  reloadPage()
  {
    window.location.reload();
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  
      /***((Export Excel)) */
      generatePDFData(exportType:any){
        this.newevent = event;
        this.baseSearchPdf.pageSize = this.totalRecords;
        this.baseSearchPdf.sortColumn =GlobalConstants.FISCAL_TABLE_SORT_COLUMN;
        //this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
        if(this.RetloginDetails.userType=='ROOTADMIN'){
          this.baseSearchPdf.filters = {accountId:this.RetRoleDetails[0].accountId,roleId:this.RetRoleDetails[0].id};
           }
        else{
          this.baseSearchPdf.filters = {accountId:this.RetRoleDetails[0].accountId};
        }
    
        this.HttpService.Insert('/setup-ws/fiscal-calender/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
          (res) => {
            //For Auth
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else {
              //this.employeelistPrint = [];
              this.FiscalCalenderPrint = [];
              if (res && res.list.length > 0) {
                var RetData = res.list;
                for (let i = 0; i < RetData.length; i++) {

                  if (RetData[i].id == undefined) {
                    RetData[i].id = "";
                  }
                  if(exportType == 'PDF'){ 
            
                    this.FiscalCalenderPrint.push({
                      'Id': RetData[i].id,    
                      'Name':RetData[i].name, 
                      'First Month':  RetData[i].startMonth,
                      'Last Month': RetData[i].endMonth,
                      'Status': RetData[i].status,
                      
                      // 
                      
                  });
                }
                  else{
                    this.FiscalCalenderPrint.push({
                      'Internal Id': RetData[i].id,    
                      'Name':RetData[i].name, 
                      'First Month':  RetData[i].startMonth,
                      'Last Month': RetData[i].endMonth,
                      'Status': RetData[i].status,
                    });
                  }
    
                }
              }
              if(exportType == 'PDF')
              {this.exportPdf();}
            }
          }
        );
      }
      exportPdf() {
        import("jspdf").then(jsPDF => {
          import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            //this.= this.employeeExport;
            //this.employeelist=[];
            (doc as any).autoTable(this.exportColumns, this.FiscalCalenderPrint);
            doc.save('fiscal-calender.pdf');
          })
        })
      }
    
    //End PDF
    
    //Start Excel
    exportExcel() {
      this.showloader=true
      this.generatePDFData('');
    
     setTimeout(() => {
      this.exportExcelData()
     }, 250);
      }
      exportExcelData()
      {
        if(this.FiscalCalenderPrint.length >0)
        { import('xlsx').then((xlsx) => {
             const worksheet = xlsx.utils.json_to_sheet(this.FiscalCalenderPrint);
             const workbook = { 
                 Sheets: { data: worksheet }, 
                 SheetNames: ['data'] 
             };
             const excelBuffer: any = xlsx.write(workbook, {
                 bookType: 'csv',
                 type: 'array',
             });
             this.saveAsExcelFile(excelBuffer, 'fiscal-calender');
             this.showloader=false;
         });}
      }
    
      saveAsExcelFile(buffer: any, fileName: string): void {
          let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
          let EXCEL_EXTENSION = '.csv';
          const data: Blob = new Blob([buffer], {
              type: EXCEL_TYPE,
          });
          FileSaver.saveAs(
              data, fileName + EXCEL_EXTENSION
              //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
          );
      }
    //End Excel 
      //List Export option End
    
       /********Export excel */
       onRowSelect(event: any) {
        let fcId = event.data.id;
        
        this.router.navigate(['/main/fiscalcalendar/action/view', fcId]);
      }
}
