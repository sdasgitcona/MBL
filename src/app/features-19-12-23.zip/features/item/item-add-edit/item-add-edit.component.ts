import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { CountryModel } from 'src/app/shared/shared-components/address/model/address.model';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { Subsidiary } from '../../subsidiary/Model/subsidiary-model';
import { Account, SubsidiaryAddress, SubsidiaryEntry } from '../../supplier/model/supplier-model';
import { Items } from '../model/item-model';
@Component({
  selector: 'app-item-add-edit',
  templateUrl: './item-add-edit.component.html',
  styleUrls: ['./item-add-edit.component.scss']
})
export class ItemAddEditComponent implements OnInit {
  item:Items=new Items();
  itemId: number = 0;
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  addressData: any;
  RetRoleDetails:any;
  displayAddressDialog: boolean = false;
  ItemHistoryList: HistoryModel[] = [];
  SubsideryObject:any[]=[];
  checked: boolean;
  selectedIndex:any
  isReloadSub:boolean;
  isReloadCurrency:boolean;
  itemtypeOptions:any;
  uomOptions:any;
  CastingOptions:any;
  assetAccountOptions:any;
  expenseAccountOptions:any;
  cogsAccountOptions:any;
  incomeAccountOptions:any;
  inventrytypeOptions:any;
  Subsidiarylist: any[] = [];
  AssetsAccountlist: Account[] = [];
  ExpenseAccountlist: Account[] = [];
  IncomeAccountlist: Account[] = [];
  isReloadAssets:boolean;
  isReloadExpense:boolean;
  showloader:boolean=false;
    // For Role Base Access
    isEditable:boolean;
    isCreatetable:boolean;
    isViewtable:boolean;
    isviewEditable:boolean=true;
  RetloginDetails: any;
    // For Role Base Access
  constructor(
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
  )
  {
    this.itemtypeOptions = ["Inventory Item","Service Item"];
    this.uomOptions = ["KG","LTR","PCS","Man Days","Man Months","Unit"];
    this.CastingOptions = ["Average"];   
    this.assetAccountOptions=[{id:1,name:"12010 Inventory : Stock on Hand"}];
    this.expenseAccountOptions=[{id:1,name:"60010 Indirect Expenses"}];
    this.cogsAccountOptions=["Cost Of Goods Sold"];
    this.incomeAccountOptions=["Sale"];
    this.inventrytypeOptions = ["Stockable","Non-Stockable"];
  }
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;
 const LDetails:any=localStorage.getItem("LoggerDTLS");
this.RetloginDetails = JSON.parse(LDetails);

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Item")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access
    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.itemId = +params['id']; // (+) converts string 'id' to a number
            this.GetItembyId();
            //this.GetAccountType("Assets",this.itemId)
            //this.GetAccountType("Expenses",this.itemId)
          }
          this.assignMode(params['action']);
          this.GetSubsideryList();
          setTimeout(() => {
           // this.countries=this.addressComponent.countries;
          }, 2000)
        } else {
        }
      },
      (error) => {
      }
    );
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        break;
      default:
        break;
    }
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  GetItembyId() {
    this.httpService
      .GetById('/masters-ws/item/get?id=' + this.itemId, this.itemId ,this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.item = res;
        this.GetAccountType(res.category == 'Inventory Item' ? "Assets":'Expense',res.subsidiaryId);
        this.GetAccountType('Income',res.subsidiaryId);
        }
        
      });
  }
  GetSubsideryList_old() {
    this.httpService.GetAll("/setup-ws/subsidiary/get/all" ,this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.Subsidiarylist = res.list;
          this.isReloadSub=false;
        }

       
      },
      (error) => {
        this.isReloadSub=false;
      }
    );
  }
  GetSubsideryList() {
    this.Subsidiarylist=[];
  
    //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    if(this.RetloginDetails.userType=='SUPERADMIN')
    {
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
       {
         this.Subsidiarylist=res;
       
      }
      },
      (error) => {
        alert(error);
       },
       ()=>{
       
       //this.loadSuppliers('');
       }
    );
    }else if(this.RetloginDetails.userType=='ENDUSER'){
      this.Subsidiarylist.push({
        "id":this.RetRoleDetails[0].subsidiaryId,
        "name":this.RetRoleDetails[0].subsidiaryName
      });
    
    }
  }

  /* Start fetching History details */
  LoadHistory() {
    if (this.ItemHistoryList.length == 0)
      this.httpService
        .GetById(
          `/masters-ws/item/get/history?id=${this.itemId}&pageSize=10000`,
          this.itemId ,this.RetloginDetails.token
        )
        .subscribe((res) => {
          //For Auth
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
          else
          {this.ItemHistoryList = res;}
         
        });
  }
  /* End fetching History details */
  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 1) {
      this.LoadHistory();
    }
  }
  handleToggleEvent(event: any) {
    event.originalEvent.cancelBubble = true;
  }
  saveItem() {
    if(this.item.subsidiaryId == undefined || this.item.subsidiaryId == 0)
    {
      this.showAlert("Please select Subsidiary");
      return false;
    }
    else  if(this.item.category == undefined || this.item.category == "")
    {
      this.showAlert("Please select Item Category");
      return false;
    }
    else  if(this.item.name == undefined || this.item.name == "")
    {
      this.showAlert("Please enter Item Code");
      return false;
    }
    else  if(this.item.description == undefined || this.item.description == "")
    {
      this.showAlert("Please enter Item Name");
      return false;
    }
    else  if(this.item.uom == undefined || this.item.uom == "")
    {
      this.showAlert("Please select UOM");
      return false;
    }
    else  if(this.item.natureOfItem == undefined || this.item.natureOfItem == "")
    {
      this.showAlert("Please select Nature of Item");
      return false;
    }
    else  if(this.item.category =='Inventory Item' && this.item.assetAccountId == undefined )
    {
      this.showAlert("Please select Asset Account");
      return false;
    } 
    else  if(this.item.category =='Service Item' && this.item.expenseAccountId == undefined)
    {
      this.showAlert("Please select Expense Account");
      return false;
    }
    this.showloader=true;

    //For Save API Call
    if(this.addMode){
      this.item.createdBy=this.RetloginDetails.username;this.item.lastModifiedBy=this.RetloginDetails.username
      }
    else if(!this.addMode){
      this.item.lastModifiedBy=this.RetloginDetails.username
      }

    this.httpService.Insert('/masters-ws/item/save', this.item ,this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          if (res && res.id > 0) {
            this.showloader=false;
            //this.saveAddress();
            this.showSuccess();
            if(this.addMode){
              this.router.navigate(['/main/item/action', 'view',res.id]);
            } else {
              this.router.navigate(['/main/item/list']);
            }
          } else {
            this.showloader=false;
            this.showError();
          }
        }


        
      },
      (error) => {
        this.showloader=false;
        this.showAlert(error);
      },
      () => {}
    );
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Item Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving item!'
    );
  }
  clearitemData() {
      this.router.navigate(['/main/item/list']);
  }
handleToggleRegtype(event: any,index:any) {
  if(event.target.value=="Unregistered"){
    //this.subsidiary.subsidiaryAddresses[index].registrationCode="";
  }
}
handleToggleAdressActive(event: any,index:any) {
  event.originalEvent.cancelBubble = true;
  // this.subsidiary.subsidiaryAddresses.map(function (val:any,i:any){
  //   if(event.checked && index!=i){
  //     val.active=false;
  //   }
  // })
}
/* Start reload Subsidery list from api */
reloadSubidery(){
  this.isReloadSub=true;
  this.item.subsidiaryId=0;
  this.GetSubsideryList();
}
/* End reload Subsidery list from api */
handleSubsidiaryChange(event: any) {
 this.GetAccountType("Assets",event.value);
 setTimeout(() =>  this.GetAccountType("Expense",event.value),100);
}
reloadAssets(){
  this.isReloadAssets=true;
  this.item.assetAccountId=0;
  this.GetAccountType("Assets",this.item.subsidiaryId)
}
reloadExpense(){
  this.isReloadExpense=true;
  this.item.expenseAccountId=0;
  this.GetAccountType("Expense",this.item.subsidiaryId)
}
reloadIncome(){
  this.isReloadExpense=true;
  this.item.expenseAccountId=0;
  this.GetAccountType("Income",this.item.subsidiaryId)
}
GetAccountType(type: any,subsideryId:any) {
  let defaultAsset:any;
  let defaultExpence:any;
 // type=this.item.category =='Inventory Item'?'Assets':this.item.category=='Service Item'?'Expense':'';
  if(type !='')
 { this.httpService.GetAll(`/masters-ws/account/get-account-by-subsidiary?subsidiaryId=${subsideryId}&type=` + type +'&formName=Item' ,this.RetloginDetails.token).subscribe(
    (res) => {
      //For Auth
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else
      {
        this.isReloadAssets=false;
      this.isReloadExpense=false;
      if (type == 'Assets') {
        this.AssetsAccountlist=[]
        this.AssetsAccountlist = res;
        for(let x=0;x<res.length;x++)
        {
          if(res[x].default)
          {
            defaultAsset=res[x].id;
          }
        }
      } if (type == 'Expense') {
        this.ExpenseAccountlist=[];
        this.ExpenseAccountlist = res;
        for(let x=0;x<res.length;x++)
        {
          if(res[x].default)
          {
            defaultExpence=res[x].id;
          }
        }
      }
      if (type == 'Income') {
        
        this.IncomeAccountlist=[];
        this.IncomeAccountlist = res;
        for(let x=0;x<res.length;x++)
        {
          if(res[x].default)
          {
            defaultExpence=res[x].id;
          }
        }
      }
      }


      
    },
    (error) => {
    },
    () => {
      if(this.addMode)
      {
        if (type == 'Assets'){this.item.assetAccountId=defaultAsset}
        if(type == 'Expense'){this.item.expenseAccountId=defaultExpence}
      }
      // 'onCompleted' callback.
      // No errors, route to new page here
    }
  );}
}
showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}
loadAccountType(subsideryId:any) {
  let type=this.item.category =='Inventory Item'?'Assets':this.item.category=='Service Item'?'Expense':'';

  this.GetAccountType(type,this.item.subsidiaryId);
  this.GetAccountType("Income",this.item.subsidiaryId);
 
}
}
