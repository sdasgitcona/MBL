import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ItemAddEditComponent } from './item-add-edit/item-add-edit.component';
import { ItemListComponent } from './item-list/item-list.component';

const routes: Routes = [
  {
    path: '',
    component: ItemListComponent,
  },
  {
    path: 'list',
    component: ItemListComponent,
  },
  {
    path: 'action/:action/:id',
    component: ItemAddEditComponent,
  },
  {
    path: 'action/:action',
    component: ItemAddEditComponent,
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ItemRoutingModule { }
