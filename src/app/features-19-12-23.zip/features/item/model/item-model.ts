export class Items {
  id?: number;
  subsidiaryId?: number;
  category?: string;
  name?: string;
  description?: string;
  uom?: string;
  costingMethod?: string;
  hsnSacCode?: any;
  integratedId?: string;
  natureOfItem?: any;
  expenseAccountId?: number;
  incomeAccountId?: number;
  cogsAccount?: any;
  incomeAccount?: any;
  assetAccountId?: number;
  createdDate?: Date;
  createdBy?: string;
  lastModifiedDate?: Date;
  lastModifiedBy?: string;
  status?: boolean=true;
  subsidiaryName?: any;
  accountId?: any;
  active?: boolean=true;
  deleted?: boolean;
  purchasable?: boolean=true;
  salable?: boolean;
  }
  export class CommonDropDownValue {
    id?: number;
    name?:string;
  }

  export class file_upliad
{
  file:File;
}

  // Base seach model for Supplier
  export class BaseSearchPdf {
    filters: ItemFilter | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }

//this class holds the custom filter values at component level.
export class ItemFilter {
  subsidiary: string = '';
  vendorname: string = '';
  vendornumber: string = '';
  vendortype: string = '';
  pan: string = '';
  active: string = '';
}