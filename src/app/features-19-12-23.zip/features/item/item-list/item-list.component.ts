import { Component, OnInit, ViewChild,LOCALE_ID, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { BaseSearch } from '../../supplier/model/supplier-model';
import { Project } from '../../project/model/project-model';
import { Items, file_upliad,BaseSearchPdf } from '../model/item-model';
import { ToastService } from 'src/app/core/services/toast.service';
import { saveAs } from 'file-saver';
import { HttpHeaderResponse, HttpHeaders } from '@angular/common/http';
import {formatDate } from '@angular/common';
import * as FileSaver from 'file-saver';
@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.scss']
})
export class ItemListComponent implements OnInit {
  columns: any[];
  departments: any[] = [];
  Itemlists: Items[] =[];
  // projectlist: Project[] = [];
  //selectedProject: Project = new Project();
  selectedItem: Items = new Items();
  totalRecords: number = 0;
  loading: boolean = false;
  RetRoleDetails:any;
  baseSearch: BaseSearch = new BaseSearch();
  exportColumns: any[];
  item: Items = new Items();
  vendorTypeOptions:any;
  showloader:boolean=false;
  newevent:any;
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  ItemPrint: any[] = [];
  itemNameList: Items[] = [];
  SubsideryObject:any[]=[];
  SubIdList:any=[];
  statusOption:any;
  uomOptions:any;
  ishiddensubsidiary:boolean=false;
  isdisablesubsidiary:boolean=false;
  itemtypeOption:any;
  file: File ;
  displayModal:boolean;
  file_upliad:file_upliad=new file_upliad();
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  RetloginDetails: any;
  // For Role Base Access
  constructor( private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService,@Inject(LOCALE_ID) public locale: string
    )
     { 
       this.statusOption = [{id:'Active',name:"Active"},{id:'Inactive',name:"Inactive"}];
       this.itemtypeOption = ["Inventory Item","Service Item"];
       this.uomOptions = ["KG","LTR","PCS","Man Days","Man Months","Unit"];
     }
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
     const retDetails:any = localStorage.getItem("RoleDTLS");
     var role_Dtls = JSON.parse(retDetails);
     this.RetRoleDetails=role_Dtls;
     const LDetails:any=localStorage.getItem("LoggerDTLS");
      this.RetloginDetails = JSON.parse(LDetails);
      
      for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
     {
       if(role_Dtls[0].rolePermissions[i].accessPoint == "Item")
       {
         this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
         this.isEditable=role_Dtls[0].rolePermissions[i].edit;
         this.isViewtable=role_Dtls[0].rolePermissions[i].view;
       }
     }
 // End For Role Base Access
    //this.resetBaseSearch();
    this.GetSubsideryList();
    //this.loadItemAll();
    this.columns = [
      { field: 'Id', header: 'Id' },
      { field: 'Subsidiary', header: 'Subsidiary' },
      { field: 'Item Code', header: 'Item Code' },
      { field: 'Item Name', header: 'Item Name' },
      { field: 'UOM', header: 'UOM' },
      { field: 'Type', header: 'Type' },
      { field: 'Status', header: 'Status' },
     ];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }
  resetBaseSearch() {
    this.baseSearch.filters = {subsidiaryId: this.SubIdList};
    this.baseSearch.pageNumber = 0;
    this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
    this.baseSearch.sortColumn = GlobalConstants.ITEM_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
    this.loadItem(this.newevent);
  }
  loadItem(event: any) {
    try {
      this.newevent=event
      this.loading = true;
      this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);;
      // this.baseSearch.pageNumber = 1;
      this.baseSearch.pageSize = event.rows;
      // this.baseSearch.sortColumn = event.sortField
      //   ? 's.' + event.sortField
      //   : GlobalConstants.ITEM_TABLE_SORT_COLUMN;
      this.baseSearch.sortColumn = event.sortField
      ?  event.sortField
      : GlobalConstants.ITEM_TABLE_SORT_COLUMN;
      this.baseSearch.sortOrder =
        event.sortOrder == -1
          ? GlobalConstants.ASCENDING
          : GlobalConstants.DESCENDING;
          if(this.SubIdList.length==0 && this.RetloginDetails.userType!='ROOTADMIN'){return;}
      this.HttpService.Insert('/masters-ws/item/get/all', this.baseSearch ,this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
            if(res.status == 401)
            { this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if(res.status == 404)
            { this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
          else
          {
            if (res && res.list.length > 0) {
              this.Itemlists = res.list;
  
              for (let i = 0; i < res.list.length; i++) {
                if (res.list[i].description!=null && res.list[i].description.length > 15) {
                  //this.AccountCodeList[i].subsidiaryName=
                  this.Itemlists[i].description = res.list[i].description.substring(0, 15) + "...";
                }
              }
              // if(this.baseSearch.filters && (Object.keys(this.baseSearch.filters).length === 0)){
              // this.VenderNameList = res.list;
              // }
              this.totalRecords = res.totalRecords;
            } else {
              this.Itemlists = [];
            }
            this.loading = false;
          }

          
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {
     }
  }
 navigateToAddViewEdit(
    action: string,
    selectedProject: Project = new Project()
  ) {
    let projectId = null;
    if (selectedProject?.id) {
      projectId = selectedProject.id;
      this.router.navigate(['/main/item/action', action, projectId]);
    } else {
      this.router.navigate(['/main/item/action', action]);
    }
   }
/*  exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.Itemlists);
            doc.save('item.pdf');
        })
    })
}*/
 /* Start fetch filter list of supplier from api */
 findby(event: any){
  let subsidyList:any=[];
  subsidyList.push(this.item.subsidiaryId);
  this.baseSearch.filters={
    subsidiaryId: subsidyList,
    name: this.item.name,
    description:this.item.description,
    category:this.item.category,
    status:this.item.status==true?'active':'inactive',
    uom:this.item.uom
}
this.baseSearch.pageNumber=-1;
   this.loadItem(this.newevent);
}
/* End filter list of supplier from api */
 /* Start Fetch Subsidery list from api */
 GetSubsideryList_old() {
  this.HttpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
    (res) => {

      //For Auth
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else
      {
        //this.Subsidiarylist = res.list;
      this.SubsideryObject=res.list;
      }
      
    },
    (error) => {
    }
  );
}
GetSubsideryList() {
  this.SubsideryObject=[];

  //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
  if(this.RetloginDetails.userType=='SUPERADMIN')
  {
    this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
     { this.showAlert("Unauthorized Access !");
       this.router.navigate(['/login']);
     }
     else if(res.status == 404)
     { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
     { this.SubsideryObject=res;
      for(let x=0;x<this.SubsideryObject.length;x++)
     { 
      this.SubIdList.push(this.SubsideryObject[x].id);
    }
    this.ishiddensubsidiary=false;
    this.isdisablesubsidiary=false;
    }
    },
    (error) => {
      alert(error);
     },
     () => {
      if(localStorage.getItem("ItemFilters") != null)
      {const LocDetails:any =localStorage.getItem("ItemFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.item.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.item.name=searcheData.filters.name;
      this.item.description=searcheData.filters.description;
      this.item.category=searcheData.filters.category;
      this.item.status=searcheData.filters.status=="active"?true:false;
      this.loadItem(this.newevent);
      this.GetAllItemList(searcheData.filters.subsidiaryId[0]);
      localStorage.removeItem("ItemFilters");
      }
      else
     { this.resetBaseSearch();}
    }
  );
  }else if(this.RetloginDetails.userType=='ENDUSER'){
    this.SubsideryObject.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });
    this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
    this.item.subsidiaryId= this.SubsideryObject[0].id;
    this.GetAllItemList(this.SubsideryObject[0].id);
    this.ishiddensubsidiary=true;
    this.isdisablesubsidiary=true;
    if(localStorage.getItem("ItemFilters") != null)
      {const LocDetails:any =localStorage.getItem("ItemFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.item.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.item.name=searcheData.filters.name;
      this.item.description=searcheData.filters.description;
      this.item.category=searcheData.filters.category;
      this.item.status=searcheData.filters.status=="active"?true:false;
      this.loadItem(this.newevent);
      localStorage.removeItem("ItemFilters");
      }
      else
     { this.resetBaseSearch();}
  }
}
/* End Fetch Subsidery list from api */
  /* Start Fetch project list All from api */
  loadItemAll() {
    var obj={
      filters: {
      },
      pageNumber: 0,
      pageSize: 1000,
      sortColumn: "i.id",
      sortOrder: "asc"
  }
    this.HttpService.Insert("/masters-ws/item/get/all",obj ,this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {this.itemNameList=res.list;}
        
      },
      (error) => {
     }
    );
  }

  Reset()
  {
    if(this.RetloginDetails.userType=='SUPERADMIN')
  {
    this.item.subsidiaryId =undefined;
  }
    
    this.item.name=undefined;
    this.item.description=undefined;
    this.item.category=undefined;
    this.item.status=true;
     this.resetBaseSearch();
  }

  GetAllItemList(SubsidiaryId:any) {
    this.HttpService.GetAll("/masters-ws/item/find-by-subsidiary?subsidiaryId="+ SubsidiaryId,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
        { 
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { 
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
        {
  
        if (res != undefined) {
        this.itemNameList = res;
        }
      }
      },
      (error) => {
        this.showAlert(error);
      }
      );
  
  }
  /* End Fetch project list All from api */
  RefreshPage()
  {
    window.location.reload();
  }
    // CSV UPLOAD
    csvUploadDownload(){
      this.displayModal = true;
    }
   @ViewChild('attachments') attachment: any;
    fileList: File[] = [];
    listOfFiles: any[] = [];
    isLoading = false;
    onFileChanged(event: any) {
      this.isLoading = true;
      this.file = event.target.files[0];
      this.listOfFiles=[]
      this.listOfFiles.push({subsidiary:this.RetRoleDetails[0].subsidiaryName,file:this.file .name});
      this.isLoading = false;
    }
    s2ab(s:any) {
      var buf = new ArrayBuffer(s.length);
      var view = new Uint8Array(buf);
      for (var i=0; i!=s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
      return buf;
    }
    uploadFile(event:any){
      this.showloader=true;
      const httpOptions = {
        headers: new HttpHeaders({
         "mimeType": "multipart/form-data",
         "Content-Type": "false"
        })
      };
    const formData = new FormData();
       formData.append('file', this.file);
      this.HttpService.uploadFile_("/masters-ws/item/upload?subsidiaryId=" +this.RetRoleDetails[0].subsidiaryId ,formData,{responseType: 'blob'} ,this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.executeSaveAs(res)
        if (res.error){
           this.toastService.addSingle(
            'error',
            'Error',
            res.error.errorMessage
          );
          }
          else{
          this.toastService.addSingle(
              'success',
              'Success',
              'File uploaded Successfully!'
            );
            window.location.reload();
          }
          this.showloader=false;
        }
      },
        error => {
        },
        () => {  this.showloader=false;});
    }
   onFileChanged1(event:any) {
    this.file = event.target.files[0];
      this.HttpService.uploadFile("/masters-ws/item/upload", this.file ,this.RetloginDetails.token)
      .subscribe(res => {

        //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          if (res.error){
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            }
            else{
              this.toastService.addSingle(
                'success',
                'Success',
                'File uploaded Successfully!'
              );
              window.location.reload();
            }
        }

       
      },
        error => {
        },
        () => {
    
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
    }
   removeSelectedFile(index: number) {
      // Delete the item from fileNames list
      this.listOfFiles.splice(index, 1);
      // delete file from FileList
      this.fileList.splice(index, 1);
    }
    executeSaveAs(content:any){
    saveAs(content, "Item Master.xlsx"); // This is from https://github.com/eligrey/FileSaver.js

  }
  DownloadTemplete() {
      //window.open(this.HttpService.baseUrl+"/masters-ws/item/download-template");
      this.HttpService.downloadFile("/masters-ws/item/download-template",this.RetloginDetails.token)
      .subscribe(res => {
        saveAs(res, 'Item_Master.xlsx');
        //this.executeSaveAs(res);
        //let blob = new Blob([res], {'type': "application/octet-stream"});
        //window.open(res)
      });
  }
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }

  editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("ItemFilters") != null)
    {
      localStorage.removeItem("ItemFilters");
    }
    localStorage.setItem("ItemFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/item/action', actionType, mainId]);
   }

    /***((Export Excel)) */
    generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.ITEM_TABLE_SORT_COLUMN;
      this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
  
      this.HttpService.Insert('/masters-ws/item/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.ItemPrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {

                if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){ 
               
                  this.ItemPrint.push({
                    'Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'Item Code': RetData[i].name,
                    'Item Name': RetData[i].description,
                    'UOM': RetData[i].uom,
                    'Type':  RetData[i].category,  
                    'Status': RetData[i].status, 
                
                    // 
                    
                });
              }
                else{
                  this.ItemPrint.push({
                    'Internal Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'Item Code': RetData[i].name,
                    'Item Name': RetData[i].description,
                    'UOM': RetData[i].uom,
                    'Type':  RetData[i].category,  
                    'Status': RetData[i].status, 
                  });
                }
  
              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    exportPdf() {
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          //this.= this.employeeExport;
          //this.employeelist=[];
          (doc as any).autoTable(this.exportColumns, this.ItemPrint);
          doc.save('Item.pdf');
        })
      })
    }
  
  //End PDF
  
  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');
  
   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.ItemPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.ItemPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'Item');
           this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
  //End Excel 
    //List Export option End
  
     /********Export excel */
     onRowSelect(event: any) {
      let Itemlists = event.data.id;
      
      this.router.navigate(['/main/item/action/view',Itemlists]);
    }
}
