import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RtvAddEditComponent } from './rtv-add-edit/rtv-add-edit.component';
import { RtvListComponent } from './rtv-list/rtv-list.component';
import { RtvApprovalComponent } from './rtv-approval/rtv-approval.component';

const routes: Routes = [
  {
    path: '',
    component: RtvListComponent,
  },
  {
    path: 'list',
    component: RtvListComponent,
  },
  
  {
    path: 'action/:action/:id/:chkid',
    component: RtvAddEditComponent,
  },
  {
    path: 'action/:action',
    component: RtvAddEditComponent,
  },
  {
    path: 'rtv-approval',
    component: RtvApprovalComponent,
  },
  {
    path: 'rtv-approval/:status',
    component: RtvApprovalComponent,
  },
  
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RtvRoutingModule { }
