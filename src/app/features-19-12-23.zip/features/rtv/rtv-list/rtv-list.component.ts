import { Component, OnInit,LOCALE_ID, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { PrimeNGConfig } from 'primeng/api';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { location } from '../../grn/model/grn-module';
import { PurchaseOrder } from '../../purchase-order/model/purchase-order-module';
import { BaseSearch, SubsidiaryEntry, Supplier } from '../../supplier/model/supplier-model';
import { Rtv,BaseSearchPdf } from '../model/rtv-model';
import { ToastService } from 'src/app/core/services/toast.service';
import * as FileSaver from 'file-saver';
import {formatDate } from '@angular/common';
@Component({
  selector: 'app-rtv-list',
  templateUrl: './rtv-list.component.html',
  styleUrls: ['./rtv-list.component.scss']
})
export class RtvListComponent implements OnInit {

  subsidiary:any;
  columns: any[];
  departments: any[] = [];
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  rtvlist: Rtv[] = [];
  selectedRTV: Rtv = new Rtv();
  rtv: Rtv = new Rtv();
  totalRecords: number = 0;
  loading: boolean = false;
  exportColumns: any[];
  newevent:any;
  taxType:any;
  RTVPrint: any[] = [];
  baseSearch: BaseSearch = new BaseSearch();
  Subsidiarylist: any[] = [];
  Subsidiaryselect: any[] = [];
  supplierlist:Supplier[] = [];
  locationlist:location[] = [];
  fromDate:any;
  toDate:any;
  statusOptions:any;
  ishiddensub:boolean=false;
  isdisabledsub:boolean=false;
  rtvlocation:location[]=[];
  showloader:boolean = false;
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  RetloginDetails:any;
  // For Role Base Access
  RetRoleDetails:any;
  SubIdList:any=[];

  constructor( private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private primengConfig: PrimeNGConfig,private toastService: ToastService,@Inject(LOCALE_ID) public locale: string) { 

   
    }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
     // For Role Base Access
     const retDetails:any = localStorage.getItem("RoleDTLS");
     var role_Dtls = JSON.parse(retDetails);
     this.RetRoleDetails=role_Dtls;

     const LDetails:any=localStorage.getItem("LoggerDTLS");
     this.RetloginDetails = JSON.parse(LDetails);

     for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
     {
       if(role_Dtls[0].rolePermissions[i].accessPoint == "Return to Vendor")
       {
         this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
         this.isEditable=role_Dtls[0].rolePermissions[i].edit;
         this.isViewtable=role_Dtls[0].rolePermissions[i].view;
       }
     }
 // End For Role Base Access

    this.GetSubsideryList();
    this.columns = [
      // { field: 'Sl No', header: 'Sl No' },
     
      { field: 'Internal Id', header: 'Internal ID' },
      { field: 'Subsidiary', header: 'Subsidiary' },
      { field: 'RTV Date', header: 'RTV Date' },
      { field: 'RTV Reference Number', header: 'RTV Reference Number' },
      { field: 'Supplier', header: 'Supplier' },
      { field: 'GRN Reference Number', header: 'GRN Reference Number' },
      { field: 'Status', header: 'Status' },
      { field: 'Amount', header: 'Amount' },

     ];
     this.statusOptions = ['Draft', 'Pending Approval', 'Partially Approved', 'Approved', 'Rejected', 'Partially Processed', 'Processed'];
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
  }

  /*exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            const doc = new jsPDF.default();
            (doc as any).autoTable(this.exportColumns, this.rtvlist);
            doc.save('rtv.pdf');
        })
    })
}*/
   /* navigate to add-edit*/
// navigateToAddViewEdit(
//   action: string,
//   selectedorder: PurchaseOrder = new PurchaseOrder()
// ) {
//   let orderid = null;
//   if (selectedorder?.id) {
//     orderid = selectedorder.id;
//     this.router.navigate(['/main/rtv/action', action, orderid]);
//   } else {
//     this.router.navigate(['/main/rtv/action', action]);
//   }
//   console.log('Action is ' + action);
// }
   /* reset base search*/
resetBaseSearch() {
  this.baseSearch.filters = {subsidiaryId: this.SubIdList};
  this.baseSearch.pageNumber = 0;
  this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
  this.baseSearch.sortColumn = GlobalConstants.RTV_TABLE_SORT_COLUMN;
  this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
  this.loadRTV(this.newevent);
}
   /* load rtv list*/
loadRTV(event: any) {
  try {
    this.newevent=event
    this.loading = true;
    this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1)?0:( event.first / event.rows);
    // this.baseSearch.pageNumber = 1;
    this.baseSearch.pageSize = event.rows;
    // this.baseSearch.sortColumn = event.sortField
    //   ? 's.' + event.sortField
    //   : GlobalConstants.SUPPLIER_TABLE_SORT_COLUMN;
    this.baseSearch.sortColumn = event.sortField
    ?  event.sortField
    : GlobalConstants.RTV_TABLE_SORT_COLUMN;
    this.baseSearch.sortOrder =
      event.sortOrder == -1
        ? GlobalConstants.ASCENDING
        : GlobalConstants.DESCENDING;
        if(this.SubIdList.length==0)
        {
         return;
        }

    this.HttpService.Insert('/procure-ws/rtv/get/all', this.baseSearch,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
        else if (res && res.list.length > 0) {
          this.rtvlist = res.list;
          // if(this.baseSearch.filters && (Object.keys(this.baseSearch.filters).length === 0)){
          // this.VenderNameList = res.list;
          // }
          this.totalRecords = res.totalRecords;
          for(let x=0;x<this.rtvlist.length;x++) {
            if( this.rtvlist[x].approvalStatus == 'Pending Approval' || this.rtvlist[x].approvalStatus == 'Partially Approved' || this.rtvlist[x].approvalStatus == 'Approved'|| this.rtvlist[x].approvalStatus == 'Rejected' || this.rtvlist[x].approvalStatus == 'Closed'|| this.rtvlist[x].approvalStatus == 'Partially Received'|| this.rtvlist[x].approvalStatus == 'Received' || this.rtvlist[x].approvalStatus == 'Partially Billed'|| this.rtvlist[x].approvalStatus == 'Billed') //Send Approval Mode
            {
              this.rtvlist[x].isApprovalButtonShowHide = 0;
            }
            else{
              this.rtvlist[x].isApprovalButtonShowHide = 1;
            }
          }
        } else {
          this.rtvlist = [];
          this.totalRecords=0
        }
        this.loading = false;
      },
      (error) => {
        console.log(error);
        this.loading = false;
      }
    );
    this.loading = false;
  } catch (err) {
  }
}


/* Start fetch filter list of Subsidiary from api */
findby(event: any){
  let subsidyList:any=[];
    subsidyList.push(this.rtv.subsidiaryId);


  let Fromdays: any = new Date(this.fromDate).getUTCDate();
  let Frommonths: any = new Date(this.fromDate).getUTCMonth() + 1;
  let Fromyear: any = new Date(this.fromDate).getUTCFullYear();

  let Todays: any = new Date(this.toDate).getUTCDate();
  let Tomonths: any = new Date(this.toDate).getUTCMonth() + 1;
  let Toyear: any = new Date(this.toDate).getUTCFullYear();

 
   /*base search filters */
 this.baseSearch.filters={
  subsidiaryId:subsidyList,
  supplierId:this.rtv.supplierId,
  locationId:this.rtv.locationId,
  fromDate:this.fromDate !== undefined ? (Fromyear + '-' + (Frommonths.toString().length == 1 ? "0" + Frommonths : Frommonths) + '-' + (Fromdays.toString().length == 1 ? "0" + Fromdays : Fromdays)) : null,
  toDate:this.toDate !== undefined ? (Toyear + '-' + (Tomonths.toString().length == 1 ? "0" + Tomonths : Tomonths) + '-' + (Todays.toString().length == 1 ? "0" + Todays : Todays)) : null,
  status:this.rtv.status
 }
 this.baseSearch.pageNumber=-1;
  this.loadRTV(this.newevent);
}
   /* Reset button*/
Reset(){
  if(this.RetloginDetails.userType=='SUPERADMIN')
  {
    this.rtv.subsidiaryId=0;
  }
  this.rtv.supplierId=undefined;
  this.rtv.locationId=undefined;
  this.fromDate=null;
  this.toDate=undefined;
  this.resetBaseSearch();
  this.baseSearch.pageNumber=-1;
  this.loadRTV(this.newevent);
}
/* End filter list of Subsidiary from api */
GetSubsideryList() {
  if(this.RetloginDetails.userType=='SUPERADMIN')
 // if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
     
      this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
    
  //this.HttpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
      }
      else
     {
      this.Subsidiarylist = res;
      for (let x = 0; x < this.Subsidiarylist.length; x++) {
        this.SubIdList.push(this.Subsidiarylist[x].id);
      }
      this.ishiddensub=false;
      this.isdisabledsub=false;
    }

    },
    (error) => {
      console.log(error);
    },
    () => {
      if(localStorage.getItem("RTVFilters") != null)
      {const LocDetails:any =localStorage.getItem("RTVFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.rtv.subsidiaryId=searcheData.filters.subsidiaryId[0];
      this.rtv.supplierId=searcheData.filters.supplierId;
      this.rtv.locationId=searcheData.filters.locationId;
      this.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
      this.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.rtv.status=searcheData.filters.status;
      this.loadRTV(this.newevent);
      this.GetSupplierList();
      localStorage.removeItem("RTVFilters");
      }
      else
     { this.resetBaseSearch();}
    }
  );
}else if(this.RetloginDetails.userType=='ENDUSER'){
  this.Subsidiarylist.push({
    "id":this.RetRoleDetails[0].subsidiaryId,
    "name":this.RetRoleDetails[0].subsidiaryName
  });
 this.rtv.subsidiaryId=this.RetRoleDetails[0].subsidiaryId;
 this.GetSupplierList();
  this.ishiddensub=true;
  this.isdisabledsub=true;
  this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
  if(localStorage.getItem("RTVFilters") != null)
      {
	  const LocDetails:any =localStorage.getItem("RTVFilters");
      let RetLocDetails = JSON.parse(LocDetails);
      this.baseSearch=RetLocDetails;
      let searcheData:any = RetLocDetails;
      this.rtv.supplierId=searcheData.filters.supplierId;
      this.rtv.locationId=searcheData.filters.locationId;
      this.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
      this.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
      this.rtv.status=searcheData.filters.status;
      this.loadRTV(this.newevent);
      localStorage.removeItem("RTVFilters");
      }
      else
     { this.resetBaseSearch();}
}
}
/* start get Get Supplier list */

GetSupplierList() {
  this.HttpService
    .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + this.rtv.subsidiaryId, this.rtv.subsidiaryId, this.RetloginDetails.token)
    .subscribe((res) => {
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        this.supplierlist = res;
      }
    });

    this.GetLocationList();
}
/* end get Get Supplier list */

/* start get Get Location list */

GetLocationList() {
      this.HttpService.GetAll('/masters-ws/location/get/all/lov?subsidiaryId='+this.rtv.subsidiaryId ,this.RetloginDetails.token).subscribe(
          (res) => {
    
            //For Auth
              if(res.status == 401)
              { this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if(res.status == 404)
              { this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
            else
            {
              debugger
              this.rtvlocation=[];
              for (const [key, value] of Object.entries(res)) {
                this.rtvlocation.push({locationId:Number(key),name:value})
               }
            }
    
            
          },
          (error) => {
           this.showAlert(error);
          },
          () => {
            // 'onCompleted' callback.
            // No errors, route to new page here
          }
        );

          
}
/* end get Get Location list */

showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}

selfApproval(id:any){
  this.showloader=true;
this.HttpService
  .GetById('/procure-ws/rtv/self-approve?rtvId=' + id, id,this.RetloginDetails.token)
  .subscribe((res) => {
    
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
   if (res == true) {
    this.showloader=false;
    window.location.reload();
    this.toastService.addSingle(
      'success',
      'Success',
      'RTV Approved Successfully!'
    );
   } else {
    this.showloader=false;
    this.showAlert(res.errorMessage);
  }
}
  },
  
    (error) => {
      this.toastService.addSingle(
        'error',
        'Error',
        'Error occured while sending RTV for Approval!'
      );
      this.showloader=false;
    }

  );
}

sendForApproval(id:any){
  this.showloader=true;
this.HttpService
    .GetById('/procure-ws/rtv/send-for-approval?id=' + id, id,this.RetloginDetails.token)
    .subscribe((res) => {
      
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
        if (res == true) {
          window.location.reload();
          this.showloader=false;
          this.toastService.addSingle(
            'success',
            'Success',
            'RTV Sent for Approval Successfully!'
          );
        } else {
          this.showloader=false;
          this.showAlert(res.errorMessage);
        }
      }
    },
      (error) => {
        this.showloader=false;
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured while sending RTV for Approval!'
        );
      }

    );
}

editview(actionType:any,mainId:any)
   {
    if (localStorage.getItem("RTVFilters") != null)
    {
      localStorage.removeItem("RTVFilters");
    }
    localStorage.setItem("RTVFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/rtv/action', actionType, mainId,0]);
   }

    /***((Export Excel)) */
    generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.RTV_TABLE_SORT_COLUMN;
      this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
  
      this.HttpService.Insert('/procure-ws/rtv/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.RTVPrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {

                if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){ 



                  this.RTVPrint.push({
                    'Internal Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'RTV Date': formatDate(RetData[i].rtvDate, 'dd-MM-yyyy' ,this.locale).toString(),
                    'RTV Reference Number': RetData[i].rtvNumber,
                    'Supplier': RetData[i].supplierName,
                    'GRN Reference Number': RetData[i].grnNumber,    
                    'Status':RetData[i].approvalStatus, 
                    'Amount': RetData[i].amount,
  
                    // 
                    
                });
              }
                else{
                  this.RTVPrint.push({
                    'Internal Id': RetData[i].id,    
                    'Subsidiary':RetData[i].subsidiaryName, 
                    'RTV Date': formatDate(RetData[i].rtvDate, 'dd-MM-yyyy' ,this.locale).toString(),
                    'RTV Reference Number': RetData[i].rtvNumber,
                    'Supplier': RetData[i].supplierName,
                    'GRN Reference Number': RetData[i].grnNumber,    
                    'Status':RetData[i].approvalStatus, 
                    'Amount': RetData[i].amount,
                                  
                  });
                }
  
              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    exportPdf() {
      import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
          const doc = new jsPDF.default();
          //this.= this.employeeExport;
          //this.employeelist=[];
          (doc as any).autoTable(this.exportColumns, this.RTVPrint);
          doc.save('rtv.pdf');
        })
      })
    }
  
  //End PDF
  
  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');
  
   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.RTVPrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.RTVPrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'rtv');
           this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
  //End Excel 
    //List Export option End
  
     /********Export excel */

     navigateToAddViewEdit(
      action: string,
      selectedRTV: Rtv = new Rtv()
    ) {
      let orderid = null;
      if (selectedRTV?.id) {
        orderid = selectedRTV.id;
        this.router.navigate(['/main/rtv/action', action, orderid]);
      } else {
        this.router.navigate(['/main/rtv/action', action]);
      }
      console.log('Action is ' + action);
    }

     onRowSelect(event: any) {
      let rtvId = event.data.id;
      
      this.router.navigate(['/main/rtv/action/view', rtvId, 0]);
    }

}
