import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RtvListComponent } from './rtv-list.component';

describe('RtvListComponent', () => {
  let component: RtvListComponent;
  let fixture: ComponentFixture<RtvListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RtvListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RtvListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
