import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { Rtv, RtvItem,rtvApprovalModel } from '../model/rtv-model';
@Component({
  selector: 'app-rtv-approval',
  templateUrl: './rtv-approval.component.html',
  styleUrls: ['./rtv-approval.component.scss']
})
export class RtvApprovalComponent implements OnInit {
  columns: any[];
  totalRecords: number = 0;
  AllSelected: boolean = false;
  showloader:boolean=false;
  departments: any[] = [];
  loading: boolean = false;
  isRejectPressed: boolean = true;
  approvalRoutingActive: boolean = false;
  approverRoleList: [{ id?: number; name?: string; }];
  SubsidiaryId: any;
  rtvApprovalModel: rtvApprovalModel[] = [];
  selectedRtvApproval: rtvApprovalModel = new rtvApprovalModel();
  roleId: any;
  url:any;
  empID: number;
  userRoleId: number;
  @ViewChild('dt') dt: Table;
  userId: number;
  RetloginDetails: any;
  RetRoleDetails: any;
  IsLoggerAdmin:any;
  visibleSaveButton:boolean;
  constructor(
    private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService
  ) { }

  ngOnInit(): void {
    if (localStorage.getItem("LoggerDTLS") == null) {
      this.router.navigate(['/login']);
    }
    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    //--Login Details
    const logDetails: any = localStorage.getItem("LoggerDTLS");
    const LoggerId = JSON.parse(logDetails);
    this.empID = LoggerId.employeeId;
    const retLoggerDetails: any = localStorage.getItem("LoggerDTLS");
    var logger_Dtls = JSON.parse(retLoggerDetails);
    this.userId = logger_Dtls.id;
    // For Role ID
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails = role_Dtls;
    this.IsLoggerAdmin=role_Dtls[0].selectedAccess;

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "PO Approval") {
        this.userRoleId = role_Dtls[0].rolePermissions[i].roleId
      }
    }
    this.loadRTVApproval();
  }
     /*global serach */
  globalSearch(event: any) {
    this.dt.filterGlobal(event.target.value, 'contains')
  }
   /* load rtv list*/
  loadRTVApproval() {
    try {
      let ReqData;
      let ReqParam;
      let ReqDataa;
      let ReqParama;
      let reqUrl:any='';
      //if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null) //--User:Super Admin
      if(this.RetloginDetails.userType=='SUPERADMIN')
      {
        ReqData=this.RetRoleDetails[0].accountId;
        ReqParam='accountId';
        
       // reqUrl='/procure-ws/rtv/approval-list?'+ReqParam+'=' + ReqData;
       reqUrl='/procure-ws/rtv/approval-list?'+ReqParam+'=1bbc34bb6d0d4f';
      }
      //else if((this.RetRoleDetails[0].selectedAccess == 'ADMIN'|| this.RetRoleDetails[0].selectedAccess == 'ADMIN_APPROVER') && this.RetRoleDetails[0].subsidiaryId != null) //--User:Admin
      else if(this.RetloginDetails.userType=='ENDUSER')
      {
        if( this.RetRoleDetails[0].selectedAccess == 'APPROVER')
        {
          ReqData=this.empID;
          ReqParam='userId';
          ReqDataa=this.RetRoleDetails[0].subsidiaryId;
          ReqParama = 'subsidiaryId';
          reqUrl='/procure-ws/rtv/approval-list?'+ReqParam+'=' + ReqData+'&' +ReqParama+'=' + ReqDataa;
        }
        else
        {
          ReqData=this.RetRoleDetails[0].subsidiaryId;
          ReqParam='subsidiaryId';
          reqUrl='/procure-ws/rtv/approval-list?'+ReqParam+'=' + ReqData;
        }
      }
      else //--User:Others
      {
        ReqData=this.empID;
        ReqParam='userId'
        reqUrl='/procure-ws/rtv/approval-list?'+ReqParam+'=' + ReqData;
      }
         this.HttpService.GetAll(reqUrl, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else if (res && res.length > 0) {
            for (let i = 0; i < res.length; i++) {
              this.NextApproverLov(res[i].subsidiaryId)
            }
            this.rtvApprovalModel = res;
            this.totalRecords = res.length;
            for (let k = 0; k < this.rtvApprovalModel.length; k++) {

              this.rtvApprovalModel[k].isAdminRole=(this.IsLoggerAdmin=="ADMIN" || this.IsLoggerAdmin=="ADMIN_APPROVER")?true:false;
            }

           

           // this.SubsidiaryId = this.supplierApprovalList[0]?.subsidiaryId;
         /*   this.supplierApprovalList.map((data:supplierApprovalModel)=>{
             // data.isAdminRole=(this.IsLoggerAdmin=="ADMIN" || this.IsLoggerAdmin=="ADMIN_APPROVER")?false:true;
              data.isAdminRole=(this.IsLoggerAdmin=="ADMIN" || this.IsLoggerAdmin=="ADMIN_APPROVER")?true:false;

            data.isAdminForSave=true;
            data.nextApprover=Number(data.nextApprover)
            })*/

            setTimeout(() => {
             // this.NextApproverLov();
            }, 250);
           

            //this.supplierApprovalList[0].isAdminRole=this.IsLoggerAdmin=="ADMIN"?false:true;
            
          } else {
            //this.supplierApprovalList = [];
            this.totalRecords = res.length;

          }
          this.loading = false;
        },
        (error) => {
          this.loading = false;
        }
      );
    } catch (err) {
    }
  }

  showAlert(AlertMSG: any) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
     /* approve rtv*/
  approvertv()
  {
    try {
      this.isRejectPressed = false
      var approveList: any = [];
      this.rtvApprovalModel.map((data: rtvApprovalModel) => {
        if (data.selected) {
          approveList.push(data.id)
        }
      })
      if (approveList.length > 0) {
        this.showloader = true;


        if(this.RetloginDetails.userType=='SUPERADMIN'){
          this.url='/procure-ws/rtv/approve-all-rtv?currentApproverId=' + this.empID;
  
         }
         else if(this.RetloginDetails.userType=='ENDUSER')
         {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                this.url='/procure-ws/rtv/approve-all-rtv?currentApproverId=' + this.empID;
              }
              else
              {
                this.url='/procure-ws/rtv/approve-all-rtv'
              }
        
         }
        this.HttpService.Insert(this.url, approveList, this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );

            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Approve selected rtv!'
              );
              this.loadRTVApproval();
            }
            // this.loading = false;
          },
          (error) => {
          }
        );
      }
    } catch (err) {
    }
  }
   /* reject rtv*/
  rejectrtv()
  {
    try {
      if (this.isRejectPressed) {
        var rejectList: any = [];
        var isrejectComments: boolean = false
        this.rtvApprovalModel.map((data: rtvApprovalModel) => {
          if (data.selected) {
            if (data.rejectedComments) {
              rejectList.push({ id: data.id, rejectComments: data.rejectedComments })
              isrejectComments = true;
              this.isRejectPressed = true

            } else {
              this.toastService.addSingle(
                'error',
                'Error',
                'Please enter Reject Comments'
              );
              isrejectComments = false;
              this.isRejectPressed = true
              return;
            }
          }
        })
        if (isrejectComments) {
          this.showloader = true;
          this.HttpService.Insert('/masters-ws/rtv/reject-all-rtv', rejectList, this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else if (res.messageCode) {
                this.showloader = false;
                this.isRejectPressed = true
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );

              }
              else {
                this.showloader = false;
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Reject selected rtv!'
                );
                this.loadRTVApproval();
              }
              this.isRejectPressed = true
            },
            (error) => {
            }
          );
        }
      } else {
        this.toastService.addSingle(
          'error',
          'Error',
          'Please enter Reject Comments'
        );
        this.isRejectPressed = true;
        this.showloader = false;
      }
    } catch (err) {
    }
  }
     /*Markall button function */
  onAllSelectChange(event: any) {
    if (event.checked) {
      this.rtvApprovalModel.map((data: rtvApprovalModel) => {
        data.selected = true;
        this.isRejectPressed = true
        //this.approvalRoutingActive=true;
      })
    }
    else {
      this.rtvApprovalModel.map((data: rtvApprovalModel) => {
        data.selected = false;
        this.isRejectPressed = true;
        // this.approvalRoutingActive=false;

      })
    }
  }
   /*approve individual */
  approveIndividual(mainId:any)
  {
    try {
      this.isRejectPressed = true
      var approveList: any = [];
      approveList.push(mainId);

      if (approveList.length > 0) {
        this.showloader = true;
        
        if(this.RetloginDetails.userType=='SUPERADMIN'){
          this.url='/procure-ws/rtv/approve-all-rtv?currentApproverId=' + this.empID;
  
         }
         else if(this.RetloginDetails.userType=='ENDUSER')
         {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                this.url='/procure-ws/rtv/approve-all-rtv?currentApproverId=' + this.empID;
              }
              else
              {
                this.url='/procure-ws/rtv/approve-all-rtv'
              }
        
         }
        //this.HttpService.Insert('/masters-ws/supplier/approve-all-supplier', approveList, this.RetloginDetails.token).subscribe(
          this.HttpService.Insert(this.url,approveList,this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );

            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Approve selected RTV!'
              );
              this.loadRTVApproval();
            }
            // this.loading = false;
          },
          (error) => {
            this.showAlert(error);
          }
        );
      }
    } catch (err) {
    }
  }
     /* reject Individual*/
  rejectIndividual(mainId:any,rejectComments:any,RowNo:any)
  {

    try {
      this.rtvApprovalModel[RowNo].selected=true;
      this.isRejectPressed=true;

      if( this.rtvApprovalModel[RowNo].rejectedComments==undefined)
      {
        this.showAlert("Please enter Reject Comments");
        return true;
      }

      if (this.isRejectPressed) {
        var rejectList: any = [];
        var isrejectComments: boolean = false;
        rejectList.push({id:mainId,rejectedComments:this.rtvApprovalModel[RowNo].rejectedComments})
              isrejectComments = true;
              this.isRejectPressed = true
              
        if (isrejectComments) {
          this.showloader = true;
          
          //this.HttpService.Insert('/masters-ws/supplier/reject-all-supplier', rejectList, this.RetloginDetails.token).subscribe(
            this.HttpService.Insert('/masters-ws/rtv/reject-all-rtv',rejectList,this.RetloginDetails.token).subscribe(
            (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else if (res.messageCode) {
                this.showloader = false;
                this.isRejectPressed = true
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );
                this.rtvApprovalModel[RowNo].selected=false;
                this.isRejectPressed=true;
                isrejectComments=false;
                this.rtvApprovalModel[RowNo].rejectedComments=undefined;
              }
              else {
                this.showloader = false;
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Reject selected RTV!'
                );
                this.loadRTVApproval();
              }
              this.isRejectPressed = true
              // this.loading = false;
            },
            (error) => {
            }
          );
        }
      } else {
        this.showAlert("Please enter Reject Comments");
        this.isRejectPressed = true;
        this.showloader = false;
      }
    } catch (err) {
      this.showAlert(err);
    }
  }

  NextApproverLov(subId: any) {
    try {
    
      if(this.RetloginDetails.userType=='SUPERADMIN'){
        this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + subId + '&formName=RTV Approval';

       }
       else if(this.RetloginDetails.userType=='ENDUSER')
       {
            if(this.RetRoleDetails[0].selectedAccess=="ADMIN"|| this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
            {
              this.url='/masters-ws/employee/get-by-role-subsidiary?subsidiaryId=' + subId + '&formName=RTV Approval';
            }
            else
            {
              this.url='/masters-ws/employee/get-by-role-subsidiary?roleId=' + this.userRoleId + '&subsidiaryId=' + subId + '&formName=RTV Approval';
            }
        
       }
    

      this.HttpService.GetAll(this.url, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res && res.length > 0) {
              this.approverRoleList = res;
              // this.totalRecords = res.length;
            } else {
              this.approverRoleList = [{}];
            }
            this.loading = false;
          }
        },
        (error) => {
          this.showAlert(error);
          this.loading = false;
        }
      );
    } catch (err) {
      this.showAlert(err);
    }
  }
  OnChangeVisibleButton(row:any,)
  {
   if(this.IsLoggerAdmin=="ADMIN")
   {
      if(this.rtvApprovalModel[row].selected)
      {
      //  this.rtvApprovalModel[row].isAdminForSave=false;
        this.visibleSaveButton=true;
      }
   }
  }

  onApproverSave()
  {
    try {
      let selectedRtv;
      let selectedapprover;
      for(let x=0;x<this.rtvApprovalModel.length;x++)
      {
        if(this.rtvApprovalModel[x].selected)
      {
        selectedRtv=this.rtvApprovalModel[x].id;
        selectedapprover=this.rtvApprovalModel[x].nextApprover
        break;
      }
      }
      this.HttpService.GetAll(`/masters-ws/rtv/update-next-approver?rtvId=${selectedRtv}&approverId=${selectedapprover}`, this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          } else if (res == true) {
            this.showloader = false;
            this.toastService.addSingle(
              'success',
              'Success',
              'saved selected RTV!'
            );
            window.location.reload();
            //this.loadSuppliersApproval();
          } 
        },
        (error) => {
        }
      );
    } catch (err) {
    }
  }

  cancel()
  {
    window.location.reload();
  }


}
