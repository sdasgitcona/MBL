import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RtvApprovalComponent } from './rtv-approval.component';

describe('RtvApprovalComponent', () => {
  let component: RtvApprovalComponent;
  let fixture: ComponentFixture<RtvApprovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RtvApprovalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RtvApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
