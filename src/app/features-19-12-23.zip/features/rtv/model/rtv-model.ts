export class RtvItem {
    id: number;
    rtvId: number;
    rtvNumber: string;
    itemId: number;
    poiId?: any;
    grnId: number;
    itemDescription: string;
    glCode?: any;
    recievedQuantity: number;
    returnQuantity: any;
    alreadyReturnQuantity: number;
    rate?: any;
    amount?: any;
    department?: any;
    createdDate: Date;
    createdBy: string;
    lastModifiedDate: Date;
    lastModifiedBy: string;
    deleted: boolean;
    selected?:boolean;
    itemName?:any;
    billQuantity:any;
    
}

export class Rtv {
    id: number;
    rtvNumber: string;
    subsidiaryId?: number;
    supplierId?: number;
    grnNumber: any;
    grnId?: any;
    locationId?: number;
    rtvDate: any;
    invoiceNumber: string;
    approvalStatus?: any;
    modeOfTransport: string;
    vehicleNumber: string;
    awNumber: string;
    rejectedComments?: any;
    approvedBy?: any;
    nextApprover?: any;
    nextApproverRole?: any;
    nextApproverLevel?: any;
    approverPreferenceId?: any;
    approverSequenceId?: any;
    approverMaxLevel?: any;
    noteToApprover?: any;
    createdDate: Date;
    createdBy: string;
    lastModifiedDate: Date;
    lastModifiedBy: string;
    rtvItems: RtvItem[]=[];
    approvers:approvers[]=[];
    subsidiaryName?: any;
    supplierName?: any;
    locationName?: any;
    deleted: boolean=false;
    approvalRoutingActive: boolean;
    amount:any;
    totalAmount:any;
    status:string;
    comments:any;
    isApprovalButtonShowHide?: any;
}
export class rtvApprovalModel {
    access:boolean;
    accountId:number;
    active:boolean;
    activeDate:any;
    approvalRoutingActive:boolean;
    approvalStatus:string;
    approvedBy:string;
    approverByName:string;
    approverMaxLevel:string;
    approverPreferenceId:string;
    approverSequenceId:string;
    approvers:string;
    contactName:string;
    contactNumber:string;
    createdBy:string;
    createdDate:any;
    currency:string;
    deleted:boolean;
    externalId:number;
    hasError:boolean;
    id:number;
    integratedId:string;
    invoiceMail:string;
    lastModifiedBy:string;
    lastModifiedDate:any;
    legalName:string;
    name:string;
    natureOfSupply:string;
    nextApprover:string;
    nextApproverLevel:string;
    nextApproverRole:string;
    nextApproverUid:number;
    noteToApprover:string;
    nsMessage:string;
    nsStatus:string;
    paymentTerm:string;
    rejectedComments:any;
    subsidiaryId:number;
    subsidiaryName:string;
    supplierAccess:string;
    supplierAccounting:string;
    supplierAddresses:string;
    supplierAttachmentDetails:string;
    supplierContacts:string;
    supplierSubsidiary:string;
    tdsWitholding:string;
    uin:string;
    uniqueNumber:string;
    vendorNumber:string;
    vendorType:string;
    selected:boolean=false;
    isAdminRole?:boolean;
  }
  export class approvers{
    id?:any;
    name?:any;
}
    // Base seach model for Supplier
    export class BaseSearchPdf {
        filters: rtv | {} = {};
        pageNumber: number = 0;
        pageSize: number = 0;
        sortColumn: string = '';
        sortOrder: string = '';
      }
    
      //this class holds the custom filter values at component level.
    export class rtv {
        subsidiary: string = '';
        vendorname: string = '';
        vendornumber: string = '';
        vendortype: string = '';
        pan: string = '';
        active: string = '';
      }