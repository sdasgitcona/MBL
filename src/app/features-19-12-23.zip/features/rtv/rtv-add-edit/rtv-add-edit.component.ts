import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { grn } from '../../grn/model/grn-module';
import { Items } from '../../item/model/item-model';
import { locations } from '../../locationmaster/model/locationmaster-model';
import { Item, POPrs, PrItems, PurchaseOrder, QAItems, supplierCurrency } from '../../purchase-order/model/purchase-order-module';
import { Subsidiary } from '../../subsidiary/Model/subsidiary-model';
import { SubsidiaryEntry, Supplier, SupplierAddress } from '../../supplier/model/supplier-model';
import { TaxGroup } from '../../tax-group/model/tax-group-model';
import { Rtv, RtvItem, approvers} from '../model/rtv-model';
import { CardModule } from 'primeng/card';
@Component({
  selector: 'app-rtv-add-edit',
  templateUrl: './rtv-add-edit.component.html',
  styleUrls: ['./rtv-add-edit.component.scss']
})
export class RtvAddEditComponent implements OnInit {

  rtv: Rtv = new Rtv();
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  aproBttn: boolean = false;
  role: any;
  transportType:any;
  rtvtype:any;
  Chktooltip:boolean=false;
  display: boolean = false;
  isReloadSub:boolean;
  isReloadgrn:boolean;
  Subsidiarylist: any[] = [];
  subsidiary:Subsidiary=new Subsidiary();
  supplier: Supplier = new Supplier();
  itemList: Items[] = [];
  grnlist: grn[] = [];
  grn: grn = new grn();
  approvers?:approvers[]=[]
  chkId:any;
  isviewapprovereject:boolean=false;
  private subscription: any;
  orderId:number;
  selectedRow:number=0;
  RTVHistoryList: HistoryModel[] = [];
  ApprovalButtonShowHide:Number=0;
  id:any
  url:any;
  empID: number;
  markall:boolean;
  isAppSequenceVisivble:boolean;
  appSequencelist:any=[];
  isloadbyId:boolean=false;
    // For Role Base Access
    isEditable:boolean;
    isCreatetable:boolean;
    isViewtable:boolean;
    isviewEditable:boolean=true;
    // For Role Base Access
    showloader:boolean = false;
    fiscalCalenderDTLS: any;
    supplierlist:Supplier[] = [];
    locationlist:locations[]=[];
    RetloginDetails:any;
    RetRoleDetails:any;
  constructor( private httpService: CommonHttpService,
    private router: Router,
    private toastService: ToastService,
    private activatedRoute: ActivatedRoute,

   ) {
    //this.subsidiary = ['MLBD', 'MLCD'];
    this.transportType = ['Air', 'Sea','Road'];
    this.rtvtype = [ 'Approved', 'Pending Approval', 'Open'];
    
  }

  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
 const retDetails:any = localStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);
 this.RetRoleDetails=role_Dtls;

 const LDetails:any=localStorage.getItem("LoggerDTLS");
this.RetloginDetails = JSON.parse(LDetails);
const LoggerId = JSON.parse(LDetails);
this.empID = LoggerId.employeeId;
 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "Return to Vendor")
   {
     this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
     this.isEditable=role_Dtls[0].rolePermissions[i].edit;
     this.isViewtable=role_Dtls[0].rolePermissions[i].view;
     if(this.isEditable==false)
     this.isviewEditable=false;
   }
 }
// End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.id=+params['id']
            this.GetRTVbyId();         
          }
          if (params['chkid']) {
            this.chkId = +params['chkid'];
           }
          this.assignMode(params['action']);
          this.GetSubsideryList();

        } else {
          this.showAlert('cannot get params');
        }
      },
      (error) => {
        this.showAlert('add');
      }
    );
    
  }
  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        this.aproBttn == false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.aproBttn == true;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.aproBttn == true;
        break;

      default:
        break;
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
     /* Tab*/
  handleTabChange(event: any) {
    //Fetch History if the selected tab index is History Tab index
    if (event.index == 1) {
      this.LoadHistory();
     // this.displayAddressDialog = false;
    }
  }

/* start get Get Subsidiary List */
GetSubsideryList() {
  if(this.RetloginDetails.userType=='SUPERADMIN')
 // if(this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null)
    {
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId='+this.RetRoleDetails[0].accountId,this.RetloginDetails.token).subscribe(
  
  //this.httpService.GetAll("/setup-ws/subsidiary/get/all",this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else
    { this.Subsidiarylist = res;
      
       this.isReloadSub=false;}
    },
    (error) => {
      this.showAlert(error);
      this.isReloadSub=false;

    }
  );
    }
    else if(this.RetloginDetails.userType=='ENDUSER')
    {
    this.Subsidiarylist.push({
      "id":this.RetRoleDetails[0].subsidiaryId,
      "name":this.RetRoleDetails[0].subsidiaryName
    });

  }
}
/* End get Get Subsidiary List */
   /* change subsidiary dropdown*/
OnSubsidiaryChnage(){
this.getFiscalDateRanges();
this.GetGRNList();
this.GetSupplierList();
this.GetLocationList();
}
/* start get Get GRN List */
GetGRNList() {
  this.httpService.GetAll("/procure-ws/grn/get-by-subsidiary-id?subsidiaryId="+this.rtv.subsidiaryId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
       { this.showAlert("Unauthorized Access !");
         this.router.navigate(['/login']);
       }
       else if(res.status == 404)
       { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else{
     this.grnlist = res;
     this.isReloadgrn=false
        }
    },
    (error) => {
      this.showAlert(error);
      this.isReloadgrn=false
    }
  );
}
/* End get Get GRN List */
   /*get supplier list */
GetSupplierList() {
  this.httpService
    .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + this.rtv.subsidiaryId,this.rtv.subsidiaryId,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
     { this.supplierlist = res;}
    });
}
   /* get location list*/
GetLocationList(){
  this.httpService.GetAll("/masters-ws/location/get-parent-location-names?subsidiaryId="+this.rtv.subsidiaryId,this.RetloginDetails.token)
  .subscribe(res => {
    if(res.status == 401)
    { this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { this.showAlert("Wrong/Invalid Token!");
       this.router.navigate(['/login']);
     }
     else if (res.error){
   // var error = JSON.parse(res.error);
    this.toastService.addSingle(
      'error',
      'Error',
      res.error.errorMessage
    );
    this.locationlist = [];
    }
    else {
    this.locationlist=res;
    }
    }, error => {
    },
     () => {
       // 'onCompleted' callback.
       // No errors, route to new page here
     });
}
   /* on grn change*/
ongrnChange() {
 
  this.rtv.totalAmount=0.00;
  this.rtv.rtvItems=[];
  this.markall=false;
  let that = this;
  this.grnlist.find(o => {
    if (o.id === parseInt(this.rtv.grnId)) {  
       that.grn=o;  
       that.rtv.supplierId= o.supplierId;
       that.rtv.locationId = o.locationId;
       that.rtv.grnNumber = o.grnNumber;

       this.GetSupplierbyId();
       this.GetLocationbyId();
       this.GetItemListByGrn();
    }
  });
}

/* start get Get item list by grn  */
GetItemListByGrn() {
  this.httpService.GetAll("/procure-ws/grn/get-by-grn-id?grnId="+this.rtv.grnId,this.RetloginDetails.token).subscribe(
    (res) => {
      this.rtv.rtvItems=[];
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
       { res.map((data:any,index:any)=>{
        this.rtv.rtvItems.push(new RtvItem())
        this.rtv.rtvItems[index].itemId= data.itemId;
        this.rtv.rtvItems[index].grnId= data.grnId;
        this.rtv.rtvItems[index].poiId= data.poiId;
        this.rtv.rtvItems[index].itemName= data.itemName;
        this.rtv.rtvItems[index].itemDescription= data.itemDescription;
        this.rtv.rtvItems[index].recievedQuantity= data.reciveQuantity;
        this.rtv.rtvItems[index].alreadyReturnQuantity= data.rtvQuantity;
        this.rtv.rtvItems[index].deleted= data.deleted;
        this.rtv.rtvItems[index].billQuantity= data.billQuantity;
        this.rtv.rtvItems[index].rate= data.rate.toFixed(2);

      })}

    },
    (error) => {
      this.showAlert(error);

    }
  );
}
/* End get Get item list by grn */

/* start get Get Supplier id */
GetSupplierbyId() {
  this.httpService
    .GetById('/masters-ws/supplier/get?id=' + this.rtv.supplierId,this.rtv.supplierId,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
      {this.supplier = res;
      this.rtv.supplierName=this.supplier.name;}
    });
}
/* end get Get Supplier id */
/* start get Get Supplier id */
GetLocationbyId() {
  this.httpService
    .GetById('/masters-ws/location/get?id=' + this.rtv.locationId,this.rtv.locationId,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
     { this.rtv.locationName=res.locationName;}
    });
}
/* end get Get Supplier id */
   /* Save function start*/
saveRTV() {
  var isAmountValid=true
  if(!this.rtv.subsidiaryId){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Subsidiary'
    );
    return;
  }
  if(!this.rtv.rtvDate){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Rtv Date'
    );
    return;
  }
  if(!this.rtv.grnNumber){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select PO Type'
    );
    return;
  }
  if(!this.rtv.supplierId){
    this.toastService.addSingle(
      'error',
      'Error',
      'Please select Supplier'
    );
    return;
  }
  let tempTRVItems:RtvItem[]=[];
  for(let i=0;i<this.rtv.rtvItems.length;i++)
  {
    if(this.rtv.rtvItems[i].selected){
         if(!this.rtv.rtvItems[i].returnQuantity || this.rtv.rtvItems[i].returnQuantity <=0)
         {
          this.toastService.addSingle(
            'error',
            'Error',
            'Return Quantity must be greater than 0!'
          );
               return;
         }
         else
         {
          tempTRVItems.push(this.rtv.rtvItems[i])
         }
    }
  }

  if(this.addMode){ this.rtv.rtvItems=tempTRVItems; }

  let days:any = new Date(this.rtv.rtvDate).getDate();
  let months:any = new Date(this.rtv.rtvDate).getMonth()+1;
  let year:any = new Date(this.rtv.rtvDate).getFullYear();
  if(months<10)
  {
    months="0".toString()+months.toString();
  }
  if(days<10)
  {
    days="0".toString()+days.toString();
  }
  this.rtv.rtvDate=year+"-"+months+"-"+days;
  this.showloader=true;

  if(this.addMode){
    this.rtv.createdBy=this.RetloginDetails.username;this.rtv.lastModifiedBy=this.RetloginDetails.username
    }
   else if(!this.addMode){
    this.rtv.lastModifiedBy=this.RetloginDetails.username
    }

  this.httpService.Insert('/procure-ws/rtv/save', this.rtv,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else if (res.error){
          this.toastService.addSingle(
            'error',
            'Error',
            JSON.stringify(res.error)
          );
          this.showloader=false;
        }        
      else if (res && res.id > 0) {
        //this.saveAddress();
        this.showSuccess();
        this.showloader=false;
        // alert('Data saved successfully');
        this.router.navigate(['/main/rtv/list']);
      } else {
        this.showError();
        this.showloader=false;
        // alert('!! Something went wrong');
      }
    },
    (error) => {
      this.showAlert('error-' + error);
      this.showloader=false;
    },
    () => { }
  );
}
showSuccess() {
  this.toastService.addSingle(
    'success',
    'Success',
    'Return To Vendor saved Successfully!'
  );
}
showError() {
  this.toastService.addSingle(
    'error',
    'Error',
    'Error occured while saving Return To Vendor!'
  );
}
clearRTVData() {
  if (this.editMode) {
    this.router.navigate(['/main/rtv/list']);
  }
  else {
    this.rtv = new Rtv();
   

  }
}


decimalFilter(event: any) {
  const reg = /^-?\d*(\.\d{0,2})?$/;
  let input = event.target.value + String.fromCharCode(event.charCode);

  if (!reg.test(input)) {
      event.preventDefault();
  }
}

onLocationChange(){
}

/* Start fetching History details */
LoadHistory() {
  if (this.RTVHistoryList.length == 0)
    this.httpService.GetById(`/procure-ws/rtv/get/history?rtvNumber=${this.rtv.rtvNumber}&pageSize=100`,
        this.id,this.RetloginDetails.token
      )
      .subscribe((res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
         else
       { this.RTVHistoryList = res;}
      });
}


showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}
showCSTMAlert(AlertMSG:string,AlertType:string,Alert:string) {
  this.toastService.addSingle(
    AlertType,
    Alert,
    AlertMSG
  );
}
/* Start Reload subsidery */
reloadSubidery(){
  //$('.refsubsidery').addClass('fa-spin');
  this.isReloadSub=true;
  this.rtv.subsidiaryId=0;
  this.grnlist=[];
  this.rtv.grnId=0;
  this.rtv.supplierId=0;
  this.rtv.locationId=0;
  this.rtv.supplierName="";
  this.rtv.locationName="";
  this.rtv.rtvItems=[];
  this.Subsidiarylist=[];
  this.GetSubsideryList();
}
/* End Reload subsidery */
chkenable()
{
  if(this.markall)
  {
    for(let i=0;i<this.rtv.rtvItems.length;i++)
    {
    this.rtv.rtvItems[i].selected=true;
    }
  }
    else
    {
      if(this.addMode)
      {
        for(let i=0;i<this.rtv.rtvItems.length;i++)
      {
      this.rtv.rtvItems[i].selected=false;
      this.rtv.rtvItems[i].returnQuantity=null;
      this.rtv.rtvItems[i].returnQuantity=undefined;
      }
    }
    }
  }
  getdueamt(quantity:any,rate:any,rowindex:number)
  {   
debugger
if( this.rtv.rtvItems[rowindex].returnQuantity)
{    
  
  let LeftAmount:any=(this.rtv.rtvItems[rowindex].recievedQuantity > 0 ?this.rtv.rtvItems[rowindex].recievedQuantity:0)-(this.rtv.rtvItems[rowindex].alreadyReturnQuantity > 0 ?this.rtv.rtvItems[rowindex].alreadyReturnQuantity:0)
   if(this.rtv.rtvItems[rowindex].returnQuantity>LeftAmount)
   {
        this.showErrorAmount();
        this.rtv.rtvItems[rowindex].returnQuantity="0.00";
        this.rtv.rtvItems[rowindex].amount="0.00";
   }
   else{
     this.rtv.rtvItems[rowindex].returnQuantity=parseFloat(this.rtv.rtvItems[rowindex].returnQuantity).toFixed(2);
     quantity=quantity ==undefined?0:quantity==""?0:quantity;
     rate=rate==undefined?0:rate=="" ?0:rate;
     this.rtv.rtvItems[rowindex].amount=(parseFloat(quantity != undefined ?quantity:0)*parseFloat(rate != undefined ?rate:0)).toFixed(2);
    
    }
  }

  this.calculatetotal();
  }
  showErrorAmount() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Return Quantity must be smaller than Receive Quantity!'
    );
  }
  /* start get Get rtv by id */
GetRTVbyId() {


  this.httpService
    .GetById('/procure-ws/rtv/get?id=' + this.id,this.id,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else
     { 
 
      if(this.chkId==1)
        {
          this.isviewapprovereject=true;
        }
      if( res.approvalStatus=='Pending Approval' || res.approvalStatus=='Processed' || res.approvalStatus=='Partially Processed' || res.approvalStatus=='Approved' || res.approvalStatus=='Closed' || res.approvalStatus=='Partially Returned' || res.approvalStatus=='Returned' ) //Send Approval Mode
        {
        this.ApprovalButtonShowHide=0;
        }
        else{
          this.ApprovalButtonShowHide=1;
        }
       for(let i=0;i<res.rtvItems.length;i++)
       {
        if(res.rtvItems[i].amount!=null)
        {
          res.rtvItems[i].amount= res.rtvItems[i].amount.toFixed(2);
        }
        if(res.rtvItems[i].rate!=null)
        {
          res.rtvItems[i].rate= res.rtvItems[i].rate.toFixed(2);
        }
       
       }
       if(res.totalAmount!=null)
       {
        res.totalAmount=res.totalAmount.toFixed(2);
       }
      
      this.rtv = res;
      this.appSequencelist=this.rtv.approvers;
let nextApprover=this.rtv.nextApprover;
let isNextApproverFound:Boolean=false;
if(this.appSequencelist!=undefined)
{
  for(let x=0;x<this.appSequencelist.length;x++)
  {
    let status='';
    if (this.appSequencelist[x].id == nextApprover)
    {
      isNextApproverFound=true;
      status='current';//this.appSequencelist[x]['status']=;
    }
    else
    {
     if(isNextApproverFound)
      {
        status='pending';
        //this.appSequencelist[x]['status']='pending';
      }else{
       status='approved';
        //this.appSequencelist[x]['status']='approved';
      }
    }
    this.appSequencelist[x]['status']=status;
  }
}

      this.rtv.rtvDate=this.rtv.rtvDate?new Date(this.rtv.rtvDate):this.rtv.rtvDate;
      this.GetGRNList();
     this.GetSupplierList();
     this.GetLocationList();
     
      }
    });
}
/* end get GetPayment by id */
/* Start Reload GRN */
reloadGrn(){
  //$('.refsubsidery').addClass('fa-spin');
  this.isReloadgrn=true;
  this.rtv.grnId=0;
  this.rtv.supplierId=0;
  this.rtv.locationId=0;
  this.rtv.supplierName="";
  this.rtv.locationName="";
  this.rtv.rtvItems=[];
  this.GetGRNList();
}
/* End Reload GRN */

CompareRTVDate()
  {  
    this.getFiscalDateRanges();
 if(this.rtv.rtvDate != undefined || this.rtv.rtvDate != null)
 {
  let Grndays:any =  new Date(this.grn.grnDate).getDate();
  let Grnmonths:any = new Date(this.grn.grnDate).getMonth()+1;
  let Grnyear:any =  new Date(this.grn.grnDate).getFullYear();

   if(this.rtv.rtvDate<new Date(this.grn.grnDate))
   {
     this.toastService.addSingle(
       'error',
       'Error',
       'RTV Date must be greater than or equal to GRN Date: ' +  (this.grn.grnDate !== undefined ? ((Grndays.toString().length ==1?"0"+Grndays:Grndays)+ '-' +(Grnmonths.toString().length ==1?"0"+Grnmonths:Grnmonths)+ '-' + Grnyear ):"")
     );
     setTimeout(() => {
      this.rtv.rtvDate="";
     }, 100);
       
   }
  }
  }
     /*Fiscal date range */
  getFiscalDateRanges() {
    let Subsidiary=this.rtv.subsidiaryId;
    let InputDate=this.rtv.rtvDate;
    if((Subsidiary != undefined || Subsidiary != "") && (InputDate!= undefined || InputDate!= null)) {

    this.httpService
    .GetById('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId=' + Subsidiary, Subsidiary,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
         this.router.navigate(['/login']);
       }
       else if (res) {
        this.fiscalCalenderDTLS=res;
        if(this.fiscalCalenderDTLS != null && this.fiscalCalenderDTLS.fiscalCalanderAccounting.length >0)
        {
        let AllowMonths: any = "Allow Months: ";
        let IsDateAvailable:boolean = false;
    
        var Dummymonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    
        let PRdays: any = new Date(InputDate).getDate();
        let PRmonths: any = new Date(InputDate).getMonth() + 1;
        let PRyear: any = new Date(InputDate).getFullYear();
        let CompareDate: any = InputDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""
    
        for (let x = 0; x < this.fiscalCalenderDTLS.fiscalCalanderAccounting.length; x++) {
          AllowMonths += this.fiscalCalenderDTLS.fiscalCalanderAccounting.length == (x + 1) ? this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month : this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month + " , "
    
          if (CompareDate >= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].fromDate && CompareDate <= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].toDate && this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month == Dummymonths[PRmonths - 1] + "-" + PRyear) {
            IsDateAvailable = true;
          }
        }
    
        if (IsDateAvailable == false) {
          this.showAlert("Selected date is not active in Fiscal Calendar ! " + AllowMonths);
          this.rtv.rtvDate = {};
        }
      }
      } else {
        this.showAlert("No Data Found");
      }
    },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
           error
        );
      }

    );

}
  }
  onDisableChange(rowindex:number)
  {
   if(this.rtv.rtvItems[rowindex].selected == false && this.addMode)
    {
      this.rtv.rtvItems[rowindex].returnQuantity=null;
      this.rtv.rtvItems[rowindex].returnQuantity=undefined;
    }
  }

  sendrtvForApproval() {
    let action: string;
    this.showloader=true;
    this.httpService
      .GetById('/procure-ws/rtv/send-for-approval?id=' + this.rtv.id, this.rtv.id,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
         else if (res == true) {
        this.toastService.addSingle(
          'success',
          'Success',
          'RTV Sent for Approval Successfully!'
        );
        this.showloader=false;
        window.location.reload();
       } else {
        this.showAlert(res.errorMessage);
        this.showloader=false;
      }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending RTV for Approval!'
          );
          this.showloader=false;
        });
  }
   /*self approval */
  sendrtvselfApproval() {
    let action: string;
    this.showloader=true;
    this.httpService
      .GetById('/procure-ws/rtv/self-approve?rtvId=' + this.rtv.id, this.rtv.id,this.RetloginDetails.token)
      .subscribe((res) => {
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
           this.router.navigate(['/login']);
         }
         else if (res == true) {
        this.toastService.addSingle(
          'success',
          'Success',
          'PR Approved Successfully!'
        );
        this.showloader=false;
        window.location.reload();
       } else {
        this.showAlert(res.errorMessage);
        this.showloader=false;
      }
      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending RTV for Approval!'
          );
          this.showloader=false;
        }
      );
  }
   /* */
  getamt(quantity:any,rate:any,rowindex:number)
  {
    quantity=quantity ==undefined?0:quantity==""?0:quantity;
    rate=rate==undefined?0:rate=="" ?0:rate;
    this.rtv.rtvItems[rowindex].amount=(parseFloat(quantity != undefined ?quantity:0)*parseFloat(rate != undefined ?rate:0)).toFixed(2);
    this.calculatetotal();

  }

  decimalfrectionRate(event: any,index:any) {
    if(event.target.value !="")
    this.rtv.rtvItems[index].rate=parseFloat(event.target.value).toFixed(2)
  }
     /* fraction*/
  decimalfrectionQuntity(event: any,index:any) {
    if(event.target.value !="")
    this.rtv.rtvItems[index].returnQuantity=parseFloat(event.target.value).toFixed(2)
  }
   /* calculate total*/
  calculatetotal()
  {
 
    this.rtv.amount=0.00;
    this.rtv.totalAmount=0.00;
   for(let i=0;i< this.rtv.rtvItems.length;i++)
   {
    if(this.rtv.rtvItems[i].rate!=undefined && this.rtv.rtvItems[i].returnQuantity!=undefined)
    {
    
      this.rtv.amount+=(parseFloat(this.rtv.rtvItems[i].rate)*parseFloat(this.rtv.rtvItems[i].returnQuantity));
     // this.debitNotes.amount=parseFloat(this.debitNotes.amount).toFixed(2)+parseFloat(this.debitNotes.debitNoteItem[i].basicAmount).toFixed(2);
      
      this.rtv.totalAmount=this.rtv.amount;
    }
     

    }
    this.rtv.amount=parseFloat(this.rtv.amount).toFixed(2);
    this.rtv.totalAmount=parseFloat(this.rtv.totalAmount).toFixed(2);
   
  }
     /* View button navigation*/
  gotopage()
{
  if(this.chkId)
  {
    this.router.navigate(['/main/rtv/rtv-approval']);
  }
  else
  {
    this.router.navigate(['/main/rtv/list']);
  }
 
  }
   /* approve from add-edit*/
  funapprove()
{
  try { 
   var approveList:any=[];   
   approveList.push(this.id);
    if(approveList.length>0){
      this.showloader = true;
      if(this.RetloginDetails.userType=='SUPERADMIN'){
        this.url='/procure-ws/rtv/approve-all-rtv?currentApproverId=' + this.empID;

       }
       else if(this.RetloginDetails.userType=='ENDUSER')
       {
            if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
            {
              this.url='/procure-ws/rtv/approve-all-rtv?currentApproverId=' + this.empID;
            }
            else
            {
              this.url='/procure-ws/rtv/approve-all-rtv'
            }
      
       }
    this.httpService.Insert(this.url,approveList,this.RetloginDetails.token).subscribe(
      (res) => {
        if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {

        if (res.messageCode) {
          this.toastService.addSingle(
            'error',
            'Error',
            res.errorMessage
          );
          this.showloader = false;
        } else {
          this.toastService.addSingle(
            'success',
            'Success',
            'Approve selected RTV!'
          );
        //this.loadPRApproval();
        this.showloader = false;
        this.router.navigate(['/main/rtv/rtv-approval']);
        }
      }
       // this.loading = false;
      },
      (error) => {
        this.showAlert(error);
        this.showloader = false;
       // this.loading = false;
      }
    );
    }
  } catch (err:any) {
    this.showAlert(err);
    this.showloader = false;
  }
}
   /*hide comments window */
hidepopup()
{
  this.display=false;
}
   /* reject rtv from add-edit page*/
funreject()
{
 
  try { 
    if(this.rtv.comments=="" || this.rtv.comments==undefined)
    {
         this.showAlert("Please enter Comments !");
         return;

    }
    else
    {
      var rejectList:any=[];
      var isrejectComments:boolean=false   
      rejectList.push({id:this.id,rejectedComments:this.rtv.comments})
     
        this.showloader = true;
        
      this.httpService.Insert('/masters-ws/rtv/reject-all-rtv',rejectList,this.RetloginDetails.token).subscribe(
        (res) => {
          if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {
  
          if (res.messageCode) {
           this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
            this.showloader = false;
            this.display=false;
          } else {
            this.toastService.addSingle(
              'success',
              'Success',
              'Reject selected RTV!'
            );
            this.display=false;
            this.showloader = false;
            this.router.navigate(['/main/rtv/rtv-approval']);
          }
          
         // this.loading = false;
        }
        },
        (error) => {
          this.display=false;
          this.showAlert(error);
          this.showloader = false;
         // this.loading = false;
        }
      );
    }
   
    
    
 
  } catch (err:any) {
    this.showAlert(err);
    this.showloader = false;
  }
}
OpenAppSequence()
{
  this.isAppSequenceVisivble=true;
}
   /*Open comments window */
Opendialog()
{
  this.display=true;
}
recallStatus(mainId:any)
{
  this.showloader = true;
  this.httpService
    .GetAllResponseText('/procure-ws/rtv/recall?id=' +mainId, this.RetloginDetails.token)
    .subscribe((res) => {
      //For Auth
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else if (res.status == 200) {
          this.toastService.addSingle(
            'success',
            'Success',
            res.error.text
          );
          this.showloader = false;
          window.location.reload();
      }
      else
      {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      }
    },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      });
}
}