import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RtvAddEditComponent } from './rtv-add-edit.component';

describe('RtvAddEditComponent', () => {
  let component: RtvAddEditComponent;
  let fixture: ComponentFixture<RtvAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RtvAddEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RtvAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
