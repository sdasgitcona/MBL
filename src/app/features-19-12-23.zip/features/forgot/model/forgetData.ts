export class OTP{
    otpC1:any;
    otpC2:any;
    otpC3:any;
    otpC4:any;
    otpC5:any;
    otpC6:any;
    username:string
    newPassword?:number;
    confirmPassword?:number;
}