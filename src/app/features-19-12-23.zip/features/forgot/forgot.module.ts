import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ForgotRoutingModule } from './forgot-routing.module';
import { ForgotPwdComponent } from './forgot-pwd/forgot-pwd.component';

import { TabViewModule } from 'primeng/tabview';
import { ButtonModule } from 'primeng/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { InputMaskModule } from "primeng/inputmask";
import {InputNumberModule} from 'primeng/inputnumber';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {InputTextModule} from 'primeng/inputtext';
@NgModule({
  declarations: [
    ForgotPwdComponent
  ],
  imports: [
    CommonModule,
    ForgotRoutingModule,
    TabViewModule,
    ButtonModule,
    InputMaskModule,
    InputNumberModule,
    ProgressSpinnerModule,
    FormsModule,
    InputTextModule
  ]
})
export class ForgotModule { }
