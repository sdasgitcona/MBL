import { Component, OnInit } from '@angular/core';
import { OTP } from '../model/forgetData';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { ActivatedRoute,Router } from '@angular/router';
import { trigger, state, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'app-forgot-pwd',
  templateUrl: './forgot-pwd.component.html',
  styleUrls: ['./forgot-pwd.component.scss']
})

export class ForgotPwdComponent implements OnInit {
  OTPsuccess: boolean;
  OTPfailed: boolean;
  OTPAvailable: boolean;
  showloader: boolean;
  GetOTP:string="";
  EnteredOTP:string="";
  OTPDetails:OTP=new OTP();
  loggerUser:any;
  display: any;
  timer:any;
  resend:any;

  constructor( private toastService: ToastService,private HttpService: CommonHttpService, private router: Router) { }

  ngOnInit(): void {
    if (localStorage.getItem("LoggerUserName") != null)
    {
      this.loggerUser=localStorage.getItem("LoggerUserName");
      //this.timer(1);
    }
  }

  getEnteredOTP(event: any) {
    //if(Input.value.toString().length >1)
    //alert(Input.value)
    let element;
    if (event.code !== 'Backspace')
      element = event.srcElement.nextElementSibling;

    if (event.code === 'Backspace')
      element = event.srcElement.previousElementSibling;

    if (element == null)
      return;
    else
      element.focus();
  }
  onDigitInput() {

      let OTPLength =this.OTPDetails.otpC1 +this.OTPDetails.otpC2+this.OTPDetails.otpC3+this.OTPDetails.otpC4+this.OTPDetails.otpC5+this.OTPDetails.otpC6;
      if(OTPLength.length == 6)
      {
        //alert(OTPLength);
        if(this.GetOTP == OTPLength)
        {
          
          this.OTPsuccess=true;
          this.OTPfailed=false;
          clearInterval(this.timer);
        }
        else{
          this.showAlert("OTP Not Matched","error");
          this.OTPsuccess=false;
          this.OTPfailed=true;
          this.OTPDetails.otpC1 = '';
          this.OTPDetails.otpC2 = '';
          this.OTPDetails.otpC3 = '';
          this.OTPDetails.otpC4 = '';
          this.OTPDetails.otpC5 = '';
          this.OTPDetails.otpC6 = '';
        }
      }
      
      
  }

  nextBox(event: any){
    if (/\D/g.test(event.target.value))
  {
    // Filter non-digits from input value.
    event.target.value = event.target.value.replace(/\D/g, '');
  }
  if( event.target.value == "" && event.code !== 'Backspace')
  {
    return;
  }

    let element;
    if (event.code !== 'Backspace')
      element = event.srcElement.nextElementSibling;

    if (event.code === 'Backspace')
      element = event.srcElement.previousElementSibling;

      if (element != null)
      element.focus();
  }

  decimalFilter(event: any) {
    const reg = /^-?\d*(\.\d{0,2})?$/;
    let input = event.target.value + String.fromCharCode(event.charCode);

    if (!reg.test(input)) {
      event.preventDefault();
    }
  }

  getOTP_old() {
    this.showloader=true;
    let userName:any = localStorage.getItem("LoggerUserName");
    this.HttpService.GetAll('/masters-ws/employee/send-mail-with-otp?mail='+userName).subscribe(
      (res) => {
        if(res.errorMessage == undefined)
        {this.GetOTP=res;
        this.showAlert("OTP has been sent to your registered email id !","success")
        this.showloader=false;
        this.OTPAvailable = true;
        this.StartTimer(2);
      }
        else
        {
          this.showAlert(res.errorMessage,"error");
        }
      },
      (error) => {
        this.showAlert("Some Error Occoured","error");
     },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
    //employee/send-mail-with-otp?mail
    //this.showloader=true;
    
  }

    getOTP() {
    
    this.showloader=true;
    let userName:any = localStorage.getItem("LoggerUserName");

    let uri = userName;
    let encoded = encodeURIComponent(uri);
    

    this.HttpService.GetAll('/masters-ws/employee/send-mail-with-otp?mail='+encoded).subscribe(
      (res) => {
        if(res.errorMessage == undefined)
        {this.GetOTP=res;
        this.showAlert("OTP has been sent to your registered email id !","success")
        this.showloader=false;
        this.OTPAvailable = true;
        this.resend = false;
        this.StartTimer(2);
      }
        else
        {
          this.showAlert(res.errorMessage,"error");
        }
      },
      (error) => {
        this.showAlert("Some Error Occoured","error");
     },
      () => {
        // 'onCompleted' callback.
        // No errors, route to new page here
      }
    );
    //employee/send-mail-with-otp?mail
    //this.showloader=true;
    
  }

ResetPassword()
{
  if(this.loggerUser === null || this.loggerUser == "")
  {
    this.showAlert("No User Name Found !",'error');
    return false;
  }
  if(this.OTPDetails.newPassword == undefined || this.OTPDetails.newPassword == null)
  {
    this.showAlert("Enter New Password !",'error');
    return false;
  }
  else if(this.OTPDetails.confirmPassword == undefined || this.OTPDetails.confirmPassword == null)
  {
    this.showAlert("Enter New Password !",'error');
    return false;
  }
  if(this.OTPDetails.newPassword == this.OTPDetails.confirmPassword)
  {
  this.OTPDetails.username=this.loggerUser ;
  this.showloader=true;
  this.HttpService.Insert('/setup-ws/api/auth/change-password', this.OTPDetails).subscribe(
    (res) => {
      if (res) {
        this.showloader=false;
        this.showAlert("Passord Reset Successfully",'success');
        localStorage.removeItem("LoggerUserName");
        this.router.navigate(['/login']);
      } else {
        this.showloader=false;
       }
    },
    (error) => {
      this.showAlert(error,'error');
      this.showloader=false;
     },
    () => {}
  );}
  else
  {
    this.showAlert("New Password and Confirm Password are mismatch !",'error');
  }
}


StartTimer(minute:any) {
  // let minute = 1;
  let seconds: number = minute * 60;
  let textSec: any = "0";
  let statSec: number = 60;

  const prefix = minute < 10 ? "0" : "";

  this.timer = setInterval(() => {
    seconds--;
    if (statSec != 0) statSec--;
    else statSec = 59;

    if (statSec < 10) {
      textSec = "0" + statSec;
    } else textSec = statSec;

    this.display = `${prefix}${Math.floor(seconds / 60)}:${textSec}`;

    if (seconds == 0) {
      this.showAlert("Your OTP has been expired",'error');
      // this.OTPAvailable=false;
      this.resend = true;
      this.GetOTP="";
      this.OTPDetails.otpC1=undefined;
      this.OTPDetails.otpC2=undefined;
      this.OTPDetails.otpC3=undefined;
      this.OTPDetails.otpC4=undefined;
      this.OTPDetails.otpC5=undefined;
      this.OTPDetails.otpC6=undefined;
      this.OTPsuccess=false;
      this.OTPfailed=false;
      clearInterval(this.timer);
    }
  }, 1000);
}

  showAlert(AlertMSG:string,MsgType:string) {
    this.toastService.addSingle(
      MsgType,
      'Alert',
      AlertMSG
    );
  }
}
