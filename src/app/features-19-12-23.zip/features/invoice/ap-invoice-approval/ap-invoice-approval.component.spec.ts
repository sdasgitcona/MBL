import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApInvoiceApprovalComponent } from './ap-invoice-approval.component';

describe('ApInvoiceApprovalComponent', () => {
  let component: ApInvoiceApprovalComponent;
  let fixture: ComponentFixture<ApInvoiceApprovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApInvoiceApprovalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApInvoiceApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
