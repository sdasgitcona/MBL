export class APInvoice {
    id?: number;
    APInvoiceId?: any;
}
export class APInvoiceModal {
    mailId: number;
    fromId: string;
    subjectLine: string;
    attachName: string;
    attachType: string;
    receiveDate: Date;
    createdBy: string;
    modifiedBy: string;
    dateCreated: Date;
    lastUpdated: Date;
    attachment?: any;
    selected?: boolean;
}

// export class InvoiceItem {
//     itemName?: any;
//     description: string;
//     uom?: any;
//     unitPrice: string;
//     discount: string;
//     netAmount: string;
//     billQty: number;
// }

// export class InvoiceDetail {
//     invoiceNo: string;
//     location?: any;
//     subsidiary?: any;
//     payTerm?: any;
//     supplierName?: any;
//     poNo: string;
//     invoiceDate: string;
//     dueDate?: any;
//     invoiceItems: InvoiceItem[]=[];
// }


export class GrnDetails {
    id: number;
    grnNumber: string;
    subsidiaryId: number;
    locationId: number;
    poNumber: string;
    grnDate: Date;
    supplierId: number;
    currency: string;
    memo?: any;
    purchaseDate?: any;
    exchangeRate: number;
    modeOfTransport: string;
    vehicleNumber: string;
    awNumber: string;
    reciver: string;
    netsuiteId: string;
    createdDate: Date;
    createdBy?: any;
    lastModifiedDate: Date;
    lastModifiedBy: string;
    poId: number;
    locationName?: any;
    subsidiaryName?: any;
    supplierName?: any;
    grnItem?: any;
    deleted: boolean;
    ewayBillNumber: string;
}
export class Grn {
    id: number;
    grnNumber: string;
    subsidiaryId: number;
    locationId: number;
    poNumber: string;
    grnDate: Date;
    supplierId: number;
    currency: string;
    memo?: any;
    purchaseDate?: any;
    exchangeRate: number;
    modeOfTransport: string;
    vehicleNumber: string;
    awNumber: string;
    reciver: string;
    netsuiteId: string;
    createdDate: Date;
    createdBy?: any;
    lastModifiedDate: Date;
    lastModifiedBy: string;
    poId: number;
    locationName?: any;
    subsidiaryName?: any;
    supplierName?: any;
    grnItem: GrnItem[];
    deleted: boolean;
    ewayBillNumber: string;

}
export interface GrnItem {
    id: number;
    grnId: number;
    itemId: number;
    poNumber: string;
    grnNumber: string;
    itemName: string;
    itemDescription?: any;
    itemUom?: any;
    taxGroupId?: any;
    quantity?: any;
    reciveQuantity?: any;
    remainQuantity: number;
    lotNumber: string;
    rate: any;
    rtvQuantity: number;
    invoiceNumber: string;
    createdDate: Date;
    createdBy?: any;
    lastModifiedDate: Date;
    lastModifiedBy: string;
    deleted: boolean;
    unbilledQuantity?: any;
}

export class InvoiceDetail {
    invoiceId: number;
    invoiceCode: string;
    supplierId: number;
    subsidiaryId: number;
    poId: number;
    poNumber: any;
    locationId: number;
    invoiceNo: string;
    invStatus: string;
    paymentTerm?: string;
    integratedId?: any;
    currency?: string;
    billTo: any;
    shipTo?: any;
    invoiceDate: any;
    dueDate: any;
    fxRate: any;
    amount: any;
    taxAmount: any;
    totalAmount: any;
    paymentAmount: number;
    amountDue?: any;
    invoiceItems: InvoiceItem[] = [];
    createdBy: string;
    lastModifiedBy: string;
    modifiedBy: string;
    dateCreated: Date;
    lastUpdated: Date;
    payTerm?: any;
    supplierName?: any;
    subsidiaryName: string;
    matchType: any;
    trn: any;
    invoicePayments: InvoicePayments[] = []
    approvalRoutingActive: boolean;
    nextApprover: any;
    approvedBy: any;
    nextApproverLevel: any;
    isApprovalButtonShowHide: any;
    requestor?:any;
    requestorName?:any;
    projectId?:any;
    departmentId?:any;
    mailId?:any;
    memo?:any;
    department:string;
}
export class InvoiceItem {
    invoiceId?: number;
    invoiceItemId: number;
    itemId?: number;
    grnId: number;
    taxGroupId: number;
    billQty: any;
    rate: any;
    amount: any;
    taxAmount: any;
    totalAmount: any;
    department: string;
    createdBy: string;
    modifiedBy: string;
    dateCreated: Date;
    lastUpdated: Date;
    itemName?: any;
    description?: any;
    uom?: any;
    discount?: any;
    netAmount?: any;
    itemDescription?: any;
    itemUom?: any;
    grnItemList: any[];
    unbilledQuantity?: any;
    poId?: any;
    disabledRate: boolean = false;
    taxOverride?: boolean;
    inclusive?:boolean=false;
    deleted?: boolean = false;
    invoiceItemTax: invoiceItemTax[] = [];
    departmentId:number;
}
export class invoiceItemTax {
    id?: any;
    invoiceId?: any;
    invoiceItemId?: any;
    taxGroupId?: any;
    basicAmount?: any;
    taxAmount?: any;
    rate?: any;
    taxName?: any;
    taxRateName?: any;
    createdBy?: any;
    lastModifiedBy?: any;
    createdDate?: any;
    lastModifiedDate?: any;
    override?: boolean;
    deleted?: boolean;
    inclusive?: boolean;
}

export class InvoicePayments {
    invoicePaymentId: number;
    invoiceId: number;
    paymentId: number;
    amount: number;
    billNo: string;
    type: string;
    bankName?: any;
    billDate?: any;
    createdBy?: any;
    modifiedBy?: any;
    dateCreated: Date;
    lastUpdated: Date;
    deleted: boolean;
}
export class matchType {
    lineNo?: any;
    itemCode?: any;
    poQuntity?: any;
    poRate?: any;
    grnQuntity?: any;
    billingQuntity?: any;
    rate?: any;
    matchStatus?: any;
    poMatch: boolean;
    grnMatch: boolean;
    unbilledQuantity?: any;
    billQuantity?: any;
}

//For CSV
export class file_upliad {
    file: File;
}

export class advancePaymentInvoiceApproval {
    invoiceId: number;
    supplierId: number;
    subsidiaryId: number;
    poId: any;
    locationId: number;
    billToId: any;
    shipToId: any;
    invoiceNo: string;
    invStatus: string;
    paymentTerm: any;
    integratedId: any;
    currency: any;
    billTo: any;
    shipTo: any;
    invoiceCode: any;
    invoiceSupplyNumber: any;
    taxRegNumber: any;
    invoiceDate: string;
    dueDat: any;
    fxRate: any;
    amount: any;
    taxAmount: any;
    totalAmount: any;
    paymentAmount: any;
    amountDue: any;
    externalId: any;
    hasError: boolean;
    approvedBy: any;
    nextApprover: any;
    nextApproverRole: any;
    nextApproverLevel: any;
    approverPreferenceId: any;
    approverSequenceId: any;
    approverMaxLevel: any;
    noteToApprover: any;
    nsMessage: any;
    nsStatus: any;
    subsidiaryName: string;
    supplierName: string;
    poNumber: any;
    locationname: string;
    rejectComment: any;
    invoiceItems: any;
    totalPaidAmount: any;
    invoicePayments: any;
    approvedByName: string;
    createdBy: any;
    lastModifiedBy: any;
    createdDate: any;
    lastModifiedDate: any;
    approvalRoutingActive: boolean;
    // for approval
    selected: boolean;
    NewrejectComments?: any;
    isAdminRole: boolean;
}
export class invoiceFilters{
    subsidiaryId:any;
    supplierId?: any;
    status?: any;
    proformaInvoice?: any;
    currency?: any;
    fromDate?: any;
    toDate?: any;
    unApproved?: any;
    recent?: any;
}
export class commonDropdown
{
    id?:any;
    name?:string;
}

export class BaseSearchPdf {
    filters: invoiceFilters | {} = {};
    pageNumber: number = 0;
    pageSize: number = 0;
    sortColumn: string = '';
    sortOrder: string = '';
  }