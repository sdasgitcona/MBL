import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApinvoiceListComponent } from './apinvoice-list/apinvoice-list.component';
import { ApinvoiceAddEditViewComponent } from './apinvoice-add-edit-view/apinvoice-add-edit-view.component';
import { ApInvoiceApprovalComponent } from './ap-invoice-approval/ap-invoice-approval.component';

const routes: Routes = [
  { path: "", component:ApinvoiceListComponent },
  { path: 'list', component: ApinvoiceListComponent },
  { path: 'list/:status', component: ApinvoiceListComponent },
  { path: 'list/:status/:id', component: ApinvoiceListComponent },
  { path: 'action/:action/:id', component: ApinvoiceAddEditViewComponent, },
  { path: 'action/:action', component: ApinvoiceAddEditViewComponent, },
  { path: 'APlist', component: ApInvoiceApprovalComponent },
  { path: 'APlist/:status', component: ApInvoiceApprovalComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InvoiceRoutingModule { }
