import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { HistoryModel } from 'src/app/shared/shared-components/history/model/history.model';
import { APInvoice, APInvoiceModal, Grn, GrnDetails, InvoiceDetail, InvoiceItem, matchType, GrnItem } from '../model/APInvoice-model';
import { Items } from '../../item/model/item-model';
import { SubsidiaryEntry, Supplier, SupplierAddress } from '../../supplier/model/supplier-model';
import { Subsidiary } from '../../subsidiary/Model/subsidiary-model';
import { Item, PrItems, PurchaseOrder, QAItems, supplierCurrency } from '../../purchase-order/model/purchase-order-module';
import { locations } from '../../locationmaster/model/locationmaster-model';
import { TaxGroup } from '../../tax-group/model/tax-group-model';
import { any } from '@amcharts/amcharts5/.internal/core/util/Array';
import { TRISTATECHECKBOX_VALUE_ACCESSOR } from 'primeng/tristatecheckbox';
import { object } from '@amcharts/amcharts5';
import { isEmpty } from 'rxjs';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { FormGroup } from '@angular/forms';
import { fromEvent, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { saveAs } from 'file-saver';
import { RenderTextMode } from 'ng2-pdf-viewer';
var Newitemcopy: any;

@Component({
  selector: 'app-apinvoice-add-edit-view',
  templateUrl: './apinvoice-add-edit-view.component.html',
  styleUrls: ['./apinvoice-add-edit-view.component.scss']
})
export class ApinvoiceAddEditViewComponent implements OnInit {
  private subscription: any;
  viewMode: boolean = false;
  addMode: boolean = false;
  editMode: boolean = false;
  APInvoice: APInvoice = new APInvoice();
  APInvoiceId: number = 0;
  paymentTermOptions: any;
  value2: number = 65;
  aPInvoices: APInvoiceModal[] = [];
  selected: boolean = false;
  baseurl = {};
  imageurl:any;
  isdeptbypo:boolean=false;
  isdeptbypo_:boolean=true;
  pdfSrc = "";
  pdfviewer:boolean=false;
  doctype: any;
  isImport: boolean = false;
  invoiceDetails: InvoiceDetail = new InvoiceDetail();
  Address: any;
  url:any;
  //purchaseorderHistoryList: PurchaseOrder[] = [];
  display: boolean = false;
  isReloadSub: boolean;
  isReloadSupplier: boolean;
  isReloadlocation: boolean;
  Subsidiarylist: any[] = [];
  subsidiary: Subsidiary = new Subsidiary();
  supplier: Supplier = new Supplier();
  supplierlist: Supplier[] = [];
  itemList: Items[] = [];
  PRitemList: PrItems[] = [];
  locationlist: locations[] = [];
  taxGroupList: TaxGroup[] = [];
  taxgroup: TaxGroup = new TaxGroup();
  currency: supplierCurrency[] = [] //[{ id?: number; name?: string; code?: string; }];
  orderId: number;
  taxamount: number = 0;
  selectedRow: number = 0;
  totalBasicAmount: number = 0;
  totalTaxAmount: number = 0;
  totalAmount: number = 0;
  PRList: any;
  QAList: any[] = [];
  QAitemList: QAItems[] = [];
  billingAddressList: SupplierAddress[] = [];
  shippingAddressList: SupplierAddress[] = [];
  poNumber: any;
  InvoiceHistoryList: HistoryModel[] = [];
  POList: PurchaseOrder[] = [];
  paymentterm: any;
  isPOtaxGroup: boolean = false;
  purchaseorder: PurchaseOrder = new PurchaseOrder();
  grnList: Grn[] = [];
  grn: Grn = new Grn();
  isPo: boolean = false;
  isGrn: boolean = false;
  isGrnlist: boolean = false;
  selectedMailId: any;
  billTo: any;
  shipTo: any;
  itemCopy: any;
  isMatchConfirm: boolean;
  matchTypes: matchType[] = [];
  RetloginDetails: any;
  // For Role Base Access
  isEditable: boolean;
  isCreatetable: boolean;
  isViewtable: boolean;
  isviewEditable: boolean = true;
  empID: number;
  // For Role Base Access
  isItemDilog: boolean = false;
  isMatchDilog: boolean = false;
  itemListByDes: Items[] = [];
  file: File; // Variable to store file
  isVisibleDIV: boolean = false;
  isEditableTaxAmount?: boolean;
  TaxGroupRowIndex?: any;
  HistoryList: HistoryModel[] = [];
  isAutoMode: boolean;
  isPOEnableMode: boolean;
  TaxViewOnly: boolean;
  showloader: boolean = false;
  fiscalCalenderDTLS: any;
  ApprovalButtonShowHide: Number = 0;
  TwoWaydisabledRate: boolean = false;
  fileUpload: boolean = true;
  uploadForm: FormGroup;
  hideAutoCreate: boolean;
  RetRoleDetails: any;
  listURL:any;
  approveMode:boolean=false;
  isConfirmMatchDisabled:boolean=false;
  approvalRejectComment:any;
  displayComments:boolean=false;
  EmployeeList:any[]=[];
  loginId:number;
  appSequencelist:any[]=[];
  isAppSequenceVisivble:boolean;
  SubIdList:any=[];
  ProjectList:any[];
  departmentOptions:any[];
  dept_header:any;
  private unsubscriber: Subject<void> = new Subject<void>();
  constructor(
    private httpService: CommonHttpService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private toastService: ToastService,
    private ToggleButtonModule: ToggleButtonModule
  ) {
    this.paymentterm = ['15 Days', '30 Days', '60 Days', '90 Days', 'DUE UPON RECEIPT'];
  }
  
  ngOnInit(): void {
    if (localStorage.getItem("LoggerDTLS") == null) {
      this.router.navigate(['/login']);
    }
    // For Role Base Access
    const logDetails: any = localStorage.getItem("LoggerDTLS");
    const LoggerId = JSON.parse(logDetails);

    const LDetails: any = localStorage.getItem("LoggerDTLS");
    this.RetloginDetails = JSON.parse(LDetails);
    this.loginId= LoggerId.employeeId;
    this.empID = LoggerId.employeeId;
    const retDetails: any = localStorage.getItem("RoleDTLS");
    var role_Dtls = JSON.parse(retDetails);
    this.RetRoleDetails = role_Dtls;

//Back Button disabled
    // history.pushState(null, '');
    // fromEvent(window, 'popstate')
    //   .pipe(takeUntil(this.unsubscriber))
    //   .subscribe((_) => {
    //     history.pushState(null, '');
    //     this.showAlert("Back Button Feature blocked");
    //   });

    for (let i = 0; i < role_Dtls[0].rolePermissions.length; i++) {
      if (role_Dtls[0].rolePermissions[i].accessPoint == "AP invoice") {
        this.isCreatetable = role_Dtls[0].rolePermissions[i].create;
        this.isEditable = role_Dtls[0].rolePermissions[i].edit;
        this.isViewtable = role_Dtls[0].rolePermissions[i].view;
        if (this.isEditable == false)
          this.isviewEditable = false;
      }
    }
    // End For Role Base Access

    this.subscription = this.activatedRoute.params.subscribe(
      (params) => {
        if (params) {
          if (params['id']) {
            this.APInvoiceId = +params['id']; // (+) converts string 'id' to a number
            this.GetInvoicebyInvoiceId();
          }
          this.assignMode(params['action']);
          this.GetSubsideryList();
          setTimeout(() => {this.GetMailAll()},400);
         // this.GetMailAll();
          if(this.addMode){ this.loadrequestor();}
          if(params['action']== "approval")
          {
            this.listURL='/main/apinvoice/APlist';
          }
          else
          {
            this.listURL='/main/apinvoice/list';
          }
          // this.testing()
        } else {
          this.listURL='/main/apinvoice/list';
        }
      },
      (error) => {
      }
    );
  }

  assignMode(action: string) {
    switch (action) {
      case 'add':
        this.addMode = true;
        this.viewMode = false;
        this.editMode = false;
        this.isVisibleDIV = false;
        this.approveMode=false;
        break;
      case 'edit':
        this.addMode = false;
        this.viewMode = false;
        this.editMode = true;
        this.isVisibleDIV = true;
        this.approveMode=false;
        break;
      case 'view':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.isVisibleDIV = true;
        this.approveMode=false;
        break;
        case 'approval':
        this.viewMode = true;
        this.addMode = false;
        this.editMode = false;
        this.approveMode=true;
  break;
      default:
        break;
    }
  }

  handleTabChange(event: any) {
    if (event.index == 3) {
      this.LoadHistory();
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.unsubscriber.next();
    this.unsubscriber.complete();
  }
  /* fetch Mail from database */
  GetMailAll() {
    this.aPInvoices = [];
   // this.httpService.GetAll('/finance-ws/mail/get/all?employeeId=' + this.loginId, this.RetloginDetails.token)
    this.httpService.GetAll('/finance-ws/mail/get/all?subsidiaryIds=' + this.SubIdList, this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.statusText != "Not Found") { this.aPInvoices = res; }
        }


      });
  }
  /* End fetch Mail from database */
  /* fetch Mail from email and save in database */
  SaveEmail() {
    this.showloader = true;
    this.isImport = true;
    //this.httpService.Insert('/finance-ws/mail/save/all?employeeId=' + this.empID, {}, this.RetloginDetails.token)
    this.httpService.Insert('/finance-ws/mail/save/all?subsidiaryId=' + this.RetRoleDetails[0].subsidiaryId, {}, this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res)
            window.location.reload();
          this.isImport = false;
        }
      }, (error) => {
        this.showAlert(error);
        this.showloader = false;
        this.isImport = false;
      },
        () => { }
      );

    // this.httpService.GetAll('/mail/get/all?employeeId='+this.empID).subscribe(
    // (res)=> {
    // }
    // )

  }
  /* End fetch Mail from email and save in database */
  onSelect(event: any, mail: APInvoiceModal) {

    
    let url = "http://43.205.33.156:8082/finance-ws/mail/get/attachment?mailId=" //--Dev
    //let url="http://3.7.123.122:8082/finance-ws/mail/get/attachment?mailId=" //--Test
    //let url = "http://3.110.239.158:8082/finance-ws/mail/get/attachment?mailId=" //--testing

    this.aPInvoices.map((data) => {
      data.selected = false;
    })

    if (event.checked) {
      mail.selected = true;
      this.selectedMailId = mail.mailId;
      this.hideAutoCreate = mail.fromId == null ? true : false;
      if (mail.attachType == "pdf") {
        this.doctype = "pdf";
        this.pdfSrc = mail.mailId.toString();
       this.baseurl = {
          url: url + mail.mailId.toString(),
          httpHeaders: { Authorization: 'Bearer ' + this.RetloginDetails.token }
        }

      } else {
        this.doctype = "img";
        this.pdfSrc = mail.mailId.toString();
        //this.baseurl = {
         // url: url + mail.mailId.toString(),
          //httpHeaders: { Authorization: 'Bearer ' + this.RetloginDetails.token }
        //}

        this.httpService.downloadFile('/finance-ws/mail/get/attachment?mailId='+mail.mailId, this.RetloginDetails.token)
        .subscribe(res => {
          
          var base64data:any;
          var reader = new FileReader();
          reader.readAsDataURL(res); 
          reader.onloadend = function() {
            base64data = reader.result;                
            console.log(base64data);
           
          }

          setTimeout(() => {this.imageurl=base64data;},600);
          
        //  saveAs(res, "ggg.jpg");
          //this.executeSaveAs(res);
          //let blob = new Blob([res], {'type': "application/octet-stream"});
          //window.open(res)
        });


      }
    }
    else {
      this.doctype = "";
      this.hideAutoCreate = false;
    }
  }

  blobToBase64(blob:any) {
    return new Promise((resolve, _) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.readAsDataURL(blob);
    });
  }
  showInvoice()
  {
    this.showloader=true;
    let url = "http://43.205.33.156:8082/finance-ws/mail/get/attachment?mailId=" //--Dev
    //let url="http://3.7.123.122:8082/finance-ws/mail/get/attachment?mailId=" //--Test http://3.110.239.158:8082
    //let url = "http://3.110.239.158:8082/finance-ws/mail/get/attachment?mailId=" //--testing

   //  mail.selected = true;
     // this.selectedMailId = mail.mailId;
      //this.hideAutoCreate = mail.fromId == null ? true : false;
      //this.invoiceDetails.mailId=96;
      
      
     
        //this.pdfSrc = mail.mailId.toString();


        this.httpService.downloadFile('/finance-ws/mail/get/attachment?mailId='+ this.invoiceDetails.mailId, this.RetloginDetails.token)
        .subscribe(res => {
          if(res.type=="image/jpeg" || res.type=="image/png")
          {
            
            var base64data:any;
            this.doctype = "img";
            var reader = new FileReader();
            reader.readAsDataURL(res); 
            reader.onloadend = function() {
              base64data = reader.result;                
              console.log(base64data);
             
            }
  
            setTimeout(() => {this.imageurl=base64data;
              this.showloader=false;
              this.pdfviewer=true;
            },600);
          }
          else{
           this.pdfviewer=true;
            this.doctype = "pdf";
            this.baseurl = {
              url: url + this.invoiceDetails.mailId.toString(),
              httpHeaders: { Authorization: 'Bearer ' + this.RetloginDetails.token }
            }
    
          }
          this.showloader=false;

        });
      
       


      //this.doctype = "";
      //this.hideAutoCreate = false;
    
  }
  testing() {
    this.httpService
      .GetByResponseType('/finance-ws/mail/get/attachment?mailId=8', 'blob', this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          var reader = new FileReader;
          reader.onload = function () {
            var blobAsDataUrl = reader.result;
          };
          reader.readAsDataURL(res);
        }


      });
  }

  deleteItemrowlevel(index: number) {
    if (index >= 0) {
      if (this.editMode) {
        if (this.invoiceDetails.invoiceItems[index].invoiceId != null) {
          this.invoiceDetails.invoiceItems[index].deleted = true;
        }
        else {
          this.invoiceDetails.invoiceItems.splice(index, 1);
        }
      }
      else { this.invoiceDetails.invoiceItems.splice(index, 1); }
    };
    this.SummuryAmount();
    this.taxgroup.taxRateRules = [];
    //this.invoiceDetails.amount=parseFloat(this.invoiceDetails.amount)-parseFloat(this.invoiceDetails.invoiceItems[index].amount)
    //this.invoiceDetails.taxAmount=parseFloat(this.invoiceDetails.taxAmount)-parseFloat(this.invoiceDetails.invoiceItems[index].taxAmount);
    //this.invoiceDetails.totalAmount=parseFloat(this.invoiceDetails.totalAmount)-parseFloat(this.invoiceDetails.invoiceItems[index].totalAmount);
  }
  deleteAttachments(row:any,formId:any)
  {
  this.showAlert("Under Process");
  }
  addItem() {

    //  if (
    //    this.invoiceDetails.invoiceItems.length > 0 &&
    //    this.invoiceDetails.invoiceItems[length - 1] == new InvoiceItem()
    //  ) {
    //    return;
    //  }
    this.invoiceDetails.invoiceItems.push(new InvoiceItem());
  }

  /* Get PO details by PO Number */
  GetInvoicebyInvoiceId() {
    let invoiceURL = '';
    let invoiceGetId: Number;
    if (this.selectedMailId) {
      invoiceURL = '/finance-ws/mail/get/invoice?mailId=';
      invoiceGetId = this.selectedMailId
    }
    else {
      invoiceURL = '/finance-ws/invoice/get?invoiceId=';
      invoiceGetId = this.APInvoiceId
    }
    this.showloader=true;
    this.httpService
      .GetById(invoiceURL + invoiceGetId, invoiceGetId, this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.errorMessage) {
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
          } else {
            this.invoiceDetails = new InvoiceDetail();
            this.visibleDiv();
            if (res.invStatus == 'Pending Approval' || res.invStatus == 'Processed' || res.invStatus == 'Partially Processed' || res.invStatus == 'Partially Approved' || res.invStatus == 'Approved' || res.invStatus == 'Closed' || res.invStatus == 'Partially Paid' || res.invStatus == 'Paid') //Send Approval Mode
            {
              this.ApprovalButtonShowHide = 0;
            }
            else {
              this.ApprovalButtonShowHide = 1;
            }
            this.invoiceDetails = res;
            this.invoiceDetails.invoiceItems = this.invoiceDetails.invoiceItems.sort((a: any, b: any) => a.invoiceItemId - b.invoiceItemId);
            this.invoiceDetails.fxRate = this.invoiceDetails.fxRate > 0 ? this.invoiceDetails.fxRate.toFixed(2) :this.invoiceDetails.fxRate;
            this.GetTaxGroupList();
            this.GetSupplierList();
            this.GetLocationList();
            this.GetSupplierCurrencyList();
            this.GetItemList();
            this.GetAddressList();
            this.GetSubsidiarybyId();
            
            //this.fnRequesterList(res.subsidiaryId);
            //this.isAutoMode=this.invoiceDetails.poId >0 ?true:false;
            //this.invoiceDetails = res;
            if (this.invoiceDetails.supplierId) {
              this.isMatchConfirm = true;
              this.GetPOList();
              this.GetPObyPOId();

              if (this.invoiceDetails.poId)
                this.GetGRNbyPOId()
              this.invoiceDetails.invoiceItems.map((data: InvoiceItem, index: number) => {
                if (data.grnId) {
                  this.GetItemByGRN(data.grnId, index);
                  this.getUnbilledAmount(data.grnId,data.itemId,index)
                  data.disabledRate = true;
                }
                data.taxGroupId
              })
            }
            this.GetAllProjectList(res.subsidiaryId);
            this.GetDepartmentList(res.subsidiaryId);
           
            setTimeout(() => {
              this.httpService
                .GetById('/finance-ws/invoice/get?invoiceId=' + this.APInvoiceId, this.APInvoiceId, this.RetloginDetails.token)
                .subscribe((res) => {

                  //For Auth
                  if (res.status == 401) {
                    this.showAlert("Unauthorized Access !");
                    this.router.navigate(['/login']);
                  }
                  else if (res.status == 404) {
                    this.showAlert("Wrong/Invalid Token!");
                    this.router.navigate(['/login']);
                  }
                  else {
                    if (res.errorMessage) {
                      this.toastService.addSingle(
                        'error',
                        'Error',
                        res.errorMessage
                      );
                    } else {
                      this.appSequencelist=res.approvers;
                      let nextApprover=res.nextApprover;
                      let isNextApproverFound:Boolean=false;
                      if(res.approvers != null)
                     { 
                      for(let x=0;x<this.appSequencelist.length;x++)
                      {
                        let status='';
                        if (this.appSequencelist[x].id == nextApprover)
                        {
                          isNextApproverFound=true;
                          status='current';//this.appSequencelist[x]['status']=;
                        }
                        else
                        {
                          if(isNextApproverFound)
                          {
                            status='pending';
                            //this.appSequencelist[x]['status']='pending';
                          }else{
                            status='approved';
                            //this.appSequencelist[x]['status']='approved';
                          }
                        }
                        this.appSequencelist[x]['status']=status;
                      }
                    }
                      this.invoiceDetails.supplierId = res.supplierId;
                      this.invoiceDetails.poId = res.poId;
                     // this.invoiceDetails.requestor = Number(res.requestor);
                      this.invoiceDetails.amount = this.invoiceDetails.amount.toFixed(2);
                      this.invoiceDetails.taxAmount =this.invoiceDetails.taxAmount > 0 ? this.invoiceDetails.taxAmount.toFixed(2):0;
                      this.invoiceDetails.totalAmount = this.invoiceDetails.totalAmount.toFixed(2);
                      this.invoiceDetails.locationId = res.locationId;
                      this.invoiceDetails.currency = res.currency;
                      this.invoiceDetails.paymentTerm = res.paymentTerm;
                      this.invoiceDetails.invoiceDate = this.invoiceDetails.invoiceDate ? new Date(this.invoiceDetails.invoiceDate) : this.invoiceDetails.invoiceDate;
                      this.invoiceDetails.dueDate = this.invoiceDetails.dueDate ? new Date(this.invoiceDetails.dueDate) : this.invoiceDetails.dueDate;
                      this.billTo = res.billTo;
                      this.shipTo = res.shipTo;
                      this.invoiceDetails.billTo = this.billTo ? parseInt(this.billTo) : this.billTo;
                      this.invoiceDetails.shipTo = this.shipTo ? parseInt(this.shipTo) : this.shipTo;
                      this.invoiceDetails.matchType = this.purchaseorder.matchType =='2 Way'? 'PO': this.purchaseorder.matchType=='3 Way'?'GRN':'';
                      this.invoiceDetails.fxRate = this.invoiceDetails.fxRate == 0 ? "" : this.invoiceDetails.fxRate;
                      this.fnCheckCurrency();
                      this.SummuryAmount();
                      this.showloader=false;
                      this.loaddepartment();
                    }
                  }

                });
            }, 1500);
          }
        }

      });

  }
  /*End  Get PO details by PO Number */

  autoCreateInvoice() {
    this.visibleDiv();
    if (this.selectedMailId) {
      this.showloader=true;
      this.httpService
        .GetById('/finance-ws/mail/get/invoice?mailId=' + this.selectedMailId, this.selectedMailId, this.RetloginDetails.token)
        .subscribe((res) => {

          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else if (res.status == 500) {
            this.showAlert("Server Error");
            this.showloader=false;
          }
          else {
            if (res.errorMessage) {
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );
            } else {

              this.isAutoMode = true;
              this.isPOEnableMode = res.poId > 0 ? true : false;
              this.invoiceDetails = res;
              this.invoiceDetails.invoiceDate = this.invoiceDetails.invoiceDate ? new Date(this.invoiceDetails.invoiceDate) : this.invoiceDetails.invoiceDate;
              this.invoiceDetails.dueDate = this.invoiceDetails.dueDate ? new Date(this.invoiceDetails.dueDate) : this.invoiceDetails.dueDate;
              this.GetSubsidiarybyId();
              this.GetTaxGroupList();
              this.GetSupplierList();
              this.GetLocationList();
              this.GetSupplierCurrencyList();
              this.GetItemList();

              //this.invoiceDetails = res;
              if (this.invoiceDetails.supplierId) {
                this.GetPOList();
                this.OnSupplierChange();
                //this.GetPObyPOId();
                if (this.invoiceDetails.poId)
                  this.GetGRNbyPOId()
                this.invoiceDetails.invoiceItems.map((data: InvoiceItem, index: number) => {
                  if (data.grnId) {
                    this.GetItemByGRN(data.grnId, 0);
                  }
                })
              }
              setTimeout(() => {
                this.httpService
                  //.GetById('/invoice/get?invoiceId='+this.APInvoiceId, this.APInvoiceId)
                  .GetById('/finance-ws/mail/get/invoice?mailId=' + this.selectedMailId, this.selectedMailId, this.RetloginDetails.token)
                  .subscribe((res) => {
                    //For Auth
                    if (res.status == 401) {
                      this.showAlert("Unauthorized Access !");
                      this.router.navigate(['/login']);
                    }
                    else if (res.status == 404) {
                      this.showAlert("Wrong/Invalid Token!");
                      this.router.navigate(['/login']);
                    }
                    else {
                      if (res.errorMessage) {
                        this.toastService.addSingle(
                          'error',
                          'Error',
                          res.errorMessage
                        );
                      } else {
                        this.invoiceDetails.supplierId = res.supplierId;
                        this.invoiceDetails.locationId = res.locationId;
                        //this.invoiceDetails.currency=res.currency;
                        //this.invoiceDetails.paymentTerm=res.paymentTerm;

                        if (this.selectedMailId) {
                          let itmAmount: any;
                          let itmTotalAmount: any;
                          for (let x = 0; x < res.invoiceItems.length; x++) {
                            this.invoiceDetails.invoiceItems[x].itemDescription = res.invoiceItems[x].description;
                            this.invoiceDetails.invoiceItems[x].amount += res.invoiceItems[x].billQty * res.invoiceItems[x].rate;
                            this.invoiceDetails.invoiceItems[x].totalAmount += res.invoiceItems[x].billQty * res.invoiceItems[x].rate;
                            itmAmount = this.invoiceDetails.invoiceItems[x].amount;
                            itmTotalAmount = this.invoiceDetails.invoiceItems[x].totalAmount;
                          }
                          this.invoiceDetails.amount = itmAmount;
                          this.invoiceDetails.taxAmount = 0.00;
                          this.invoiceDetails.totalAmount = itmTotalAmount;
                        }
                        this.invoiceDetails.amount = this.invoiceDetails.amount != undefined && this.invoiceDetails.amount > 0 ? this.invoiceDetails.amount.toFixed(2) : 0.00;
                        this.invoiceDetails.taxAmount = this.invoiceDetails.taxAmount != undefined && this.invoiceDetails.taxAmount > 0 ? this.invoiceDetails.taxAmount.toFixed(2) : 0.00;
                        this.invoiceDetails.totalAmount = this.invoiceDetails.totalAmount != undefined && this.invoiceDetails.totalAmount > 0 ? this.invoiceDetails.totalAmount.toFixed(2) : 0.00;
                        this.invoiceDetails.invoiceDate = this.invoiceDetails.invoiceDate ? new Date(this.invoiceDetails.invoiceDate) : this.invoiceDetails.invoiceDate;
                        this.invoiceDetails.dueDate = this.invoiceDetails.dueDate ? new Date(this.invoiceDetails.dueDate) : this.invoiceDetails.dueDate;
                        // this.billTo=res.billTo;
                        // this.shipTo=res.shipTo;
                        // this.invoiceDetails.billTo=this.billTo?parseInt(this.billTo):this.billTo;
                        // this.invoiceDetails.shipTo=this.shipTo?parseInt(this.shipTo):this.shipTo;
                        //this.invoiceDetails.matchType = this.purchaseorder.matchType;
                        this.invoiceDetails.matchType = this.purchaseorder.matchType =='2 Way'? 'PO': this.purchaseorder.matchType=='3 Way'?'GRN':'';
                        this.invoiceDetails.fxRate = this.invoiceDetails.fxRate == 0 ? "" : this.invoiceDetails.fxRate;
                        this.fnCheckCurrency();
                        if(this.addMode){ this.loadrequestor();}
                        this.showloader=false;
                      }
                    }

                  });
              }, 1500);
              this.SummuryAmount();
            }
          }




        });
    }
  }
  visibleDiv() {
    this.isVisibleDIV = true;
  }
  //--Get Unbilled Amount
  getUnbilledAmount(grnID: any, itemId: any, index: number) {
    let that = this;
    this.httpService.GetAll(`/procure-ws/grn/getByGrnItemId?grnId=${grnID}&itemId=${itemId}`, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res == null || res == undefined) {
            this.toastService.addSingle(
              'error',
              'Error',
              'No data found'
            );
          }
          else {
            that.invoiceDetails.invoiceItems[index].unbilledQuantity = res.unbilledQuantity;
            //   that.invoiceDetails.invoiceItems[index].itemDescription = res.itemDescription;
            //   that.invoiceDetails.invoiceItems[index].itemUom = res.itemUom;
            //   that.invoiceDetails.invoiceItems[index].billQty = 0.00;//(res.reciveQuantity).toFixed(2);
            //   that.invoiceDetails.invoiceItems[index].rate = (res.rate).toFixed(2);
            //   that.invoiceDetails.invoiceItems[index].amount = (parseFloat(res.billQty)* parseFloat(res.rate)).toFixed(2);
            //   that.invoiceDetails.invoiceItems[index].taxGroupId = res.taxGroupId;
            //   that.invoiceDetails.invoiceItems[index].taxAmount = "0.00";
            //  that.invoiceDetails.invoiceItems[index].totalAmount = that.invoiceDetails.invoiceItems[index].amount;
            //  that.invoiceDetails.invoiceItems[index].disabledRate=true;

          }
        }



      },
        error => {
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  /* start get Get Subsidiary by Id */
  GetSubsidiarybyId() {
    this.httpService
      .GetById('/setup-ws/subsidiary/get?id=' + this.invoiceDetails.subsidiaryId, this.invoiceDetails.subsidiaryId, this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else { this.subsidiary = res; }

      });
  }
  /* end  get Get Subsidiary by Id */

  /* start get Get Subsidiary List */
  GetSubsideryListold() {
    this.httpService.GetAll("/setup-ws/subsidiary/get/all", this.RetloginDetails.token).subscribe(
      (res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.Subsidiarylist = res.list;
          this.isReloadSub = false;
        }


      },
      (error) => {
        this.isReloadSub = false;
      }
    );
  }
  GetSubsideryList() {
    //if (this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null) {
      if(this.RetloginDetails.userType=='SUPERADMIN' ){
      this.httpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId=' + this.RetRoleDetails[0].accountId, this.RetloginDetails.token).subscribe(
  
        //this.HttpService.GetAll('/setup-ws/subsidiary/get/all',this.RetloginDetails.token).subscribe(
        (res) => {
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.Subsidiarylist = res;
            for (let x = 0; x < this.Subsidiarylist.length; x++) {
              this.SubIdList.push(this.Subsidiarylist[x].id);
            }
          }
        },
        (error) => {
          this.showAlert(error);
        },
        () => {
        }
      );
    }
    else if(this.RetloginDetails.userType=='ENDUSER' || this.RetloginDetails.userType===null ){
      this.Subsidiarylist.push({
        "id": this.RetRoleDetails[0].subsidiaryId,
        "name": this.RetRoleDetails[0].subsidiaryName
      });
      this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
    }
  }
  /* End get Get Subsidiary List */
  /* Start Reload subsidery */
  reloadSubidery() {
    //$('.refsubsidery').addClass('fa-spin');
    this.isReloadSub = true;
    this.Subsidiarylist=[]
    this.invoiceDetails.subsidiaryId = 0;
    this.GetSubsideryList();
    this.invoiceDetails.supplierId = 0;
    this.reloadSupplier();
    this.invoiceDetails.poId = 0;
    this.GetPOList();
    this.invoiceDetails.locationId = 0;
    this.GetLocationList();
    this.invoiceDetails.currency = "";
    this.GetSupplierCurrencyList();
    this.invoiceDetails.invoiceItems = [];
    this.billingAddressList = [];
    this.shippingAddressList = [];
    this.invoiceDetails.billTo = "";
    this.invoiceDetails.shipTo = "";
    this.invoiceDetails.trn = "";
    this.invoiceDetails.matchType = "";
    this.grnList = [];
    this.itemList = [];
    this.taxGroupList = [];
    this.reloadPoList();
    this.SummuryAmount();
    this.isReloadSub = false;
    //this.invoiceDetails.requestor=undefined;
    this.EmployeeList=[];
  }
  /* End Reload subsidery */
  OnSubsidiaryChnage() {
    // this.GetPoNumber()
    this.getFiscalDateRanges();
    this.GetSubsidiarybyId();
    this.GetSupplierList();
    this.GetItemList();
    this.GetTaxGroupList();
    this.GetLocationList();
    this.GetAllProjectList(this.invoiceDetails.subsidiaryId);
    this.GetDepartmentList(this.invoiceDetails.subsidiaryId);
    if (this.invoiceDetails.supplierId) {
      this.GetPOList();
    }
    //this.fnRequesterList( this.invoiceDetails.subsidiaryId);
    //this.GetPRItemList()
    // if(this.purchaseorder.poType=='PR Based'){
    //   this.GetSupplierList();
    //   this.GetLocationList();
    //   if(this.purchaseorder.locationId){
    //     this.GetPRList();
    //   }
    // }
    // else if(this.purchaseorder.poType=='Stand Alone PR Based'){
    //   this.GetSupplierList();
    //   this.GetLocationList();
    //   this.GetItemList();
    // }
    // else if(this.purchaseorder.poType=='QA Based'){

    //   this.GetQAList();
    // }
  }
  OnSupplierChange() {
    this.GetSupplierbyId();
    this.GetAddressList();
    this.GetSupplierCurrencyList();
    //  if(this.purchaseorder.poType=='QA Based'){   
    //   this.GetQALocationList();
    //   if(this.purchaseorder.locationId)
    //   this.GetQAItemList();
    // }
    this.GetPOList();
    setTimeout(() => {
      if (this.invoiceDetails.invoiceDate && this.invoiceDetails.paymentTerm) {
        var termsday = this.invoiceDetails.paymentTerm == "15 Days" ? 15 : this.invoiceDetails.paymentTerm == "30 Days" ? 30 : this.invoiceDetails.paymentTerm == "60 Days" ? 60 : this.invoiceDetails.paymentTerm == "90 Days" ? 90 : 0
        this.invoiceDetails.dueDate = new Date(new Date(this.invoiceDetails.invoiceDate).setDate(this.invoiceDetails.invoiceDate.getDate() + termsday))
      }
    }
      , 200);
  }

  /* start get Get Supplier list */
  GetSupplierList() {
    this.httpService
      .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + this.invoiceDetails.subsidiaryId, this.invoiceDetails.subsidiaryId, this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.supplierlist = res;
          this.isReloadSupplier = false;
        }



      });
  }
  /* end get Get Supplier list */
  /* start get Get Supplier id */
  GetSupplierbyId() {
    this.httpService
      .GetById('/masters-ws/supplier/get?id=' + this.invoiceDetails.supplierId, this.invoiceDetails.supplierId, this.RetloginDetails.token)
      .subscribe((res) => {

        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.supplier = res;
          this.invoiceDetails.paymentTerm = this.supplier.paymentTerm!;
          // this.invoiceDetails.currency=this.supplier.supplierSubsidiary.supplierCurrency!;
          this.supplier.supplierSubsidiary.map((data: any) => {
            if (data.preferredCurrency) {
              this.invoiceDetails.currency = data.supplierCurrency;
            }
          })
          if (this.subsidiary.currency == this.invoiceDetails.currency) {
            this.invoiceDetails.fxRate = (1.00).toFixed(2);
            //this.invoiceDetails.fxRate=this.invoiceDetails.fxRate.toFixed(2);
          }
        }




      });
  }
  /* end get Get Supplier id */
  /* Start Fetch Currency list by supplier id from api */
  GetSupplierCurrencyList(): any {
    this.httpService.GetAll("/masters-ws/supplier/get-currency-by-supplier?supplierId=" + this.invoiceDetails.supplierId, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            //var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            this.currency = [];
          } else {
            this.currency = res;
          }
        }
      },
        error => {
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  /* End Fetch Currency list by supplier id from api */
  /* tax group list */
  GetTaxGroupList() {
    this.httpService.GetAll("/setup-ws/tax-group/get-by-subsidiary?subsidiaryId=" + this.invoiceDetails.subsidiaryId, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            // var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            this.taxGroupList = [];
          } else {
            this.taxGroupList = res;
          }
        }


      }, error => {
      },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  /* end tax group list */



  decimalFilter(event: any) {
    const reg = /^-?\d*(\.\d{0,2})?$/;
    let input = event.target.value + String.fromCharCode(event.charCode);

    if (!reg.test(input)) {
      event.preventDefault();
    }
  }
  taxCodeSave() {
    this.display = false;
    this.isEditableTaxAmount = false;
    this.invoiceDetails.invoiceItems[this.selectedRow].invoiceItemTax = [];

    for (let x = 0; x < this.taxgroup.taxRateRules.length; x++) {

      this.invoiceDetails.invoiceItems[this.selectedRow].invoiceItemTax.push(
      { 
       taxRateName:this.taxgroup.taxRateRules[x].taxRateName,
       basicAmount:this.taxgroup.taxRateRules[x].basicAmount,
       //this.taxgroup.inclusive?((this.invoiceDetails.invoiceItems[this.selectedRow].amount *100)/(100 + (this.taxgroup.taxRateRules[x].taxRates*1)) ):this.invoiceDetails.invoiceItems[this.selectedRow].amount ,
       rate:this.taxgroup.taxRateRules[x].taxRates,
       deleted:this.taxgroup.taxRateRules[x].deleted,
        id: this.taxgroup.taxRateRules[x].id,
        invoiceId: this.taxgroup.taxRateRules[x].invoiceId,
        invoiceItemId: this.taxgroup.taxRateRules[x].invoiceItemId,
        taxAmount:this.taxgroup.isTaxOverride? this.taxgroup.taxRateRules[x].taxAmount :
       this.taxgroup.inclusive ?(this.invoiceDetails.invoiceItems[this.selectedRow].amount *100)/(100 + (this.taxgroup.taxRateRules[x].taxRates*1)) * (this.taxgroup.taxRateRules[x].taxRates) / 100 : this.taxgroup.isTaxOverride ? this.taxgroup.taxRateRules[x].taxAmount:(this.invoiceDetails.invoiceItems[this.selectedRow].amount * this.taxgroup.taxRateRules[x].taxRates) / 100 
      }
        );
    }


    this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount = this.taxamount.toFixed(2);
    this.invoiceDetails.invoiceItems[this.selectedRow].taxOverride = this.taxgroup.isTaxOverride
    this.invoiceDetails.invoiceItems[this.selectedRow].inclusive = this.taxgroup.inclusive
    this.taxamount = 0;
    this.invoiceDetails.invoiceItems[this.selectedRow].amount = (parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].billQty != undefined ? this.invoiceDetails.invoiceItems[this.selectedRow].billQty : 0) * parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].rate != undefined ? this.invoiceDetails.invoiceItems[this.selectedRow].rate : 0)).toFixed(2);

    if (this.taxgroup.inclusive) {
      this.invoiceDetails.invoiceItems[this.selectedRow].amount = (parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount) - parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount)).toFixed(2);
      //this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount=parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount).toFixed(2)
    } else {
      let LineTotalAmount = parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount) + parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount);
      this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount = LineTotalAmount.toFixed(2);
    }
    this.SummuryAmount()
  }
  SummuryAmount() {
    this.invoiceDetails.amount = 0.00;
    this.invoiceDetails.taxAmount = 0.00;
    this.invoiceDetails.totalAmount = 0.00;
    this.invoiceDetails.invoiceItems.map((data, index) => {
      data.amount = data.amount != "NaN" ? data.amount : "";
      data.totalAmount = data.totalAmount != "NaN" ? data.totalAmount : "";

      this.invoiceDetails.amount += parseFloat(parseFloat(data.amount).toFixed(2));
      this.invoiceDetails.taxAmount += data.taxAmount ? parseFloat(parseFloat(data.taxAmount).toFixed(2)) : 0.00;
      // this.totalAmount+=parseFloat(data.totalAmount)
      if (!this.addMode) {
        if (this.taxgroup.inclusive) {
          data.totalAmount = (data.amount != "" ? parseFloat(data.amount) : 0) + (data.taxAmount != undefined ? parseFloat(data.taxAmount) : 0)
          //data.totalAmount =parseFloat(this.invoiceDetails.invoiceItems[index].amount).toFixed(2)
          this.invoiceDetails.totalAmount += data.totalAmount !== null ? parseFloat(data.totalAmount) : "";
        } else {
          data.totalAmount = (data.amount != "" ? parseFloat(data.amount) : 0) + (data.taxAmount != undefined ? parseFloat(data.taxAmount) : 0)
          //data.totalAmount =(this.invoiceDetails.invoiceItems[index].amount !="" ?parseFloat(this.invoiceDetails.invoiceItems[index].amount) :0)+(this.invoiceDetails.invoiceItems[index].taxAmount != undefined ? parseFloat(this.invoiceDetails.invoiceItems[index].taxAmount) : 0.00)
          this.invoiceDetails.totalAmount += data.totalAmount !== null ? parseFloat(data.totalAmount) : "";

        }
      }
      else {
        data.totalAmount = (data.amount != "" ? parseFloat(data.amount) : 0) + (data.taxAmount != undefined ? parseFloat(data.taxAmount) : 0)
        this.invoiceDetails.totalAmount += data.totalAmount !== null ? parseFloat(data.totalAmount) : "";
        //this.invoiceDetails.totalAmount+=parseFloat(data.totalAmount)
      }

    })
    this.invoiceDetails.amount = this.invoiceDetails.amount ? parseFloat(this.invoiceDetails.amount).toFixed(2) : "0.00";
    this.invoiceDetails.taxAmount = this.invoiceDetails.taxAmount ? parseFloat(this.invoiceDetails.taxAmount).toFixed(2) : "0.00";
    //this.invoiceDetails.totalAmount=this.invoiceDetails.totalAmount?parseFloat(this.invoiceDetails.totalAmount).toFixed(2):"0.00";
    let ShowTotal = parseFloat(this.invoiceDetails.amount) + (parseFloat(this.invoiceDetails.taxAmount));
    this.invoiceDetails.totalAmount = ShowTotal.toFixed(2);

  }
  CalculateAmmount(quantity: any, rate: any, index: any) {
    if (quantity != "" && rate != "") {
      this.invoiceDetails.invoiceItems[index].amount = (parseFloat(quantity) * parseFloat(rate)).toFixed(2);
      this.invoiceDetails.invoiceItems[index].totalAmount = (parseFloat(this.invoiceDetails.invoiceItems[index].amount ? this.invoiceDetails.invoiceItems[index].amount : 0) + (this.invoiceDetails.invoiceItems[index].taxAmount ? this.invoiceDetails.invoiceItems[index].taxAmount : 0)).toFixed(2)
    }
    else if (quantity != "" && rate == "") {
      this.invoiceDetails.invoiceItems[index].amount = "";
      this.invoiceDetails.invoiceItems[index].totalAmount = "";
      //this.invoiceDetails.invoiceItems[index].amount=(parseFloat(quantity)*1).toFixed(2)
      //this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount=(parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount?this.invoiceDetails.invoiceItems[this.selectedRow].amount:0)+(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount?this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount:0)).toFixed(2)
    } else if (quantity == "" && rate != "") {
      this.invoiceDetails.invoiceItems[index].amount = "";
      this.invoiceDetails.invoiceItems[index].totalAmount = "";
      //this.invoiceDetails.invoiceItems[index].amount=(1*parseFloat(rate)).toFixed(2)
      //this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount=(parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount?this.invoiceDetails.invoiceItems[this.selectedRow].amount:0)+(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount?this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount:0)).toFixed(2)

    } else {
      this.invoiceDetails.invoiceItems[index].amount = "";
      this.invoiceDetails.invoiceItems[index].totalAmount = "";
    }
    this.SummuryAmount();
    this.TaxViewOnly = false;
  }
  calculateEMAmount(Event: any, RowIndex: any, type: string) {
    if (Event.value != null) {

      var Qty = type == "QTY" ? Event.value : (this.invoiceDetails.invoiceItems[RowIndex].billQty != undefined ? this.invoiceDetails.invoiceItems[RowIndex].billQty : 0);
      var Rate = type == "RATE" ? Event.value : (this.invoiceDetails.invoiceItems[RowIndex].rate != undefined ? this.invoiceDetails.invoiceItems[RowIndex].rate : 0);
      this.invoiceDetails.invoiceItems[RowIndex].amount = (parseFloat(Qty) * parseFloat(Rate)).toFixed(2);
      this.invoiceDetails.invoiceItems[RowIndex].totalAmount = parseFloat(this.invoiceDetails.invoiceItems[RowIndex].amount ? this.invoiceDetails.invoiceItems[RowIndex].amount : 0) + parseFloat(this.invoiceDetails.invoiceItems[RowIndex].taxAmount ? this.invoiceDetails.invoiceItems[RowIndex].taxAmount : 0);

      this.invoiceDetails.invoiceItems[RowIndex].billQty = parseFloat(Qty).toFixed(2);
      this.invoiceDetails.invoiceItems[RowIndex].rate = parseFloat(Rate).toFixed(2);

      this.invoiceDetails.invoiceItems[RowIndex].taxGroupId=0;
      this.invoiceDetails.invoiceItems[RowIndex].taxAmount=0;

//    if(this.invoiceDetails.invoiceItems[RowIndex].taxOverride)
//    {
//     if (this.invoiceDetails.invoiceItems[this.selectedRow].billQty == undefined || this.invoiceDetails.invoiceItems[this.selectedRow].billQty == null || this.invoiceDetails.invoiceItems[this.selectedRow].billQty == "") {
//       this.invoiceDetails.invoiceItems[this.selectedRow].billQty = 0;
//     }
//     if (this.invoiceDetails.invoiceItems[this.selectedRow].rate == undefined || this.invoiceDetails.invoiceItems[this.selectedRow].rate == null || this.invoiceDetails.invoiceItems[this.selectedRow].rate == "") {
//       this.invoiceDetails.invoiceItems[this.selectedRow].rate = 0;
//     }
//     this.invoiceDetails.invoiceItems[this.selectedRow].amount=parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].billQty) * parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].rate);
   
//     this.taxgroup.taxRateRules.map((data: any, index: any) => {
//       //data.taxAmount= this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.taxRates * 1)) * data.taxRates) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100
//       data.taxAmount=this.taxgroup.isTaxOverride?data.taxAmount: this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.taxRates * 1)) * data.taxRates) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100
//       this.taxamount += data.taxAmount
//       if ( this.invoiceDetails.poId > 0) { // this.isPOtaxGroup
//         this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount += this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.taxRates * 1)) * data.taxRates) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100
//       }
//     })

//     if (this.taxgroup.inclusive) {
//       let tAmount=parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].billQty) * parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].rate);
//        this.invoiceDetails.invoiceItems[this.selectedRow].amount = ((tAmount) - parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount)).toFixed(2);
//     } else {
//       let LineTotalAmount = parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount) + parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount);
//       this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount = LineTotalAmount.toFixed(2);
//       //this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount = (parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount) + parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount)).toFixed(2)
//     }

//    }
// else
//   {  
//     this.calculateTAXAMount(this.invoiceDetails.invoiceItems[RowIndex].taxGroupId, RowIndex);
//   }
      this.isEditableTaxAmount=false;
    } else {
      this.invoiceDetails.invoiceItems[RowIndex].amount = "";
      this.invoiceDetails.invoiceItems[RowIndex].totalAmount = "";
    }
    this.SummuryAmount();
  }
  calculateTAXAMount(taxgroupId: number, RowNo: any) {
    this.showloader = true;
    if (taxgroupId > 0) {
      this.httpService.GetById("/setup-ws/tax-group/get?id=" + taxgroupId, taxgroupId, this.RetloginDetails.token)
        .subscribe(res => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res.error) {
              //var error = JSON.parse(res.error);
              this.toastService.addSingle(
                'error',
                'Error',
                res.error.errorMessage
              );
              this.taxgroup = new TaxGroup();
            } else {
              this.taxgroup = res;
              this.taxamount = 0;
              this.selectedRow = RowNo;
              this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount = 0;
              if (this.invoiceDetails.invoiceItems[this.selectedRow].billQty == undefined || this.invoiceDetails.invoiceItems[this.selectedRow].billQty == null || this.invoiceDetails.invoiceItems[this.selectedRow].billQty == "") {
                this.invoiceDetails.invoiceItems[this.selectedRow].billQty = 0;
              }
              if (this.invoiceDetails.invoiceItems[this.selectedRow].rate == undefined || this.invoiceDetails.invoiceItems[this.selectedRow].rate == null || this.invoiceDetails.invoiceItems[this.selectedRow].rate == "") {
                this.invoiceDetails.invoiceItems[this.selectedRow].rate = 0;
              }
              this.invoiceDetails.invoiceItems[this.selectedRow].amount=parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].billQty) * parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].rate);

              this.taxgroup.taxRateRules.map((data: any, index: any) => {
                data.taxAmount= this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.taxRates * 1)) * data.taxRates) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100
                this.taxamount += data.taxAmount
                if ( this.invoiceDetails.poId > 0) { // this.isPOtaxGroup
                  this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount += this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.taxRates * 1)) * data.taxRates) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100
                }
              })

              if (this.taxgroup.inclusive) {
                let tAmount=parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].billQty) * parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].rate);
                 this.invoiceDetails.invoiceItems[this.selectedRow].amount = ((tAmount) - parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount)).toFixed(2);
              } else {
                let LineTotalAmount = parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount) + parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount);
                this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount = LineTotalAmount.toFixed(2);
                //this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount = (parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount) + parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount)).toFixed(2)
              }

              // this.taxgroup.taxRateRules.map((data: any, index: any) => {
              //   if (this.taxgroup.inclusive) {
              //     this.invoiceDetails.invoiceItems[this.selectedRow].amount = (this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.taxRates * 1))
              //     this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount = parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount).toFixed(2)
              //   } else {
              //     this.invoiceDetails.invoiceItems[this.selectedRow].amount = parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].billQty) * parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].rate);
              //     this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount = (parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount) + parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount)).toFixed(2)
              //   }
              //   this.taxamount += this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.taxRates * 1)) * data.taxRates) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100

              //   if (this.invoiceDetails.invoiceItems[this.selectedRow].taxGroupId > 0) {
              //        this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount = this.taxamount;//this.taxgroup.inclusive?(((this.invoiceDetails.invoiceItems[this.selectedRow].amount *100)/(100 + (data.taxRates*1)) * data.taxRates) / 100 ):(this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100
              //   }
              // });

            }
          }
        }, error => {
        },
          () => {
            this.SummuryAmount();
            this.showloader = false;
          });
    }
    else {
      this.SummuryAmount();
      this.showloader = false;
    }
  }

  GetAddressList(): any {
    this.billingAddressList = [];
    this.shippingAddressList = [];
    this.httpService.GetAll("/masters-ws/supplier/address/get?supplierId=" + this.invoiceDetails.supplierId, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            // var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            this.billingAddressList = [];
            this.shippingAddressList = [];

          }
          else {
            this.billingAddressList = res;
            this.shippingAddressList = res;
            if (this.addMode) {
              this.invoiceDetails.billTo = null
              this.invoiceDetails.shipTo = null
            }

            res.map((val: any, index: any) => {
              var address = (val.address1 ? val.address1 : "") + (val.address2 ? " " + val.address2 : "") + (val.city ? " " + val.city : "") + (val.state ? " " + val.state : "") + (val.country ? " " + val.country : "") + (val.pin ? "- " + val.pin : "");
              this.billingAddressList[index].address1 = address;
              this.shippingAddressList[index].address1 = address
              if (val.defaultBilling) {
                this.invoiceDetails.billTo = val.id;
                this.invoiceDetails.trn = val.taxRegistrationNumber;

                //this.billingAddressList.push(val)
              }
              if (val.defaultShipping) {
                this.invoiceDetails.shipTo = val.id;

                // this.shippingAddressList.push(val)
              }

            })
            if (this.editMode || this.viewMode) {
              setTimeout(() => {
                this.invoiceDetails.billTo = this.billTo ? parseInt(this.billTo) : this.billTo;
                this.invoiceDetails.shipTo = this.shipTo ? parseInt(this.shipTo) : this.shipTo;

              }, 500);
            }
          }
        }

      },
        error => {
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  onAddressChange(value: string) {
    let that = this;
    this.billingAddressList.find(o => {
      if (o.id === parseInt(value)) {
        this.invoiceDetails.trn = o.taxRegistrationNumber;
      }
    });
  }
  GetItemList(): any {
    this.httpService.GetById("/masters-ws/item/find-by-subsidiary?subsidiaryId=" + this.invoiceDetails.subsidiaryId, this.invoiceDetails.subsidiaryId, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            //var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            this.itemList = [];
          }
          else {
            this.isPo = false;
            this.isGrn = false;
            this.itemList = res;
          }
        }



      },
        error => {
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  /* End Fetch Item list from api */
  onItemChange(index: number, value: string) {
    let that = this;
    // for(let j=0;j<this.invoiceDetails.invoiceItems.length;j++)
    // {
    // if(j !== index && Number(value) ==this.invoiceDetails.invoiceItems[j].itemId)
    // {
    //   this.showAlert("Same Item not allowed !");
    //   this.invoiceDetails.invoiceItems[index]=new InvoiceItem();
    //   return false;
    // }
    // }
   
    if (this.invoiceDetails.poId) {
      this.httpService.GetAll(`/procure-ws/po/getByPoItemId?poId=${this.invoiceDetails.poId}&itemId=${value}`, this.RetloginDetails.token)
        .subscribe(res => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res.error) {
              this.toastService.addSingle(
                'error',
                'Error',
                res.error.errorMessage
              );
            }
            else {
              res = res.filter((t: any) => t.itemId == value);
              that.invoiceDetails.amount = 0.00;
              that.invoiceDetails.taxAmount = 0.00;
              that.invoiceDetails.totalAmount = 0.00;
              that.invoiceDetails.invoiceItems[index].itemDescription = res[0].itemDescription;
              that.invoiceDetails.invoiceItems[index].itemUom = res[0].itemUom;
              that.invoiceDetails.invoiceItems[index].billQty = 0.00;// (res.quantity).toFixed(2);
              that.invoiceDetails.invoiceItems[index].rate = res[0].rate != undefined ? (res[0].rate).toFixed(2) : res[0].rate;
              that.invoiceDetails.invoiceItems[index].amount = that.invoiceDetails.invoiceItems[index].billQty * that.invoiceDetails.invoiceItems[index].rate;// (res.amount).toFixed(2);
              that.invoiceDetails.invoiceItems[index].taxGroupId = res[0].taxGroupId;
              that.invoiceDetails.invoiceItems[index].taxAmount = res[0].taxAmount != undefined ? (res[0].taxAmount).toFixed(2) : res[0].taxAmount;
              that.invoiceDetails.invoiceItems[index].totalAmount = res[0].totalAmount != undefined ? (res[0].totalAmount).toFixed(2) : res[0].totalAmount;
              that.invoiceDetails.invoiceItems[index].department = res[0].department;
              that.invoiceDetails.invoiceItems[index].unbilledQuantity = res[0].unbilledQuantity;
              that.invoiceDetails.invoiceItems[index].departmentId=res[0].departmentId;
              that.invoiceDetails.invoiceItems[index].department=res[0].departmentName;
              this.loaddepartment();
              if (res.taxGroupId) {
                this.isPOtaxGroup = true;
                this.selectedRow = index;
                this.GetTaxGroupbyId(res.taxGroupId);
              }
              else {
                this.SummuryAmount();
              }
            }
          }

        },
          error => {
          },
          () => {
            // 'onCompleted' callback.
            // No errors, route to new page here
          });
      // this.purchaseorder.purchaseOrderItems.find(o => {
      //   if (o.itemId === parseInt(value)) {
      //     that.invoiceDetails.invoiceItems[index].description = o.itemDescription;
      //     that.invoiceDetails.invoiceItems[index].uom = o.itemUom;
      //     that.invoiceDetails.invoiceItems[index].billQty = (o.quantity).toFixed(2);
      //     that.invoiceDetails.invoiceItems[index].rate = (o.rate).toFixed(2);
      //     that.invoiceDetails.invoiceItems[index].amount = (o.amount).toFixed(2);
      //     that.invoiceDetails.invoiceItems[index].taxGroupId = o.taxGroupId;
      //     that.invoiceDetails.invoiceItems[index].taxAmount = (o.taxAmount).toFixed(2);
      //     that.invoiceDetails.invoiceItems[index].totalAmount = (o.totalAmount).toFixed(2);
      //     that.invoiceDetails.invoiceItems[index].department = o.department;

      //   }
      // });
    } else {
      this.itemList.find(o => {
        if (o.id === parseInt(value)) {
          that.invoiceDetails.invoiceItems[index].itemDescription = o.description;
          that.invoiceDetails.invoiceItems[index].itemUom = o.uom;
          that.invoiceDetails.invoiceItems[index].departmentId=this.invoiceDetails.departmentId;
          that.invoiceDetails.invoiceItems[index].department=this.dept_header;
          //that.invoiceDetails.invoiceItems[index].accountCode=o.accountId
        }
      });
    }
  }
  /* Start Fetch PO list from api */
  GetPOList(): any {
    this.httpService.GetAll(`/procure-ws/po/getBySupplierSubsidiary?supplierId=${this.invoiceDetails.supplierId}&subsidiaryId=${this.invoiceDetails.subsidiaryId}`, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            //var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            this.POList = [];
          }
          else {
            this.POList = res;
            this.isGrn = false;
            if (!this.addMode) {
              let PiIdExist = false;
              this.POList.filter((element: any) => {
                if (element.id == this.invoiceDetails.poId) {
                  PiIdExist = true
                  return;
                }
              });
              if (!PiIdExist) {
                this.POList.push({
                  "id": this.invoiceDetails.poId,
                  "poNumber": this.invoiceDetails.poNumber,
                  purchaseOrderItems: []
                })
              }
            }

            //this.isPo=true;
            // if(this.editMode || this.viewMode){
            //   setTimeout(() => {
            //     this.invoiceDetails.invoiceItems=Newitemcopy//this.itemCopy;
            //   }, 2000);
            // }
          }
        }


      },
        error => {
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  reloadPoList() {

    this.invoiceDetails.poId = 0;
    this.invoiceDetails.departmentId = undefined;
    if(this.invoiceDetails.poId > 0)
    {

      this.isdeptbypo=true;
      this.isdeptbypo_=false;
    }
    else
    {
      

      this.isdeptbypo=false;
      this.isdeptbypo_=true;
    }
    this.isGrnlist = false
   
    this.GetPOList();
    this.invoiceDetails.invoiceItems = [];
    this.invoiceDetails.invoiceDate = {};
    this.invoiceDetails.dueDate = {};
    this.invoiceDetails.matchType = "";
    this.SummuryAmount();
    this.isPo = false;
    this.invoiceDetails.locationId = 0;
    this.invoiceDetails.paymentTerm = undefined;
    this.invoiceDetails.currency = undefined;
    this.invoiceDetails.fxRate = undefined;
    this.purchaseorder.poDate = undefined;
    this.TwoWaydisabledRate = false;

  }
  /* End Fetch PO list from api */
  /* Start Fetch Location list from api */
  GetLocationList() {
    this.httpService.GetAll("/masters-ws/location/get-parent-location-names?subsidiaryId=" + this.invoiceDetails.subsidiaryId, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            // var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            this.locationlist = [];
          }
          else {
            this.locationlist = res;
          }
        }


      }, error => {
      },
        () => {
          this.isReloadlocation = false;
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  /* End Fetch Location list from api */
  CalculateTaxGroup(taxgroupId: any, rowIndex: any) {
    this.invoiceDetails.invoiceItems[rowIndex].taxOverride = false
    if (this.invoiceDetails.invoiceItems[rowIndex].amount) {
      this.TaxGroupRowIndex = rowIndex;
      this.TaxViewOnly = false;
      this.selectedRow = rowIndex;
      this.GetTaxGroupbyId(taxgroupId);
      this.display = true;
      if (this.invoiceDetails.invoiceItems[rowIndex].taxOverride) {
        this.taxgroup.isTaxOverride = this.invoiceDetails.invoiceItems[rowIndex].taxOverride
        this.isEditableTaxAmount = true;
      }
      else {
        this.taxgroup.isTaxOverride = false;
        this.isEditableTaxAmount = false;
      }
    }
    else {
      this.showAlert("No Amount Found");
    }
  }
  /* tax group by id */
  GetTaxGroupbyId(taxgroupId: any) {
    this.httpService.GetById("/setup-ws/tax-group/get?id=" + taxgroupId, taxgroupId, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            //var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            this.taxgroup = new TaxGroup();
          } else {
            //this.taxgroup.taxRateRules = [];
           
            if(this.editMode)
            {
              if(this.invoiceDetails.invoiceItems[this.selectedRow].invoiceItemTax.length >0)
             {
              this.taxgroup.taxRateRules=this.invoiceDetails.invoiceItems[this.selectedRow].invoiceItemTax;
             }
              this.taxgroup.taxRateRules.map((data: any, index: any) => {
                data.deleted=true;
              });

              this.taxgroup.name=res.name;
              this.taxgroup.inclusive=res.inclusive;
              this.taxgroup.isTaxOverride=res.isTaxOverride;
              this.invoiceDetails.invoiceItems[this.selectedRow].inclusive=res.inclusive;
              this.invoiceDetails.invoiceItems[this.selectedRow].taxOverride=res.isTaxOverride;
              for(let x=0;x<res.taxRateRules.length;x++)
              { this.taxgroup.taxRateRules.push(res.taxRateRules[x]); }
            }
            else if(this.addMode)
            {
              this.taxgroup.taxRateRules = []; 
              this.taxgroup = res;
            }
           
            this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount = 0;
            this.taxamount = 0;
            if (this.invoiceDetails.invoiceItems[this.selectedRow].billQty == undefined || this.invoiceDetails.invoiceItems[this.selectedRow].billQty == null || this.invoiceDetails.invoiceItems[this.selectedRow].billQty == "") {
              this.invoiceDetails.invoiceItems[this.selectedRow].billQty = 0;
            }
            if (this.invoiceDetails.invoiceItems[this.selectedRow].rate == undefined || this.invoiceDetails.invoiceItems[this.selectedRow].rate == null || this.invoiceDetails.invoiceItems[this.selectedRow].rate == "") {
              this.invoiceDetails.invoiceItems[this.selectedRow].rate = 0;
            }

            this.invoiceDetails.invoiceItems[this.selectedRow].amount = parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].billQty) * parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].rate);
            this.taxgroup.taxRateRules.map((data: any, index: any) => {
              data.taxAmount= data.deleted == false?this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 +  parseFloat(data.taxRates)* 1) * parseFloat(data.taxRates)) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount * parseFloat(data.taxRates)) / 100 : 0
              data.basicAmount=data.deleted == false?this.taxgroup.inclusive && this.taxgroup.isTaxOverride == false?((this.invoiceDetails.invoiceItems[this.selectedRow].amount *100)/(100 + (data.deleted==false?data.taxRates:0*1)) ):this.invoiceDetails.invoiceItems[this.selectedRow].amount:0
              this.taxamount += data.taxAmount
              if ( this.invoiceDetails.poId > 0){
              //if (this.isPOtaxGroup) {
                //this.invoiceDetails.invoiceItems[this.selectedRow].taxGroupId=taxgroupId
                this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount += this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.deleted==false?data.taxRates:0 * 1)) * (data.deleted==false?data.taxRates:0)) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount *(data.deleted==false? data.taxRates:0)) / 100
                if (this.taxgroup.inclusive) {
                  this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount = parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount).toFixed(2)
                  //this.taxgroup.taxRateRules[a].CustomtaxAmount
                } else {
                  this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount = (parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount) + parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount)).toFixed(2)
                }
              }
            })

            this.SummuryAmount();
          }
        }


      }, error => {
      },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  /* end tax group by id */

  ViewTaxGroupDilog(taxgroupId: any, rowIndex: any, ViewType: any) {

    if (taxgroupId > 0 && this.invoiceDetails.invoiceItems[rowIndex].amount > 0) {
      this.TaxGroupRowIndex = rowIndex;
      this.selectedRow = rowIndex;
      //this.viewOnlyTaxGroupbyId(taxgroupId,rowIndex);

      this.taxgroup.taxRateRules = [];
      this.taxamount = 0;
      this.taxgroup.inclusive= this.invoiceDetails.invoiceItems[rowIndex].inclusive;
      this.taxgroup.isTaxOverride= this.invoiceDetails.invoiceItems[rowIndex].taxOverride;
      if(this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax.length > 0)
      {
        for (let x = 0; x < this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax.length; x++) {
        this.taxgroup.taxRateRules.push(
          {
          taxRateName :this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax[x].taxRateName,
          taxRates:this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax[x].rate,
          basicAmount:this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax[x].basicAmount,
          taxAmount:this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax[x].taxAmount,
          deleted:this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax[x].deleted,
          id:this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax[x].id,
          invoiceId:this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax[x].invoiceId,
          invoiceItemId:this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax[x].invoiceItemId
          });
          if(this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax[x].deleted == false)
          {
            this.taxamount +=Number(this.invoiceDetails.invoiceItems[rowIndex].invoiceItemTax[x].taxAmount)
          }else if(this.taxgroup.isTaxOverride == false)
       { this.taxamount += Number(this.taxgroup.taxRateRules[x].taxAmount);}
      }
       
      }
      else
      {
        this.viewOnlyTaxGroupbyId(taxgroupId,rowIndex);
      }
      if (this.invoiceDetails.invoiceItems[rowIndex].taxOverride) {
        this.taxgroup.isTaxOverride = this.invoiceDetails.invoiceItems[rowIndex].taxOverride
        //this.fnCalculate(null,null);
        this.isEditableTaxAmount = true;
      }
      else {
        this.taxgroup.isTaxOverride = false;
        this.isEditableTaxAmount = false;
      }
      this.display = true;
      this.TaxViewOnly = true;
    }
    else {
      if (taxgroupId == undefined || taxgroupId == null) {
        this.showAlert("Please select Tax Group !");
        return;
      }
      else if (this.invoiceDetails.invoiceItems[rowIndex].amount == 0 || this.invoiceDetails.invoiceItems[rowIndex].amount == null || this.invoiceDetails.invoiceItems[rowIndex].amount == "" || this.invoiceDetails.invoiceItems[rowIndex].amount == undefined) {
        this.showAlert("No valid Amount Found !");
        return;
      }
    }
  }

  viewOnlyTaxGroupbyId(taxgroupId: any, Row: any) {
    this.httpService.GetById("/setup-ws/tax-group/get?id=" + taxgroupId, taxgroupId, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            this.taxgroup = new TaxGroup();
          } else {
            this.taxgroup = res;
            this.taxamount = 0;
            if(this.invoiceDetails.invoiceItems[this.selectedRow].billQty ==undefined || this.invoiceDetails.invoiceItems[this.selectedRow].billQty ==null || this.invoiceDetails.invoiceItems[this.selectedRow].billQty == "")
            {
              this.invoiceDetails.invoiceItems[this.selectedRow].billQty=0;
            }
            if(this.invoiceDetails.invoiceItems[this.selectedRow].rate ==undefined || this.invoiceDetails.invoiceItems[this.selectedRow].rate ==null || this.invoiceDetails.invoiceItems[this.selectedRow].rate == "")
            {
              this.invoiceDetails.invoiceItems[this.selectedRow].rate=0;
            }
            this.invoiceDetails.invoiceItems[this.selectedRow].amount=parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].billQty) * parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].rate);
            this.taxgroup.taxRateRules.map((data: any, index: any) => {
              data.taxAmount = data.deleted == false? this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.taxRates * 1)) * data.taxRates) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100 : 0
              data.basicAmount= data.deleted == false? this.taxgroup.inclusive?((this.invoiceDetails.invoiceItems[this.selectedRow].amount *100)/(100 + (data.taxRates*1))):this.invoiceDetails.invoiceItems[this.selectedRow].amount : 0
              this.taxamount += data.taxAmount
              //this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.taxRates * 1)) * data.taxRates) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100
             
              // if(this.isPOtaxGroup){
              //   this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount+= this.taxgroup.inclusive?(((this.invoiceDetails.invoiceItems[this.selectedRow].amount *100)/(100 + (data.taxRates*1)) * data.taxRates) / 100 ):(this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100
              // if(this.taxgroup.inclusive){
              //   this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount=parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount).toFixed(2)
              //   }else{
              //   this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount=(parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount)+parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount)).toFixed(2)
              //     }
              //   }
            })
            if (this.invoiceDetails.invoiceItems[Row].taxOverride) {
              this.taxgroup.isTaxOverride = this.invoiceDetails.invoiceItems[Row].taxOverride
              //this.fnCalculate(null,null);
              this.isEditableTaxAmount = true;
            }
            else {
              this.taxgroup.isTaxOverride = false;
              this.isEditableTaxAmount = false;
            }
            //this.SummuryAmount();
          }
        }


      }, error => {
      },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  /* tax group by id */
  viewTaxGroupbyId(taxgroupId: any) {
    this.httpService.GetById("/setup-ws/tax-group/get?id=" + taxgroupId, taxgroupId, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.error) {
            //var error = JSON.parse(res.error);
            this.toastService.addSingle(
              'error',
              'Error',
              res.error.errorMessage
            );
            this.taxgroup = new TaxGroup();
          } else {
            this.taxgroup = res;
            //this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount=0;
            this.taxamount = 0;
            //this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount=0;
            if (this.invoiceDetails.invoiceItems[this.selectedRow].billQty == undefined || this.invoiceDetails.invoiceItems[this.selectedRow].billQty == null || this.invoiceDetails.invoiceItems[this.selectedRow].billQty == "") {
              this.invoiceDetails.invoiceItems[this.selectedRow].billQty = 0;
            }
            if (this.invoiceDetails.invoiceItems[this.selectedRow].rate == undefined || this.invoiceDetails.invoiceItems[this.selectedRow].rate == null || this.invoiceDetails.invoiceItems[this.selectedRow].rate == "") {
              this.invoiceDetails.invoiceItems[this.selectedRow].rate = 0;
            }

            this.invoiceDetails.invoiceItems[this.selectedRow].amount = parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].billQty) * parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].rate);
            this.taxgroup.taxRateRules.map((data: any, index: any) => {
              this.taxamount += this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.taxRates * 1)) * data.taxRates) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100
              if (this.isPOtaxGroup) {
                //this.invoiceDetails.invoiceItems[this.selectedRow].taxGroupId=taxgroupId
                this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount += this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[this.selectedRow].amount * 100) / (100 + (data.taxRates * 1)) * data.taxRates) / 100) : (this.invoiceDetails.invoiceItems[this.selectedRow].amount * data.taxRates) / 100
                if (this.taxgroup.inclusive) {
                  this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount = parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount).toFixed(2)
                  //this.taxgroup.taxRateRules[a].CustomtaxAmount
                } else {
                  this.invoiceDetails.invoiceItems[this.selectedRow].totalAmount = (parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].amount) + parseFloat(this.invoiceDetails.invoiceItems[this.selectedRow].taxAmount)).toFixed(2)
                }
              }
            })
            //this.SummuryAmount();
          }
        }


      }, error => {
      },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  /* end tax group by id */

  onPaymentTermChange() {
    if (this.purchaseorder.poDate != null) {
      let days: any = new Date(this.invoiceDetails.invoiceDate).getDate();
      let months: any = new Date(this.invoiceDetails.invoiceDate).getMonth() + 1;
      let year: any = new Date(this.invoiceDetails.invoiceDate).getFullYear();

      let PRdays: any = new Date(this.purchaseorder.poDate).getDate();
      let PRmonths: any = new Date(this.purchaseorder.poDate).getMonth() + 1;
      let PRyear: any = new Date(this.purchaseorder.poDate).getFullYear();

      let InvDate = this.invoiceDetails.invoiceDate !== undefined ? (year + '-' + (months.toString().length == 1 ? "0" + months : months) + '-' + (days.toString().length == 1 ? "0" + days : days)) : ""
      let PoDate = this.purchaseorder.poDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""
      if (InvDate < PoDate) {
        this.showAlert("Invoice Date must be greater than or equal to PO Date- " + PoDate);
        this.invoiceDetails.invoiceDate = {};
        this.invoiceDetails.dueDate = {};
        return false;
      }

      // if(new Date(this.invoiceDetails.invoiceDate) < new Date(this.purchaseorder.poDate ))
      // {
      //   this.showAlert("Invoice Date must be greater or equal than PO Date")
      //   this.invoiceDetails.invoiceDate={};
      //   this.invoiceDetails.dueDate={};
      //   return false;
      // }
    }
    if (this.invoiceDetails.invoiceDate && this.invoiceDetails.paymentTerm) {
      var termsday = this.invoiceDetails.paymentTerm == "15 Days" ? 15 : this.invoiceDetails.paymentTerm == "30 Days" ? 30 : this.invoiceDetails.paymentTerm == "60 Days" ? 60 : this.invoiceDetails.paymentTerm == "90 Days" ? 90 : 0
      this.invoiceDetails.dueDate = new Date(new Date(this.invoiceDetails.invoiceDate).setDate(this.invoiceDetails.invoiceDate.getDate() + termsday))
    }
    this.getFiscalDateRanges();
  }
  hidepopup() {
    this.display = false;
    this.isEditableTaxAmount = false;
    this.invoiceDetails.invoiceItems[this.TaxGroupRowIndex].taxGroupId = 0;
    this.invoiceDetails.invoiceItems[this.TaxGroupRowIndex].taxAmount = 0;
    this.invoiceDetails.invoiceItems[this.TaxGroupRowIndex].amount= this.invoiceDetails.invoiceItems[this.TaxGroupRowIndex].billQty* this.invoiceDetails.invoiceItems[this.TaxGroupRowIndex].rate
    this.SummuryAmount();
  }
  /* Get PO details by PO id */
  GetPObyPOId() {
    if (this.invoiceDetails.poId > 0) {
      this.httpService
        .GetById('/procure-ws/po/getByPoId?poId=' + this.invoiceDetails.poId, this.invoiceDetails.poId, this.RetloginDetails.token)
        .subscribe((res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res.errorMessage) {
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );
            } else {
              //this.isGrn=false;
              this.purchaseorder = res;
              //this.invoiceDetails.matchType = this.purchaseorder.matchType;
              this.invoiceDetails.matchType = this.purchaseorder.matchType =='2 Way'? 'PO': this.purchaseorder.matchType=='3 Way'?'GRN':'';
              this.invoiceDetails.currency = this.purchaseorder.currency;
              this.invoiceDetails.paymentTerm = this.purchaseorder.paymentTerm;
              this.invoiceDetails.locationId = this.purchaseorder.locationId;
              this.purchaseorder.billTo ? this.invoiceDetails.billTo = this.purchaseorder.billTo : null
              this.purchaseorder.shipTo ? this.invoiceDetails.shipTo = this.purchaseorder.shipTo : null
              this.invoiceDetails.projectId = this.invoiceDetails.poId > 0 ?  this.purchaseorder.projectId :undefined;
              this.invoiceDetails.departmentId = this.invoiceDetails.poId > 0 ?  this.purchaseorder.departmentId :undefined;
              //this.isPo=true;

              // this.itemList=this.purchaseorder.purchaseOrderItems;
            }
          }


        });
    }
  }
  /* End Get PO details by PO id */
  OnPoChange() {
   
    this.invoiceDetails.invoiceItems = [];
    this.invoiceDetails.amount = 0.00;
    this.invoiceDetails.taxAmount = 0.00;
    this.invoiceDetails.totalAmount = 0.00;
    this.GetPObyPOId();
    this.GetGRNbyPOId();
    this.invoiceDetails.invoiceDate = {};
    this.invoiceDetails.dueDate = {};
    this.isPo = true;
    //this.isAutoMode=this.invoiceDetails.poId >0 ?true:false;
    if(this.invoiceDetails.poId > 0)
    {

      this.isdeptbypo=true;
      this.isdeptbypo_=false;
    }
    else
    {
      

      this.isdeptbypo=false;
      this.isdeptbypo_=true;
    }

   
  }
  /* Get GRN details by PO id */
  GetGRNbyPOId() {
    this.httpService
      .GetById('/procure-ws/grn/getByPoId?poId=' + this.invoiceDetails.poId, this.invoiceDetails.poId, this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.errorMessage) {
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
          } else if (res.length > 0) {
            this.isPo = true;
            this.isGrnlist = true;
            this.grnList = res;
          }
          else {
            //  this.isGrn=true;
            this.isPo = true;
            this.isGrnlist = false;
            this.TwoWaydisabledRate = true;
            //this.grnList = res;
          }
        }


      });
  }
  /* End Get GRN details by PO id */
  /* Get GRN details by PO id */
  GetItemByGRN(grnId: any, RowIndex: any) {
    this.httpService
      .GetById('/procure-ws/grn/getByGrnId?grnId=' + grnId, grnId, this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.errorMessage) {
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
          } else {
            this.isGrn = true;
            this.isPo = false;
            this.grn = res;
            this.invoiceDetails.invoiceItems[RowIndex].grnItemList = res.grnItem;
            //  for(let x=0;x<res.grnItem.length;x++)
            //  {
            //   this.invoiceDetails.invoiceItems[RowIndex].grnItemList.push({
            //     'itemId':res.grnItem[x].itemId,
            //     'itemName':res.grnItem[x].itemName
            //   }) ;
            //  }

            // if(this.editMode || this.viewMode){
            //   setTimeout(() => {
            //     this.invoiceDetails.invoiceItems=this.itemCopy;
            //   }, 1000);
            // }
          }
        }



      });
  }
  /* End Get GRN details by PO id */
  onGRNItemChange(index: number, value: string, grnValue: any) {
    for (let j = 0; j < this.invoiceDetails.invoiceItems.length; j++) {
      if (j !== index && Number(value) == this.invoiceDetails.invoiceItems[j].itemId && Number(grnValue) == this.invoiceDetails.invoiceItems[j].grnId) {
        this.showAlert("Same GRN and Item not allowed !");
        //this.invoiceDetails.invoiceItems[index].itemId=undefined
        this.invoiceDetails.invoiceItems[index] = new InvoiceItem();
        return false;
      }
    }
    let that = this;
    this.httpService.GetAll(`/procure-ws/grn/getByGrnItemId?grnId=${this.invoiceDetails.invoiceItems[index].grnId}&itemId=${this.invoiceDetails.invoiceItems[index].itemId}`, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res == null || res == undefined) {
            this.toastService.addSingle(
              'error',
              'Error',
              'No data found'
            );
          }
          else {
            that.invoiceDetails.amount = 0.00;
            that.invoiceDetails.taxAmount = 0.00;
            that.invoiceDetails.totalAmount = 0.00;
            that.invoiceDetails.invoiceItems[index].unbilledQuantity = res.unbilledQuantity;
            that.invoiceDetails.invoiceItems[index].itemDescription = res.itemDescription;
            that.invoiceDetails.invoiceItems[index].itemUom = res.itemUom;
            that.invoiceDetails.invoiceItems[index].billQty = 0.00;//(res.reciveQuantity).toFixed(2);
            that.invoiceDetails.invoiceItems[index].rate = (res.rate).toFixed(2);
            that.invoiceDetails.invoiceItems[index].amount = (parseFloat(res.billQty) * parseFloat(res.rate)).toFixed(2);
            that.invoiceDetails.invoiceItems[index].taxGroupId = res.taxGroupId;
            that.invoiceDetails.invoiceItems[index].taxAmount = "0.00";
            that.invoiceDetails.invoiceItems[index].totalAmount = that.invoiceDetails.invoiceItems[index].amount;
            that.invoiceDetails.invoiceItems[index].disabledRate = true;
            that.invoiceDetails.invoiceItems[index].departmentId=res.departmentIdFromPo;
            that.invoiceDetails.invoiceItems[index].department=res.departmentName;
            this.loaddepartment();
            if (res.taxGroupId) {
              this.isPOtaxGroup = true;
              this.selectedRow = index;
              this.GetTaxGroupbyId(res.taxGroupId);
            } else {
              this.SummuryAmount();
            }
          }
        }


      },
        error => {
        },
        () => {
          // 'onCompleted' callback.
          // No errors, route to new page here
        });
    // this.grn.grnItem.find(o => {
    //   if (o.id === parseInt(value)) {
    //     that.invoiceDetails.invoiceItems[index].description = o.itemDescription;
    //     that.invoiceDetails.invoiceItems[index].uom = o.itemUom;
    //     that.invoiceDetails.invoiceItems[index].billQty = (o.quantity).toFixed(2);
    //     that.invoiceDetails.invoiceItems[index].rate = (o.rate).toFixed(2);
    //     that.invoiceDetails.invoiceItems[index].amount = (parseFloat(o.quantity)* parseFloat(o.rate)).toFixed(2);
    //     that.invoiceDetails.invoiceItems[index].taxGroupId = o.taxGroupId;
    //     that.invoiceDetails.invoiceItems[index].taxAmount = "0.00";
    //    that.invoiceDetails.invoiceItems[index].totalAmount = that.invoiceDetails.invoiceItems[index].amount;
    //     // that.invoiceDetails.invoiceItems[index].department = o.department;

    //   }
    // });
  }
  saveInvoice() {
    var isSuccess = true
    if (this.invoiceDetails.subsidiaryId == undefined || this.invoiceDetails.subsidiaryId == null) {
      this.showAlert("Please select Subsidiary !");
      return false;
    }
    else if (this.invoiceDetails.invoiceNo == undefined || this.invoiceDetails.invoiceNo == '') {
      this.showAlert("Please enter Invoice No !");
      return false;
    }
    else if (this.invoiceDetails.supplierId == undefined || this.invoiceDetails.supplierId == null) {
      this.showAlert("Please select Supplier !");
      return false;
    }
    else if (this.invoiceDetails.locationId == undefined || this.invoiceDetails.locationId == null) {
      this.showAlert("Please select Location !");
      return false;
    }
    else if (this.invoiceDetails.invoiceDate == undefined || this.invoiceDetails.invoiceDate == null || JSON.stringify(this.invoiceDetails.invoiceDate) === '{}') {
      this.showAlert("Please enter Invoice Date !");
      return false;
    }
    else if (this.subsidiary.currency != this.invoiceDetails.currency) {
      if (this.invoiceDetails.fxRate == undefined || this.invoiceDetails.fxRate == "") {
        this.showAlert("Please enter Exchange Rate !");
        return false;
      }

    }
   if (this.invoiceDetails.requestor == undefined || this.invoiceDetails.requestor === null) {
        this.showAlert("Please select Requester !");
        return false;
    }
    if(this.invoiceDetails.poId > 0)
    {

      if (this.invoiceDetails.departmentId == undefined || this.invoiceDetails.departmentId === null) {
        this.showAlert("Please select Department !");
        return false;
    }

  }
    if (this.invoiceDetails.poId > 0) {

      let days: any = new Date(this.invoiceDetails.invoiceDate).getDate();
      let months: any = new Date(this.invoiceDetails.invoiceDate).getMonth() + 1;
      let year: any = new Date(this.invoiceDetails.invoiceDate).getFullYear();

      let PRdays: any = new Date(this.purchaseorder.poDate).getDate();
      let PRmonths: any = new Date(this.purchaseorder.poDate).getMonth() + 1;
      let PRyear: any = new Date(this.purchaseorder.poDate).getFullYear();

      let InvDate = this.invoiceDetails.invoiceDate !== undefined ? (year + '-' + (months.toString().length == 1 ? "0" + months : months) + '-' + (days.toString().length == 1 ? "0" + days : days)) : ""
      let PoDate = this.purchaseorder.poDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""
      if (InvDate < PoDate) {
        this.showAlert("Invoice Date must be greater than or equal to PO Date !");
        this.invoiceDetails.invoiceDate = {};
        this.invoiceDetails.dueDate = {};
        return false;
      }




      // if(new Date(this.invoiceDetails.invoiceDate) < new Date(this.purchaseorder.poDate ))
      //     {
      //       this.showAlert("Invoice Date must be greater or equal than PO Date");
      //       this.invoiceDetails.invoiceDate={};
      //       this.invoiceDetails.dueDate={};
      //       return false;
      //     }
    }
    if (this.invoiceDetails.poId) {


      // if(this.invoiceDetails.matchType=="2 Way"){
      //   this.invoiceDetails.invoiceItems.map((data:any,index:any)=>{
      //     if(parseFloat(data.billQty)> this.purchaseorder.purchaseOrderItems[index].quantity){
      //       //isSuccess=true;
      //       isSuccess=false;
      //       return
      //     }
      //     else if(parseFloat(data.rate)> this.purchaseorder.purchaseOrderItems[index].rate){
      //       //isSuccess=true;
      //       isSuccess=false;
      //       return
      //     }
      //     // else{
      //     //   isSuccess=false;
      //     //   return
      //     // }
      //   })
      //   if(isSuccess){
      //     this.isMatchDilog=false;
      //   }else{
      //     this.isMatchDilog=true;
      //   }
      // }else{
      //   this.invoiceDetails.invoiceItems.map((data:any,index:any)=>{
      //     if(parseFloat(data.billQty)> this.grn.grnItem[index].quantity){
      //       //this.isMatchDilog=true;
      //       isSuccess=false;
      //       return
      //     }
      //     else if(parseFloat(data.rate)> this.purchaseorder.purchaseOrderItems[index].rate){
      //       //isSuccess=true;
      //       isSuccess=false;
      //       return
      //     }
      //     // else{

      //     // }
      //   })
      //   if(isSuccess){
      //     this.isMatchDilog=false;
      //   }else{
      //     this.isMatchDilog=true;
      //   }
      // }

      //--Temp Off
      
      // if (this.invoiceDetails.matchType == "2 Way") {
      //   this.invoiceDetails.invoiceItems.map((data: any, index: any) => {
      //     if (parseFloat(data.billQty) > parseFloat(data.unbilledQuantity)) {
      //       isSuccess = false;
      //       return
      //     }
      //   })
      //   if (isSuccess) {
      //     this.isMatchDilog = false;
      //     this.isMatchConfirm = true;
      //   } else {
      //     this.isMatchDilog = true;
      //     this.isMatchConfirm = false;
      //     this.OpenMatch();
      //   }
      // } else {
      //   this.invoiceDetails.invoiceItems.map((data: any, index: any) => {
      //     if (parseFloat(data.billQty) > parseFloat(data.unbilledQuantity))
      //     {
      //       isSuccess = false;
      //       return
      //     }
      //     data.grnItemList.map((GRNdata: any, index: any) => {
      //       if (GRNdata.itemId != data.itemId) {
      //         data.grnItemList.splice(index, 1);
      //       }
      //     });
         
      //   })
      //   if (isSuccess) {
      //     this.isMatchDilog = false;
      //     this.isMatchConfirm = true;

      //   } else {
      //     this.isMatchDilog = true;
      //     this.isMatchConfirm = false;
      //     this.OpenMatch();
      //   }
      // }
    

      //----For New Changes
       //if (this.invoiceDetails.matchType == "2 Way") {
        if (this.invoiceDetails.matchType == "PO") {
        this.invoiceDetails.invoiceItems.map((data: any, index: any) => {
          if (parseFloat(data.billQty) > parseFloat(data.reciveQuantity)) {
            isSuccess = false;
            return
          }
        })
        if (isSuccess) {
          this.isMatchDilog = false;
          this.isMatchConfirm = true;
        } else {
          this.isMatchDilog = true;
          this.isMatchConfirm = false;
          this.OpenMatch();
        }
      } else {
        this.invoiceDetails.invoiceItems.map((data: any, index: any) => {
          // if (parseFloat(data.billQty) > parseFloat(data.reciveQuantity))
          // {
          //   isSuccess = false;
          //   return
          // }
          if( data.grnItemList != undefined)
          {
            data.grnItemList.map((GRNdata: any, index: any) => {
            if (GRNdata.itemId != data.itemId) {
              data.grnItemList.splice(index, 1);
            }
            if (parseFloat(data.billQty) > parseFloat(GRNdata.reciveQuantity))
            {
              isSuccess = false;
              return
            }
          
          });
        }
        })
        if (isSuccess) {
          this.isMatchDilog = false;
          this.isMatchConfirm = true;

        } else {
          this.isMatchDilog = true;
          this.isMatchConfirm = false;
          this.OpenMatch();
        }
      }
      //----End
    
    }

    if (isSuccess) {
      if (this.invoiceDetails.invoiceItems.length == 0) {
        this.showAlert("Item & Expenses details not found !");
        return false;
      }
      for (let k = 0; k < this.invoiceDetails.invoiceItems.length; k++) {
        if (this.invoiceDetails.poId != undefined || this.invoiceDetails.poId != "") { this.invoiceDetails.invoiceItems[k].poId = this.invoiceDetails.poId }

        if (this.invoiceDetails.invoiceItems[k].billQty == null || this.invoiceDetails.invoiceItems[k].billQty == "" || this.invoiceDetails.invoiceItems[k].billQty == undefined || this.invoiceDetails.invoiceItems[k].billQty == 0) {
          if (this.invoiceDetails.invoiceItems[k].billQty == 0) {
            this.showAlert("Billing Quantity Value must be greater than 0 !");
            return false;
          }
          this.showAlert("Billing Quantity cannot be blank !");
          return false;
        }
        else if (this.invoiceDetails.invoiceItems[k].rate == null || this.invoiceDetails.invoiceItems[k].rate == "" || this.invoiceDetails.invoiceItems[k].rate == undefined || this.invoiceDetails.invoiceItems[k].rate == 0) {
          if (this.invoiceDetails.invoiceItems[k].rate == 0) {
            this.showAlert("Rate must be greater than 0 !");
            return false;
          }
          this.showAlert("Rate cannot be blank !");
          return false;
        }
        // else if(this.invoiceDetails.invoiceItems[k].billQty == 0  || this.invoiceDetails.invoiceItems[k].rate == 0)
        // {
        //   this.showAlert("Billing Quantity Value & Rate value must be greater than 0 !");
        //   return false;
        // }
      }

      //For Save API Call
      if (this.addMode) {
        this.invoiceDetails.createdBy = this.RetloginDetails.username; this.invoiceDetails.lastModifiedBy = this.RetloginDetails.username
      }
      else if (!this.addMode) {
        this.invoiceDetails.lastModifiedBy = this.RetloginDetails.username
      }
      this.invoiceDetails.requestorName=this.invoiceDetails.requestor;
      this.invoiceDetails.mailId=this.selectedMailId != null ? this.selectedMailId: undefined;
//this.invoiceDetails.invoiceItems.map((data: any) => {
 // data.departmentId=this.invoiceDetails.departmentId
//});

      this.showloader = true;
      this.httpService.Insert('/finance-ws/invoice/save', this.invoiceDetails, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res.errorMessage) {
              this.showAlert(res.errorMessage);
              this.showloader = false;
            }
            else if (res && res.invoiceId > 0) {
              // if(this.isAutoMode) // Changed by Sumon da 
              if(this.selectedMailId != undefined && this.selectedMailId > 0)
              {
                this.httpService.GetAll('/finance-ws/mail/change-mail-status?mailId=' +  this.selectedMailId,this.RetloginDetails.token)
                .subscribe((res) => {
                  if(res)
                  { this.showSuccess();
                    if(this.addMode)
                    {
                      this.router.navigate(['/main/apinvoice/action', 'view',res.invoiceId]);
                    }
                    else{
                    this.router.navigate(['/main/apinvoice/list']);
                    }
                  }
                });
              }else
              {
                if(this.addMode)
                {
                  this.router.navigate(['/main/apinvoice/action', 'view',res.invoiceId]);
                }
                else{
                this.router.navigate(['/main/apinvoice/list']);
                }
              }
              this.showloader = false;
           
            } else {
              this.showloader = false;
              this.showError();
            }
          }


        },
        (error) => {
          this.showAlert(error);
          this.showloader = false;
        },
        () => { }
      );
    }
  }
  showSuccess() {
    this.toastService.addSingle(
      'success',
      'Success',
      'Ap Invoice Saved Successfully!'
    );
  }
  showError() {
    this.toastService.addSingle(
      'error',
      'Error',
      'Error occured while saving ap invoice!'
    );
  }
  showAlert(AlertMSG: string) {
    this.toastService.addSingle(
      'error',
      'Error',
      AlertMSG
    );
  }
  showAllAlert(AlertMSG: string) {
    this.toastService.addMultiple(
      AlertMSG
    );
  }
  clearInvoiceData() {
    if (this.editMode) {
      this.router.navigate(['/main/apinvoice/list']);
    }
    else {
      // this.supplier=new Supplier();
      // this.subsidiary=new Subsidiary();
      //this.purchaseorder = new PurchaseOrder();
      this.invoiceDetails = new InvoiceDetail();
      this.reloadSubidery();
    }
  }


  // file: string;

  // handleChange(files: FileList) {
  //   if (files && files.length) {
  //     this.file = files[0].name;
  //   }
  // }
  /* Item Pop */
  GetItemListByDescription(description: any, curRow: any): any {
    if (description != undefined) {
      this.selectedRow = curRow;
      var SplittedDescription = description;
      var splitted = SplittedDescription.split(" ", 1);
      this.httpService.GetAll(`/masters-ws/item/getByDescMatch?description=${splitted}&subsidiaryId=${this.invoiceDetails.subsidiaryId}`, this.RetloginDetails.token)
        .subscribe(res => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res.error) {
              //var error = JSON.parse(res.error);
              this.toastService.addSingle(
                'error',
                'Error',
                res.error.errorMessage
              );
              this.itemListByDes = [];
            }
            else {
              if (res.length > 0) {
                this.itemListByDes = res;
                this.isItemDilog = true;
              }
              else {
                this.showAlert("No Data Found !");
              }
            }
          }


        },
          error => {
          },
          () => {
            //this.isItemDilog=true;

            // 'onCompleted' callback.
            // No errors, route to new page here
          });
    }
  }
  onItemDesChange(id: any, index: any, description: any) {
    this.isItemDilog = false;
    this.invoiceDetails.invoiceItems[this.selectedRow].itemId = id;
    //this.invoiceDetails.invoiceItems[this.selectedRow].description=description;
    //this.onItemChange(index,id);
    this.onItemChange(this.selectedRow, id);

  }
  onDescriptionChange() {

    this.isItemDilog = true;
  }
  addNewItem() {
    this.isItemDilog = false;
    const url = this.router.serializeUrl(
      this.router.createUrlTree(["/#/main/item/action/add"])
    );
    window.open(decodeURIComponent(url))
  }
  /* ** */

  onFileChange(event: any) {
    // Create form data
    const formData: FormData = new FormData();

    //[old] 
    this.file = event.currentTarget.files[0];
    if (this.file) {
      //[New]
      //this.file = event.files[0]

      // Store form name as "file" with file data
      //formData.append("file", this.file);
      formData.append("file", this.file, this.file.name);//, this.file.name
      //this.httpService.uploadFile("/finance-ws/mail/save/file",formData)
      //this.httpService.uploadFile("/finance-ws/mail/save/file?employeeId=" + this.empID, formData, this.RetloginDetails.token)
      this.httpService.uploadFile("/finance-ws/mail/save/file?subsidiaryId=" +this.RetRoleDetails[0].subsidiaryId, formData, this.RetloginDetails.token)
        .subscribe(res => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res.errorMessage) {
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );
            }
            else {
              this.toastService.addSingle(
                'success',
                'Success',
                'File uploaded Successfully!'
              );
              window.location.reload();
            }
          }


        },
          (error) => {
            this.showAlert(error.error.errorMessage);
          },
          () => {

            // 'onCompleted' callback.
            // No errors, route to new page here
          });
    }
    else {
      this.showAlert("No Attachment Found !")
    }
  }

  /* Start Reload supplier */
  reloadSupplier() {
    //$('.refsubsidery').addClass('fa-spin');
    this.isReloadSupplier = true;
    this.invoiceDetails.supplierId = 0;
    this.GetSupplierList();
    this.POList = [];
    this.invoiceDetails.paymentTerm = undefined;
    this.currency = [];
    this.invoiceDetails.currency = "";
    this.invoiceDetails.fxRate = "";
    this.reloadPoList();
  }
  /* End Reload supplier */
  /* Start Reload supplier */
  reloadLocation() {
    //$('.refsubsidery').addClass('fa-spin');
    this.isReloadlocation = true;
    this.invoiceDetails.locationId = 0;
    this.GetLocationList();
  }

  /* End Reload supplier */
  decimalfrection(event: any) {
    this.invoiceDetails.fxRate = event.target.value != "" ? parseFloat(event.target.value).toFixed(2) : "";
  }
  decimalfrectionRate(event: any, index: any) {
    if (event.target.value != "")
      this.invoiceDetails.invoiceItems[index].rate = parseFloat(event.target.value).toFixed(2)
  }
  decimalfrectionQuntity(event: any, index: any) {
    if (event.target.value != "")
      this.invoiceDetails.invoiceItems[index].billQty = parseFloat(event.target.value).toFixed(2)
  }
  OpenMatch() {
    var that = this;
    this.matchTypes = [];
    let TotalGrnList: GrnItem[] = [];
    //let POItems:Item[]=[];
    if (this.invoiceDetails.matchType == 'GRN')//'3 Way') 
    {
      let POItems: any = this.purchaseorder.purchaseOrderItems.map(item => item.itemId).filter((value, index, self) => self.indexOf(value) === index);

      this.invoiceDetails.invoiceItems.map((data: any, index: any) => {
        this.matchTypes.push(new matchType())
        //if(data.billQuantity != undefined)
        if(data.grnItemList != undefined) //--New Changes[G-11-9-23]
        {   
         // data.billQuantity.find((o: any) => {
            data.grnItemList.find((o: any) => { //New Changes[G-11-9-23]
            if (o.itemId == parseInt(data.itemId)) {
            that.matchTypes[index].itemCode = o.itemName;
            that.matchTypes[index].poQuntity = o.quantity;
            that.matchTypes[index].grnQuntity = o.reciveQuantity;
            //that.matchTypes[index].billingQuntity = o.billQuantity;
            that.matchTypes[index].billQuantity = o.billQuantity;
          }
        });
        }
        //that.matchTypes[index].itemCode = data.grnItemList[0].itemName;
        that.matchTypes[index].poRate = data.rate;
        //that.matchTypes[index].poQuntity = data.grnItemList[0].quantity;

        //  this.grn.grnItem.find(o => {
        //   if (o.grnId == data.grnId && o.itemId == parseInt(data.itemId) ) {
        //     that.matchTypes[index].grnQuntity = o.reciveQuantity;
        //     that.matchTypes[index].unbilledQuantity = o.unbilledQuantity.toFixed(2);
        //   }
        // });

        //that.matchTypes[index].grnQuntity = data.grnItemList[0].reciveQuantity;
        that.matchTypes[index].unbilledQuantity = data.unbilledQuantity > 0 ? data.unbilledQuantity : 0;

        that.matchTypes[index].rate = data.rate;
        that.matchTypes[index].poMatch = true;
        that.matchTypes[index].billingQuntity = data.billQty;
        //that.matchTypes[index].grnMatch=that.matchTypes[index].grnQuntity>=data.billQty? that.matchTypes[index].poRate>=data.rate?true:false:false
        //--Old//that.matchTypes[index].grnMatch = that.matchTypes[index].unbilledQuantity >= data.billQty ? that.matchTypes[index].poRate >= data.rate ? true : false : false
       
       //--Old[22-6-23]  that.matchTypes[index].grnMatch = that.matchTypes[index].unbilledQuantity  >= (data.billQty - that.matchTypes[index].billQuantity > 0 ? (data.billQty - that.matchTypes[index].billQuantity):that.matchTypes[index].unbilledQuantity *2)? true : false;
       that.matchTypes[index].grnMatch = data.billQty <= that.matchTypes[index].unbilledQuantity ? true : false;
        
        //that.matchTypes[index].unbilledQuantity >= data.billQty ? that.matchTypes[index].poRate >= data.rate ? true : false : false
   
      })
    } else {
      this.invoiceDetails.invoiceItems.map((data: any, index: any) => {
        this.matchTypes.push(new matchType())

        this.purchaseorder.purchaseOrderItems.find(o => {
          if (o.itemId === parseInt(data.itemId)) {
            that.matchTypes[index].itemCode = o.itemName;
            that.matchTypes[index].poRate = o.rate;
            that.matchTypes[index].poQuntity = o.quantity;
            that.matchTypes[index].unbilledQuantity = o.unbilledQuantity.toFixed(2);
           // that.matchTypes[index].billQuantity = o.quantity;
           that.matchTypes[index].billQuantity = o.billQuantity;
          }
        });
        that.matchTypes[index].grnQuntity = 0;
        that.matchTypes[index].billingQuntity = data.billQty;
        that.matchTypes[index].rate = data.rate;
        that.matchTypes[index].grnMatch = true;
        //that.matchTypes[index].poMatch =true;
        //that.matchTypes[index].poMatch=that.matchTypes[index].poQuntity>=data.billQty? that.matchTypes[index].poRate>=data.rate?true:false:false
        //that.matchTypes[index].poMatch = that.matchTypes[index].unbilledQuantity >= data.billQty ? that.matchTypes[index].poRate >= data.rate ? true : false : false
        //that.matchTypes[index].poMatch = that.matchTypes[index].unbilledQuantity  >= (data.billQty - that.matchTypes[index].billingQuntity)? true : false
        that.matchTypes[index].poMatch = that.matchTypes[index].unbilledQuantity  >= (data.billQty - that.matchTypes[index].billQuantity > 0 ? (data.billQty - that.matchTypes[index].billQuantity):that.matchTypes[index].unbilledQuantity *2)? true : false;
       
      })
    }

    for(let x=0;x<this.matchTypes.length;x++)
    {
      if(this.matchTypes[x].grnMatch == false)
      {
        this.isConfirmMatchDisabled=true;
        break;
      }
      else
      {
        this.isConfirmMatchDisabled=false;
      }
    }
  
    this.isMatchDilog = true;
  }

  confirmMatchSave() {

  }

  ConfirmMatch() {
    var isSuccess = true
    //if (this.invoiceDetails.matchType == "2 Way") {
      if (this.invoiceDetails.matchType == "PO") {
      this.invoiceDetails.invoiceItems.map((data: any, index: any) => {
        if (parseFloat(data.billQty) > this.matchTypes[index].poQuntity) {
          //isSuccess=true;
          isSuccess = false;
          return
        }
        else if (parseFloat(data.rate) > this.matchTypes[index].poRate) {
          //isSuccess=true;
          isSuccess = false;
          return
        }
        // else{
        //   isSuccess=false;
        //   return
        // }
      })
      if (isSuccess) {
        this.isMatchDilog = false;
        this.isMatchConfirm = true;
      } else {
        this.isMatchDilog = true;
        this.isMatchConfirm = false;

      }
    } else {
      this.invoiceDetails.invoiceItems.map((data: any, index: any) => {
        if (parseFloat(data.billQty) > this.matchTypes[index].grnQuntity) {
          //this.isMatchDilog=true;
          isSuccess = false;
          return
        }
        else if (parseFloat(data.rate) > this.matchTypes[index].poRate) {
          //isSuccess=true;
          isSuccess = false;
          return
        }
        // else{

        // }
      })
      if (isSuccess) {
        this.isMatchDilog = false;
        this.isMatchConfirm = true;

      } else {
        this.isMatchDilog = true;
        this.isMatchConfirm = false;

      }
    }
    // setTimeout(() => {
    //   this.SummuryAmount();
    //  }, 500);

  }
  ConfirmMatch1() {
    var isSuccess = true
    //if (this.invoiceDetails.matchType == "2 Way") {
      if (this.invoiceDetails.matchType == "PO") {
      this.invoiceDetails.invoiceItems.map((data: any, index: any) => {
        if (parseFloat(data.billQty) > this.purchaseorder.purchaseOrderItems[index].quantity) {
          //isSuccess=true;
          isSuccess = false;
          return
        }
        else if (parseFloat(data.rate) > this.purchaseorder.purchaseOrderItems[index].rate) {
          //isSuccess=true;
          isSuccess = false;
          return
        }
        // else{
        //   isSuccess=false;
        //   return
        // }
      })
      if (isSuccess) {
        this.isMatchDilog = false;
        this.isMatchConfirm = true;
      } else {
        this.isMatchDilog = true;
        this.isMatchConfirm = false;

      }
    } else {
      this.invoiceDetails.invoiceItems.map((data: any, index: any) => {
        if (parseFloat(data.billQty) > this.grn.grnItem[index].quantity) {
          //this.isMatchDilog=true;
          isSuccess = false;
          return
        }
        else if (parseFloat(data.rate) > this.purchaseorder.purchaseOrderItems[index].rate) {
          //isSuccess=true;
          isSuccess = false;
          return
        }
        // else{

        // }
      })
      if (isSuccess) {
        this.isMatchDilog = false;
        this.isMatchConfirm = true;

      } else {
        this.isMatchDilog = true;
        this.isMatchConfirm = false;

      }
    }
  }
  OnMatchSelect(quantity: any, rate: any, index: any, event: any) {
    if (event.checked) {
      this.matchTypes[index].billingQuntity = (quantity);
      this.invoiceDetails.invoiceItems[index].billQty = (quantity);
      this.invoiceDetails.invoiceItems[index].rate = (rate);
      this.CalculateAmmount(this.invoiceDetails.invoiceItems[index].billQty, this.invoiceDetails.invoiceItems[index].rate, index);
      this.calculateTAXAMount(this.invoiceDetails.invoiceItems[index].taxGroupId, index);
    }

  }
  fnOnActiveTax() {
    var TGRow = this.TaxGroupRowIndex;
    if (this.taxgroup.isTaxOverride) {
      this.isEditableTaxAmount = true;
      for (let a = 0; a < this.taxgroup.taxRateRules.length; a++) {
        //var TotaltaxAmount= this.taxgroup.inclusive?(((this.invoiceDetails.invoiceItems[a].amount *100)/(100 + (this.taxgroup.taxRateRules[a].taxRates*1)) * this.taxgroup.taxRateRules[a].taxRates) / 100 ):(this.invoiceDetails.invoiceItems[a].amount * this.taxgroup.taxRateRules[a].taxRates) / 100 ;
        //var aa=this.taxgroup.taxRateRules[a].taxAmount;
        this.taxgroup.taxRateRules[a].taxAmount = this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[TGRow].amount * 100) / (100 + (this.taxgroup.taxRateRules[a].taxRates * 1)) * this.taxgroup.taxRateRules[a].taxRates) / 100).toFixed(2) : ((this.invoiceDetails.invoiceItems[TGRow].amount * this.taxgroup.taxRateRules[a].taxRates) / 100).toFixed(2);
      }
    }
    else {
      this.taxamount = 0;
      for (let a = 0; a < this.taxgroup.taxRateRules.length; a++) {
        let amt: any = this.taxgroup.inclusive ? (((this.invoiceDetails.invoiceItems[TGRow].amount * 100) / (100 + (this.taxgroup.taxRateRules[a].taxRates * 1)) * this.taxgroup.taxRateRules[a].taxRates) / 100) : (this.invoiceDetails.invoiceItems[TGRow].amount * this.taxgroup.taxRateRules[a].taxRates) / 100;
        this.taxamount += Number(amt)
      }
      this.isEditableTaxAmount = false;
    }
  }
  fnCalculate(Data: any, RowIndex: any) {
    this.taxamount = 0;
    for (let a = 0; a < this.taxgroup.taxRateRules.length; a++) {
      //var TotaltaxAmount= this.taxgroup.inclusive?(((this.invoiceDetails.invoiceItems[a].amount *100)/(100 + (this.taxgroup.taxRateRules[a].taxRates*1)) * this.taxgroup.taxRateRules[a].taxRates) / 100 ):(this.invoiceDetails.invoiceItems[a].amount * this.taxgroup.taxRateRules[a].taxRates) / 100 ;
      if(this.taxgroup.taxRateRules[a].deleted == false){
      this.taxamount += Number(this.taxgroup.taxRateRules[a].taxAmount);
      }
      //this.taxamount+= this.taxgroup.inclusive?(((this.invoiceDetails.invoiceItems[RowIndex].amount *100)/(100 + (this.taxgroup.taxRateRules[a].taxRates*1)) * this.taxgroup.taxRateRules[a].taxRates) / 100 ):(this.invoiceDetails.invoiceItems[RowIndex].amount * this.taxgroup.taxRateRules[a].taxRates) / 100 ;
    }

  }
  /* Start fetching History details */
  LoadHistory() {
    if (this.HistoryList.length == 0)
      this.httpService
        .GetById(
          `/finance-ws/invoice/get/history?invoiceId=${this.APInvoiceId}&pageSize=10000`,
          this.APInvoiceId, this.RetloginDetails.token
        )
        .subscribe((res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            this.HistoryList = res;
          }


        });
  }
  /* End fetching History details */

  fnCheckCurrency() {
    if (this.subsidiary.currency == this.invoiceDetails.currency) {
      this.invoiceDetails.fxRate = 1.00.toFixed(2);
    }
    else {
      if (this.invoiceDetails.fxRate == "NaN" || this.invoiceDetails.fxRate == undefined) {
        this.invoiceDetails.fxRate = "";
      }
    }
  }
  //*---Check Date On Fiscal Calendar
  getFiscalDateRanges() {
    this.fiscalCalenderDTLS = null;
    let AllowMonths: any = "Allow Months: ";
    let IsDateAvailable: boolean = false;
    let Dummymonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    if (this.invoiceDetails.subsidiaryId != undefined && this.invoiceDetails.invoiceDate != undefined) {
      this.httpService
        .GetById('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId=' + this.invoiceDetails.subsidiaryId, this.invoiceDetails.subsidiaryId, this.RetloginDetails.token)
        .subscribe((res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            if (res) {
              this.fiscalCalenderDTLS = res;
              if (this.fiscalCalenderDTLS != null && this.fiscalCalenderDTLS.fiscalCalanderAccounting.length > 0) {

                let PRdays: any = new Date(this.invoiceDetails.invoiceDate).getDate();
                let PRmonths: any = new Date(this.invoiceDetails.invoiceDate).getMonth() + 1;
                let PRyear: any = new Date(this.invoiceDetails.invoiceDate).getFullYear();
                let PRDate: any = this.invoiceDetails.invoiceDate !== undefined ? (PRyear + '-' + (PRmonths.toString().length == 1 ? "0" + PRmonths : PRmonths) + '-' + (PRdays.toString().length == 1 ? "0" + PRdays : PRdays)) : ""

                for (let x = 0; x < this.fiscalCalenderDTLS.fiscalCalanderAccounting.length; x++) {
                  AllowMonths += this.fiscalCalenderDTLS.fiscalCalanderAccounting.length == (x + 1) ? this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month : this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month + " , "

                  if (PRDate >= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].fromDate && PRDate <= this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].toDate && this.fiscalCalenderDTLS.fiscalCalanderAccounting[x].month == Dummymonths[PRmonths - 1] + "-" + PRyear) {
                    IsDateAvailable = true;
                  }
                }

                if (IsDateAvailable == false) {
                  this.showAlert("Selected Date is Not available in Fiscal Calendar ! " + AllowMonths);
                  this.invoiceDetails.invoiceDate = {};
                }
              }
              else {
                this.showAlert("Selected Date is Not available in Fiscal Calendar !");
                this.invoiceDetails.invoiceDate = {};
              }

            } else {
              this.showAlert("No Data Found");
            }
          }


        },
          (error) => {
            this.toastService.addSingle(
              'error',
              'Error',
              error
            );
          }

        );

      // this.httpService
      // .GetAll('/setup-ws/fiscal-calender/get-by-subsidairy-id?subsidiaryId='+this.invoiceDetails.subsidiaryId)
      // .subscribe((res) => {
      //   if (res != undefined) {
      //     this.fiscalCalenderDTLS=res;
      //   } else {
      //     this.showAlert("No Data Found");
      //   }
      // });

    }
  }

  sendForApproval() {
    this.showloader = true;
    this.httpService
      .GetById('/finance-ws/invoice/send-for-approval?id=' + this.invoiceDetails.invoiceId, this.invoiceDetails.invoiceId, this.RetloginDetails.token)
      .subscribe((res) => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          // this.pr = res;
          if (res == true) {
            this.toastService.addSingle(
              'success',
              'Success',
              'Invoice Sent for Approval Successfully!'
            );
            this.showloader = false;
            window.location.reload();
          } else {
            this.showAlert(res.errorMessage);
            this.showloader = false;
          }
        }

      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending for Approval!'
          );
          this.showloader = false;
        });
  }

  selfApproval() {
    this.showloader = true;
    this.httpService
      .GetById('/finance-ws/invoice/self-approve?invoiceId=' + this.invoiceDetails.invoiceId, this.invoiceDetails.invoiceId, this.RetloginDetails.token)
      .subscribe((res) => {

        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          // this.pr = res;
          if (res == true) {
            this.toastService.addSingle(
              'success',
              'Success',
              'Invoice Approved Successfully!'
            );
            this.showloader = false;
            window.location.reload();
          } else {
            this.showAlert(res.errorMessage);
            this.showloader = false;
          }
        }

      },
        (error) => {
          this.toastService.addSingle(
            'error',
            'Error',
            'Error occured while sending for Approval!'
          );
          this.showloader = false;
        }
      );
  }

  approveIndividual(mainId:any)
  {
    try {
      var approveList: any = [];
      approveList.push(mainId);

      if (approveList.length > 0) {
        this.showloader = true;
        if(this.RetloginDetails.userType=='SUPERADMIN'){
          this.url='/finance-ws/invoice/approve-all-invoices?currentApproverId=' + this.empID;
  
         }
         else if(this.RetloginDetails.userType=='ENDUSER')
         {
              if(this.RetRoleDetails[0].selectedAccess=="ADMIN" || this.RetRoleDetails[0].selectedAccess=="ADMIN_APPROVER")
              {
                this.url='/finance-ws/invoice/approve-all-invoices?currentApproverId=' + this.empID;
              }
              else
              {
                this.url='/finance-ws/invoice/approve-all-invoices'
              }
        
         }
          //this.HttpService.Insert('/procure-ws/pr/approve-all-prs',approveList,this.RetloginDetails.token).subscribe(
            this.httpService.Insert(this.url,approveList ,this.RetloginDetails.token).subscribe(
          (res) => {
            if (res.status == 401) {
              this.showAlert("Unauthorized Access !");
              this.router.navigate(['/login']);
            }
            else if (res.status == 404) {
              this.showAlert("Wrong/Invalid Token!");
              this.router.navigate(['/login']);
            }
            else if (res.messageCode) {
              this.showloader = false;
              this.toastService.addSingle(
                'error',
                'Error',
                res.errorMessage
              );

            } else {
              this.showloader = false;
              this.toastService.addSingle(
                'success',
                'Success',
                'Approve selected AP Invoice!'
              );
              this.router.navigate([this.listURL]);
            }
            // this.loading = false;
          },
          (error) => {
            this.showAlert(error);
            this.showloader = false;
          }
        );
      }
    } catch (err:any) {
      this.showAlert(err)
      this.showloader = false;
    }
  }
  rejectIndividual(mainId:any,rejectComments:any)
  {
    try {

      if( rejectComments==undefined)
      {
        this.showAlert("Please enter Reject Comments");
        return true;
      }
        var rejectList: any = [];
        var isrejectComments: boolean = false;
        //rejectList.push({id:mainId,rejectedComments:rejectComments})
        rejectList.push({invoiceId:mainId,rejectedComments:rejectComments})
              isrejectComments = true;
              //this.isRejectPressed = true
              
        if (isrejectComments) {
          this.showloader = true;
           // this.HttpService.Insert('/procure-ws/pr/reject-all-prs',rejectList,this.RetloginDetails.token).subscribe(
            //this.httpService.Insert('/finance-ws/advance/reject-all-advance-payments',rejectList ,this.RetloginDetails.token).subscribe(
            this.httpService.Insert('/finance-ws/invoice/reject-all-invoices',rejectList ,this.RetloginDetails.token).subscribe(
          
              (res) => {
              if (res.status == 401) {
                this.showAlert("Unauthorized Access !");
                this.router.navigate(['/login']);
              }
              else if (res.status == 404) {
                this.showAlert("Wrong/Invalid Token!");
                this.router.navigate(['/login']);
              }
              else if (res.messageCode) {
                this.showloader = false;
                this.toastService.addSingle(
                  'error',
                  'Error',
                  res.errorMessage
                );
                isrejectComments=false;
              }
              else {
                this.showloader = false;
                this.toastService.addSingle(
                  'success',
                  'Success',
                  'Reject selected AP Invoice!'
                );
                this.router.navigate([this.listURL]);
              }
              // this.loading = false;
            },
            (error) => {
              this.showAlert(error);
            }
          );
        }

    } catch (err:any) {
      this.showAlert(err);
      this.showloader = false;
    }
  }

  showHideUpload(data: any) {
    if (this.fileUpload)
      this.fileUpload = false
    else
      this.fileUpload = true
  }
  OpenCommentpopup()
  {
    this.displayComments=true;
  }
  hideCommentspopup()
  {
    this.displayComments=false;
  }
  fnRequesterList(SubID:any)
{
  this.httpService.GetById('/masters-ws/employee/get-employee-by-subsidiary?subsidiaryId=' + SubID, SubID,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res.status == 401)
      { 
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { 
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else
      {

      if (res != undefined) {
        this.EmployeeList=[];
      this.EmployeeList = res;

      }
    }
    },
    (error) => {
      this.showAlert(error);
    },
    ()=>{
      
    }
    );
}
ReloadGetAllEmployeeList()
{
 // this.invoiceDetails.requestor=undefined;
}
loadrequestor()
{
  this.httpService.GetAll('/masters-ws/employee/get?id='+this.loginId,this.RetloginDetails.token).subscribe(
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.invoiceDetails.requestor=res.fullName
     
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );
}
OpenAppSequence()
{
  this.isAppSequenceVisivble=true;
}
recallStatus(invoiceId:any)
{
  this.showloader = true;
  this.httpService
    .GetAllResponseText('/finance-ws/invoice/change-to-draft?id=' +invoiceId, this.RetloginDetails.token)
    .subscribe((res) => {
      //For Auth
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else if (res.status == 200) {
          this.toastService.addSingle(
            'success',
            'Success',
            res.error.text
          );
          this.showloader = false;
          window.location.reload();
      }
      else
      {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      }
    },
      (err:any) => {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      });
}
GetAllProjectList(subsidiaryId:any)
{
  this.httpService.GetById('/masters-ws/project/get-by-subsidiary-id?subsidiaryId=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {
      this.ProjectList=[];
      for(let x=0;x<res.length;x++)
      {
        this.ProjectList.push({
          "id":res[x].id,
          "name":res[x].name
        })
      }
    }
    },
    (error) => {
      this.showAlert(error);
    }
  );
;
}
reloadProjectList()
{
  this.GetAllProjectList(this.invoiceDetails.subsidiaryId);
  this.invoiceDetails.projectId=undefined;
}
reloadDepartment()
{
  this.GetDepartmentList(this.invoiceDetails.subsidiaryId);
  this.invoiceDetails.departmentId=undefined;
}
GetDepartmentList(subsidiaryId:any) {
  this.httpService.GetAll('/masters-ws/department/get/all/lov?subsidiaryId='+ subsidiaryId,this.RetloginDetails.token).subscribe(
  (res) => {
    if(res.status == 401)
  { 
    this.showAlert("Unauthorized Access !");
    this.router.navigate(['/login']);
  }
  else if(res.status == 404)
  { 
    this.showAlert("Wrong/Invalid Token!");
    this.router.navigate(['/login']);
  }
  else
  {
    this.departmentOptions=[]
    Object.keys(res).forEach(key => { 
      this.departmentOptions.push({
          "id":Number(key),
          "departmentName":res[key]
        })   
      });

      this.departmentOptions.push({
        "id":0,
        "departmentName":'ALL'
      });
  
  }
  },
  (error) => {
    this.showAlert(error);
  }
);

}

downloadInvoice()
{
  this.httpService.downloadFile('/finance-ws/mail/get/attachment?mailId=' + this.invoiceDetails.mailId, this.RetloginDetails.token)
  .subscribe(res => {
    if(this.doctype == "img")
    {
      saveAs(res, "Invoice-"+this.invoiceDetails.mailId+".jpg");
    }
    else
    {
      saveAs(res, "Invoice-"+this.invoiceDetails.mailId+".pdf");
    }
    
    //this.executeSaveAs(res);
    //let blob = new Blob([res], {'type': "application/octet-stream"});
    //window.open(res)

    
  });
}

loaddepartment()
{
          let department:any;
          let isdepartment:boolean=false;
          department=this.invoiceDetails.invoiceItems[0].department;
          for(let i=0;i<this.invoiceDetails.invoiceItems.length;i++)
          { 
            if(department==this.invoiceDetails.invoiceItems[i].department)
            {
               isdepartment=false;
            }
            else
            {
               isdepartment=true;
               break;
            }
          }
          if(isdepartment)
          {
           // this.invoiceDetails.department="All";
            this.invoiceDetails.departmentId=0;
          }
          else
          {
            this.invoiceDetails.department=this.invoiceDetails.invoiceItems[0].department;
            this.invoiceDetails.departmentId=this.invoiceDetails.invoiceItems[0].departmentId;
                }
          isdepartment=false;
}

OnDeptChange(event:any)
{
 this.dept_header=event.originalEvent.currentTarget.ariaLabel;



 for(let i=0;i<this.invoiceDetails.invoiceItems.length;i++)
 {
  this.invoiceDetails.invoiceItems[i].departmentId=this.invoiceDetails.departmentId;
  this.invoiceDetails.invoiceItems[i].department=this.dept_header;
 }



}

onUpdateFile(event: any) {
  // Create form data
  const formData: FormData = new FormData();
  //[old] 
  this.file = event.currentTarget.files[0];
  if (this.file) {
    //[New]
    formData.append("file", this.file, this.file.name);//, this.file.name
    this.showloader=true;
    this.httpService.uploadFile("/finance-ws/mail/save/file?subsidiaryId=" +this.RetRoleDetails[0].subsidiaryId, formData, this.RetloginDetails.token)
      .subscribe(res => {
        //For Auth
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          if (res.errorMessage) {
            this.toastService.addSingle('error','Error',res.errorMessage);
            this.showloader=false;
          }
          else {
            this.UpdateMailStatus(res.mailId);
            this.updateAttachment(res.mailId);
            this.showUploadedInvoice(res.mailId);
            this.showloader=false;
            this.toastService.addSingle(
              'success',
              'Success',
              'File uploaded Successfully!'
            );
          }
        }
      },
        (error) => {
          this.showAlert(error.error.errorMessage);
          this.showloader=false;
        },
        () => {

          // 'onCompleted' callback.
          // No errors, route to new page here
        });
  }
  else {
    this.showAlert("No Attachment Found !")
  }
}
showUploadedInvoice(mailId:any)
{
  this.showloader=true;
  //let url = "http://43.205.33.156:8082/finance-ws/mail/get/attachment?mailId=" //--Dev
  //let url="http://3.7.123.122:8082/finance-ws/mail/get/attachment?mailId=" //--Test http://3.110.239.158:8082
  let url = "http://3.110.239.158:8082/finance-ws/mail/get/attachment?mailId=" //--testing

      this.httpService.downloadFile('/finance-ws/mail/get/attachment?mailId='+ mailId, this.RetloginDetails.token)
      .subscribe(res => {
        if(res.type=="image/jpeg" || res.type=="image/png")
        {
          
          var base64data:any;
          this.doctype = "img";
          var reader = new FileReader();
          reader.readAsDataURL(res); 
          reader.onloadend = function() {
            base64data = reader.result;                
            console.log(base64data);
           
          }

          setTimeout(() => {this.imageurl=base64data;
            this.showloader=false;
            this.pdfviewer=true;
          },600);
        }
        else{
         this.pdfviewer=true;
          this.doctype = "pdf";
          this.baseurl = {
            url: url + mailId.toString(),
            httpHeaders: { Authorization: 'Bearer ' + this.RetloginDetails.token }
          }
  
        }
        this.showloader=false;

      });
}
UpdateMailStatus(MailId:any)
{
  if(MailId != undefined && MailId > 0)
  {
    this.httpService.GetAll('/finance-ws/mail/change-mail-status?mailId=' +  MailId,this.RetloginDetails.token)
    .subscribe((res) => {
      if(res)
      { 
        //this.showSuccess();
      }
    });
  }
}
updateAttachment(MailId:any)
{
  this.httpService.GetAll(`/finance-ws/mail/change-invoice-attachment?mailId=${MailId}&invoiceId=${this.APInvoiceId}`, this.RetloginDetails.token)
  .subscribe(res => {
    //For Auth
    if (res.status == 401) {
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if (res.status == 404) {
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else {
      if (res == null || res == undefined) {
        this.toastService.addSingle(
          'error',
          'Error',
          'No data found'
        );
      }
      else {

      }
    }
  },
    error => {
    },
    () => {
      // 'onCompleted' callback.
      // No errors, route to new page here
    });
}
}
