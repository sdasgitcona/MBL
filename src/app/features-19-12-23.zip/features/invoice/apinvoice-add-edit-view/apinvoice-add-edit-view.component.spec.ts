import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApinvoiceAddEditViewComponent } from './apinvoice-add-edit-view.component';

describe('ApinvoiceAddEditViewComponent', () => {
  let component: ApinvoiceAddEditViewComponent;
  let fixture: ComponentFixture<ApinvoiceAddEditViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApinvoiceAddEditViewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApinvoiceAddEditViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
