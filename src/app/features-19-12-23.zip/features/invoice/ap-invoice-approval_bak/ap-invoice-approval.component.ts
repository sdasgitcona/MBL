import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Table } from 'primeng/table';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { ToastService } from 'src/app/core/services/toast.service';
import { supplierApprovalModel } from '../../supplier/model/supplier-model';
import { APInvoice,advancePaymentInvoiceApproval } from '../model/APInvoice-model';

@Component({
  selector: 'app-ap-invoice-approval',
  templateUrl: './ap-invoice-approval.component.html',
  styleUrls: ['./ap-invoice-approval.component.scss']
})
export class ApInvoiceApprovalComponent implements OnInit {

  columns: any[];
  departments: any[] = [];

  apiApprovalList: advancePaymentInvoiceApproval[] = [];
  apiSelectedApproval: APInvoice = new APInvoice();
  totalRecords: number = 0;
  loading: boolean = false;
  AllSelected:boolean=false;
  isRejectPressed:boolean=false;
  approvalRoutingActive:boolean=false;
  userRoleId:number;
  empID:number;
  approverRoleList: [{ id?: number; name?: string;  }];
  IsLoggerAdmin:string;
  LoggerRoleName:string;

  @ViewChild('dt') dt: Table;


  constructor(
    private routeStateService: RouteStateService,
    private router: Router,
    private HttpService: CommonHttpService,
    private toastService: ToastService

  ) {
   
  }

  ngOnInit(): void {
     // For Role Base Access
 const logDetails:any = sessionStorage.getItem("LoggerDTLS");
 const LoggerId=JSON.parse(logDetails);
 this.empID= LoggerId.employeeId;
 const retDetails:any = sessionStorage.getItem("RoleDTLS");
 var role_Dtls = JSON.parse(retDetails);

 for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
 {
   if(role_Dtls[0].rolePermissions[i].accessPoint == "AP Invoice Approval")
   {
     this.userRoleId=role_Dtls[0].rolePermissions[i].roleId 
     
   }
 }
 this.IsLoggerAdmin=role_Dtls[0].selectedAccess;
 this.LoggerRoleName=role_Dtls[0].name;
// End For Role Base Access
if(this.userRoleId != undefined){
  this.loadPRApproval();
}
else
{
  this.router.navigate(['/main/dashboard']);
}
  }

  loadPRApproval() {
    try {    
      this.HttpService.GetAll('/procure-ws/invoice/get-invoice-approval?user='+this.empID).subscribe(
      // this.HttpService.GetAll('/payment/get-payment-approval?user='+this.empID).subscribe(
        (res) => {
          // console.log(res);
          if (res) {
            this.apiApprovalList = res;
            this.totalRecords = res.length;
            //this.SubsidiaryId=this.poApprovalList[0]?.subsidiaryId;
            //this.NextApproverLov()
          } else {
            //this.poApprovalList = [];
            this.totalRecords = res.length;

          }
          this.loading = false;
        },
        (error) => {
          console.log(error);
          this.loading = false;
        }
      );
    } catch (err) {
      console.log(err);
    }
  }

  navigateToAdd() {
    this.router.navigate(['/main/supplier/update']);
  }

  globalSearch(event: any) {
    this.dt.filterGlobal(event.target.value, 'contains')
  }

  approveAP(){
    try { 
      this.isRejectPressed=false
      var approveList:any=[];   
      this.apiApprovalList.map((data:advancePaymentInvoiceApproval)=>{
        if(data.selected){
          approveList.push(data.invoiceId)
        }
      })
      if(approveList.length>0){
      this.HttpService.Insert('/procure-ws/invoice/send-for-approval?id='+this.empID,approveList).subscribe(
        (res) => {
          // console.log(res);
          if (res.messageCode) {
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
           
          } else {
            this.toastService.addSingle(
              'success',
              'Success',
              'Approve selected AP Invoice!'
            );
          this.loadPRApproval();
          }
         // this.loading = false;
        },
        (error) => {
          console.log(error);
         // this.loading = false;
        }
      );
      }
    } catch (err) {
      console.log(err);
    }
  }

  rejectAP(){
    try { 
      if(this.isRejectPressed){
      var rejectList:any=[];
      var isrejectComments:boolean=false   
      this.apiApprovalList.map((data:advancePaymentInvoiceApproval)=>{
        if(data.selected){
          if(data.rejectComment){
            rejectList.push({id:data.invoiceId,rejectedComments:data.rejectComment})
            isrejectComments=true;
            this.isRejectPressed=true
          }else{
            this.toastService.addSingle(
              'error',
              'Error',
              'Please enter Reject Comments'
            );
            // alert("Please enter rejectComments");
            isrejectComments=false;
            this.isRejectPressed=true
            return;
          }
        }
      })
      if(isrejectComments){
      this.HttpService.Insert('/advance/reject-all-advance-payments',rejectList).subscribe(
        (res) => {
          // console.log(res);
          if (res.messageCode) {
            this.isRejectPressed=true
            this.toastService.addSingle(
              'error',
              'Error',
              res.errorMessage
            );
         
          } else {
            this.toastService.addSingle(
              'success',
              'Success',
              'Reject selected AP Invoice!'
            );
            this.loadPRApproval();
          }
          this.isRejectPressed=false
         // this.loading = false;
        },
        (error) => {
          console.log(error);
         // this.loading = false;
        }
      );
      }
    }else{
      this.isRejectPressed=true;
    }
    } catch (err) {
      console.log(err);
    }
  }

  onAllSelectChange(event:any){
    if(event.checked){
      this.apiApprovalList.map((data:advancePaymentInvoiceApproval)=>{
        data.selected=true;
        this.isRejectPressed=false
        //this.approvalRoutingActive=true;
      })
    }
    else{
      this.apiApprovalList.map((data:advancePaymentInvoiceApproval)=>{
        data.selected=false;
        this.isRejectPressed=false;
       // this.approvalRoutingActive=false;

      })
    }
  }

  onSelectChange(event:any,routingStatus:any){
    if(!event.checked && this.AllSelected){
    this.AllSelected=false;
    //this.approvalRoutingActive=routingStatus;
    }
    this.isRejectPressed=false
  }

  viewSupplier(id:any){
    const url = this.router.serializeUrl(
      this.router.createUrlTree(["/main/supplier/action/view/"+id])
    );
    this.isRejectPressed=false
    window.open(url)
  }

  NextApproverLov(subsidiaryId:number) {
    try {    
      this.HttpService.GetAll('/employee/get-by-role-subsidiary?roleId='+this.userRoleId+'&subsidiaryId='+subsidiaryId).subscribe(
        (res) => {
          // console.log(res);
          if (res && res.length > 0) {
            this.approverRoleList = res;          
           // this.totalRecords = res.length;
          } else {
            this.approverRoleList = [{}];
           // this.totalRecords = res.length;

          }
          this.loading = false;
        },
        (error) => {
          console.log(error);
          this.loading = false;
        }
      );
    } catch (err) {
      console.log(err);
    }
  }

  OnChangeNextApprover(PrId:number,ApproverId:any) {
    try {    
if(ApproverId != null )
{
  ApproverId=Number(ApproverId);
}
else
{
  ApproverId=0;
}
      this.HttpService.GetAll(`/advance/update-next-approver?advancePaymentId=`+PrId+ `&approverId=`+ApproverId).subscribe(
        (res) => {
          if (res == true) {
            this.toastService.addSingle(
              'success',
              'Success',
              'Next Approver Assigned!'
            );
           } else {
            this.showAlert(res.errorMessage);
          }
        },
        (error) => {
          console.log(error);
        }
      );
    } catch (err) {
      console.log(err);
    }
  }
  
  showAlert(AlertMSG:string) {
    this.toastService.addSingle(
      'error',
      'Alert',
      AlertMSG
    );
  }
}
