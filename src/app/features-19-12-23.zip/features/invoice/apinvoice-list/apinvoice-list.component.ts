import { Component, OnInit, LOCALE_ID, Inject, ViewChild } from '@angular/core';
import { InvoiceModule } from '../invoice.module';
import { CommonHttpService } from 'src/app/core/services/common-http.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RouteStateService } from 'src/app/core/services/route-state.service';
import { GlobalConstants } from 'src/app/shared/constants/global-constants';
import { DatePipe } from '@angular/common';
import { APInvoice, InvoiceDetail, commonDropdown, file_upliad,invoiceFilters, BaseSearchPdf } from '../model/APInvoice-model';
import { BaseSearch, SubsidiaryEntry, Supplier } from '../../supplier/model/supplier-model';
import { ToastService } from 'src/app/core/services/toast.service';
import { HttpHeaderResponse, HttpHeaders } from '@angular/common/http';
import { saveAs } from 'file-saver';
import { fromEvent, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import {formatDate } from '@angular/common';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-apinvoice-list',
  templateUrl: './apinvoice-list.component.html',
  styleUrls: ['./apinvoice-list.component.scss']
})
export class ApinvoiceListComponent implements OnInit {
  columns: any[];
 // APInvoiceList: any[];
  selectedAPInvoice:APInvoice = new APInvoice();
  APInvoice: APInvoice = new APInvoice();
  totalRecords: number = 0;
  loading: boolean = false;
  APInvoiceList:InvoiceDetail[]= [];
  newevent:any;
  baseSearch: BaseSearch = new BaseSearch();
  Subsidiarylist: any[] = [];
  SubsidiarylistCopy: any[] = [];
  supplierlist:Supplier[] = [];
  subsidiaryId:any;
  supplierId:any;
  subsidiaryName:any;
  supplierName:any;
  fromDate:any;
  toDate:any;
  exportColumns: any[];
  RetloginDetails: any;
  // For Role Base Access
  isEditable:boolean;
  isCreatetable:boolean;
  isViewtable:boolean;
  invoiceFilters:invoiceFilters= new invoiceFilters();
  // For Role Base Access
  file: File ;
  displayModal:boolean;
  file_upliad:file_upliad=new file_upliad();
  SubIdList: any = [];
  RetRoleDetails: any;
  statusOptions:any;
  showloader: boolean = false;
  ApprovalButtonShowHide: Number = 0;
  isParams: boolean = true;
  filteredStatus:any;
  date_to:any;
  date_from:any;
  subId:any;
  CFOSubsidiaryId:any = [];
  CFOSubsidiaryIdList:any = [];
  baseSearchPdf: BaseSearchPdf = new BaseSearchPdf();
  invoicePrint: any[] = [];
  

  constructor(private routeStateService: RouteStateService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private HttpService: CommonHttpService,
    private toastService: ToastService,
    @Inject(LOCALE_ID) public locale: string
    ) { }
  ngOnInit(): void {
    if(localStorage.getItem("LoggerDTLS") == null)
    {
      this.router.navigate(['/login']);
    }

  

  // For Role Base Access
  const retDetails:any = localStorage.getItem("RoleDTLS");
  var role_Dtls = JSON.parse(retDetails);
  this.RetRoleDetails = role_Dtls;

  const LDetails:any=localStorage.getItem("LoggerDTLS");
  this.RetloginDetails = JSON.parse(LDetails);

  for(let i=0;i<role_Dtls[0].rolePermissions.length;i++)
  {
    if(role_Dtls[0].rolePermissions[i].accessPoint == "AP invoice")
    {
      this.isCreatetable=role_Dtls[0].rolePermissions[i].create;
      this.isEditable=role_Dtls[0].rolePermissions[i].edit;
      this.isViewtable=role_Dtls[0].rolePermissions[i].view;
    }
  }
// End For Role Base Access
    this.GetSubsideryList();
    //this.GetSupplierList();
    this.columns = [
      { field: 'invoiceDate', header: 'Invoice Date' },
      { field: 'dueDate', header: 'Due Date' },
      { field: 'invoiceNo', header: 'Invoice Number' },
      { field: 'supplierName', header: 'Supplier' },
      { field: 'currency', header: 'Currency' },
      { field: 'invStatus', header: 'Status' },
      { field: 'amount', header: 'Basic Amount' },
      { field: 'taxAmount', header: 'Tax Amount' },
      { field: 'totalAmount', header: 'Total Amount' },
      { field: 'amountDue', header: 'Amount Due' },
      { field: 'requestor', header: 'Creator' },
      
      //  { field: 'invoiceId', header: 'Internal ID' },
      // { field: 'subsidiaryName', header: 'Subsidiary' },
      //  { field: 'invoiceDate', header: 'Invoice Date' },
      //  { field: 'invoiceNo', header: 'Invoice Number' },
      // { field: 'supplierName', header: 'Supplier' },
      //  { field: 'currency', header: 'Currency' },
      //  { field: 'invStatus', header: 'Status' },
      //  { field: 'totalAmount', header: 'Invoice Amount' },

     ];
    //  this.statusOptions=['Pending Approval','Approval','Approved','Open','Close','Processed','Partially Processed','Rejected']
    this.statusOptions=['Pending Approval','Approved','Draft','Close','Paid','Partially Paid','Rejected']
    this.exportColumns = this.columns.map(col => ({
      title: col.header,
      dataKey: col.field
    }));
    // For Getting Filtered Data from Dashboard
    let subsidyList: any = [];
    subsidyList.push(this.invoiceFilters.subsidiaryId);
    this.activatedRoute.params.subscribe((params) => {
      if (params) {
        if (params['status']) {
          this.isParams = true;
          this.filteredStatus = params['status']
          this.subId = params['id'];
          if(this.filteredStatus == 'Recent'){
            this.getDate();
            this.baseSearch.filters={
              subsidiaryId:subsidyList,
              recentlyCreated:this.invoiceFilters.recent = true
            }
            this.loadAPInvoice(this.newevent);
          } else if (this.filteredStatus == 'UnapprovedInvoice') {
            let subIdList = this.subId.split(",").map(Number);
            this.CFOSubsidiaryId.push(subIdList);
            if(subIdList.length > 1){
              setTimeout(() => { 
                this.baseSearch.filters = {
                  subsidiaryId: this.CFOSubsidiaryId[0],
                  unApproved:this.invoiceFilters.unApproved = true
                }
                this.loadAPInvoice(this.newevent);
              },700);
            } else {
              setTimeout(() => { 
                this.baseSearch.filters = {
                  subsidiaryId: this.CFOSubsidiaryId[0],
                  unApproved:this.invoiceFilters.unApproved = true
                }
                this.loadAPInvoice(this.newevent);
              },700);
            }
          } else {
            this.baseSearch.filters={
              subsidiaryId:subsidyList,
              status:this.invoiceFilters.status = this.filteredStatus,
            }
            this.loadAPInvoice(this.newevent);
          }
         
      } 
   }
 });
 // For Getting Filtered Data from Dashboard
  }
 // loadAPInvoice(event: any) {}
//   exportPdf() {
//     import("jspdf").then(jsPDF => {
//         import("jspdf-autotable").then(x => {
//             const doc = new jsPDF.default();
//             (doc as any).autoTable(this.exportColumns, this.APInvoiceList);
//             doc.save('invoice.pdf');
//         })
//     })
// }
navigateToAddViewEdit(
  action: string,
  selectedAPInvoice:APInvoice = new APInvoice()
) {
  let APInvoiceId = null;
    if (selectedAPInvoice?.id) {
      APInvoiceId = selectedAPInvoice.id;
      this.router.navigate(['/main/apinvoice/action', action, APInvoiceId]);
    } else {
      this.router.navigate(['/main/apinvoice/action', action]);
    }
   }

   apInvoiceEditView(actionType:any,mainId:any)
   {
    if (localStorage.getItem("ApInvoiceFilters") != null)
    {
      localStorage.removeItem("ApInvoiceFilters");
    }
    localStorage.setItem("ApInvoiceFilters", JSON.stringify(this.baseSearch));
    this.router.navigate(['/main/apinvoice/action', actionType, mainId]);
   }

loadAPInvoice(event: any) {
try {
  this.newevent=event
  this.loading = true;
  this.baseSearch.pageNumber = (this.baseSearch.pageNumber == -1) ? 0 : (event.first / event.rows);
  this.baseSearch.pageSize = event.rows;
  // this.baseSearch.sortColumn = event.sortField
  //   ? 's.' + event.sortField
  //   : GlobalConstants.SUPPLIER_TABLE_SORT_COLUMN;
  this.baseSearch.sortColumn = event.sortField
  ?  event.sortField
  : GlobalConstants.INVOICE_TABLE_SORT_COLUMN;
  this.baseSearch.sortOrder =
    event.sortOrder == -1
      ? GlobalConstants.ASCENDING
      : GlobalConstants.DESCENDING;

      if(this.SubIdList.length==0)
         {
          return;
         }
         
  this.HttpService.Insert('/finance-ws/invoice/get/all', this.baseSearch ,this.RetloginDetails.token).subscribe(
    (res) => {
      //For Auth
          if(res.status == 401)
          { this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if(res.status == 404)
          { this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
        else
        {
          this.APInvoiceList=[]
          if (res && res.list && res.list.length > 0) {
            this.APInvoiceList = res.list;
            //this.APInvoiceList=res.list.Select((o:any)=>o.invoiceId).Distinct()
            for(let x=0;x<this.APInvoiceList.length;x++)
            {
              this.APInvoiceList[x].totalAmount=this.APInvoiceList[x].totalAmount.toFixed(2);
              this.APInvoiceList[x].amountDue=this.APInvoiceList[x].amountDue.toFixed(2);
              if ( this.APInvoiceList[x].invStatus == 'Pending Approval' || this.APInvoiceList[x].invStatus == 'Processed' || this.APInvoiceList[x].invStatus == 'Partially Processed' || this.APInvoiceList[x].invStatus == 'Partially Approved' || this.APInvoiceList[x].invStatus == 'Approved' || this.APInvoiceList[x].invStatus == 'Closed' || this.APInvoiceList[x].invStatus == 'Partially Paid' || this.APInvoiceList[x].invStatus == 'Paid') //Send Approval Mode
            {
              this.APInvoiceList[x].isApprovalButtonShowHide = 0;
            }
            else {
              this.APInvoiceList[x].isApprovalButtonShowHide = 1;
            }
            }
            this.totalRecords = res.totalRecords;
          } else {
            this.APInvoiceList = [];
            this.totalRecords =0;
          }
          this.loading = false;
        }
    },
    (error) => {
      this.loading = false;
    }
  );
} catch (err) {
 }
}
/* Start fetch filter list of Subsidiary from api */
findby(event: any){
  let subsidyList: any = [];
  let Fromdays: any;  
  let Frommonths: any;
  let Fromyear: any; 
  let Todays: any; 
  let Tomonths: any;
  let Toyear: any; 
  // this.SubsidiarylistCopy.map((x)=>{
  //   subsidyList.push(x.id)
  // })
  subsidyList.push(this.invoiceFilters.subsidiaryId);
 if (this.invoiceFilters.fromDate != undefined)
 { 
  Fromdays = new Date(this.invoiceFilters.fromDate).getUTCDate();
  Frommonths = new Date(this.invoiceFilters.fromDate).getUTCMonth() + 1;
  Fromyear = new Date(this.invoiceFilters.fromDate).getUTCFullYear();
  }
  if (this.invoiceFilters.toDate != undefined )
  { 
  Todays = new Date(this.invoiceFilters.toDate).getUTCDate();
  Tomonths = new Date(this.invoiceFilters.toDate).getUTCMonth() + 1;
  Toyear = new Date(this.invoiceFilters.toDate).getUTCFullYear();
  }
  this.baseSearch.filters={
    subsidiaryId:subsidyList,
    supplierId:this.invoiceFilters.supplierId,
    status:this.invoiceFilters.status,
    invoiceNumber:this.invoiceFilters.proformaInvoice,
    currency:this.invoiceFilters.currency,
    fromDate:this.invoiceFilters.fromDate != undefined ? (Fromyear + '-' + (Frommonths.toString().length == 1 ? "0" + Frommonths : Frommonths) + '-' + (Fromdays.toString().length == 1 ? "0" + Fromdays : Fromdays)) : undefined,
    toDate:this.invoiceFilters.toDate != undefined ? (Toyear + '-' + (Tomonths.toString().length == 1 ? "0" + Tomonths : Tomonths) + '-' + (Todays.toString().length == 1 ? "0" + Todays : Todays)) : undefined,
    unApproved:this.invoiceFilters.unApproved,
    recentlyCreated:this.invoiceFilters.recent
 }
   this.loadAPInvoice(this.newevent);
 }
 Reset()
{
  //this.invoiceFilters.subsidiaryId=undefined;
  this.invoiceFilters.supplierId=undefined;
  this.invoiceFilters.fromDate=undefined;
  this.invoiceFilters.toDate=undefined;
  this.invoiceFilters.currency=undefined;
  this.invoiceFilters.status=undefined;
  this.invoiceFilters.proformaInvoice=undefined;
  this.resetBaseSearch();
  this.baseSearch.pageNumber=-1;
  this.loadAPInvoice(this.newevent);
}
 /* End filter list of Subsidiary from api */
 resetBaseSearch() {
  this.baseSearch.filters = {subsidiaryId: this.SubIdList,supplierId:
  this.RetRoleDetails[0].selectedAccess=='VENDOR' ?this.RetloginDetails.supplierId : undefined};
  this.baseSearch.pageNumber = 0;
  this.baseSearch.pageSize = GlobalConstants.TABLE_PAGE_SIZE;
  this.baseSearch.sortColumn = GlobalConstants.INVOICE_TABLE_SORT_COLUMN;
  this.baseSearch.sortOrder = GlobalConstants.ASCENDING;
  this.loadAPInvoice(this.newevent);
}
/* End filter list of Subsidiary from api */

GetSubsideryList() {
  //if (this.RetRoleDetails[0].accountId !== null && this.RetRoleDetails[0].subsidiaryId == null) {
    if(this.RetloginDetails.userType=='SUPERADMIN' ){
     this.HttpService.GetAll('/setup-ws/subsidiary/get/all/lov?accountId=' + this.RetRoleDetails[0].accountId, this.RetloginDetails.token).subscribe(

      //this.HttpService.GetAll('/setup-ws/subsidiary/get/all',this.RetloginDetails.token).subscribe(
      (res) => {
        if (res.status == 401) {
          this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if (res.status == 404) {
          this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
        else {
          this.Subsidiarylist = res;
          for (let x = 0; x < this.Subsidiarylist.length; x++) {
            this.SubIdList.push(this.Subsidiarylist[x].id);
          }
        }
      },
      (error) => {
        this.showAlert(error);
      },
      () => {
       // this.checkedSubdidiary();
       if(localStorage.getItem("ApInvoiceFilters") != null)
       {const LocDetails:any =localStorage.getItem("ApInvoiceFilters");
       let RetLocDetails = JSON.parse(LocDetails);
       this.baseSearch=RetLocDetails;
       let searcheData:any = this.baseSearch;
       this.invoiceFilters.subsidiaryId=searcheData.filters.subsidiaryId[0];
       this.invoiceFilters.supplierId=searcheData.filters.supplierId;
       this.invoiceFilters.proformaInvoice=searcheData.filters.invoiceNumber;
       this.invoiceFilters.currency=searcheData.filters.currency;
       this.invoiceFilters.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
       this.invoiceFilters.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
       this.invoiceFilters.status=searcheData.filters.status;
       this.GetSupplierList(searcheData.filters.subsidiaryId[0]);
       this.loadAPInvoice(this.newevent);
       localStorage.removeItem("ApInvoiceFilters");
       }
       else
       { this.resetBaseSearch();}
       
      }
    );
  }
  else if(this.RetloginDetails.userType=='ENDUSER' || this.RetloginDetails.userType===null  ){
    this.Subsidiarylist.push({
      "id": this.RetRoleDetails[0].subsidiaryId,
      "name": this.RetRoleDetails[0].subsidiaryName
    });
    this.SubIdList.push(this.RetRoleDetails[0].subsidiaryId);
    this.invoiceFilters.subsidiaryId = this.RetRoleDetails[0].subsidiaryId;
    this.GetSupplierList(this.RetRoleDetails[0].subsidiaryId);
    if(localStorage.getItem("ApInvoiceFilters") != null)
       {const LocDetails:any =localStorage.getItem("ApInvoiceFilters");
       let RetLocDetails = JSON.parse(LocDetails);
       this.baseSearch=RetLocDetails;
       let searcheData:any = this.baseSearch;
       this.invoiceFilters.subsidiaryId=searcheData.filters.subsidiaryId[0];
       this.invoiceFilters.supplierId=searcheData.filters.supplierId;
       this.invoiceFilters.proformaInvoice=searcheData.filters.invoiceNumber;
       this.invoiceFilters.currency=searcheData.filters.currency;
       this.invoiceFilters.fromDate=searcheData.filters.fromDate != undefined ? new Date(searcheData.filters.fromDate ):undefined;
       this.invoiceFilters.toDate=searcheData.filters.toDate != undefined ? new Date(searcheData.filters.toDate ):undefined;
       this.invoiceFilters.status=searcheData.filters.status;
       
       this.loadAPInvoice(this.newevent);
       localStorage.removeItem("ApInvoiceFilters");
       }
       else
    {this.resetBaseSearch();}
  }
}

checkedSubdidiary()
{
  if (
    this.Subsidiarylist &&this.Subsidiarylist.length > 0 ) {
  {
      let copiedValue = JSON.parse(
        JSON.stringify(this.Subsidiarylist)
      );
      //this.role.restrictedDepartments = [];
      this.SubsidiarylistCopy = [];
      copiedValue.forEach((element: any) => {
        let item = this.Subsidiarylist.find(
          (o) => o.id == element.id
        );
        if (item) {
          // let role1 = new commonDropdown()
          // role1.id = item.id;
          // role1.name = item.name;
          this.SubsidiarylistCopy?.push({
            id : item.id,
            name : item.name
          });
        }
      });
    }
  }

}
/* start get Get Supplier list */
GetSupplierList(subId:any) {
  this.HttpService
  .GetById('/masters-ws/supplier/get-by-subsidiary-id?subsidiaryId=' + subId,subId,this.RetloginDetails.token)
  .subscribe((res) => {

    //For Auth
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
    else
    {this.supplierlist = res;
      this.AssignCurrencyForSubsidiary(this.invoiceFilters.subsidiaryId);
    }

    
  });
  // this.HttpService
  //   .GetAll('/supplier/get-suppliers')
  //   .subscribe((res) => {
  //     this.supplierlist = res;
     
  //   });
}
AssignCurrencyForSubsidiary(subsidiaryId: any) {
  this.HttpService.GetById('/setup-ws/subsidiary/get' + '?id=' + subsidiaryId, subsidiaryId,this.RetloginDetails.token).subscribe( 
    (res) => {
      if(res.status == 401)
    { 
      this.showAlert("Unauthorized Access !");
      this.router.navigate(['/login']);
    }
    else if(res.status == 404)
    { 
      this.showAlert("Wrong/Invalid Token!");
      this.router.navigate(['/login']);
    }
    else
    {

      this.invoiceFilters.currency = res.currency;
    }
       },
       (error) => {
        this.showAlert(error);
       }
     );
}
/* end get Get Supplier list */
// CSV UPLOAD
csvUploadDownload(){
  this.displayModal = true;
}
@ViewChild('attachments') attachment: any;
fileList: File[] = [];
listOfFiles: any[] = [];
isLoading = false;
onFileChanged(event: any) {
  this.isLoading = true;
  this.file = event.target.files[0];
  this.listOfFiles=[]
  this.listOfFiles.push(this.file .name);
  //this.fileList = event.target.files[0];
  // for (var i = 0; i <= event.target.files.length - 1; i++) {
  //   var selectedFile = event.target.files[i];
  //   if (this.listOfFiles.indexOf(selectedFile.name) === -1) {
  //     this.fileList.push(selectedFile);
  //     this.listOfFiles.push(selectedFile.name);
  //   }
  // }
  this.isLoading = false;
  //this.attachment.nativeElement.value = '';
}
uploadFile(event:any){
  const httpOptions = {
    headers: new HttpHeaders({
     //"Content-Type": "multipart/form-data" 
     "mimeType": "multipart/form-data",
     "Content-Type": "false"
    })
  };
  //this.file = event.target.files[0];
  //let fileElement:any;
  //fileElement =document.getElementById('file_');
  //this.file = fileElement.files[0]
  const formData = new FormData();
  // formData.set('file', this.file);
   formData.append('file', this.file);
  this.HttpService.uploadFile_("/finance-ws/invoice/upload?subsidiaryId=" +this.RetRoleDetails[0].subsidiaryId + '&requestor='+this.RetloginDetails.username ,formData ,{responseType: 'blob'} ,this.RetloginDetails.token)
  .subscribe(res => {

    //For Auth
        if(res.status == 401)
        { this.showAlert("Unauthorized Access !");
          this.router.navigate(['/login']);
        }
        else if(res.status == 404)
        { this.showAlert("Wrong/Invalid Token!");
          this.router.navigate(['/login']);
        }
      else
      {
        saveAs(res,'invoice_result.xlsx');
        if (res.error){
            this.toastService.addSingle(
            'error',
            'Error',
            res.error.errorMessage
          );
          }
          else{
            
            this.toastService.addSingle(
              'success',
              'Success',
              'File uploaded Successfully!'
            );
            window.location.reload();
          }
      }
    


  },
    error => {
     },
    () => {

      // 'onCompleted' callback.
      // No errors, route to new page here
    });
}
onFileChanged1(event:any) {
this.file = event.target.files[0];
  this.HttpService.uploadFile("/finance-ws/invoice/upload", this.file ,this.RetloginDetails.token)
  .subscribe(res => {

    //For Auth
      if(res.status == 401)
      { this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if(res.status == 404)
      { this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
    else
    {
      if (res.error){
        this.toastService.addSingle(
          'error',
          'Error',
          res.error.errorMessage
        );
        }
        else{
          this.toastService.addSingle(
            'success',
            'Success',
            'File uploaded Successfully!'
          );
          window.location.reload();
        }
    }

    
  },
    error => {
    },
    () => {

      // 'onCompleted' callback.
      // No errors, route to new page here
    });
}
removeSelectedFile(index: number) {
  // Delete the item from fileNames list
  this.listOfFiles.splice(index, 1);
  // delete file from FileList
  this.fileList.splice(index, 1);
}
executeSaveAs(content:any){
  let blob = new Blob([content], {'type': "application/octet-stream"});
 saveAs(blob, "invoice.xlsx"); // This is from https://github.com/eligrey/FileSaver.js
};
DownloadTemplete() {
  //window.open(this.HttpService.baseUrl+"/finance-ws/invoice/download-template")
  this.HttpService.downloadFile("/finance-ws/invoice/download-template",this.RetloginDetails.token)
  .subscribe(res => {
    let blob = new Blob([res], {'type': "application/octet-stream"});
    saveAs(res, 'Invoice.xlsx');
  });
 
}
showAlert(AlertMSG:string) {
  this.toastService.addSingle(
    'error',
    'Alert',
    AlertMSG
  );
}
sendForApproval(invoiceId:any) {
  this.showloader = true;
  this.HttpService
    .GetById('/finance-ws/invoice/send-for-approval?id=' +invoiceId, invoiceId, this.RetloginDetails.token)
    .subscribe((res) => {
      //For Auth
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        // this.pr = res;
        if (res == true) {
          this.toastService.addSingle(
            'success',
            'Success',
            'Invoice Sent for Approval Successfully!'
          );
          this.showloader = false;
          window.location.reload();
        } else {
          this.showAlert(res.errorMessage);
          this.showloader = false;
        }
      }

    },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured while sending for Approval!'
        );
        this.showloader = false;
      });
}

selfApproval(invoiceId:any) {
  this.showloader = true;
  this.HttpService
    .GetById('/finance-ws/invoice/self-approve?invoiceId=' + invoiceId, invoiceId, this.RetloginDetails.token)
    .subscribe((res) => {

      //For Auth
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else {
        // this.pr = res;
        if (res == true) {
          this.toastService.addSingle(
            'success',
            'Success',
            'Invoice Approved Successfully!'
          );
          this.showloader = false;
          window.location.reload();
        } else {
          this.showAlert(res.errorMessage);
          this.showloader = false;
        }
      }

    },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured while sending for Approval!'
        );
        this.showloader = false;
      }
    );
}

recallStatus(invoiceId:any)
{
  this.showloader = true;
  this.HttpService
    .GetAllResponseText('/finance-ws/invoice/change-to-draft?id=' +invoiceId, this.RetloginDetails.token)
    .subscribe((res) => {
      //For Auth
      if (res.status == 401) {
        this.showAlert("Unauthorized Access !");
        this.router.navigate(['/login']);
      }
      else if (res.status == 404) {
        this.showAlert("Wrong/Invalid Token!");
        this.router.navigate(['/login']);
      }
      else if (res.status == 200) {
          this.toastService.addSingle(
            'success',
            'Success',
            res.error.text
          );
          this.showloader = false;
          window.location.reload();
      }
      else
      {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      }
    },
      (error) => {
        this.toastService.addSingle(
          'error',
          'Error',
          'Error occured !'
        );
        this.showloader = false;
      });
}

getDate() {
  const currentDate = new Date();
  const year = currentDate.getFullYear();
  const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
  const day =( currentDate.getDate()-1).toString().padStart(2, '0');
  this.date_to = `${year}-${month}-${day}`;

  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(currentDate.getDate() - 7);
  const fromYear = sevenDaysAgo.getFullYear();
  const fromMonth = (sevenDaysAgo.getMonth() + 1).toString().padStart(2, '0');
  const fromDay = sevenDaysAgo.getDate().toString().padStart(2, '0');
  this.date_from = `${fromYear}-${fromMonth}-${fromDay}`;
}



    /***((Export Excel)) */
    generatePDFData(exportType:any){
      this.newevent = event;
      this.baseSearchPdf.pageSize = this.totalRecords;
      this.baseSearchPdf.sortColumn =GlobalConstants.INVOICE_TABLE_SORT_COLUMN;
      this.baseSearchPdf.filters = {subsidiaryId: this.SubIdList};
  
      this.HttpService.Insert('/finance-ws/invoice/get/all', this.baseSearchPdf, this.RetloginDetails.token).subscribe(
        (res) => {
          //For Auth
          if (res.status == 401) {
            this.showAlert("Unauthorized Access !");
            this.router.navigate(['/login']);
          }
          else if (res.status == 404) {
            this.showAlert("Wrong/Invalid Token!");
            this.router.navigate(['/login']);
          }
          else {
            //this.employeelistPrint = [];
            this.invoicePrint = [];
            if (res && res.list.length > 0) {
              var RetData = res.list;
              for (let i = 0; i < RetData.length; i++) {

                if (RetData[i].id == undefined) {
                  RetData[i].id = "";
                }
                if(exportType == 'PDF'){ 
                  this.invoicePrint.push({
                    'Invoice Date': RetData[i].invoiceDate!=null?formatDate(RetData[i].invoiceDate, 'dd-MM-yyyy' ,this.locale):"",  
                    'Due Date':RetData[i].dueDate!=null?formatDate(RetData[i].dueDate, 'dd-MM-yyyy' ,this.locale):"",
                    'Invoice Number':  RetData[i].invoiceNo,
                    'Currency': RetData[i].currency,
                    'Status':RetData[i].invStatus,
                    'Basic Amount':RetData[i].amount,
                    'Tax Amount':RetData[i].taxAmount,
                    'Total Amount':RetData[i].totalAmount,
                    'Amount Due':RetData[i].amountDue,
                    'Creator':RetData[i].requestor,
                    
                });
              }
                else{
                  this.invoicePrint.push({
                    'Invoice Date': RetData[i].invoiceDate!=null?formatDate(RetData[i].invoiceDate, 'dd-MM-yyyy' ,this.locale):"",  
                    'Due Date':RetData[i].dueDate!=null?formatDate(RetData[i].dueDate, 'dd-MM-yyyy' ,this.locale):"",
                    'Invoice Number':  RetData[i].invoiceNo,
                    'Currency': RetData[i].currency,
                    'Status':RetData[i].invStatus,
                    'Basic Amount':RetData[i].amount,
                    'Tax Amount':RetData[i].taxAmount,
                    'Total Amount':RetData[i].totalAmount,
                    'Amount Due':RetData[i].amountDue,
                    'Creator':RetData[i].requestor,
                  });
                }
  
              }
            }
            if(exportType == 'PDF')
            {this.exportPdf();}
          }
        }
      );
    }
    // exportPdf() {
    //   import("jspdf").then(jsPDF => {
    //     import("jspdf-autotable").then(x => {
    //       const doc = new jsPDF.default();
    //       //this.= this.employeeExport;
    //       //this.employeelist=[];
    //       (doc as any).autoTable(this.exportColumns, this.invoicePrint);
    //       doc.save('Invoice.pdf');
    //     })
    //   })
    // }

     // loadAPInvoice(event: any) {}
  exportPdf() {
    import("jspdf").then(jsPDF => {
        import("jspdf-autotable").then(x => {
            //const doc = new jsPDF.default();
            const doc = new jsPDF.default("landscape");
            (doc as any).autoTable(this.exportColumns, this.APInvoiceList);
            doc.save('invoice.pdf');
        })
    })
}
  
  //End PDF
  
  //Start Excel
  exportExcel() {
    this.showloader=true
    this.generatePDFData('');
  
   setTimeout(() => {
    this.exportExcelData()
   }, 250);
    }
    exportExcelData()
    {
      if(this.invoicePrint.length >0)
      { import('xlsx').then((xlsx) => {
           const worksheet = xlsx.utils.json_to_sheet(this.invoicePrint);
           const workbook = { 
               Sheets: { data: worksheet }, 
               SheetNames: ['data'] 
           };
           const excelBuffer: any = xlsx.write(workbook, {
               bookType: 'csv',
               type: 'array',
           });
           this.saveAsExcelFile(excelBuffer, 'Invoice');
           this.showloader=false;
       });}
    }
  
    saveAsExcelFile(buffer: any, fileName: string): void {
        let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
        let EXCEL_EXTENSION = '.csv';
        const data: Blob = new Blob([buffer], {
            type: EXCEL_TYPE,
        });
        FileSaver.saveAs(
            data, fileName + EXCEL_EXTENSION
            //fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION
        );
    }
  //End Excel 
    //List Export option End
  
     /********Export excel */

     onRowSelect(event: any) {
      let apiId = event.data.invoiceId;
      
      this.router.navigate(['/main/apinvoice/action/view', apiId]);
    }


}
